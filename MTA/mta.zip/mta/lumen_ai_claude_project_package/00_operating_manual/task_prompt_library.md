Use the standalone files in `00_operating_manual/prompts/` as copy-paste task prompts. Each prompt file contains only the text to paste into a Claude chat.

Core prompts:

- `00_context_updater_interviewer.md`
- `01_research_method_review.md`
- `02_manager_team_communication.md`

Optional prompts:

- `optional_deep_literature_review.md`
- `optional_post_meeting_update.md`
