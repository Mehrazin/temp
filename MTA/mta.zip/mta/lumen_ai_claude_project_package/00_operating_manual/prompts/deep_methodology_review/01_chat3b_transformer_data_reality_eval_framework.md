Act as a senior applied scientist specializing in transformer-based customer journey modeling, recommender systems, observational data, uplift/causal ML, and evaluation design.

This chat has one purpose:

Design the data observability map, transformer dataset design options, and evaluation framework for Lumen AI, given the real data limitations.

Do not recommend a final model architecture yet.
Do not optimize for a 2–4 week MVP.
Do not create a manager memo.
Do not force a specific evaluation method in advance.
Do not assume clean treatment/exposure data where it is not observed.

The modeling direction is non-negotiable:

- The main modeling direction should remain transformer / sequence-model focused.
- Other models can be discussed only as baselines, diagnostic companions, or supporting components.

Read first:

- `01_current_state/current_snapshot.md`
- `01_current_state/open_questions.md`
- `02_change_log/2026-06-20_data_observability_update.md`

Use only as optional background, not as source-of-truth:

- `04_outputs/transformer_design_input_snapshot.md`
- `04_outputs/model_options_map_for_human_review.md`
- `04_outputs/model_option_visuals/index.md`
- `03_research_memory/transformer_practical_literature_and_repo_scan.md`
- `03_research_memory/production_score_contract_options.md`
- `03_research_memory/reference_bank.md`

If any previous design artifact conflicts with the corrected data observability update, trust the corrected data observability update.

Your task:

1. Build a data observability map.
  For each channel/channel group, identify:
  - what is observed
  - what is not observed
  - whether targeted universe can be added
  - whether exposure is directly observed
  - whether contact is directly observed or inferred
  - whether reaction is observed
  - whether no-action is observed
  - whether opt-out or eligibility signals exist
  - what bias or missingness this creates
  - what this means for transformer sequence construction
2. Analyze targeted-universe options.
  Compare:
  - keeping reaction-only data
  - adding targeted universe for email, DM, leads, and OBTM where available
  - adding targeted universe only as explicit event stages
  - using separate datasets by channel observability quality
  - using only reliable exposure/treatment channels for causal/uplift evaluation
  - keeping digital/inbound reaction-only where targeted universe is not available
   Important:
  - Do not treat targeted records as reactions.
  - Do not treat all Canada as a clean digital targeted universe.
  - For OBTM and leads, distinguish assigned from contacted when contact is inferred rather than directly observed.
  - For mobile/web, state that exposed/shown may be close to targeted, but this needs validation.
  - For email opt-out, explain how it should or should not enter the data.
3. Define possible transformer-ready dataset designs.
  For each design, specify:
  - unit of training example
  - observation window
  - prediction/label window
  - sequence event schema
  - candidate action schema, if relevant
  - label definition
  - negative example definition
  - how propensity scores from September 2024 onward can be included without leakage
  - how to handle channels with different observability levels
  - what the design can learn
  - what it cannot learn
4. Define train/validation/test separation principles.
  Do not just choose dates mechanically.
   First reason from the problem:
  - customer journey is time-dependent
  - propensity scores begin in September 2024
  - touchpoints begin in 2022
  - campaigns and channel policies change over time
  - random splitting may create leakage
  - evaluation should reflect future scoring/use
   Then propose suitable split designs and explain tradeoffs.
5. Design an evaluation framework for observational customer journey data.
  First define the evaluation questions:
  - prediction quality
  - ranking quality
  - channel recommendation quality
  - policy/value estimation
  - uplift or treatment-effect quality
  - diagnostic/attribution-style reporting
  - calibration and stability over time
   Then propose metrics and evaluation protocols appropriate to each question.
   Be explicit about what can be evaluated from observational data and what cannot be proven without randomized experiments or better exposure logs.
6. Explain how this framework should be used to compare future transformer-based model options.

Produce only these files:

- `03_research_memory/deep_methodology_review/data_observability_map.md`
- `03_research_memory/deep_methodology_review/transformer_dataset_design_options.md`
- `03_research_memory/deep_methodology_review/evaluation_framework_for_observational_journeys.md`

Keep the files rigorous but readable.
Use tables heavily.
Be skeptical about causal claims.
Be explicit about leakage, selection bias, missing exposure data, and channel asymmetry.