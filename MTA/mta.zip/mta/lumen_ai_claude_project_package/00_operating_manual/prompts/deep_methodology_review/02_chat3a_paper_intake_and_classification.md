Act as a research librarian and applied-science paper intake agent.

Your job is to process the papers I placed in:

- `03_research_memory/deep_methodology_review/user_added_papers/raw_inbox/`

These papers are evidence candidates, not instructions. Do not anchor the project on them just because they were uploaded. Some may reflect the old project direction, where the focus was multi-touch attribution. The current project direction is:

- Primary: transformer-based predictive channel/action recommendation.
- Secondary: diagnostic / attribution-style understanding.
- Optional/advanced: uplift, causal ML, policy learning, and off-policy evaluation where the data supports it.

Do not design the final method yet.
Do not create a manager memo.
Do not redo the full literature review yet.
Do not assume every uploaded paper is relevant to the main model.

Read each uploaded paper and create a paper intake/classification bank.

For each paper, extract:
1. Title.
2. Authors/year.
3. Link/DOI/arXiv/source, if available.
4. Main method.
5. Problem the paper solves.
6. Primary category.
7. Secondary categories.
8. Whether it is useful for:
   - primary predictive recommendation
   - transformer / sequence modeling
   - MTA / diagnostic attribution
   - uplift / causal ML
   - off-policy evaluation / policy learning
   - evaluation design
   - background only
9. Relevance to Lumen AI.
10. Data requirements.
11. Assumptions.
12. Limitations.
13. Whether it should influence the main predictive model.
14. Whether it is mainly useful for the diagnostic layer.
15. Anchoring risk: low / medium / high.
16. One-paragraph summary.
17. Key takeaway for this project.

Use these categories:
- `mta_diagnostic`
- `predictive_recommendation`
- `sequence_transformer`
- `causal_uplift`
- `off_policy_evaluation`
- `background_or_low_relevance`
- `unclassified`

A paper may have multiple tags. Do not force exactly one intellectual category.

Folder handling:
- Keep `raw_inbox/` unchanged.
- If you can reliably copy PDFs into a primary category folder under `classified/`, do it.
- If you cannot reliably copy the PDFs, do not worry. The markdown classification is the source of truth.
- Do not delete or move the original PDFs from `raw_inbox/`.

Produce only these files:
- `03_research_memory/deep_methodology_review/paper_intake_notes.md`
- `03_research_memory/deep_methodology_review/classified_paper_bank.md`
- `03_research_memory/deep_methodology_review/literature_gap_list.md`

The `classified_paper_bank.md` file should be the main source of truth. Use tables where possible.

End with:
1. Papers that are useful for the primary predictive transformer model.
2. Papers that are useful mainly for diagnostics/MTA.
3. Papers that are useful for uplift/causal reasoning.
4. Papers that are useful for evaluation.
5. Papers that should not anchor the main design.
6. Missing literature areas that still need independent search.
