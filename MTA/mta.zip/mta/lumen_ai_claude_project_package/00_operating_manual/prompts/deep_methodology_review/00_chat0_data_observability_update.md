Chat 0 — Data Observability Update

Update the project memory with the following data reality. Do not design a model yet. Do not recommend an MVP. Your job is to preserve this as source-of-truth project context and identify open questions.

Project data reality update:

Touchpoint history:

- Customer touchpoints are available from 2022 up to the current project date, June 2026.
- Propensity model scores are available from September 2024 up to June 2026.
- The modeling direction remains transformer / sequence-model focused. Other model families can be baselines or supporting components, but the main methodology should stay sequence/transformer-oriented.

Inbound channels:

- Inbound channels are branch, phone, mobile, and web.
- Adding a true targeted universe for inbound channels is not currently possible.
- For branch and phone:
  - We observe customer reaction touchpoints only.
  - Reactions include examples like interested, not interested, follow up later.
  - We do not observe all customers who were eligible, all offers loaded, or all offers that could have been presented.
  - A customer may visit a branch or call the bank, but the employee may not open/present the offer workflow, so no observed touchpoint is created.
- For mobile and web:
  - We observe offers shown/loaded in the app or web experience.
  - We also observe no action events.
  - The targeted universe is probably very close to the exposed/shown universe, but this should still be validated.
  - Adding a separate targeted universe is not currently possible.

Outbound channels:

- Email:
  - Current touchpoint data includes only customers who opened an email or clicked a link.
  - The full sent/targeted email universe can likely be added.
  - There is also an email opt-out signal from another source.
  - The exact opt-out date may not be available; month of opt-out may be available.
- Direct mail / DM:
  - Current touchpoint data includes only customers who used the URL or QR code to apply through EasyApply.
  - The full list of DMs sent by the bank can likely be added.
- Leads:
  - Current data includes customers contacted by phone.
  - The full assigned leads list can likely be added.
  - Usually around 95–97% of assigned leads get contacted.
- OBTM:
  - The full targeted/list universe can be added.
  - Reaction is not currently available.
  - Actual contact is not directly observed, but most assigned records are probably contacted.
- Digital:
  - Paid search: click only.
  - SEO: click only.
  - Display: view and click.
  - For digital channels, only reactions/exposures like clicks/views are currently available.
  - A true targeted universe is not cleanly available; We potentially can treat all canada as targeted.

Important data principle:

- The project must distinguish targeted, assigned, sent, shown, contacted, opened, clicked, viewed, interested, not interested, follow-up-later, no-action, applied, and converted.
- Do not mix targeted-universe records and reaction records as if they are the same kind of touchpoint.
- If targeted universe is added for only some channels, the data becomes asymmetric across channels. This may still be useful, but the asymmetry must be explicit in dataset design and evaluation.

Please update:

- `01_current_state/current_snapshot.md`
- `01_current_state/open_questions.md`
- `01_current_state/context_index.md`

Also create a dated change log:

- `02_change_log/2026-06-20_data_observability_update.md`

The change log should summarize:

1. Current touchpoint coverage by channel.
2. Which channels can add targeted universe.
3. Which channels are reaction-only.
4. Which channels have exposure-like events.
5. Which channels have inferred contact.
6. Which signals are missing.
7. Why this matters for transformer dataset design and observational evaluation.

