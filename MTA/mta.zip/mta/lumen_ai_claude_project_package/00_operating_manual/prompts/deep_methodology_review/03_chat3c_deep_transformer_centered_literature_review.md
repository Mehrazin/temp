Act as a senior research scientist specializing in transformer sequence modeling, customer journey modeling, recommender systems, uplift modeling, causal ML, treatment-effect estimation, off-policy evaluation, and marketing measurement.

This is a deep literature review, not an MVP planning task.

The modeling direction is non-negotiable:
- The main model direction must remain transformer / sequence-model focused.
- Other methods can be used as baselines, diagnostic companions, causal/uplift heads, evaluation tools, or policy-learning extensions.

Do not optimize for implementation timeline.
Do not create a manager memo.
Do not simply summarize uploaded papers.
Do not anchor on the team's MTA papers.
Do not assume multi-touch attribution is the primary project goal.

Read first:
- `03_research_memory/deep_methodology_review/data_observability_map.md`
- `03_research_memory/deep_methodology_review/transformer_dataset_design_options.md`
- `03_research_memory/deep_methodology_review/evaluation_framework_for_observational_journeys.md`
- `03_research_memory/deep_methodology_review/classified_paper_bank.md`
- `03_research_memory/deep_methodology_review/literature_gap_list.md`

Also use:
- `01_current_state/current_snapshot.md`
- `04_outputs/model_options_map_for_human_review.md`
- `04_outputs/model_option_visuals/index.md`
- `03_research_memory/reference_bank.md`, if useful
- `03_research_memory/transformer_practical_literature_and_repo_scan.md`, if useful

Use Scholar Gateway, alphaXiv, PDF Viewer, GitHub Integration, and web search where helpful.

Your task:

1. Conduct an independent literature review for transformer-centered predictive channel/action recommendation under observational customer journey data.
2. Identify methods from the broader literature that are not present in the uploaded paper set.
3. Explain how uplift, causal ML, treatment-effect modeling, and off-policy evaluation can fit around a transformer-centered approach.
4. Explain where MTA literature is useful and where it is not sufficient.
5. Separate predictive modeling, causal/uplift modeling, policy evaluation, and diagnostic attribution.
6. Ground the review in the corrected data reality.

Cover methodology families if supported by the literature:
- transformer encoders for event/customer journey representation
- action-conditioned transformer scoring
- sequential recommendation / next-action transformers
- multi-task transformer models
- transformer representation plus downstream scorer/ranker
- transformer representation plus uplift/CATE layer
- causal/uplift sequence models
- contextual bandits / policy learning / off-policy evaluation
- survival or time-to-event sequence modeling
- diagnostic MTA / attribution-style reporting
- hybrid predictive + diagnostic systems

For each family, explain:
1. What the method is.
2. What problem it solves.
3. What data it needs.
4. How it uses sequence/time information.
5. What labels or targets it uses.
6. What it can learn from Lumen AI's current data.
7. What it cannot learn from Lumen AI's current data.
8. Accuracy potential.
9. Causal/uplift validity.
10. Diagnostic usefulness.
11. Evaluation requirements.
12. Key references or repos.
13. Practical risks.

Produce only these files:
- `03_research_memory/deep_methodology_review/deep_transformer_centered_literature_review.md`
- `03_research_memory/deep_methodology_review/method_family_evidence_map.md`
- `03_research_memory/deep_methodology_review/updated_reference_bank_transformer_causal_reco.md`

Be rigorous and skeptical.
Prefer primary sources and strong technical references.
Flag weak evidence clearly.
Do not turn this into an implementation roadmap.
