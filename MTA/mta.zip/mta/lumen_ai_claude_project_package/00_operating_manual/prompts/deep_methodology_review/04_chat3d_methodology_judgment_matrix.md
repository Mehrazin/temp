Act as a senior research scientist and applied ML method reviewer.

Your task is to synthesize the corrected data framework, classified paper bank, and deep literature review into a methodology judgment matrix for Lumen AI.

Do not create a manager memo.
Do not optimize for the 2–4 week MVP.
Do not design implementation steps yet.
Do not make MTA the primary modeling direction.
Do not ignore MTA either; treat it as diagnostic/attribution literature unless there is a justified predictive use.

The modeling direction is non-negotiable:
- The primary modeling direction must remain transformer / sequence-model focused.
- Other methods can be included as baselines, diagnostic layers, uplift/causal extensions, policy evaluation methods, or downstream scorers.

Read:
- `03_research_memory/deep_methodology_review/data_observability_map.md`
- `03_research_memory/deep_methodology_review/transformer_dataset_design_options.md`
- `03_research_memory/deep_methodology_review/evaluation_framework_for_observational_journeys.md`
- `03_research_memory/deep_methodology_review/classified_paper_bank.md`
- `03_research_memory/deep_methodology_review/deep_transformer_centered_literature_review.md`
- `03_research_memory/deep_methodology_review/method_family_evidence_map.md`
- `03_research_memory/deep_methodology_review/updated_reference_bank_transformer_causal_reco.md`
- `04_outputs/model_options_map_for_human_review.md`
- `04_outputs/model_option_visuals/index.md`

Produce:
- `03_research_memory/deep_methodology_review/methodology_options_matrix.md`
- `03_research_memory/deep_methodology_review/final_methodology_judgment.md`

The methodology matrix should compare the serious transformer-centered options. For each option, include:
1. Plain-English description.
2. Required data design.
3. Required labels.
4. How it uses sequence/time information.
5. What it predicts or estimates.
6. Whether it supports candidate-channel/action scoring.
7. Whether it supports top-K or multiple-channel recommendation.
8. Accuracy potential.
9. Causal/uplift validity.
10. Diagnostic usefulness.
11. Whether diagnostics come from the same model or a separate layer.
12. Data requirements.
13. Evaluation requirements.
14. Main assumptions.
15. Main risks.
16. What evidence supports it.
17. What evidence is weak or missing.
18. Fit to Lumen AI.
19. Key references.

The final judgment file should answer:
1. Strongest transformer-centered direction for predictive recommendation.
2. Strongest transformer-centered direction if causal/uplift validity matters.
3. Strongest diagnostic companion approach.
4. Whether MTA should be core model, diagnostic layer, or separate analysis.
5. Whether uplift/causal ML should be core model, companion layer, or future extension.
6. What data additions would most improve methodology quality.
7. What should be avoided because the data cannot support it.
8. What needs manual business/science review before committing.
9. What model/evaluation experiments should decide between options.

Use clear tables.
Be opinionated but evidence-based.
State uncertainty explicitly.
