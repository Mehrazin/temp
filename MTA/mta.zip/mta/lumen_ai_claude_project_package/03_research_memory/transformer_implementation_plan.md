# Lumen AI — Transformer Implementation Plan & Shortlist

**Date:** 2026-06-15c
**Direction:** Manager-directed to pursue the **transformer path** (supersedes the "lighter-models-first" recommendation; see decision register D004). Goal is **good-enough and flexible, not perfect.** Horizon: **2–4 weeks** to produce a plan and run initial experiments. Bias toward **available packages / repos / easy-to-implement papers.**
**Companion docs:** background survey in `transformer_sequence_modeling_review.md`; data context (sparse, low-frequency bank journeys from 2022; current model collapses an April–July snapshot to a flat vector) in that doc's §0.6.

---

## 1. The single most important design decision: **treatment-conditional core model + a thin assignment process**

The business requirement — *"this month assign from this channel set; for these customers choose from that set; output can be one channel or a combo; don't pre-score every combination"* — rules out the shelved 2^N combinatorial model and dictates the architecture:

> **Build ONE core model where the proposed action (a channel or a set of channels) is an INPUT, not a fixed output head.** Then a lightweight, swappable **process layer** decides *which* action-sets to ask the model about each month and runs the constrained assignment.

This is the **g-computation / counterfactual-query pattern**: the model answers *"what is the outcome if we apply action-set A to this customer?"*, and the process decides which A's are worth asking and how to allocate under business caps.

```
                     CORE MODEL  (train once)
  customer context (PRISM) ┐
  journey (2022+ events)   ├─► encoder ─► fuse with ─► P(convert | journey, context, A)
  proposed action-set A ───┘             action rep        and uplift(A) = P(·|A) − P(·|∅)
        (multi-hot / set of channel embeddings)

                     PROCESS LAYER  (re-run monthly, no retrain)
  business rules this month:  allowed channel universe U,
     per-customer/segment eligible sets {A_c}, caps/budget, 1-vs-combo policy
        │
        ▼
  for each customer c: score only the relevant candidate sets A ∈ {A_c}
        │   (tens of candidates, not 2^N)
        ▼
  uplift table (customer × candidate-set) ─► constrained optimizer (ILP) ─► assignment
```

Two properties make this satisfy the requirement:

1. **Combos are handled compositionally, not enumerated.** Represent an action-set as a **set of channel embeddings** pooled permutation-invariantly (Deep Sets / Set Transformer: sum/mean/attention pooling). The model then generalizes to action-sets it never saw in training, so you never pre-train 2^N heads. Single channel = a set of size 1; a combo = a larger set. (Set Transformer, arXiv 1810.00825; Deep Sets.)
2. **Business logic lives in the process, not the model.** Changing the allowed universe, eligible sets, caps, or the one-vs-combo policy is a config change to the process — the core model is untouched. The optimizer is the same constrained-assignment idea Lumen already has, optionally upgraded to a differentiable-ILP allocation (arXiv 2408.11623).

**Causality, pragmatically:** the simplest way to get uplift from any of the models below is the **S-learner** trick — train the outcome model with the action as input, then `uplift(A) = predict(journey, A) − predict(journey, ∅)`. It's "good enough" for v1 and works with every option in §2. The rigorous version (counterfactual + confounding adjustment) is options A4. Either way, **remember the prior review's caveat: offline uplift is model-estimated; a real claim needs a live test.**

---

## 2. The shortlist — 5 buildable options for the CORE model, ranked by implementation effort

All five plug into the same process layer (§1). All five take the action-set as input → all five support on-demand combo scoring. Pick the rung that matches the 2–4 week budget; they are not mutually exclusive (start low, escalate).

### A1 — FT-Transformer / TabTransformer on engineered journey+treatment features  ·  *easiest, lowest risk*
- **What:** a tabular transformer (FT-Transformer: feature-tokenizer + transformer) over PRISM scores + **temporal journey features** (multi-window/RFM/recency over 2022+ history) + the **proposed action as multi-hot channel inputs**. Predict conversion; difference for uplift (S-learner).
- **Why it fits:** checks the "transformer" box, trivially handles any combo (flip the multi-hot), and is robust on sparse/short data because it doesn't require long event sequences. Closest drop-in to today's XGBoost feature vector.
- **Code:** **pytorch-tabular** (`FTTransformer`, `TabTransformer`; manujosephv/pytorch_tabular) — high-level, Lightning-based, days to a baseline. Also lucidrains/tab-transformer-pytorch. Paper: Gorishniy et al., "Revisiting Deep Learning Models for Tabular Data," arXiv 2106.11959.
- **Limitation:** not a true sequence model (uses aggregated features), S-learner causality is weak. Best as the fast baseline / fallback.

### A2 — Temporal Fusion Transformer (TFT)  ·  *best easy fit for "set the plan, read the outcome"*
- **What:** TFT natively separates **static covariates** (PRISM), **time-varying observed past** (journey events), and — critically — **known future inputs**. Put the **planned channel/action for the next period as a known future input**; the model predicts the outcome under that plan. Query different plans/combos by changing the future input. Built-in variable selection + interpretable attention.
- **Why it fits:** the "known future input" slot is *exactly* the treatment-as-input requirement, with no custom architecture. Sequence-aware but handles modest data; strong, well-documented library.
- **Code:** **pytorch-forecasting** (`TemporalFusionTransformer` + `TimeSeriesDataSet`). Paper: Lim et al., arXiv 1912.09363.
- **Limitation:** designed for continuous multi-horizon forecasting; needs adapting for a binary conversion target; S-learner causality (difference plan-A vs no-contact).

### A3 — Sequence-rec transformer (SASRec / BST) repurposed as a treatment-conditional conversion model  ·  *production rec stack*
- **What:** encode the journey with a SASRec/BST-style encoder, append the **proposed action-set as candidate tokens** (the way CTR models append a candidate item), predict conversion. Combos = pool the candidate tokens.
- **Why it fits:** BST already uses **learned time-gap embeddings** for irregular journeys; production-grade serving path.
- **Code:** **Transformers4Rec** (NVIDIA Merlin, HuggingFace-backed) + NVTabular/Triton; RecBole for quick SASRec/BST baselines.
- **Limitation:** rec libraries optimize next-item, not conversion/uplift — needs a custom head and label; benefits from longer sequences than we may have.

### A4 — Causal Transformer / G-Transformer  ·  *the rigorous causal option, treatment-as-input by design*
- **What:** purpose-built to estimate **counterfactual outcomes under arbitrary treatment strategies over time**, with explicit confounding adjustment. Treatment is a first-class input; **g-computation** simulates forward under any plan = literally "score any action-set." This is the "do it properly" target that also directly delivers the flexible combo query.
- **Code (verified):** Causal Transformer — **github.com/Valentyn1997/CausalTransformer** (Melnychuk et al., ICML 2022, arXiv 2204.07258; PyTorch Lightning). G-Transformer — **github.com/konstantinhess/G_transformer** (Hess/Melnychuk/Feuerriegel, CAPO over time, arXiv 2405.21012); a separate g-computation G-Transformer (Monte-Carlo forward simulation under dynamic regimes) is arXiv 2406.05504.
- **Limitation:** research-grade code, **healthcare provenance** (see data-fit checklist §3), highest effort; likely a parallel/stretch track within 2–4 weeks, not the first deliverable.

### A5 — Set/Deep-Sets treatment module (the combo enabler) bolted onto a minimal encoder  ·  *the design primitive*
- **What:** not a standalone competitor but the **component that makes A1–A4 compositional over combos**: encode each channel in the action-set to an embedding, pool permutation-invariantly (Deep Sets sum, or Set Transformer PMA), concat with the journey/context representation, predict outcome. Easiest standalone form: a small custom HuggingFace/PyTorch model = `journey encoder + set-pooled treatment embedding + MLP head`, trained S-learner style.
- **Why call it out:** if you build only one custom thing in 2–4 weeks, this is it — it's what guarantees "any combo without pre-enumeration" and is ~50 lines on top of any encoder. (Set Transformer, arXiv 1810.00825.)

**Recommended sequencing for the spike:** **A1 or A2 first** (fast, flexible baseline with the process layer wired up), build the **A5 set-treatment head** so combos work compositionally, then **pilot A4** as the rigorous causal track if time allows. A3 only if journeys turn out long/dense enough to justify a rec encoder.

---

## 3. Cross-domain data-fit checklist (most of A2/A4 come from forecasting/healthcare — verify before trusting)

For each candidate, check these in *your* data before committing. Red flags mean "good-enough S-learner (A1/A2) over rigorous causal (A4)," or more feature engineering.

| What to check | Why it matters | Which option cares most | Red flag |
|---|---|---|---|
| **Touches per customer (sequence length distribution)** | Attention/sequence models need signal across steps | A3, A4, A2 | Mostly 0–2 touches → use A1 (tabular), skip rec encoders |
| **Per-channel & per-combo frequency** | Compositional set head needs each *channel* seen enough; combos can be unseen | All (esp. A5) | A channel with too few positives → pool/drop it (Tree-VIF already does this) |
| **Treatment overlap / positivity** | Counterfactual queries are only valid where that action is plausible for that customer type | A4 (and any uplift claim) | Some customers never eligible for a channel → restrict the eligible set in the process, don't extrapolate |
| **Time-varying confounding** (does past response drive who gets contacted next?) | This is the whole reason to use A4 over a plain S-learner | A4 | If assignment is basically random/rule-based → a simple S-learner (A1/A2) may suffice |
| **Static vs time-varying split** | TFT requires you to label each feature | A2 | Unclear which PRISM features are time-varying → start by treating them static |
| **Availability of the "planned action" as a known future input** | TFT's treatment slot; the process must supply candidate plans | A2 | If you can't express "next period's planned channel" cleanly → use A1/A5 instead |
| **Outcome timing / censoring** | "Converted by when?" vs static binary | A4 (and survival framing) | Long, censored horizons → consider the survival head from the companion doc (F2) |
| **Volume per arm** | DL needs enough rows; GBDT wins when small | All | <~tens of thousands of informative rows → expect parity with XGBoost, justify the transformer on flexibility not accuracy |
| **Label leakage from treatment-in-features** | The prior review's one-vs-rest collinearity bug (C1/C2) | All S-learner variants | Treatment must enter ONLY through the action-input, not also as a journey feature |

---

## 4. A concrete 2–4 week experimentation plan

**Week 1 — data audit + scaffolding.** Run the §3 checklist on the 2022+ tables (sequence length, per-channel/combo frequency, overlap, censoring, volume). Define the conversion label + horizon. Build the **process-layer skeleton** (allowed universe, per-customer eligible sets, caps) against the *current* XGBoost scores so the assignment pipeline exists independent of the new model. Decide static-vs-time-varying feature split.

**Week 2 — first transformer baseline (A1 or A2).** Stand up FT-Transformer (pytorch-tabular) or TFT (pytorch-forecasting) with the **action as input**; train S-learner; produce `uplift(A) = pred(A) − pred(∅)`. Wire it into the process layer. Sanity-check single-channel uplift against today's DR scores (agreement, sign).

**Week 3 — combo flexibility (A5) + validation.** Add the **set-pooled treatment head** so arbitrary combos score compositionally; verify it generalizes to held-out combos. Adopt a **time-based holdout** (train ≤ month *t*, test > *t*) per the method-review fix (C6). Evaluate with **Qini/AUUC**, not just AUC. Define the manager-facing comparison: transformer vs. current XGBoost-DR on the *same* time split.

**Week 4 — rigorous track (A4) spike + write-up.** If on track, run the **Causal Transformer or G-Transformer** repo on a reduced feature set to see whether confounding-adjusted counterfactuals differ materially from the S-learner; if not, the cheaper A1/A2 is "good enough." Deliver: chosen architecture, the core-model+process design, validation results, effort/risk to productionize (incl. the separate compliance path a new architecture requires).

**Stop rules (good-enough guardrails):** if A1/A2 + S-learner matches XGBoost-DR on the time-based split and the process layer delivers flexible combos, that is a shippable v1 — do not block on A4. If the data audit shows mostly 0–2 touches/customer, drop A3/A4 and standardize on A1/A2 (tabular transformer), justifying the transformer on flexibility + manager direction, not an accuracy win.

---

## 5. How this satisfies the business requirement (recap)

- **One core model, trained once**, with the action-set as input → no 2^N pre-scoring.
- **Combos generated on demand** by the process from each month's rules; only relevant candidate sets are scored (compositional set head makes unseen combos valid).
- **One channel or a combo** is just an action-set of size 1 or >1 — same model call.
- **Changing business needs** = reconfigure the process (universe, eligible sets, caps, one-vs-combo), no retrain.
- **Decoupled** model vs. decision, exactly as requested ("a core model plus a process that uses the model to generate the combo scores").

---

## 6. References & repos (this round)

Core / treatment-conditional transformers:
- Temporal Fusion Transformer — Lim et al. — arXiv 1912.09363 — pkg: pytorch-forecasting
- FT-Transformer / "Revisiting DL for Tabular Data" — Gorishniy et al. — arXiv 2106.11959 — pkg: pytorch-tabular (manujosephv/pytorch_tabular); TabTransformer: lucidrains/tab-transformer-pytorch
- Causal Transformer — Melnychuk, Frauen, Feuerriegel, ICML 2022 — arXiv 2204.07258 — code github.com/Valentyn1997/CausalTransformer
- G-Transformer (CAPO over time) — Hess, Melnychuk, Feuerriegel — arXiv 2405.21012 — code github.com/konstantinhess/G_transformer
- G-Transformer (g-computation, dynamic regimes) — arXiv 2406.05504
- Transformers4Rec — de Souza Pereira Moreira et al., RecSys 2021 — github.com/NVIDIA-Merlin/Transformers4Rec; RecBole — github.com/RUCAIBox/RecBole
- BST (time-gap embeddings) — arXiv 1905.06874; SASRec — arXiv 1808.09781

Combo / set representation + assignment process:
- Set Transformer — Lee et al., ICML 2019 — arXiv 1810.00825 (Deep Sets: Zaheer et al., 2017)
- Uplift Modeling for Multiple Treatments with Cost Optimization — Zhao & Harinen — arXiv 1908.05372 (implemented in Uber **CausalML**)
- End-to-End Cost-Effective Incentive Recommendation under Budget Constraint (differentiable ILP allocation) — arXiv 2408.11623
- Multi-Treatment Multi-Task Uplift Modeling — arXiv 2408.12803; Multi-treatment uplift ranking + calibration — arXiv 2408.13628

Libraries: pytorch-forecasting (TFT), pytorch-tabular (FT-Transformer), Transformers4Rec/RecBole (rec encoders), CausalML / scikit-uplift (multi-treatment uplift + Qini/AUUC), CausalTransformer & G_transformer repos (causal).
