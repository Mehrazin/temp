# Method Critiques

## Status

First critique pass completed 2026-06-15. Full report: `04_outputs/2026-06-15_method_review.md`. Critiques below are grouped by category with severity labels.

## Critique Categories

(Reference list — used below.) Data design · Cohort definition · Label definition · Treatment definition · Confounding and selection bias · Overlap / positivity · Propensity model quality · Response model quality · Doubly robust assumptions · Negative lift interpretation · Offline validation · Optimization objective · Business constraints · Production-readiness · Governance · Communication risk

## Severity Labels

- Critical production blocker
- Important validation gap
- Research improvement
- Acceptable phase-1 limitation
- Communication caveat

---

## Critiques (2026-06-15)

### C1 — Underdetermined covariance / `zstat=-inf` (Doubly robust assumptions; Overlap/positivity)

**Severity: Critical production blocker (for causal/inference claims).**
EconML's warning fires when rank(final-stage feature matrix) < #parameters. The final matrix is featurizer(X) + intercept, interacted with treatment. Causes in Lumen: (a) one-vs-rest places t_channel_* in X/W *and* as T → treatment near-collinear with conditioning columns; (b) rare channels = too few treated units per arm; (c) propensity-overlap violations → extreme IPW. Tree-VIF (removed Social_CT) reduced but did not eliminate it (Paid_Search persists). Invalidates all SEs/CIs/p-values; point predictions from cross-fitted regressions less affected. Fix: remove treatment cols from X/W or confirm correct EconML API usage; shrink final-stage dimension; raise rare-channel threshold / pool; trim or use overlap (ATO) weights.

### C2 — One-vs-rest treatment-in-X design (Treatment definition; Confounding)

**Severity: Important validation gap (drives C1).**
Placing t_channel_* in both the conditioning set and as the treatment risks leakage/collinearity and is the team's own "training an s-learner effectively" concern. Verify against EconML's expected X/T/W contract; this is likely the single highest-leverage fix.

### C3 — `W_test = zeros` counterfactual at scoring (Treatment definition; Communication risk)

**Severity: Research improvement / communication caveat.**
Scoring with all other channels off defines an "isolated channel" counterfactual that may not match business intent (realistic contact mix). It shapes the scores feeding the optimizer; decide and document. (open_questions #7.)

### C4 — Propensity calibration & AUC-tuning mismatch (Propensity model quality)

**Severity: Important.**
XGBoost propensity tuned to AUC ranks well but may be miscalibrated; DR weighting needs calibrated probabilities, not rankings. Miscalibration → extreme weights → feeds C1. Re-evaluate with Brier/reliability.

### C5 — Calibration disabled on the consumed probabilities (Response model quality)

**Severity: Communication caveat / revisit.**
CalibratedClassifierCV trialed then disabled on "little effect"; the optimizer consumes raw probabilities. Re-test with calibration metrics, not "did the number move."

### C6 — Non-temporal random split (Offline validation)

**Severity: Important validation gap.**
Random 60/20/20 leaks future-into-past for a forward-scoring deployment and likely explains unrealistic test-set channel mix. Adopt a time-based / windowed holdout before reporting any metric as predictive. (open_questions #9.)

### C7 — OPE-vs-PRISM "lucky match" (Offline validation; Communication risk)

**Severity: Important validation gap + communication caveat.**
+11.18% AUC (0.831 vs 0.719) on 7,070 matched rows has four problems: measures ranking not uplift; selection-on-agreement bias; no significance test; confounded (different data/features). Suggestive only; replace with proper IPS/DR off-policy evaluation. (open_questions #10.)

### C8 — Optimizer objective = conversion, not uplift (Optimization objective)

**Severity: Research improvement → Important.**
Maximizing predicted conversion targets "sure things." Switch objective to incremental lift (`_1` − `_0`), which the DR machinery already produces. Mostly a wiring change.

### C9 — Direct-mail sourcing / data-foundation artifact (Data design; Cohort definition)

**Severity: Important; partial blocker.**
Historical MTA DM empty → DM enters via TMIA only → DM≫Email imbalance and unrealistic mix; MTA/TMIA/hybrid unresolved. Model partly fits a collection artifact; caveat all DM comparisons until fixed. (open_questions #1–2.)

### C10 — Negative-ATE interpretation not built (Negative lift interpretation; Communication risk)

**Severity: Communication caveat / research improvement.**
Email/Mobile negative at channel level (Email-CLICK positive). Negative lift is a real finding (cannibalization/over-contact), not a bug; needs a narrative before any diagnostic communication.

### C11 — No experimental / defensible-OPE validation (Confounding; Offline validation)

**Severity: Critical production blocker (for uplift claims).**
All DR estimates are observational (unconfoundedness unverified). No experiment exists. Cannot claim incremental business impact. Path: defensible OPE now, champion/challenger field test eventually.

### C12 — Reproducibility & governance (Production-readiness; Governance)

**Severity: Critical for registration.**
Models not persisted (saved_models commented out), notebooks messy/unversioned. Must serialize (MLflow registry) and version before registration/compliance. Architecture lock-in: XGBoost approval path will not transfer to a transformer.

### C13 — Single shared hyperparameters across all channels & both nuisance models (Response/Propensity model quality)

**Severity: Acceptable phase-1 limitation.**
Reusing overall_best_params is pragmatic but leaves nuisance models untuned per arm; contributes to rare-channel instability. Acceptable for v1; revisit.

### C14 — Journey collapsed to a single snapshot vector; 2022+ history unused (Data design; Label definition)

**Severity: Important validation gap / research improvement.** New 2026-06-15b (tech-lead data context).
Current Lumen uses only an **April–July snapshot condensed into one flat feature vector** for XGBoost, so it (a) **discards temporal order / sequence structure**, (b) **ignores customer history available from 2022**, and (c) treats a fundamentally **right-censored time-to-event** outcome (convert-or-not over a multi-year journey) as a static binary label. Consequences: wastes data, blocks the time-based holdout (C6), mishandles not-yet-converted customers, and overstates how "sequence-ready" the pipeline is. The data is **bank journeys with low/uneven frequency** (digital frequent; Email/DM/Leads sparse) — a regime where GBDT and simpler sequence-aware models beat transformers. **Recommended ladder (see `transformer_sequence_modeling_review.md` §6b/§10):** F0 temporal-feature XGBoost over full history (low effort, keeps DR) → F2 Causal Survival Forest (native uplift on censored time-to-event) → Markov/GRU baselines → transformer only if volume/sequence length later justify it. A transformer is **not** the right next step for this data.

---

## What is defensible vs. not (summary)

- **Defensible now:** DR-over-Shapley direction (C-evidence: sign flips); cross-fitting design; channel-level actionable scores; constrained optimizer with illustrative-unconstrained labeling.
- **Not defensible yet:** any causal CI/p-value (C1); any incremental-uplift number (C11); the +11.18% PRISM beat (C7); production-readiness (C6, C12).
