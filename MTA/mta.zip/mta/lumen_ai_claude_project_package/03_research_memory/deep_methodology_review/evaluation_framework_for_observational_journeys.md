# Evaluation Framework for Observational Customer-Journey Data — Lumen AI

**Date:** 2026-06-21
**Scope:** Deep methodology review, chat 3b. Defines the evaluation questions, the metrics and protocols appropriate to each, what can and cannot be established from observational data, and how this framework is used to compare future transformer-based model options.
**Status:** Research memory. **Does not** force a single evaluation method, does not pick an architecture, is not a manager memo. The transformer/sequence direction is assumed.

**Reads with:** `data_observability_map.md` and `transformer_dataset_design_options.md` (companions, this folder). Evaluation inherits their constraints: channel observability tiers, no fabricated negatives, inferred-state flags, the Sept-2024 score gap, time-based splits, and the reliable-exposure causal subset (Design D5).

**Authority:** `02_change_log/2026-06-20_data_observability_update.md` and `01_current_state/` govern. Claim discipline (D005): no causal CI/p-value until the DR rank-deficiency is fixed (C1); no incremental-uplift claim without an experiment or defensible OPE; no "beats PRISM."

---

## 0. First principle: evaluation is question-shaped, not metric-shaped

The brief is explicit — **do not force a specific evaluation method in advance.** The right metric depends on the question being asked, and the questions sit on a ladder of increasing causal strength and decreasing observational defensibility:

```
prediction  →  ranking  →  recommendation  →  policy value  →  treatment effect / uplift
(fully observational)                                          (needs experiment or strong assumptions)
        ─────────────────────── what observational data can support ───────────────────────►
                                                          ◄─── what it cannot prove ───
```

The single most important discipline: **state which question a number answers, and stop the number from being read as a stronger question's answer.** A high AUC answers "prediction/ranking," not "this channel caused conversions." This framework is built to keep those separate.

---

## 1. The evaluation questions

| # | Question | What it really asks | Causal strength | Observationally answerable? |
|---|---|---|---|---|
| Q1 | **Prediction quality** | Does the model predict conversion / response accurately and in calibrated fashion? | none (associational) | **Yes** — on a time-based holdout |
| Q2 | **Ranking quality** | Does the model order customers/channels so the top of the list is right? | none | **Yes** — on a time-based holdout |
| Q3 | **Channel-recommendation quality** | Is the recommended channel the right one given the customer? | weak-causal (implicitly counterfactual) | **Partially** — observationally only as agreement/ranking; causal part needs Q5 |
| Q4 | **Policy / value estimation** | What conversion/value would the model's *policy* produce vs the logged/BAU policy? | medium-causal (off-policy) | **Partially** — via IPS/DR-OPE with assumptions + CIs, restricted to reliable channels |
| Q5 | **Uplift / treatment-effect quality** | What is the *incremental* effect of a channel (vs not)? | strong-causal | **Only with strong assumptions** (D5 subset) — **not proven** without randomization |
| Q6 | **Diagnostic / attribution reporting** | What does the model key on; which touches associate with conversion? | none (associational, must not be sold as causal) | **Yes**, but **labelled non-causal** |
| Q7 | **Calibration & stability over time** | Are probabilities calibrated, and does performance hold across time/policy regimes? | none | **Yes** — via rolling-origin evaluation |

The ladder matters: **Q1–Q2, Q6, Q7 are fully observational. Q3 is partly observational. Q4 is observational-with-assumptions. Q5 is the one that observational data cannot prove.** The framework treats each accordingly.

---

## 2. Metrics and protocols per question

### Q1 — Prediction quality

- **Metrics:** PR-AUC (primary, given sparse positives), ROC-AUC (secondary), log-loss / Brier score, calibration curve. PR-AUC over ROC-AUC because conversion is rare and PR-AUC is sensitive to the positive class.
- **Protocol:** time-based holdout (train ≤ `t_cut`, test on a forward window) per the dataset-design split principles. Report on the **reliable-exposure subset** and on the **full integrated set** separately — they answer different population questions.
- **Observability caveat:** on reaction-only datasets (D1) prediction quality is **survivorship-conditioned** ("among engagers"), and must be labelled as such; it is not population prediction.

### Q2 — Ranking quality

- **Metrics:** NDCG@k, Recall@k / Precision@k, lift@k (top-decile lift), MAP. For per-customer channel ranking: mean reciprocal rank of the realized channel where a realized choice exists.
- **Protocol:** time-based holdout; evaluate top-k against realized outcomes in the label window. Use bootstrap CIs over customers for stability.
- **Caveat:** ranking quality measures ordering, **not** incremental value. Per D005, a ranking win (e.g., the +11.18% AUC "lucky match" vs PRISM) is **not** "beating PRISM" and is **not** uplift — it is ranking on a biased matched subset, not significance-tested.

### Q3 — Channel-recommendation quality

- **Metrics:** match/agreement rate with the realized channel among customers who converted; top-k channel hit-rate; **but** flagged as agreement, not correctness (the realized channel was chosen by the *logged* policy, not known to be optimal).
- **Protocol:** restricted to customers/channels with observed exposure (reliable-exposure subset); for the causal portion of "is it the *right* channel," defer to Q4/Q5.
- **Caveat:** observational recommendation evaluation **cannot** confirm a recommended channel is better than the road not taken — that is a counterfactual (Q5). Agreement-with-logged-policy rewards mimicking BAU, which is not the goal. Treat Q3 observational numbers as **necessary-not-sufficient**.

### Q4 — Policy / value estimation (off-policy evaluation)

- **Metrics:** estimated policy value (expected conversion/value under the model's policy) via **Inverse Propensity Scoring (IPS)**, **self-normalized IPS (SNIPS)**, and **doubly-robust OPE (DR-OPE)**; report **confidence intervals** and **effective sample size** / weight diagnostics (max weight, ESS) — high-variance IPS with tiny ESS is not a usable estimate.
- **Protocol:**
  - Restrict to the **reliable-exposure causal subset (D5)** where a logging propensity can be estimated and positivity/overlap plausibly hold.
  - Use **Sept-2024+ window** when score-based propensity adjustment is required (score availability gap).
  - Validate overlap/positivity **before** trusting any estimate — the rank-deficient DR instability (C1) is the warning that overlap is currently poor.
  - This is the **principled replacement** for the "lucky match" OPE-vs-PRISM comparison (OQ22, C7/C11).
- **What it can establish:** an assumption-laden estimate, *with CIs*, of how the model's policy would perform vs the logged policy — useful for go/no-go before a live test.
- **What it cannot establish:** a *proven* causal value. IPS/DR-OPE rest on unconfoundedness + positivity + correct propensity; all are unverifiable on observational data. The estimate is a **defensible projection, not proof.**

### Q5 — Uplift / treatment-effect quality

- **Metrics (when a causal claim is genuinely on the table):** Qini curve / AUUC (area under the uplift curve), uplift@k, policy risk; per-channel CATE with CIs **only if** a defensible identification holds.
- **Protocol:**
  - **Only** on the reliable-exposure subset (D5), Sept-2024+ where score adjustment is needed, with overlap/positivity confirmed.
  - Prefer estimators robust to the rank-deficiency that broke the linear DR stage (e.g., causal forests with honest splitting, or an S-learner difference as a cheap floor) — but the estimator choice does not rescue the identification assumptions.
- **What it can establish:** an *estimate* of incremental effect under stated, unverifiable assumptions, for a channel subset.
- **What it cannot establish — the hard line:** **true incremental business uplift cannot be proven from observational data.** It requires randomized experimentation (champion/challenger, geo/holdout) or, at minimum, a defensible OPE design whose assumptions are argued and stress-tested. Per D005: **no incremental-uplift claim ships without an experiment or a defensible OPE.** Branch/phone/SEO/paid-search/OBTM are **excluded** from uplift claims entirely (no clean exposure).

### Q6 — Diagnostic / attribution-style reporting

- **Metrics/tools:** feature importance, SHAP, attention maps, ablations, touch-association summaries.
- **Protocol:** report freely as **model-explanation**, never as causal attribution.
- **Hard caveat (carried from the model-options map):** **predictive diagnostics ≠ causal attribution**, and **attention weights are not attribution.** SHAP/importance explain *what the model keys on*; they are not incremental-effect estimates. A transformer's value here is a better *encoder/scorer*, not a channel-credit claim. Any attribution-style output must be labelled associational.

### Q7 — Calibration & stability over time

- **Metrics:** Brier score and reliability diagrams (calibration); performance drift across rolling-origin folds; PSI / population-stability of inputs; per-time-block AUC/PR-AUC/Brier; subgroup calibration (e.g., by observability tier, by score-available vs masked).
- **Protocol:** **rolling-origin / expanding-window evaluation** across the 2022→2026 history; explicitly report pre/post-Sept-2024 (score gap) and pre/post fuller-universe-integration (regime boundary) separately. Stability is a first-class question because campaigns/policies/observability drift.
- **Why first-class:** a model that scores well on one window but degrades across regimes is a production risk; the optimizer consumes these probabilities, so calibration is not optional.

---

## 3. What observational data can and cannot establish (summary)

| Claim type | Status on observational journey data | Requires |
|---|---|---|
| "This model predicts/ranks conversion well on future data" | **Establishable** (Q1/Q2) | time-based holdout |
| "Probabilities are calibrated and stable over time" | **Establishable** (Q7) | rolling-origin eval |
| "Here is what the model keys on" | **Establishable, associational** (Q6) | label as non-causal |
| "The model's policy would likely outperform BAU" | **Estimable with assumptions + CIs** (Q4) | IPS/DR-OPE on reliable subset, overlap checks |
| "Channel X has incremental effect Y" | **Estimate only, unprovable observationally** (Q5) | randomization or defensible OPE; reliable subset; D005 |
| "Lumen beats PRISM" | **Not licensed** | held back per D005 |
| "This is the truly optimal channel for this customer" | **Not establishable observationally** | counterfactual / experiment |

The framing discipline (from the design-input snapshot, adopted here): **default the evaluation to predictive/ranking questions (Q1–Q2, Q6–Q7), which are measurable on a plain time-based split with no positivity prerequisites. Treat policy-value and uplift (Q4–Q5) as conditional, assumption-laden additions tied to a specific causal claim — not default spike metrics.**

---

## 4. Bias and validity threats the evaluation must surface (not hide)

| Threat | Where it bites | How the framework handles it |
|---|---|---|
| **Survivorship / response-conditioning** | D1 reaction-only; email/DM today | Report reaction-only metrics as "among engaged"; prefer exposure-anchored datasets (D2/D3); separate populations |
| **Missing negatives / selection on presentation** | branch/phone (no-present → no row) | Exclude from negative-bearing metrics and from uplift; absence = unobserved, not no-action |
| **Fused exposure+reaction** | paid search / SEO clicks | Never treat clicks as exposure; exclude from exposure-conditioned and causal metrics |
| **Exposure unobserved** | digital (no targeted universe); OBTM (no reaction) | Excluded from Q4/Q5; OBTM is context-only |
| **Inferred states laundered as observed** | leads/OBTM contact | Carry inferred flags; offer observed-only subsets for rigorous runs |
| **Propensity-score gap** | pre-Sept-2024 segments | Block the boundary; restrict score-adjusted causal work to Sept-2024+ |
| **Policy/observability drift** | 2022→2026 history | Rolling-origin + blocked-regime evaluation (Q7) |
| **Leakage from random split** | legacy baseline | Time-based holdout mandatory; random split retained only to reproduce the legacy number |
| **Positivity/overlap failure** | the DR rank-deficiency (C1) | Overlap diagnostics gate Q4/Q5; no DR CI until C1 fixed |
| **Channel asymmetry read as signal** | any cross-channel comparison | Per-channel availability map travels with the eval; compare like-with-like (per-tier, D4) |

---

## 5. Using this framework to compare future transformer-based model options

The framework's second job: a **fair, non-circular** protocol for judging future transformer designs (and the strengthened XGBoost/DR baseline) against each other.

### 5.1 The comparison protocol

1. **Fix the evaluation design before modeling** (OQ43) — same split, same data layer/subset, same metric set, declared up front, so the comparison is not retrofitted to a winner.
2. **Same data, same split, same population.** All candidates evaluated on the identical time-based holdout (and rolling-origin folds), on the identical dataset design (e.g., D2 for the predictive comparison; D5 for any causal comparison) — ideally on the **full-data Layer-4** dataset, not the prototype slice, so the comparison is not on a non-representative population.
3. **Primary metrics = predictive/ranking + calibration/stability (Q1, Q2, Q7).** These are measurable, assumption-light, and directly relevant to a scorer that feeds a config-driven decision layer. The transformer must beat (or at least match) the strengthened GBDT baseline here first.
4. **Policy-value (Q4) only if an uplift/policy claim is in scope**, on the reliable-exposure subset, with CIs and overlap diagnostics — never as the default head-to-head metric.
5. **Uplift (Q5) is a conditional, late-stage comparison**, gated on overlap and on D005; a transformer "winning" on an unidentified uplift metric proves nothing.
6. **Diagnostics (Q6) are reported for understanding, not for scoring the contest** — attention/SHAP differences do not decide the winner.
7. **Stability (Q7) is a tie-breaker and a production gate.** A marginally-better but unstable model loses to a stable one for a system whose scores feed an optimizer monthly.

### 5.2 Per-design evaluation matrix (how candidate designs map to questions)

| Model option (from model-options map) | Q1 Pred | Q2 Rank | Q4 Policy | Q5 Uplift | Q6 Diag | Q7 Stab | Eval dataset |
|---|---|---|---|---|---|---|---|
| **CP1** Temporal-feature XGBoost (baseline/floor) | ✅ primary | ✅ | via separate DR (caveated) | only via DR (C1-blocked) | predictive only | ✅ | D2 / D4 |
| **CP2** Tabular/temporal transformer (action-as-input) | ✅ primary | ✅ | via S-learner diff (optional) | optional, gated | predictive (attention≠attribution) | ✅ | D2 / D3 |
| **CP3** Hybrid encoder → XGBoost/DR | ✅ + ablation | ✅ | via existing DR (caveated) | via DR (C1-blocked) | ablation marginal value | ✅ | D2 |
| **CP4** Sequence-rec encoder | ✅ ranking-native | ✅ primary | — | — | predictive | ✅ | D3 (if long/dense) |
| **CP5** Self-supervised / multi-task | ✅ multi-signal | ✅ | — | — | predictive multi-head | ✅ | D3 |
| **CP6** Causal/uplift head | indirect | — | DR-OPE | ✅ (the only native, still gated) | causal (own head) | ⚠️ | **D5 only** |

Reading: **the contest is decided primarily on Q1/Q2/Q7 over D2 (predictive) on the same time-based split.** Causal questions (Q4/Q5) enter only for CP6 / when an uplift claim is explicitly in scope, only on D5, only with overlap + CIs, and never as proof of business uplift without an experiment.

### 5.3 What "good enough to finalize" means, evaluation-side

A transformer design is finalize-able when, on the agreed fixed protocol: it **matches or beats** the strengthened GBDT baseline on the primary predictive/ranking metrics (Q1/Q2), is **calibrated and stable** across rolling-origin folds (Q7), honors the **leakage and observability discipline** (no fabricated negatives, no conflated event types, no leaked scores), and any causal/policy number it reports is **correctly scoped** (Q4/Q5 caveats, D005). "Transformer merely matches GBDT" is a legitimate, reportable outcome — judged on the full-data comparison, not the prototype slice.

---

## 6. One-page protocol summary

| Step | Action |
|---|---|
| 1 | Declare the evaluation question(s) (Q1–Q7) **before** modeling. |
| 2 | Choose the dataset design fit to the question (D2 predictive; D5 causal; D4 per-tier). |
| 3 | Apply the **time-based holdout + rolling-origin** split; block the Sept-2024 and integration boundaries. |
| 4 | Score predictive/ranking primary (PR-AUC, NDCG@k, lift@k) + calibration/stability (Brier, reliability, drift). |
| 5 | Add policy-value (IPS/SNIPS/DR-OPE + CIs + ESS) **only** on the reliable subset **if** a policy claim is in scope. |
| 6 | Add uplift (Qini/AUUC) **only** on D5, **only** with overlap confirmed, **never** as proof of business uplift. |
| 7 | Report diagnostics (SHAP/attention) labelled **associational**. |
| 8 | Compare candidates on identical data/split/metrics; decide on Q1/Q2/Q7; break ties on stability. |
| 9 | Apply claim discipline (D005) to every number before it leaves the team. |

---

*Sources: `01_current_state/current_snapshot.md` (Results To Date, Known Limitations, D005); `01_current_state/open_questions.md` (OQ9–11, OQ20–24, OQ43, OQ48–56); `02_change_log/2026-06-20_data_observability_update.md`; `02_change_log/2026-06-16_data_scale_correction.md`; companions `data_observability_map.md`, `transformer_dataset_design_options.md`. Optional background reconciled, not relied on: `04_outputs/transformer_design_input_snapshot.md` (§13–14), `04_outputs/model_options_map_for_human_review.md` (claim-discipline reminders), `03_research_memory/production_score_contract_options.md`. No new external research; observational limits stated explicitly; causal claims held to D005.*
