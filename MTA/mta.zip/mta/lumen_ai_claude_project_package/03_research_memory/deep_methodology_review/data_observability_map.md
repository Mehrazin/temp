# Data Observability Map — Lumen AI

**Date:** 2026-06-21
**Scope:** Deep methodology review, chat 3b. This file builds a rigorous, channel-by-channel observability map and analyzes targeted-universe options for transformer/sequence dataset construction.
**Status:** Research memory. Not a model recommendation, not an MVP plan, not a manager memo. The confirmed modeling direction (transformer / sequence-model focused) is unchanged; this file constrains *what data a sequence model can be built on*, not *which architecture wins*.

**Authority:** Where this file and any earlier design artifact disagree, the corrected data-observability picture in `02_change_log/2026-06-20_data_observability_update.md` and `01_current_state/current_snapshot.md` governs. Counts are approximate per the four-layer data-scale view (`02_change_log/2026-06-16_data_scale_correction.md`).

---

## 0. Why this map exists (the load-bearing distinction)

The single most consequential fact in the corrected data picture is that **observing a record does not tell you what kind of event it was.** A row in a channel table can mean any of:

`targeted · assigned · sent · shown · contacted · opened · clicked · viewed · interested · not-interested · follow-up-later · no-action · applied · converted`

These are **not interchangeable**. They sit at different points on a causal chain:

```
eligible  →  targeted  →  sent/assigned  →  shown/contacted  →  reaction (open/click/view/interested/...)  →  applied  →  converted
            (selection)   (delivery)        (exposure)          (response)                                    (outcome)
```

Every channel observes a **different, often truncated, slice of this chain.** The two failure modes this map is designed to prevent:

1. **Conflation** — treating a targeted/sent record as if it were a reaction (or vice versa). This corrupts both the sequence event vocabulary and the labels.
2. **Implicit-negative error** — reading "no row for customer × channel" as "customer was offered this channel and did not respond," when in many channels it actually means "we never observed whether this customer was eligible, targeted, or exposed at all."

A transformer over journeys is *especially* exposed to both failures, because it consumes the event vocabulary directly and learns from the structure of presences and absences. Asymmetry that a flat tabular model can paper over becomes a learned bias in a sequence model.

**Conventions used below:**
- **Observed** = a row exists whose semantics are directly recorded.
- **Inferred** = the state is not directly logged but can be assigned with stated probability (must be flagged as inferred, never as observed truth).
- **Not observed** = no record; absence is uninformative or ambiguous.
- **(validate)** = a working assumption from the tech-lead update that has not been confirmed against the data.

---

## 1. Master observability table

This is the per-channel core. Read it as: *for this channel, where on the causal chain does observation start, and where does it stop?*

| Channel | Group | Event nature today | Targeted universe addable? | Exposure directly observed? | Contact directly observed? | Reaction observed? | No-action observed? | Opt-out / eligibility signal? | Earliest clean exposure point |
|---|---|---|---|---|---|---|---|---|---|
| **Branch (inbound)** | Inbound | reaction-only (interested / not-interested / follow-up-later) | **No** (not currently possible) | No | No (employee-mediated; not logged as contact) | Yes (only when offer presented) | **No** (no-present → no row) | Eligibility not observed | Reaction only |
| **Phone (inbound)** | Inbound | reaction-only (same three states) | **No** | No | No | Yes (only when presented) | **No** | Eligibility not observed | Reaction only |
| **Mobile (app)** | Inbound | exposure-like: offers shown/loaded + no-action | **No separate** universe; shown ≈ targeted (validate) | **Yes** (shown/loaded) | n/a (digital surface) | Yes (action on shown offer) | **Yes** (shown + no-action) | Eligibility ≈ "was shown" | Shown/loaded |
| **Web** | Inbound | exposure-like: offers shown/loaded + no-action | **No separate**; shown ≈ targeted (validate) | **Yes** | n/a | Yes | **Yes** | Eligibility ≈ "was shown" | Shown/loaded |
| **Email** | Outbound | reaction-only today (opened/clicked) | **Yes** — full **sent** universe likely addable | **Sent = exposure proxy** once added (today: no) | n/a (delivery, not contact) | Yes (open/click) | **Only after sent added** (sent + no-open) | **Opt-out** signal exists (month granularity likely) | Sent (once integrated) |
| **Direct mail (DM)** | Outbound | reaction-only (applied via EasyApply URL/QR) | **Yes** — full **sent** list likely addable | **Sent = exposure proxy** once added (today: no) | n/a | Yes (applied only — a deep reaction) | **Only after sent added** | None known | Sent (once integrated) |
| **Leads** | Outbound | contact (phone-contacted) | **Yes** — full **assigned** list likely addable | Assigned ≈ exposure (validate) | **Inferred**: ~95–97% of assigned are contacted | Partial (contact logged; downstream response varies) | After assigned added (assigned − contacted) | None known | Assigned (once integrated); contact inferred |
| **OBTM** | Outbound | targeted/list only; **no reaction** | **Yes** — full **targeted** list addable | Targeted is the only signal | **Inferred**: most assigned probably contacted (weaker than leads) | **No** (reaction unavailable) | Implicit only (targeted, no outcome link) | None known | Targeted |
| **Paid search** | Digital | reaction/exposure: click only | No clean universe; all-Canada proxy (validate, weak) | Click ≈ exposure+reaction fused | n/a | Yes (click) | **No** (no impression log) | None | Click |
| **SEO** | Digital | reaction/exposure: click only | No clean universe; all-Canada proxy (validate, weak) | Click only | n/a | Yes (click) | **No** | None | Click |
| **Display** | Digital | exposure + reaction: view + click | No clean universe; all-Canada proxy (validate, weak) | **Yes** (view) | n/a | Yes (click) | View-without-click ≈ no-action | None | View |

### How to read the asymmetry

The decisive column is the last one — **earliest clean exposure point** — combined with **no-action observed**. It sorts the channels into three observability tiers:

- **Tier A — exposure + non-response both observed (richest):** Mobile, Web, Display. A clean "shown but no action" exists, so absence-of-reaction is *informative*. These are the channels where exposed-vs-unexposed contrasts are most defensible.
- **Tier B — exposure becomes observable once the fuller universe is integrated:** Email (sent), DM (sent), Leads (assigned). Today truncated to reactions/contact; the "sent/assigned" join is the unlock that creates an observed non-response set.
- **Tier C — exposure never cleanly observed:** Branch, Phone (reaction-only, no eligible/presented universe); Paid search, SEO (click fuses exposure and reaction, no impression log); OBTM (targeted only, *no* reaction at all — the inverse truncation).

OBTM is the odd one out: it is the only channel observed at the *top* of the chain (targeted) with nothing downstream, while branch/phone/digital are observed at the *bottom* (reaction) with nothing upstream. They fail the contrast for opposite reasons.

---

## 2. Per-channel detail: bias, missingness, and sequence implications

For each channel: what the missingness *is*, the bias it creates, and what it means for transformer **sequence construction** specifically.

### 2.1 Inbound branch / phone (reaction-only)

- **Observed:** customer reacted to a presented offer (interested / not-interested / follow-up-later).
- **Not observed:** the eligible population, who walked in / called, which customers had an offer *available* to present, and crucially every case where an employee did **not** open the offer workflow. No-present → no row.
- **Bias created:** **selection on presentation.** The presented set is filtered by branch staff behavior (who they judged worth pitching, time pressure, training). The "not-interested" rows are conditioned on having been pitched — they are not a random sample of non-responders. There is **no clean negative class**: the absence of a branch event does not mean "offered and declined," it means "we never saw whether anything happened."
- **Sequence implication:** branch/phone events should enter the sequence **only as positive reaction events**, never as implied negatives. A missing branch token must be encoded as *unobserved*, not as *no-action*. Do **not** synthesize branch "non-events." Because presentation is staff-mediated and unlogged, branch/phone cannot anchor an exposed-vs-unexposed contrast and should be excluded from any uplift/positivity analysis for those channels.

### 2.2 Inbound mobile / web (exposure-like)

- **Observed:** offers shown/loaded, plus no-action — i.e., both exposure and non-response.
- **Not observed:** a *separate* targeted universe (the decision logic upstream of "show"); whether "shown" exactly equals "intended-to-target."
- **Bias created:** mild relative to other channels. The main risk is that "shown" is itself an algorithmic/eligibility-filtered event (the app decided to surface the offer), so it is an **exposure under the app's own targeting policy**, not a random exposure. Still, because non-response *is* observed, this is the cleanest inbound signal.
- **Sequence implication:** these are the **best-behaved tokens** — they support a genuine `shown → {action, no-action}` mini-structure inside the sequence. Treat `shown` and `no-action` as distinct event types. The assumption **shown ≈ targeted** (validate) is acceptable as a working approximation *for these two channels only*; it must not be generalized to digital or branch.

### 2.3 Email (outbound)

- **Observed today:** opened / clicked only (reaction-only).
- **Addable:** the full **sent** universe — this is the highest-value integration, because it converts email from reaction-only (Tier B truncated) into exposure+non-response (Tier A-like).
- **Opt-out:** a **separate** signal exists, likely at **month** granularity (exact date possibly missing).
- **Bias created (today, before sent is added):** severe survivorship — only engagers are visible, so email looks artificially effective and the non-engaged majority is invisible. This is a documented driver of the DM≫Email imbalance and the unrealistic channel mix (OQ2, C9).
- **Sequence implication:** once **sent** is integrated, email gains a proper `sent → {opened, clicked, no-open}` structure and a real negative (sent, not opened). **Opt-out must enter as a state-change / eligibility event, not as a reaction and not as a label.** Specifically: opt-out marks the customer as **ineligible for email exposure from that month forward**; sequence events of type `email_sent` after the opt-out month are inconsistent and must be reconciled (treat post-opt-out as no-send eligibility, and censor email exposure rather than counting silence as non-response). Because opt-out is month-granular, align it to the **month boundary** and treat the opt-out month itself as ambiguous (see §4 on opt-out handling).

### 2.4 Direct mail (outbound)

- **Observed today:** only customers who applied via EasyApply URL/QR — i.e., a **deep reaction (applied)**, the most truncated outbound signal of all. Historical MTA DM is effectively empty; DM currently comes via TMIA only (OQ2).
- **Addable:** the full **sent** list.
- **Bias created (today):** extreme. Observing only appliers means the DM table is essentially a positive-only outcome table masquerading as a touchpoint table. Any model fed this without the sent universe will read DM as enormously effective — a pure collection artifact.
- **Sequence implication:** **do not treat the current DM rows as exposure events.** They are `applied` events (near-outcome). Until the **sent** universe is joined, DM cannot contribute a usable exposure token or a negative class; it can only contribute a late-stage positive. Once **sent** is added, DM behaves like email (`sent → {applied, no-apply}`), but note the reaction observed is `applied` (much deeper in the funnel than open/click), so DM's non-response set will be very large and its positive set very small — a strong class-imbalance and label-horizon consideration.

### 2.5 Leads (outbound)

- **Observed today:** customers contacted by phone.
- **Addable:** the full **assigned** list.
- **Inferred:** ~95–97% of assigned leads are contacted → contact can be **inferred** for most assigned records, but must be flagged as inferred.
- **Bias created:** modest if assigned is added; the ~3–5% assigned-but-not-contacted gap is small but non-ignorable for any contact-conditioned analysis. Today (contact-only) there is mild survivorship on the contact step.
- **Sequence implication:** distinguish **assigned** (observed once integrated) from **contacted** (mostly inferred). Encode an `assigned` event and a separate `contacted` event with an **inferred-contact flag**. Do not collapse assigned into contacted. For sequence modeling the assigned event is the defensible exposure anchor; contacted is a high-probability-but-imputed refinement. The ~95–97% rate is a population statistic, not a per-customer truth — never hard-label an individual assigned record as contacted without the flag.

### 2.6 OBTM (outbound)

- **Observed:** the **targeted / list** universe only.
- **Not observed:** any reaction (none available) and **direct contact** (most assigned *probably* contacted — inferred, and more weakly than leads).
- **Bias created:** OBTM is exposure-without-outcome. There is no observed response, so OBTM can never, on its own, supply a label or a reaction event. Its contact inference is weaker than leads (no stated 95–97% anchor — "probably").
- **Sequence implication:** OBTM contributes a `targeted` (and optionally inferred-`contacted`) event with **no reaction token and no per-channel label**. It is useful as **context / exposure history** that may explain downstream conversion on *other* channels, but it cannot be a prediction target itself. Flag inferred contact explicitly and weight OBTM-contact inference as lower-confidence than leads.

### 2.7 Digital — paid search / SEO / display

- **Observed:** paid search and SEO = **click only** (exposure and reaction fused into one event); display = **view + click** (so display alone has a non-response signal: viewed-not-clicked).
- **Not observed:** a clean targeted universe. The only candidate is the **all-Canada proxy** (treat the whole addressable population as "targeted") — explicitly weak and to be validated/decided, not confirmed.
- **Bias created:** for paid search / SEO, clicks are **self-selected** — they are customers who already searched and chose to click, i.e., high pre-existing intent. Reading clicks as exposure massively overstates effect (the click *is* the response). No impression log means no non-response set. Display is better (views give a non-response baseline) but still has no clean targeted universe.
- **Sequence implication:** paid search / SEO clicks are **reaction events with no exposure counterpart** — encode them as reactions, never as exposures, and never infer "not-clicked = not-exposed." Display view/click can support a `view → {click, no-click}` micro-structure. Do **not** use the all-Canada proxy as a targeted universe inside the sequence event vocabulary without separate validation; if used at all, it belongs in a separate, clearly-labeled design (see targeted-universe analysis §3), not mixed into reaction records.

---

## 3. Targeted-universe options analysis

The central design question: **for which channels, and how, should a fuller (targeted/sent/assigned) universe be added?** Below, each option from the brief is evaluated on what it buys, what it costs, and where it breaks. The non-negotiable constraints first:

- **Do not treat targeted records as reactions.** A `sent`/`assigned`/`targeted` row is exposure-or-earlier; conflating it with `opened`/`clicked`/`interested` fabricates response signal.
- **Do not treat all of Canada as a clean digital targeted universe.** The all-Canada proxy is a weak, unvalidated approximation, acceptable only as an explicitly-flagged separate analysis, never as a confirmed targeted set inside the main sequence data.
- **For OBTM and leads, distinguish assigned from contacted** when contact is inferred rather than directly observed.
- **For mobile/web, shown ≈ targeted is plausible but must be validated**, and applies only to those two channels.
- **Email opt-out enters as an eligibility/state event, not a reaction and not a label.**

### 3.1 Option comparison

| Option | What it does | Pros | Cons / risks | Verdict |
|---|---|---|---|---|
| **(a) Keep reaction-only data** | Use only what is observed today (opens/clicks/applied/contacted/interested) | Zero integration cost; all events are directly observed (no inference) | Severe survivorship bias (esp. email, DM); no negative class for outbound; no exposed-vs-unexposed contrast; transformer learns a response-conditioned, not population, process | **Insufficient alone.** Acceptable only as a fallback or as one explicitly-biased view; cannot support uplift or honest no-action modeling |
| **(b) Add targeted universe for email, DM, leads, OBTM where available** | Join sent/sent/assigned/targeted universes to existing reactions | Creates observed non-response for email/DM/leads; enables exposed-vs-unexposed for outbound; fixes the DM/email mix artifact | Integration + reconciliation work; introduces inferred contact (leads/OBTM); makes data **asymmetric** vs inbound/digital; OBTM still has no reaction | **Primary recommended direction**, with asymmetry made explicit |
| **(c) Add targeted universe only as explicit event stages** | Add `sent/assigned/targeted` strictly as distinct event types in the sequence, never merged with reactions | Preserves the causal-chain semantics cleanly; transformer sees the funnel structure; no conflation | Requires disciplined event schema + per-channel availability map; more event types to encode | **Recommended implementation of (b)** — this is *how* (b) should be done |
| **(d) Separate datasets by channel observability quality** | Build distinct datasets per tier (Tier A exposure+response; Tier B once-integrated; Tier C reaction/targeted-only) | Each dataset has internally consistent semantics; avoids forcing one schema onto incompatible channels; supports tiered evaluation | Fragmentation; a single transformer over all channels needs a unifying schema anyway; cross-channel journeys span tiers | **Use for evaluation and for causal/uplift slices**, not necessarily for the main sequence-encoder training set |
| **(e) Use only reliable exposure/treatment channels for causal/uplift evaluation** | Restrict any uplift/OPE estimate to channels with clean exposure + non-response (Tier A: mobile/web/display; Tier B once integrated: email/DM/leads) | Defensible positivity/overlap; honest causal contrasts; avoids branch/phone/SEO confounding | Narrows causal claims to a channel subset; cannot make uplift claims for branch/phone/paid-search/SEO/OBTM | **Strongly recommended for the causal/uplift lens** — the only honest path given the data |
| **(f) Keep digital/inbound reaction-only where no targeted universe exists** | Leave branch/phone/paid-search/SEO as reaction-only; don't fabricate universes | Honest about what is unobservable; no invented negatives | These channels then can't support uplift/exposure analysis (accepted limitation) | **Recommended** — pairs with (e); reaction-only channels stay predictive-context only |

### 3.2 Recommended composite

The options are not mutually exclusive. The defensible composite:

1. **Integrate fuller universes for email (sent), DM (sent), leads (assigned), OBTM (targeted)** — option (b) — **as explicit event stages** — option (c).
2. **Keep inbound branch/phone and paid-search/SEO reaction-only** — option (f) — and encode their absences as *unobserved*, never as no-action.
3. **Treat mobile/web/display as the Tier-A exposure channels** (shown/view + no-action observed), with shown ≈ targeted validated for mobile/web only.
4. **For any causal/uplift or off-policy work, restrict to the reliable-exposure subset** — options (e) — and build **separate evaluation datasets by observability tier** — option (d).
5. **Make the asymmetry explicit everywhere:** a per-channel event-availability map travels with the dataset so that "absence of a token" is interpreted per channel, not globally.

### 3.3 Email opt-out — exactly how it should and should not enter

- **Should:** as an **eligibility state-change event** at month granularity. From the opt-out month forward, the customer is **ineligible for email exposure**; email non-events after that point are *structural* (we would not send), not behavioral non-response. Use opt-out to **censor** email exposure/label windows, and optionally as a (lagged, coarse) engagement-decline feature.
- **Should not:** as a **reaction** (it is not a response to a specific send), as a **label/outcome** (opting out is not a conversion signal for the offer), or at false precision (do not assign a day when only the month is known — align to the month boundary and treat the opt-out month as ambiguous).

### 3.4 Inferred contact — leads vs OBTM

| | Leads | OBTM |
|---|---|---|
| Top-of-chain observed | assigned (once integrated) | targeted |
| Contact | **inferred**, ~95–97% of assigned | **inferred**, "most probably" (no rate anchor) |
| Reaction | partial (contact logged; response varies) | **none** |
| Encoding | `assigned` event + `contacted` event with **inferred-contact flag** (high confidence) | `targeted` event + optional `contacted` with **inferred-contact flag** (low confidence) |
| Use as label target? | Cautiously, contact-conditioned, with flag | **No** — exposure/context only |

Never hard-code an individual record's inferred contact as observed. Carry a confidence/inferred flag so downstream evaluation can subset to observed-only when rigor demands it.

---

## 4. Temporal observability asymmetry (propensity-score gap)

A second, orthogonal asymmetry sits *across time*, not across channels:

| Signal | Coverage | Gap |
|---|---|---|
| Customer touchpoints | **2022 → June 2026** | full history |
| Propensity (PRISM) scores | **Sept 2024 → June 2026 only** | **no score features before Sept 2024** |

Implications for the map:

- Any score-conditioned feature is **unavailable** for ~2.5 years of the earliest history. Sequence segments predating Sept 2024 have touchpoint events but no propensity context.
- This is a **missing-feature-by-time-period** problem, not a missing-channel problem. It interacts with window choice and label horizon (handled in `transformer_dataset_design_options.md`), but the observability fact to record here is: **the feature space is time-varying in availability**, and a sequence model must be told (via masking / availability flags) when scores are simply absent vs genuinely low.
- Do **not** backfill pre-Sept-2024 scores by imputation-as-truth; absence must be representable.

---

## 5. What this means for transformer sequence construction (summary of constraints)

These are the binding constraints any downstream sequence/dataset design must honor (carried forward into `transformer_dataset_design_options.md`):

1. **Distinct event types, never collapsed:** `targeted / assigned / sent / shown / contacted / opened / clicked / viewed / interested / not-interested / follow-up-later / no-action / applied / converted`. Conflation corrupts both the sequence and the labels.
2. **Per-channel event-availability map travels with the data.** "Absence of a token" means *not targeted*, *targeted-no-reaction*, *presented-no-action*, or *unobserved* — and which one differs by channel.
3. **No fabricated negatives.** Branch/phone/paid-search/SEO absences are *unobserved*, not no-action. Real negatives exist only where exposure is observed (Tier A, and Tier B once integrated).
4. **Inferred states are flagged, not laundered into observations.** Leads/OBTM contact, shown≈targeted, all-Canada proxy — all carry confidence flags.
5. **Opt-out is an eligibility/censoring event**, month-aligned, never a reaction or label.
6. **Time-varying feature availability.** Propensity scores exist only from Sept 2024; pre-period absence must be representable (masking), not imputed as truth.
7. **Causal/uplift work is restricted to the reliable-exposure channel subset** and to separate, tier-consistent evaluation datasets — never claimed across branch/phone/SEO/OBTM.

---

## 6. Channel observability scorecard (one-glance)

| Channel | Exposure obs. | Non-response obs. | Reaction obs. | Clean negative class? | Causal/uplift-eligible? | Sequence role |
|---|---|---|---|---|---|---|
| Mobile | ✅ shown | ✅ | ✅ | ✅ | ✅ (validate shown≈targeted) | full funnel token |
| Web | ✅ shown | ✅ | ✅ | ✅ | ✅ (validate) | full funnel token |
| Display | ✅ view | ✅ (view-no-click) | ✅ click | ✅ | ⚠️ no targeted universe | exposure+reaction token |
| Email | ⛔→✅ (sent) | ⛔→✅ (after sent) | ✅ open/click | after sent | ✅ once sent integrated | funnel token once integrated; opt-out censors |
| DM | ⛔→✅ (sent) | ⛔→✅ (after sent) | ✅ applied (deep) | after sent | ✅ once sent integrated | sparse positive; fix sourcing first |
| Leads | ✅ assigned (once integrated) | partial | ✅ contact | partial | ✅ (assigned-anchored, contact inferred) | assigned + inferred-contact tokens |
| OBTM | ✅ targeted | implicit | ⛔ none | ⛔ | ⛔ (no reaction) | context/exposure only, no label |
| Branch | ⛔ | ⛔ | ✅ (if presented) | ⛔ | ⛔ | positive reaction only; absence = unobserved |
| Phone (inbound) | ⛔ | ⛔ | ✅ (if presented) | ⛔ | ⛔ | positive reaction only; absence = unobserved |
| Paid search | ⛔ (click fuses) | ⛔ | ✅ click | ⛔ | ⛔ | reaction-only token |
| SEO | ⛔ (click fuses) | ⛔ | ✅ click | ⛔ | ⛔ | reaction-only token |

Legend: ✅ observed/eligible · ⚠️ partial/with caveat · ⛔ not observed/not eligible · ⛔→✅ unlocked once the fuller universe is integrated.

---

*Sources: `01_current_state/current_snapshot.md` (Data Observability by Channel, Data Scale layers); `01_current_state/open_questions.md` (§Data Observability & Universe Construction, OQ48–56); `02_change_log/2026-06-20_data_observability_update.md` (primary, source-of-truth); `02_change_log/2026-06-16_data_scale_correction.md` (four-layer scale). Optional background reconciled, not relied on: `04_outputs/transformer_design_input_snapshot.md`, `04_outputs/model_options_map_for_human_review.md`, `03_research_memory/production_score_contract_options.md`. No new external research; no facts invented; inferred/unvalidated items flagged.*
