# Transformer-Ready Dataset Design Options — Lumen AI

**Date:** 2026-06-21
**Scope:** Deep methodology review, chat 3b. Defines candidate **dataset designs** (not model architectures) for a transformer/sequence model, given the corrected data-observability reality, and the train/validation/test separation principles that must govern them.
**Status:** Research memory. **Does not** pick a final architecture, does not optimize for a 2–4 week MVP, does not force a single evaluation method. The transformer/sequence direction is assumed (confirmed elsewhere); this file constrains the data the model is built on.

**Reads with:** `data_observability_map.md` (companion, this folder). Every design below inherits its constraints — distinct event types, no fabricated negatives, flagged inferred states, opt-out as eligibility/censoring, time-varying feature availability, causal work restricted to reliable-exposure channels.

**Authority:** `02_change_log/2026-06-20_data_observability_update.md` and `01_current_state/` govern. Counts approximate (four-layer view, `02_change_log/2026-06-16_data_scale_correction.md`): full source ≈10–15M customers since ≈2022; Layer-4 cleaned dataset does not exist yet.

---

## 0. Shared building blocks (used by all designs)

Before the designs, the primitives they all reuse.

### 0.1 Canonical event schema (the sequence vocabulary)

Each event in a customer journey is a tuple. The vocabulary is the load-bearing object; it is what prevents conflation.

```
event = (
  timestamp,                 # event time; granularity varies by channel (validate, OQ28)
  channel,                   # branch | phone | mobile | web | email | dm | leads | obtm | paid_search | seo | display
  event_type,               # targeted | assigned | sent | shown | contacted | opened | clicked | viewed
                            #   | interested | not_interested | follow_up_later | no_action | applied | converted
  funnel_stage,             # derived: selection | delivery | exposure | response | outcome
  observed_flag,            # observed | inferred  (leads/OBTM contact, shown≈targeted → inferred)
  confidence,               # for inferred events: e.g. leads-contact ~0.96; OBTM-contact ~"probable"; else 1.0
  channel_obs_tier,         # A (exposure+nonresponse) | B (unlocked-by-integration) | C (reaction/targeted-only)
  score_context_available,  # 1 if PRISM scores exist for this period (>= Sept 2024), else 0
)
```

Static, per-customer context (not part of the sequence): ~10 PRISM scores (**only valid Sept 2024+**), credit-card indicator, and any stable demographics. PRISM scores are themselves time-stamped monthly and may be treated as static (latest-as-of) or as a slow time-varying side channel.

### 0.2 The candidate-action representation (when a design has a head)

Where a design scores actions, the **candidate channel/action is an INPUT**, never a fixed output head (per D010 elsewhere). Single channel = size-1 action; sets/sequences via compositional encoding are deferred (V2). This file does not mandate a head — designs range from representation-only to action-conditioned.

### 0.3 Three absence semantics (must be encodable)

A missing `(customer, channel, period)` token is one of:
- **not-eligible / not-targeted** (e.g., post-opt-out email; never in a targeted universe),
- **targeted/exposed but no reaction** (a *real* negative — only where exposure is observed),
- **unobserved** (branch/phone not-presented; paid-search/SEO no impression log).

Every design must carry per-channel availability metadata so these three are never collapsed into one "0."

---

## 1. Dataset design options

Five designs, ordered roughly from most conservative (observed-only) to most ambitious (full integrated funnel). They are **not** mutually exclusive — D1/D2 can be subsets or ablations of D3. For each: unit, observation window, label window, event schema notes, candidate-action schema, label, negatives, propensity-leakage handling, observability handling, and the learn/can't-learn boundary.

---

### Design D1 — Reaction-only sequence (observed-events-only)

The minimal, fully-observed dataset: only directly-observed events, no integrated universes, no inferred states.

| Field | Specification |
|---|---|
| **Unit of training example** | One customer's reaction-event sequence up to an index time `t`, paired with a forward outcome. |
| **Observation window** | All observed reaction events in `[2022, t]` (full history; no exposure backbone). |
| **Prediction/label window** | `(t, t + H]` for a fixed horizon `H` (e.g., 30/60/90 days — chosen from journey profiling, OQ25/30). |
| **Sequence event schema** | Reaction/exposure tokens only: opened, clicked, viewed, interested, not_interested, follow_up_later, applied, plus mobile/web `shown`+`no_action` (these are observed today). **No** sent/assigned/targeted tokens. |
| **Candidate action schema** | Optional. If action-conditioned: single channel as input, restricted to channels with observed reactions. |
| **Label definition** | Conversion (application/booking) within `H`, or next-touch reaction, depending on the eval question. |
| **Negative example definition** | **Only** where genuinely observed: mobile/web/display `shown`/`view` → no_action. **No fabricated negatives** for email/DM/branch/phone/SEO. |
| **Propensity-score (Sept-2024+) inclusion w/o leakage** | Use only PRISM scores effective **on or before `t`** (`score_context_available=1`); mask scores for pre-Sept-2024 segments; never use a score dated after `t`. |
| **Observability handling** | Pure Tier-C/A-reaction view; absence is `unobserved` everywhere except mobile/web/display. |
| **Can learn** | Response-conditioned patterns: given a customer is reacting, what predicts conversion; recency/sequence of engaged touches; a ranking signal among *engaged* customers. |
| **Cannot learn** | Anything about the non-engaged population (survivorship); true exposure→response rates; uplift; honest no-action behavior for outbound; channel effectiveness on the population. |

**Use:** a clean, low-risk baseline dataset and a sanity floor; honest about its survivorship limits. **Not** a basis for any causal or population claim.

---

### Design D2 — Exposure-anchored sequence for integrated channels (Tier A + Tier B once integrated)

Adds the fuller universes for email (sent), DM (sent), leads (assigned), and keeps mobile/web/display exposure — i.e., the channels where a real negative class exists or is unlocked. Excludes OBTM-as-target-only and reaction-only channels from the *labelable* core.

| Field | Specification |
|---|---|
| **Unit of training example** | One customer's **exposure-anchored** event sequence up to `t`, paired with forward outcome. An "exposure anchor" = a sent/assigned/shown/view event. |
| **Observation window** | `[2022, t]`; exposure backbone from integrated universes where available (email sent / DM sent / leads assigned once integrated), plus mobile/web/display exposure throughout. |
| **Prediction/label window** | `(t, t+H]`. For DM (reaction = `applied`, deep funnel) consider a **longer** `H` than for email (open/click). Label horizon may differ by channel — record per-channel. |
| **Sequence event schema** | Full funnel tokens for integrated channels: `sent/assigned → {opened/clicked/contacted/applied, no_action}`; mobile/web/display `shown/view → {action, no_action}`. Inferred `contacted` (leads) carried with `observed_flag=inferred`, `confidence≈0.96`. |
| **Candidate action schema** | Action-as-input, restricted to channels with an exposure anchor (email, DM, leads, mobile, web, display). |
| **Label definition** | Exposure-conditioned response/conversion within `H`: among exposed, did the customer respond/convert. |
| **Negative example definition** | **Real negatives now exist:** exposed (sent/assigned/shown) with no response in `H`. This is the key gain over D1. Opt-out **censors** email exposure (no negatives manufactured after opt-out month). |
| **Propensity-score inclusion w/o leakage** | Scores effective ≤ `t` only; mask pre-Sept-2024; for exposure events whose period predates Sept 2024, `score_context_available=0` (do not impute). |
| **Observability handling** | Tier A + integrated Tier B. Reaction-only channels (branch/phone/SEO/paid-search) and OBTM enter **only as context tokens**, never as labelable anchors. Inferred contact flagged. |
| **Can learn** | Exposure→response on the channels where exposure is observed; honest non-response patterns; the structure that supports defensible (channel-restricted) uplift/OPE later. |
| **Cannot learn** | Exposure effects for branch/phone/SEO/paid-search/OBTM (no clean exposure); population effects beyond the integrated channels; anything DM-positive-rich until sourcing is fixed (OQ2). |

**Use:** the **recommended primary training dataset** for any design that wants honest negatives and a path to causal-restricted evaluation. This is the composite recommendation from the observability map operationalized.

---

### Design D3 — Targeted-universe-as-explicit-stages (full asymmetric funnel)

The most complete view: integrate **all** addable universes (email sent, DM sent, leads assigned, **OBTM targeted**) as explicit funnel-stage events, keep reaction-only and digital as context, and let the transformer see the entire asymmetric funnel — with the asymmetry encoded, not hidden.

| Field | Specification |
|---|---|
| **Unit of training example** | One customer's **full funnel** event sequence up to `t` (all channels, all observed stages), paired with forward outcome(s). |
| **Observation window** | `[2022, t]`, all channels. OBTM contributes `targeted` (+inferred `contacted`) with no reaction. |
| **Prediction/label window** | `(t, t+H]`; multi-horizon optional (next-touch + 30/60/90-day conversion). |
| **Sequence event schema** | The **full** vocabulary (§0.1), with `channel_obs_tier` and `observed_flag` on every token so the model can condition on observability. OBTM = targeted/contacted only; branch/phone = reaction-only; digital per channel. |
| **Candidate action schema** | Action-as-input across the controllable channels; OBTM scoreable as exposure-context but **not** as a reaction target. |
| **Label definition** | Overall conversion within `H` (channel-agnostic outcome), and/or per-channel exposure-conditioned response where exposure is observed. |
| **Negative example definition** | Per-channel and **per-tier**: real negatives for Tier A + integrated Tier B; `targeted-no-outcome` for OBTM is a weak/structural negative (flag, don't treat as behavioral non-response); reaction-only channel absence stays `unobserved`. |
| **Propensity-score inclusion w/o leakage** | As D2; the time-varying availability flag matters more here because the long full history is in scope. |
| **Observability handling** | **This is the design whose entire purpose is to make asymmetry explicit.** Every token carries tier + observed flags; the per-channel availability map is mandatory metadata. The transformer can learn channel-specific absence semantics *because they are encoded.* |
| **Can learn** | The richest representation: cross-channel journey structure, exposure history (incl. OBTM as context) predicting downstream conversion, channel-specific funnel dynamics — all while "knowing" which absences are informative. |
| **Cannot learn** | Still cannot manufacture causal contrasts where exposure is unobserved; OBTM reaction (none exists); pre-Sept-2024 score context. Asymmetry is *represented*, not *removed* — uplift still restricted to reliable channels. |

**Use:** the most expressive dataset for a **predictive/representation** transformer. Highest engineering cost (full integration + reconciliation), highest event-vocabulary discipline required. The asymmetry is a feature here (encoded), not a bug — but it does not license cross-channel causal claims.

---

### Design D4 — Per-observability-tier datasets (separated by channel quality)

Rather than one schema, build **parallel datasets** segmented by observability tier, each internally consistent. Operationalizes option (d) from the map.

| Field | Specification |
|---|---|
| **Unit of training example** | Per-tier customer-sequence: **Tier-A dataset** (mobile/web/display: exposure+non-response), **Tier-B dataset** (email/DM/leads once integrated), **Tier-C dataset** (branch/phone/SEO/paid-search reactions; OBTM targeted). |
| **Observation window** | `[2022, t]` within each tier's channels. |
| **Prediction/label window** | `(t, t+H]`, may differ per tier (Tier-A short next-action horizons feasible; Tier-C reaction-only). |
| **Sequence event schema** | Tier-homogeneous vocabularies — no mixing of exposure-rich and reaction-only semantics in one file. |
| **Candidate action schema** | Per tier; action-conditioning only where exposure exists (A, integrated-B). |
| **Label definition** | Tier-appropriate: A/B exposure-conditioned response; C reaction/context only. |
| **Negative example definition** | Clean within tier (A/B real negatives; C no fabricated negatives). |
| **Propensity-score inclusion w/o leakage** | Same ≤`t` rule per tier; time-availability flag per tier. |
| **Observability handling** | Asymmetry handled by **separation** rather than by in-schema flags. |
| **Can learn** | Within-tier models are cleanest; ideal for **evaluation** and for **causal/uplift on Tier A + integrated B only**; supports fair per-tier comparison of future designs. |
| **Cannot learn** | Cross-tier / cross-channel journey interactions are lost inside a single tier model (a customer's journey spans tiers). Needs a reconciliation/ensemble step to serve whole-journey decisions. |

**Use:** **best for evaluation and for the causal/uplift lens**; a useful companion to D2/D3 rather than the sole training set. The reliable-channel causal subset (option (e)) is naturally the Tier-A + integrated-Tier-B union.

---

### Design D5 — Reliable-exposure causal/uplift dataset (treatment-grade subset)

A deliberately narrow dataset built **only** from channels with defensible exposure + non-response, for the *causal/uplift/off-policy* lens — not the main predictive training set. Operationalizes options (e)+(f).

| Field | Specification |
|---|---|
| **Unit of training example** | An **exposure decision** unit: (customer state at exposure time, channel exposed, response in `H`) for reliable-exposure channels only. |
| **Observation window** | `[2022, t]` customer state; exposure events from mobile/web/display + integrated email/DM/leads. |
| **Prediction/label window** | `(exposure, exposure+H]` response/conversion. |
| **Sequence event schema** | Exposure-anchored, with the pre-exposure journey as the conditioning sequence; reaction-only/OBTM channels appear only as **pre-exposure context covariates**, never as treatments. |
| **Candidate action schema** | Treatment = the exposed channel; explicit `∅`/no-exposure baseline where a comparable unexposed set exists (Tier A: shown-vs-not within app logic; email: sent-vs-not in eligible population). |
| **Label definition** | Exposure-conditioned response/conversion within `H`. |
| **Negative example definition** | Exposed-no-response **and** a defensible unexposed comparison group (only where positivity/overlap hold — gated by profiling, OQ-overlap). |
| **Propensity-score inclusion w/o leakage** | Scores ≤ `t`; **here propensity is doubly sensitive** — used both as confounder adjustment and at risk of leakage; only Sept-2024+ segments are eligible for score-adjusted causal work, which **further restricts the causal window**. |
| **Observability handling** | Strictest: only channels passing the exposure + non-response + positivity bar. Branch/phone/SEO/paid-search/OBTM **excluded as treatments** (context only). |
| **Can learn** | Defensible (channel-restricted, assumption-laden) treatment-effect/uplift estimates and off-policy value — *with* explicit caveats; the honest basis for any incremental claim short of an experiment. |
| **Cannot learn** | Population-wide or cross-channel causal effects; any uplift for excluded channels; effects pre-Sept-2024 if score adjustment is required; **true incremental business uplift cannot be proven here without randomization or a defensible OPE design** — this dataset *enables* the attempt, it does not validate the claim. |

**Use:** the dataset for the **causal/uplift/OPE** evaluation questions in the evaluation framework. Narrow by design; rigor over coverage.

---

## 2. Design comparison at a glance

| | D1 Reaction-only | D2 Exposure-anchored (integrated) | D3 Full asymmetric funnel | D4 Per-tier datasets | D5 Reliable-exposure causal |
|---|---|---|---|---|---|
| Integration cost | none | medium | high | medium–high | medium (subset) |
| Real negatives | mobile/web/display only | yes (integrated channels) | yes + structural for OBTM | clean within tier | yes + comparison group |
| Survivorship bias | severe | low (integrated) | low (encoded) | low within tier | lowest (by construction) |
| Channel coverage | reactions only | integrated + Tier A | **all channels** | all, separated | **narrow** (reliable only) |
| Asymmetry handling | n/a (ignored) | excluded channels are context | **encoded in schema** | **separated** | excluded by design |
| Causal-eligible? | no | partially (restrict later) | no (predictive) | Tier A+B only | **yes (the purpose)** |
| Primary role | floor/sanity | **recommended training set** | richest predictive | **evaluation + causal subset** | **causal/uplift lens** |
| Leakage surface | low | low–medium | medium | low–medium | **high (propensity dual-use)** |

**Headline:** D2 is the recommended primary **training** dataset (honest negatives, manageable cost); D3 is the richest **predictive** option (full funnel, asymmetry encoded) when integration budget allows; D4/D5 are the **evaluation and causal** datasets. D1 is a floor/ablation. None of these decides the architecture — all are sequence-ready under the shared schema (§0).

---

## 3. Propensity-score leakage handling (cross-cutting, all designs)

The Sept-2024 score-onset gap is both a **missingness** problem and a **leakage** problem. Rules for including scores without leakage:

1. **As-of-`t` only.** For an example indexed at time `t`, use only PRISM scores with `effective_date ≤ t`. Never a score dated in the label window `(t, t+H]` — that is the classic target leak.
2. **Mask, don't impute, the pre-Sept-2024 gap.** Segments before Sept 2024 get `score_context_available=0`; the model sees a masked/absent score, not a fabricated value. Imputing a 2023 score from later data leaks future information backward.
3. **Watch the dual-use in D5.** When propensity is used for confounder adjustment *and* the model can see it, ensure the adjustment uses scores strictly pre-exposure and that the score is not a deterministic function of the treatment (the collinearity that broke the DR baseline, C1/C2). Treatment enters **only** through the action-input, never also as a journey/score feature.
4. **Window choice interacts with the gap.** A long observation window crossing Sept 2024 has mixed score availability; designs should either (a) use availability flags throughout, or (b) for the causal lens (D5), restrict to the Sept-2024+ window where score adjustment is valid, accepting reduced coverage.
5. **Opt-out is not a score.** Email opt-out (month-granular) enters as eligibility/censoring (see map §3.3), aligned to month boundaries, never as a leaked future feature.

---

## 4. Train / validation / test separation principles

Per the brief: **do not pick dates mechanically.** Reason from the problem first.

### 4.1 Why a naive random split is wrong here

- **The customer journey is time-dependent.** A random split scatters events from the same journey across train/test, leaking future touches into the past — the model sees a customer's later behavior at training time and is tested on their earlier behavior. This is the documented flaw in the current baseline's random 60/20/20 (OQ9, C6).
- **Propensity scores begin Sept 2024.** Any split that mixes pre- and post-Sept-2024 segments randomly creates train/test feature-availability mismatch and can leak the (later) score regime into (earlier) evaluation.
- **Touchpoints begin 2022; campaigns and channel policies change over time.** The targeting policy, channel mix, and even the observability (e.g., when the fuller universes get integrated) drift. A model evaluated on a random slice is judged on a blend of policy regimes it will not face at deployment.
- **Deployment is forward scoring.** The real use is: train on the past, score customers going forward. Evaluation must mimic that — **test on a future period the model could not have seen.**

### 4.2 Candidate split designs and tradeoffs

| Split design | How it works | Pros | Cons / when it breaks |
|---|---|---|---|
| **Time-based holdout (primary)** | Train on events ≤ `t_cut`; validate on `(t_cut, t_val]`; test on `(t_val, T]`. All of a customer's *features* come from ≤ split time; labels from after. | Mirrors deployment; no future→past leak; respects policy drift | Must choose `t_cut` so test reflects the *current* policy/observability regime; less data for the latest period |
| **Rolling-origin / expanding-window CV** | Multiple time-ordered folds, each training on past and testing on the next window; average over folds. | Robust estimate of forward performance; captures stability over time; uses the long history well | More compute; folds early in 2022–2024 lack score context (handle via availability flags) |
| **Customer-grouped + time split (combined)** | Split by customer *and* by time so no customer and no future period leaks; test = new-ish customers in a future window. | Strongest against both journey-leak and customer-leak; closest to "score next month's population" | Most conservative; smallest effective test set; must ensure enough labeled positives in the window |
| **Blocked split around policy changes** | Cut at known campaign/policy/observability-integration boundaries (e.g., before vs after the fuller-universe integration, or pre/post-Sept-2024 scores). | Evaluation reflects a *single coherent regime*; surfaces brittleness to policy change | Requires knowing the change dates; reduces within-block data |
| **Random 60/20/20 (current baseline)** | Shuffle rows. | Simple; maximal data | **Leaks future into past; not deployment-faithful; do not use for any predictive/causal claim** — retained only to reproduce the legacy baseline number |

### 4.3 Recommended separation principles

1. **Primary protocol: time-based holdout with a forward test window**, reflecting the most recent (current) policy + observability regime. Train ≤ `t_cut`, validate next, test latest.
2. **Add rolling-origin CV** for a stability estimate over time (directly serves the "calibration and stability over time" evaluation question).
3. **Combine with customer grouping** when the deployment question is "score customers we have not decisioned recently" — prevents both journey- and customer-level leakage.
4. **Block the Sept-2024 score boundary.** Either evaluate score-conditioned models only on the Sept-2024+ regime, or carry availability flags and report pre/post separately; never let the boundary leak.
5. **Respect observability-integration timing.** If the fuller universes are integrated mid-history, do not let post-integration exposure data leak into a pre-integration "no-exposure" interpretation. Treat integration as a regime boundary.
6. **The split is fixed before modeling** so the future transformer-vs-baseline comparison is fair and not circular (carried into the evaluation framework, OQ43).

---

## 5. What each design can and cannot learn (consolidated)

| Design | Strongest claim it can support | Claim it cannot support |
|---|---|---|
| D1 | Ranking among engaged customers; response-conditioned prediction | Anything population-level; uplift; non-engaged behavior |
| D2 | Honest exposure→response prediction on integrated channels; basis for restricted causal work | Effects for non-integrated channels; cross-channel causal effects |
| D3 | Richest cross-channel predictive representation with encoded asymmetry | Causal contrasts where exposure unobserved; OBTM reaction; pre-Sept-2024 score effects |
| D4 | Cleanest within-tier prediction; fair per-tier comparison; causal on Tier A+B | Whole-journey cross-tier interactions within one tier model |
| D5 | Defensible (assumption-laden, channel-restricted) uplift/OPE estimates | **True incremental business uplift without randomization or defensible OPE**; population/cross-channel causal effects |

**Standing caution (all designs):** observational data + a sequence model yields *prediction* and, at best, *assumption-laden treatment-effect estimates on a channel subset*. It does **not** yield proven incremental business uplift. That boundary is owned by the evaluation framework (`evaluation_framework_for_observational_journeys.md`) and by experiment design — not by any dataset choice here.

---

*Sources: `01_current_state/current_snapshot.md`; `01_current_state/open_questions.md` (OQ9, OQ25–30, OQ44, OQ48–56); `02_change_log/2026-06-20_data_observability_update.md`; `02_change_log/2026-06-16_data_scale_correction.md`; companion `data_observability_map.md`. Optional background reconciled, not relied on: `04_outputs/transformer_design_input_snapshot.md` (§11–14), `04_outputs/model_options_map_for_human_review.md`, `03_research_memory/production_score_contract_options.md`. No new external research; counts approximate; inferred/unvalidated items flagged.*
