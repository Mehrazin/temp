# Transformer — Practical Literature & Repo Scan (Consolidated)

**Date:** 2026-06-16
**Status:** Consolidated research memory. Merges the 2026-06-15 Chat-1 work (`transformer_sequence_modeling_review.md`, `transformer_implementation_plan.md`, `literature_notes.md`, `method_critiques.md`, `2026-06-15_method_review.md`) with the 2026-06-16 Chat-2 work (independent literature/repo scan, the lift-de-emphasis correction, and the output-contract review).
**This is a research package, not a final architecture.** It does not pick the model. Companion file: `production_score_contract_options.md` (the external interface). Evidence labels used throughout: **[ACADEMIC] [INDUSTRY] [CODE] [INTERPRETATION]**.

> **DATA-SCALE CORRECTION (2026-06-16b) — read §11 first.** Earlier sections assumed a "moderate / ~500K-customer" scale. That was wrong: **500K was the test/evaluation subset; the prototype trained on ~2–3M customers; the full source data (2022+) likely covers ~10–15M customers with rich touchpoints.** Statements in §1.2 and §7 that lean on "small/moderate volume" are **revised in §11**. The net change is narrow: scale is no longer a reason to expect mere parity with GBDT, and large-data approaches (pretraining, sequence encoders) become more attractive — **but raw availability is not sequence-readiness**, and journey richness per controllable channel remains unconfirmed.

## Framing (carried into every section)

- **Lift / uplift / CATE is NOT the default objective.** It entered Lumen historically through the diagnostic doubly-robust attribution work and was partially carried into the predictive version. For the transformer phase, the deployable output can be a **probability, ranking score, candidate-action score, expected value, or lift** — whichever the evidence and the business question justify.
- **Lift is also not rejected.** It remains one legitimate scoring objective, computable from the same scorer, worth keeping where it genuinely changes a decision (see §6).
- **The external output contract is separate from the internal model.** Design the interface first so the model family and the objective can both change without downstream re-engineering (see companion file).
- **Practicality gate:** prioritize what can be investigated or built in **2–4 weeks**; treat ordered multi-channel sequences and causal-policy optimization as options to assess for realism, not assumed V1 scope.

---

## 1. Consolidated Findings — Literature, Industry, Repositories

### 1.1 The structural insight both chats converged on

A "Lumen transformer" is **three stacked layers**, and the literature lives in three communities:

1. **Sequence/representation encoder** — turn the customer journey into a representation. *Mature, low-risk.*
2. **Action-conditioned scorer (head)** — score a candidate channel / set against that representation. *This is the part that does real work for Lumen.* It can be framed as **prediction** (P(conversion | history, action)), **ranking**, or **uplift** (score(A) − score(∅)) — the framing is a choice, not a property of the architecture.
3. **Decision / optimization layer** — turn scores into assignments under caps, eligibility, no-contact, objectives. *Solved separately in the optimization/bandit literature; reuse Lumen's existing constrained optimizer.*

**[INTERPRETATION] Both chats independently reached the same conclusion:** off-the-shelf recommender transformers and attribution models (LiDDA) give you layer 1 + next-item/credit prediction; they do **not** give you a causal head, and — the Chat-2 correction adds — **you do not necessarily need one.** A transformer's contribution is a better encoder/scorer; incremental uplift and causal validity come from the head framing and the *evaluation*, not from attention.

### 1.2 Does the data even favor a transformer? (the sober, convergent answer)

- **[ACADEMIC]** Tree ensembles still match or beat deep nets on typical tabular data at small/medium scale; transformers pull ahead mainly at **large scale + long, dense sequences** (Chat-1 §8: "When Do Neural Nets Outperform Boosted Trees," arXiv 2305.02997; discretized-tokenization wins at 600K entities/5M examples, arXiv 2603.07448).
- **[ACADEMIC]** Strongest single datapoint (Chat-2): **UpliftBench (2604.06123)** — an **S-Learner over gradient-boosted trees beats Causal Forest on the 13.98M-row Criteo uplift set** (Qini 0.376; top-20% captures 77.7% of incremental conversions). The existing GBDT/S-learner instinct is the genuinely strong baseline, not a naive one.
- **[ACADEMIC]** Closest fintech analogue: **TIMeSynC (Capital One, 2410.12825)** — an encoder-decoder transformer over multi-channel financial-services journeys predicting next intent/action, with time-aware attention. **But** it trains on **30M+ sequences / 500+ intents** (≈100× Lumen's ~500K customers), is a **prediction/recall** model not a causal one, and its lifts over a strong SASRec+tabular baseline are **modest (~+2–8% recall).** Excellent architecture template; *not* evidence a transformer beats GBDT at Lumen's scale.
- **[INTERPRETATION] Confirmed data context (Chat-1 §0.6), partially REVISED by §11:** bank journeys from 2022, low/uneven event frequency (digital frequent; Email/DM/Leads sparse), and the current model collapses an April–July snapshot into one flat XGBoost vector. The earlier add-on claim that this is "moderate volume" reflected the prototype/test slice, **not** the full source population (~10–15M customers) — see §11. The *richness/sparsity* concern stands (it depends on touches-per-customer, still unconfirmed); the *volume* concern is largely retired. Net: on short/sparse journeys a transformer may still only **match** XGBoost regardless of customer count, but at full scale with rich journeys it could genuinely win — richness, not headcount, is now the open question.

### 1.3 Encoders (layer 1) — mature, well-coded

- **[ACADEMIC/CODE]** SASRec (1808.09781, causal self-attention) and BERT4Rec (1904.06690, bidirectional/masked) are the canonical sequence recommenders; replicability studies (2207.07483, "Dross into Gold" 2309.07602) show BERT4Rec's edge over SASRec is **fragile and training-budget-dependent** → SASRec is the pragmatic default, don't over-invest in bidirectionality.
- **[ACADEMIC]** BST (Alibaba, 1905.06874) is the better marketing/CTR template — **learned time-gap embeddings** for irregular journeys. PinnerFormer (2205.04507) shows a reusable **batch** user embedding (fits a monthly scoring job). HSTU/Generative Recommenders (Meta, 2402.17152) is the scaled frontier — overkill for Lumen.

### 1.4 Action-conditioned heads & objective framings (layer 2)

- **Prediction-first (Chat-2 emphasis):** `P(conversion | history, candidate channel)` with the action as input — *is* the reusable scorer. **[ACADEMIC]** Action-as-input + top-k selection is precisely the Cao & Zhu NBA pattern (2108.08846, an RNN/RL precedent). Multi-task variants (conversion + next-channel + engagement) are well-trodden (**[ACADEMIC]** Huawei pairwise-ranking MTL 2406.02163; Tencent cross-task distillation 2202.09852; Pinterest DHEN 2504.08169).
- **Self-supervised pretraining (Chat-2 addition):** pretrain the encoder on **unlabeled** journeys (next-touch / masked-channel) then fine-tune for conversion/next-channel. **[ACADEMIC]** SRP4CTR (2407.19658) pretrains a sequential recommender to improve CTR; Abacus (2512.16581) self-supervised user/purchase modeling; Markovian Pre-Trained Transformer (2601.08275) shows pretraining aids transfer **with little labeled data** — relevant for sparse positive labels. BERT4Rec is itself masked-event modeling.
- **Uplift / causal (Chat-1 emphasis, now optional):** the rigorous sequence head is the Causal Transformer (2204.07258) / CRN (2002.04083) lineage with adversarial confounding balancing; multi-treatment via M³TN (2401.14426). Non-DL causal alternative that fits sparse censored data: **Causal Survival Forests** (grf, 2001.09887). All real but research-grade / data-hungry, and **none can prove incremental lift without an experiment** (D005).

### 1.5 Decision/optimization layer (layer 3) — keep separate, reuse the ILP

**[ACADEMIC]** A strong line treats "scores → assignment under budget/caps" as its own layer: Alibaba unified budget allocation (1902.01128), Meituan direct heterogeneous causal learning (2211.15728) and decision-focused causal learning (2407.13664), Kuaishou end-to-end under budget (2302.04477), differentiable-ILP incentive allocation (2408.11623). **[INTERPRETATION]** This supports D010/D011: keep the scorer and the policy/optimizer decoupled; caps, eligibility, no-contact, top-1/top-K live in the existing constrained optimizer, not in the model.

### 1.6 Repositories inspected / referenced (maturity judgments)

| Repo | Role | Maturity | Note |
|---|---|---|---|
| **[CODE] NVIDIA Transformers4Rec** | SASRec/XLNet encoder, NVTabular, Triton serving | **Production** | item-prediction framing; bolt on your head; GPU-oriented |
| **[CODE] pytorch-forecasting (TFT)** | TFT with static / observed / **known-future** typing (action = known-future slot) | **Mature** | best easy fit for "set the plan, read the outcome" |
| **[CODE] pytorch-tabular (FT-Transformer/TabTransformer)** | tabular transformer over engineered features + multi-hot action | Mature | easiest drop-in to today's XGBoost vector |
| **[CODE] Valentyn1997/CausalTransformer** | rigorous counterfactual head | **Research-grade** | datasets are cancer-sim/MIMIC-III; rewrite data layer; not a 2–4 wk drop-in |
| **[CODE] konstantinhess/G_transformer** | g-computation counterfactual over time | Research-grade | stretch causal track |
| **[CODE] Aman12x/UpliftBench** | Qini/AUUC/policy-sim/SHAP + GBDT meta-learner baselines | Lightweight, reproducible | adopt as the **eval harness + baseline** |
| **[CODE] grf** | `causal_survival_forest`, `causal_forest` | Mature | causal uplift on censored data; non-DL |
| **[CODE] RecBole / EconML / CausalML / scikit-uplift** | quick SASRec/BERT4Rec; DR/causal-forest; multi-treatment uplift + Qini | Mature | components, production-usable |

---

## 2. The Reconciliation: Chat-1 architecture + Chat-2 objective-neutrality

**[INTERPRETATION]** The two chats are not in conflict; they slot together:

- Chat-1's central design — **one core model where the proposed action (channel or set) is an INPUT, plus a thin process/optimizer layer** (D010) — is **objective-agnostic.** Chat-1 wrote its output as `uplift(A) = pred(A) − pred(∅)`; Chat-2's correction simply says the *default* output should be `score(A)` (a probability/ranking score), with `uplift(A)` as one optional derivation.
- The architecture, the action-as-input interface, the compositional set encoding for combos (A5 / Deep Sets / Set Transformer, 1810.00825), and the reuse of the constrained optimizer **all survive the relabeling unchanged.**
- The data-fit reality (short/sparse journeys) from Chat-1 and the GBDT-is-hard-to-beat evidence from Chat-2 both point to the **same MVP shape:** a tabular/temporal transformer (FT-Transformer or TFT) with the action as input, predictive output, benchmarked against a strengthened XGBoost baseline — *not* a sequence-rec encoder or a causal transformer first.

So the consolidated recommendation is **Chat-1's interface + Chat-2's objective + the contract file's external schema.**

---

## 3. Consolidated Implementation Paths (5 viable + cross-cutting primitive)

Scored for a **spike-grade** 2–4 week deliverable (a model + a fair comparison + a design decision), not a production model. Bracketed labels map to the prior chats' taxonomies.

### CP1 — Temporal-feature XGBoost, conditional channel score *(Chat-1 F0/P0; Chat-2 Path A) — baseline & floor*
- **Method:** stop collapsing the snapshot; engineer multi-window / RFM / recency / inter-touch-gap features over 2022+ history; XGBoost predicting `P(conversion | history, candidate channel)` with action as a feature. Reuse existing DR wiring + optimizer.
- **Data:** existing tables + timestamps. No new modality, no positivity prerequisites.
- **Difficulty:** Low. **Value:** High value-per-effort; **[ACADEMIC]** UpliftBench shows GBDT is the hard bar. **Risks:** doesn't satisfy the transformer mandate; ceiling limited if journeys are long/rich.
- **Repos:** XGBoost/LightGBM, EconML, scikit-uplift, UpliftBench eval. **2–4 wk:** **Yes.** Also unblocks the time-based holdout (C6).

### CP2 — Tabular/temporal transformer scorer, action-as-input *(Chat-1 A1 FT-Transformer / A2 TFT; Chat-2 R1) — MVP candidate*
- **Method:** FT-Transformer over engineered features, **or** TFT with the planned channel as a **known-future input**; output default = conversion probability/ranking score; uplift optional via difference. Combos via compositional set encoding. Feed scores to the existing config-driven ILP.
- **Data:** sequences + timestamps + channel taxonomy + conversion label; PRISM as static features. Needs journey-length/event-richness facts (§5) to choose TFT vs FT-Transformer.
- **Difficulty:** Medium. **Value:** Medium-high — satisfies the transformer mandate, the reusable-scorer requirement, and (via the contract) all flexible-output use cases; gives a genuine transformer-vs-GBDT comparison. **Risks:** may only **match** CP1 on accuracy at this scale (the honest expectation); set-pooled combo generalization unproven (OQ36).
- **Repos:** pytorch-forecasting (TFT), pytorch-tabular (FT-Transformer); Transformers4Rec if going sequence-native. **2–4 wk:** **Yes** (spike grade). **Eval:** predictive metrics primary (AUC/PR-AUC/calibration, NDCG/Recall@k) on a time-based holdout; Qini/AUUC only if an uplift objective is claimed.

### CP3 — Hybrid: transformer encoder → existing XGBoost/DR downstream *(Chat-2 R2/Path-9) — low-risk on-ramp / fallback*
- **Method:** train/pretrain an encoder; export journey embeddings; append to the existing tabular feature set; the **current XGBoost scorer + optimizer** consume them. Clean with/without-embedding ablation.
- **Difficulty:** Low–Medium. **Value:** High value-per-effort + **lowest compliance disruption** (reuses the existing approval lineage) + directly measures the transformer's marginal value. **Risks:** embedding may add little (itself a cheap, useful finding).
- **Repos:** any encoder + existing XGBoost/EconML stack. **2–4 wk:** **Yes, comfortably.**

### CP4 — Sequence-rec encoder + action-conditioned head *(Chat-1 A3 SASRec/BST; Chat-2 Path C) — conditional alternative*
- **Method:** SASRec/BST encoder (Transformers4Rec) → customer-state vector; small action-conditioned head (state ⊕ candidate-channel embedding → conversion); top-k.
- **Difficulty:** Medium-high. **Value:** Conditional — high **only if** journeys are long/dense; low if sparse (then CP1/CP2 dominate). **Risks:** sparse-journey degradation; cold-start on rare channels; more infra than CP2 for uncertain gain.
- **Repos:** Transformers4Rec, RecBole. **2–4 wk:** **Partial** — prototype yes, fair tuned comparison may slip.

### CP5 — Self-supervised pretraining / multi-task scorer *(Chat-2 R3/R5) — prediction-first stretch*
- **Method:** pretrain encoder on unlabeled journeys (next-touch/masked-channel) then fine-tune; and/or a shared encoder with heads for conversion + next-channel + engagement.
- **Difficulty:** Medium-High. **Value:** High in the sparse-label regime (regularizes a scarce conversion label; yields multiple downstream signals). **Risks:** scope creep; time-box pretraining.
- **Repos:** Transformers4Rec, RecBole; **[ACADEMIC]** SRP4CTR/Abacus/MPT. **2–4 wk:** **Partial.**

### CP6 — Causal / uplift head *(Chat-1 A4 Causal Transformer/G-Transformer + F2 Causal Survival Forest) — optional objective, stretch/deferred*
- **Method:** add a rigorous counterfactual head (Causal/G-Transformer) or, for sparse censored data, a **Causal Survival Forest** (non-DL); or simply emit S-learner `score(A) − score(∅)` from CP2 (cheap).
- **Difficulty:** High (rigorous DL) / Low (S-learner difference) / Medium (causal survival forest). **Value:** Conditional — see §6. **Risks:** research-grade code, healthcare→marketing transfer unproven, adversarial-training instability, new-architecture compliance.
- **Repos:** Valentyn1997/CausalTransformer, konstantinhess/G_transformer, grf. **2–4 wk:** S-learner difference yes; rigorous causal **no** (Week-4 pilot question only).

### Cross-cutting primitive — A5 set/Deep-Sets treatment encoder
Not a standalone path: the ~50-line permutation-invariant set-pooling component that makes CP2/CP4/CP6 score **arbitrary channel combos compositionally** (single channel = size-1 set), without enumerating 2^N. Build it once if combos are in near-term scope; otherwise defer (V2).

### Deferred (assess realism, not V1): ordered sequences & RL
Ordered multi-channel **sequences** and **sequential RL/bandit** decisioning (Chat-1 Family D, DRQN-attention; TPP for "when") are **V2/V3** — higher engineering + governance, and they introduce a timing/"when" dimension out of current scope. Keep the action representation and contract from foreclosing them, but do not build them in the spike.

| Path | Role | Effort | Beats GBDT accuracy? | 2–4 wk? |
|---|---|---|---|---|
| CP1 temporal-feature XGBoost | **Baseline / floor** | Low | (is the bar) | Yes |
| CP2 tabular/temporal transformer (action-in) | **MVP** | Med | Uncertain (likely match) | Yes (spike) |
| CP3 hybrid encoder → XGBoost | **Fallback / on-ramp** | Low–Med | Marginal, measurable | Yes |
| CP4 seq-rec encoder + head | Alt if journeys long | Med-high | Only if long/dense | Partial |
| CP5 pretraining / multi-task | Prediction-first stretch | Med-high | Possible at sparse labels | Partial |
| CP6 causal / uplift head | Optional objective / stretch | High (rigorous) | N/A (different goal) | No (rigorous) |

---

## 4. Recommended MVP Candidates

**Primary MVP — CP2 (tabular/temporal transformer, action-as-input, *predictive* output), benchmarked against CP1.** It honors the confirmed transformer direction (D004), realizes the reusable-scorer + config-driven-layer requirement (D010/D011) in one architecture, is buildable to spike grade on mature libraries, and produces the exact spike artifact: a fair transformer-vs-GBDT comparison on a **predictive** metric. By defaulting the output to a probability/ranking score (not uplift), it is checkable on a plain time-based holdout, has no positivity/confounding prerequisites (the very things currently broken in the data), and carries low D005/compliance risk. Uplift stays one line away (`score(A) − score(∅)`) if justified.

**Co-MVP / low-risk alternative — CP3 (hybrid encoder → existing XGBoost).** If GPU/library/data-prep friction threatens the timeline, CP3 still introduces a transformer while reusing the existing approval lineage and answering the cheap, management-relevant question: *does the transformer representation add anything over our current features?*

---

## 5. Fallback Options

- **CP3 (hybrid)** is the transformer-flavored fallback — keeps a transformer in the story, lowest compliance disruption.
- **CP1 (temporal-feature XGBoost)** is the floor — a materially improved, defensible model on the existing lineage; it is also the mandatory baseline, so the work is never wasted. **[ACADEMIC]** UpliftBench gives this real credibility.
- **Chat-1's lighter ladder** remains valid below the transformer: F2 **Causal Survival Forest** (if a causal objective is wanted on sparse censored data), F1 Markov/HMM and F3 GRU baselines.

---

## 6. Stretch Options & the Neutral Verdict on Uplift/CATE

**Stretch:** CP5 (self-supervised pretraining / multi-task) as the best *prediction-first* stretch; CP6 (rigorous causal head) as a **Week-4, time-boxed pilot question** — *does a confounding-adjusted counterfactual differ materially from the S-learner?* — paired with an EconML CausalForestDML / grf causal-survival-forest comparator. Combos (A5), ordered sequences, and RL are V2+.

**Should uplift/CATE be MVP, stretch, or deferred? → DEFERRED, kept as an optional objective.** Neutral assessment:
- **Keep lift when** the decision genuinely includes *whether to contact at all* (no-contact / "sleeping dogs"), budget is scarce enough to demand ranking by *incremental* return, or an **experiment** exists/will exist to validate it. Then the same scorer emits `score(A) − score(∅)` — no separate model.
- **Drop / postpone lift when** (mostly the current situation) the question is "which channel given we contact"; **overlap/positivity is poor and confounding severe** (the regime that produced the rank-deficient DR `zstat=-inf`), so causal estimates are unreliable and a prediction is the more honest output; or there is no experiment to falsify an offline uplift number.
- **Does causal framing materially help *this* MVP? [INTERPRETATION] No:** prediction accuracy is higher and *measurable*; for "which channel given contact," predicted-conversion ranking is decision-equivalent to uplift when the `∅` baseline is similar across channels (they diverge only at the contact margin); and a **calibrated probability is easier to validate and defend to compliance** than a causal estimate. Carry `score_type` + nullable CI columns so uplift can be added later free of re-engineering — but don't make it a structural assumption.

---

## 7. Evidence To Generate From Our Own Data (before committing)

Union of Chat-1 OQ25–31 / data-fit checklist and Chat-2 §7. These gate the architecture *and* the objective.

1. **Journey-length distribution** (touches/customer). The single biggest determinant. Mostly 0–2 touches → CP1/CP2(FT-Transformer); long/dense → CP2(TFT)/CP4 justified.
2. **Event richness & per-channel frequency** — distinct `channel×interaction` types; confirm Email/DM/Leads sparsity and the broken direct-mail sourcing (OQ2). Sparse controllable channels degrade every sequence model.
3. **Volume vs DL threshold** — **REVISED (§11):** ~500K is the *test set*; the prototype used ~2–3M customers and the full source likely ~10–15M (2022+). Confirm the population that survives cleaning into sequences (raw ≠ model-ready), not the test slice. At full scale, volume is within ~2× of TIMeSynC's 30M, not two orders below — volume is no longer the binding constraint; journey *richness* is.
4. **Timestamp quality/granularity** — needed for time-gap embeddings (BST) / TPP. Coarse timestamps erode the transformer's temporal edge.
5. **Combo support** — count distinct observed channel combinations + their conversion volume; whether enough exists to **hold out unseen combos** (gates A5/CP6 combos, OQ36).
6. **Overlap / positivity per channel** — gates *any* uplift estimate's defensibility; root of the current DR instability.
7. **Label horizon** — next-touch conversion vs long-term engagement (PinnerFormer-style); also whether it should be **time-to-event/censored** (Chat-1 C14/F2).
8. **Is timing/multi-step in product scope?** — decides whether TPP/RL (sequences, "when") are in or out.
9. **Evaluation design, fixed up front** — adopt a **time-based holdout** (not the current random split, C6); choose **predictive metrics as primary** (AUC/PR-AUC/calibration, NDCG/Recall@k); use **Qini/AUUC + IPS/DR-OPE with CIs only if an uplift business claim is on the table.** Reuse UpliftBench's metric code. **[INTERPRETATION]** Decide this *before* modeling so the transformer-vs-baseline comparison is fair and not circular.

---

## 8. What To Avoid Overengineering (union of both chats)

1. **No from-scratch transformer.** Use TFT/Transformers4Rec/pytorch-tabular; spend the spike on the head + evaluation, not on reimplementing attention.
2. **No bidirectional/BERT4Rec sophistication chase.** Its edge over SASRec is fragile and budget-dependent.
3. **No 2^N combo enumeration / pre-trained per-combo heads.** Action(s) as an input via set encoding; combos are a hook, not V1.
4. **No caps/eligibility/no-contact/objectives inside the model.** They belong in the config-driven ILP layer (D010/D011), well-supported by the allocation literature.
5. **No Causal Transformer / decision-focused learning as V1.** Rigorous causal heads are a Week-4 pilot; healthcare→marketing transfer is unproven.
6. **Don't claim uplift from AUC/recall.** A better Recall@k (TIMeSynC-style) is not incremental business value. Hold D005: any uplift *claim* needs Qini/AUUC + defensible OPE on a time-based split.
7. **Don't let "transformer" become the goal.** The goal is a reusable, decision-useful scorer. If §7 shows short/sparse/small-scale data, the honest result may be "CP1/CP3 is sufficient now; revisit the transformer as data depth grows" — a legitimate, valuable finding.
8. **Don't lock into one model family.** Build to the external scoring contract (companion file) so any of CP1–CP6 can be swapped without downstream change.
9. **Don't anchor on lift** (the Chat-2 correction) — *or* on prediction. The objective is a decision the design agent makes from the data, not a default.

---

## 9. Caveats On This Consolidation

- Repo maturity judgments are from inspecting structure/READMEs; version/GPU compatibility against TD's Databricks/Azure is unverified.
- All cited lifts (TIMeSynC recall, UpliftBench Qini, Cao & Zhu reward lift, BST online CTR) are **authors' results on their data**, not predictions for Lumen.
- A new architecture still needs its own compliance/model-validation path; it cannot inherit the XGBoost approval (D004). The contract makes *swapping* technically cheap, not compliance-free.
- Source arXiv IDs are recorded as found via the discovery tools; a couple were cross-checked, but treat any single ID as verify-before-cite.

---

## 10. Guidance for Chat 1C (CONSISTENCY AUDIT / DESIGN INPUT SNAPSHOT) and Chat 2 (TRANSFORMER DELIVERY PLANNER)

### What is currently well-supported (high confidence)
- **Three-layer decomposition** (encoder → action-conditioned scorer → decision layer) and **decoupling the scorer from the policy/optimizer** (D010/D011). Convergent across both chats and the allocation literature.
- **Action-as-input core model** (a channel/set is an INPUT, not a fixed output head); combos handled compositionally via set pooling — no 2^N enumeration.
- **An objective-agnostic external scoring contract** (long, PRISM-style table + registry) lets the model family and objective change without downstream re-engineering. See `production_score_contract_options.md`.
- **GBDT is the strong baseline**; on short/sparse/moderate-volume data a transformer likely **matches** it on accuracy. Mature libraries exist for encoders (Transformers4Rec, pytorch-forecasting, pytorch-tabular); the causal head is research-grade only.
- **Most flexible-output use cases (top-1, top-K, multiple-per-customer, allowed-set, caps, no-contact) are decision-layer operations over single-channel scores** — no new model or schema.

### What remains uncertain (needs data, not more reading)
- Whether journeys are long/dense enough for a sequence encoder (CP4) to beat tabular CP1/CP2 — depends on §7 facts 1–4.
- Whether the set encoding generalizes to **held-out combos** (OQ36) — must be tested before relying on on-demand combo scoring.
- Whether a transformer beats CP1 on *any* axis at Lumen's scale, or only matches it (then justification is flexibility/representation, not accuracy).
- Whether overlap/positivity even permits a defensible uplift estimate (gates CP6 and any lift claim).

### What should NOT be assumed
- **Do not assume lift/uplift/CATE is the objective.** It is one option; default the MVP to a predictive/ranking score.
- **Do not assume a transformer will be more accurate** than the tuned GBDT here.
- **Do not assume a sequence-rec encoder (SASRec/BST) is right** before confirming journey length.
- **Do not assume combos/sequences/RL are in V1 scope** — assess realism; current evidence defers them to V2+.
- **Do not conflate** "we must not *claim* causal uplift without an experiment" (true, D005) with "the model must *produce* causal uplift" (false).

### What the final design agent must still decide
1. **Objective for V1:** prediction, ranking, candidate-action score, or uplift (and whether multi-task). Default: predictive; justify any deviation from the data.
2. **Encoder family:** tabular (FT-Transformer), temporal (TFT), or sequence-rec (SASRec/BST) — decided by the §7 journey-length/volume facts.
3. **MVP vs co-MVP:** CP2 (transformer scorer) vs CP3 (hybrid encoder→XGBoost) as the first deliverable, given timeline/GPU/compliance risk.
4. **Whether to build the set/combo primitive (A5) now or defer to V2.**
5. **Evaluation protocol:** metrics (predictive primary; Qini/AUUC/OPE only if claiming uplift), the time-based split, and the data source (MTA vs TMIA vs hybrid) — so the baseline comparison is fair (OQ43).
6. **Whether a causal head (CP6) is worth a Week-4 pilot**, contingent on overlap/positivity and the prospect of an experiment.
7. **V1 use-case scope** (OQ41) and the **minimum data prep** required before the spike can produce a meaningful result (OQ40).

---

## 11. Data-Scale Correction (2026-06-16b)

**What was corrected.** Earlier passes treated Lumen as a "~500K-customer / moderate-volume" problem. That conflated the **test/evaluation subset** with the modeling population. Corrected context:
- The XGBoost/DR work was a **prototype** on a **filtered experiment slice** (~**2–3M customers**), with a **~500K** test/eval set.
- The **full available rich-touchpoint source** (≈2022+) likely covers **~10–15M customers** with many historical touchpoints.
- Therefore **500K is the eval subset, not the population.** Full source is large — but it is **raw, not model-ready**; turning it into a cleaned, transformer-ready sequence dataset is itself substantial work.

**Guardrail against overcorrection (stated up front):** more customers ≠ longer or denser journeys. The controllable channels (Email/DM/Leads) can still be sparse *per customer* even across 10–15M customers; large raw volume does not prove sequence-readiness; and the ETL to build the sequence dataset competes for the 2–4 week budget. Volume is no longer a blocker; **journey richness and data-engineering effort are now the binding questions.**

### 11.1 — Which previous conclusions were affected
Only scale/richness-dependent statements; the architecture, objective-neutrality, and contract conclusions are unaffected.
- **Affected & revised:** (a) §1.2's "moderate volume → expect parity with GBDT" — the *volume* leg is retired (the *richness* leg stands); (b) the recurring "two orders below TIMeSynC's 30M" framing — at full scale it is within ~2×, so the "transformer can't earn its keep at our scale" argument weakens; (c) §7 item 3 (now points at the full population and the cleaned-sequence yield, not the test slice); (d) the data-fit checklist red flag "≪ tens of thousands of rows → expect GBDT to win" — that ceiling no longer applies at population scale.
- **NOT affected:** the action-as-input core + process design (D010), the objective-neutral framing (lift is optional), CP-path *definitions*, and the entire output-contract analysis (a larger population *reinforces* the long-table choice). The "transformer = encoder/scorer, not free uplift/causal validity" point is unchanged.

### 11.2 — Does the corrected scale make transformer modeling more feasible?
**Yes, materially — in principle.** Sequence/representation transformers earn their advantage at **large scale + long, dense sequences**; the volume precondition is now plausibly met. **But feasibility within 2–4 weeks is gated by two unchanged unknowns:** (1) journey *richness* (touches per customer, per-channel sparsity), and (2) the **cost of producing the transformer-ready dataset** from 10–15M raw customers. So: feasibility of the *method* rises; feasibility of *doing it well inside the spike* still depends on profiling and ETL throughput.

### 11.3 — Which approaches become MORE attractive with multi-year, multi-million-customer data
- **CP5 — self-supervised pretraining (next-touch / masked-channel) then fine-tune.** The biggest beneficiary: pretraining feeds on **large *unlabeled* journey data**, which is exactly what's now available. **[ACADEMIC]** SRP4CTR/Abacus/MPT. Moves up from "stretch" toward a credible **MVP+** if the sequence dataset can be built.
- **CP4 — sequence-rec encoder + action head (SASRec/BST via Transformers4Rec).** Was gated on "are journeys long/dense enough"; the population is now large enough that, *if* journeys are also rich, a sequence encoder is justified rather than parity-bound.
- **CP2 — tabular/temporal transformer (TFT/FT-Transformer).** Still the MVP; at full scale its case strengthens from "matches GBDT, justified on flexibility" to "may genuinely win" — pending richness.
- **CP6 — uplift/CATE (incl. causal survival forest).** More *estimable* at scale (more positives per channel, better overlap support) — but rigor and 2–4-week cost are unchanged (see 11.4).

### 11.4 — Which approaches remain too complex for 2–4 weeks despite more data
- **CP6 rigorous causal head (Causal Transformer / G-Transformer):** still research-grade code, healthcare→marketing transfer unproven, adversarial-training instability — more data doesn't fix any of that. Week-4 pilot at most.
- **Ordered multi-channel sequences, sequential RL/bandit, TPP "when-to-contact":** still V2/V3; more data doesn't shrink the engineering/governance/timing-scope cost.
- **Frontier generative recommenders (HSTU-scale):** overkill regardless.
- **And a new one:** **building the full transformer-ready dataset for all 10–15M customers** is itself likely too much for the spike — run the spike on a **representative cleaned sample** first (see 11.6/11.8).

### 11.5 — Evidence still needed to confirm the full data is transformer-ready
Raw availability ≠ readiness. Confirm, on the **full source** (not the prototype slice): journey-length distribution (touches/customer over 2022+); per-channel event frequency, especially controllable-channel sparsity; conversion/positive rate and **positives-per-channel**; timestamp coverage/granularity; **customer-identity resolution across years** (can touchpoints be stitched into one journey per customer reliably?); combo occurrence counts; overlap/positivity per channel; leakage checks; and **ETL throughput** (can the cleaned-sequence dataset actually be produced, and at what cost?). Readiness = a cleaned, deduped, identity-resolved, sequence-formatted dataset with a defined label/horizon and a time-based split — not a row count.

### 11.6 — Immediate data profiling before committing to an architecture
1. **Population funnel:** counts at each stage — raw source → joinable/identity-resolved → cleanable → modelable sequences. (Quantifies the gap between "10–15M available" and "N usable.")
2. **Journey length & richness:** touches-per-customer distribution; distinct `channel×interaction` types populated; controllable-channel (Email/DM/Leads) sparsity. *This decides tabular (CP2-FT) vs sequence (CP2-TFT/CP4).*
3. **Label & timing:** positive rate, positives-per-channel, conversion-timing/censoring; candidate label horizon.
4. **Timestamp & identity quality:** event-time granularity; reliability of stitching touchpoints into per-customer journeys over 2022+.
5. **Overlap/combos:** per-channel positivity; distinct observed combinations and their volumes (gates combos/uplift).
6. **ETL feasibility & cost:** time/throughput to produce the sequence dataset; whether a representative sample is needed for the spike.

### 11.7 — Distinguishing the four datasets (the design agent must label every claim)
| # | Dataset | Approx size | What it is | Status |
|---|---|---|---|---|
| 1 | **Prototype training slice** | ~2–3M customers | filtered experiment slice the XGBoost/DR baseline trained on | historical; not the target population |
| 2 | **Test / eval subset** | ~500K customers | evaluation subset of the prototype | a metric scope, **never** the "population" |
| 3 | **Full source data** | ~10–15M customers, 2022+ | rich raw touchpoints | **availability, NOT model-ready** |
| 4 | **Transformer-ready dataset** | TBD (≤ #3, after cleaning) | cleaned, identity-resolved, sequence-formatted, labeled, time-split | **a deliverable to be built**, not a given |
**Rule:** every quoted number, metric, or feasibility claim must state which of #1–#4 it refers to; never cite 500K as the modeling population, and never cite "10–15M" as if it were already model-ready.

### 11.8 — Does the correction change MVP / fallback / stretch?
**Modest, not wholesale.**
- **MVP — still CP2** (tabular/temporal transformer, action-as-input, predictive output), benchmarked against CP1. Unchanged *choice*; **strengthened rationale** (a real chance to beat GBDT at full scale, not just match) and an **added precondition**: run the spike on a **representative cleaned sample** while the full sequence ETL matures — don't block the model spike on cleaning all 10–15M customers.
- **New first-class workstream:** **data profiling + sequence ETL** (11.6) becomes an explicit, parallel part of the spike and is likely the binding constraint on what's achievable in 2–4 weeks.
- **Stretch — CP5 pretraining moves up** (from "stretch" toward "MVP+ if the sequence dataset exists"), because large unlabeled data is now its fuel. CP6 rigorous causal stays stretch/pilot.
- **Fallback — unchanged:** CP3 (hybrid encoder→XGBoost) and CP1 (temporal-feature XGBoost) remain the low-risk floor, and are the natural place to run *while* the transformer-ready dataset is being built.

### 11.9 — Does it change lift/uplift/CATE vs prediction/ranking/scoring?
**No change to the default; a slight strengthening of uplift's *option* value.** Objective choice is orthogonal to scale, so the **prediction-first MVP stance stands.** What scale changes: more data → more positives-per-channel and better overlap support → uplift/CATE becomes **more estimable and more defensible later** (and pretraining can produce a representation that serves either objective). Causal *claims* still require an experiment (D005). So keep lift as a viable later objective via the same scorer — the correction makes that future a bit more realistic, but does not make lift the V1 objective.

### 11.10 — Does it change the production score-contract recommendations?
**No structural change — it reinforces them, with operational notes.** A 10–15M-customer population scored across channels × objectives × monthly cycles makes the **long table even more clearly correct** (a wide table would be untenable) and raises the importance of: `effective_date` **partitioning**, retention policy, and scoring only **policy-supplied candidate actions** (not the full power set) to bound row volume. Two additions for the contract file: (a) the registry/run metadata should distinguish **scoring population vs training population vs eval set** (datasets #1–#4), so a score row's provenance is unambiguous; (b) plan for serving-cost/throughput at population scale. These are noted in `production_score_contract_options.md`.
