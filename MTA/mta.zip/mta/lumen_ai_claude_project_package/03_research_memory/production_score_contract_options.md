# Production Score-Contract Options (Consolidated)

**Date:** 2026-06-16
**Status:** Consolidated research memory. Distilled from the 2026-06-16 output-contract review (`04_outputs/2026-06-16_output_contract_review.md`).
**Architecture-neutral by design.** This file specifies the **external output contract** so that the internal model (any of CP1–CP6 in `transformer_practical_literature_and_repo_scan.md`) can change without forcing downstream re-engineering. Core principle: **bind downstream consumers to a data contract, not to a model.**

**Anchor fact:** PRISM-style scores already live in a familiar **long table** — `customer_id, model_id, model_score, model_score_rank, effective_date` — historized monthly by `effective_date`, one row per `(customer, model_id, effective_date)`, extended by **adding rows, not columns**.

---

## 1. Recommended Contract: two tables + a registry

**Table 1 — Score fact table (scorer output; append-only; generalizes the PRISM long pattern):**

```
customer_id
effective_date          -- scoring cycle, historized like PRISM
model_id                -- which scorer/version produced this row (FK -> model registry)
candidate_action_id     -- what was scored: a channel, a set, or a sequence (FK -> action registry)
objective_id            -- semantics of the score (FK -> objective registry)
score                   -- numeric: probability | ranking score | expected value | uplift
score_rank              -- optional rank within (customer, effective_date, model_id, objective)
score_lower, score_upper-- optional/nullable; only for interval-bearing scores (e.g. uplift CIs)
```

**Table 2 — Assignment/decision table (config-driven policy-layer output):**

```
customer_id
effective_date
policy_run_id           -- which config/policy produced this decision (FK -> policy registry)
assigned_action_id      -- channel / set / sequence chosen (FK -> action registry)
position                -- ordering slot; NULL for single/unordered, 1..k for sequences/top-K
selected                -- boolean / reason code (capacity, eligibility, no_contact)
```

The score table is *what the model believes*; the assignment table is *what the business decided this cycle*. This split is what lets the **same scores** serve top-1, top-K, capacity-constrained, allowed-set, and no-contact decisions **without rescoring or schema change** — the whole flexible-output requirement (D011) becomes reads/joins over Table 1 producing Table 2.

**Three packaging options:**
- **Option A (recommended):** generalized long score table mirroring PRISM + registry + separate assignment table.
- **Option B:** Option A as system-of-record + materialized **wide views** per consumer that wants a pivoted shape.
- **Option C:** new custom wide table — only defensible for a frozen single use case; contradicts the stated business reality. Not recommended.

---

## 2. Long-table vs Wide-table Tradeoff

| Dimension | Wide (column per channel/objective/model) | Long (row per score) |
|---|---|---|
| Add channel / objective / model version | **Schema migration** (ALTER, backfill, contract break) | **Add rows** |
| Unordered sets / ordered sequences | Column explosion (→2^N) | Native, one row per candidate action |
| Sparse / variable candidate sets | NULL-heavy | Native |
| Single-use-case query | Trivial | Filter + pivot |
| Row volume | Low | High → partition by `effective_date`, index `(customer_id, effective_date)` |
| Score semantics | Implicit in column name | **Explicit** via `score_type`/registry |
| Match to PRISM ops | Poor | **Exact** — reuses tooling & consumer habits |
| Future model swap | Often forces column/contract change | Transparent (new `model_id` rows) |

**[INTERPRETATION]** For a system whose defining requirement is *changing outputs over time*, **long wins decisively.** Its only real costs — query inconvenience and row volume — are mitigated by Option B (wide views) and `effective_date` partitioning. **Long as system-of-record; wide only as derived views.**

---

## 3. Reusing the PRISM-style Schema

**Reuse the *pattern*, in a *parallel* Lumen table — do not write into PRISM's own table.**
- **Keep:** the long shape, `effective_date` historization, `model_id`, `score`, `score_rank`, row-extensibility. The operational familiarity is a real, bankable benefit (consumers and scoring jobs already understand this shape) and lowers onboarding/governance cost.
- **Add:** `candidate_action_id`, `objective_id` (+ optional CI columns). PRISM scores a *customer against a model*; Lumen scores a *customer against a candidate action under an objective* — those two dimension keys are the whole difference and are what make the table action- and objective-agnostic.
- **Why parallel, not shared:** Lumen actions are structured (sets/sequences) and its scores carry heterogeneous semantics (probability vs uplift vs ranking score). Keep it out of PRISM's governed asset; share a registry *convention*. Registering Lumen as extra `model_id`s inside PRISM couples Lumen's faster cadence to PRISM's governance — defer that consolidation until Lumen's schema is stable.

---

## 4. Model / Action / Objective Registry

**Required, not optional**, once `candidate_action_id` and `objective_id` exist — otherwise a score is uninterpretable and unauditable. Three small dimension tables:
- **Model registry:** `model_id → name, version, score_type (prob | rank_score | uplift | ev), objective_id, training_window, approval/validation status, champion|challenger`. Lets champion/challenger coexist as different `model_id`s on the same `effective_date` (as PRISM already does) and gives compliance a per-version status field.
- **Action registry + members bridge:** `action_id → action_type (single | set | sequence)` + `action_members(action_id, channel_id, position)` (`position` NULL for single/sets, `1..k` for sequences). This is what lets single channels, unordered sets, and ordered sequences all be referenced by one `candidate_action_id` **without schema change**.
- **Objective registry:** `objective_id → definition, direction (max/min), score_type, label horizon`.

**[INTERPRETATION]** The registry is the linchpin of model-replaceability: the *meaning* of a score lives in metadata, so a new model is just new rows + a registry entry, never a downstream change. Build a minimal version in V1 even if it holds one model, a few channels, one objective.

---

## 5. Representing Channels, Sets, and Sequences

The score table never changes shape; the **action registry** absorbs structural complexity.
- **Single channel:** `action_type=single`, one member, `position=NULL`.
- **Unordered set `{email, leads, direct_mail}`:** `action_type=set`, members `position=NULL`; generate a **deterministic `action_id`** by sorting member `channel_id`s and hashing (so the same set always resolves to one id, no duplicates).
- **Ordered sequence `email → leads → direct_mail`:** `action_type=sequence`, members `position=1..k`; `action_id` = hash of the *ordered* list (a different order = a different id).
- **No-contact:** an **explicit** `action_id` (`action_type=none`), not an absent row — so it is scoreable, assignable, and auditable (and supports a future contact-vs-no-contact margin).
- **Cardinality discipline:** never enumerate 2^N sets or all permutations. The **policy layer supplies the candidate-action list** each cycle; the scorer only scores those. The long table then holds a bounded number of rows per customer.

---

## 6. How Different Model Families Produce the Same Contract

| Model family (CP path) | Same external structure? | Internal change | Downstream sees | Re-engineering to adopt later? | Stage |
|---|---|---|---|---|---|
| Plain conversion prediction | Yes (`action=∅/baseline`) | single model | a `∅` baseline score | none | V1 (baseline) |
| **Customer × candidate-channel scoring (CP2)** | **Yes — canonical producer** (`action=single`) | action as input | one score row per (customer, channel) | none | **V1** |
| Sequential recommendation / ranking (CP4) | Yes (`score`=rank_score + `score_rank`) | ranking loss | same rows; `score_type=rank_score` | none (policy respects rank semantics) | V1/V1.5 |
| Transformer representation + downstream (CP3) | Yes (downstream emits rows) | encoder internal only | identical | **none — encoder swap invisible** | V1.5 |
| Multi-task (CP5) | Yes (rows per objective) | shared encoder, multi heads | more objective rows | additive | V1.5/V2 |
| Uplift / CATE (CP6) | Yes (`score_type=uplift` + CIs) | needs `∅` baseline + CIs | same rows, uplift semantics | additive | V1.5/V2 (optional) |
| Unordered combination scorer | Yes (`action_type=set`) | set encoder/input | same rows → set | none to table; policy supplies sets | V2 |
| Ordered sequence scorer | Yes (`action_type=sequence`) | sequence-aware scoring | same rows → ordered members | none to table; may add timing dim | V2 |

**[INTERPRETATION] Headline:** every family emits into the **same** two-table contract; differences are internal or registry metadata (`score_type`, `action_type`, `objective_id`). **No family on the list forces a schema change** if the contract is built generalized from V1. Swapping XGBoost → transformer → hybrid = new `model_id` rows; champion/challenger run side by side as different `model_id`s.

**Second finding:** **top-1, top-K, multiple-per-customer, allowed-set, caps, and no-contact are decision-layer operations over single-channel scores** — no new model, no new schema. Only genuine sets/sequences need the model to score structured actions. **So V1 single-channel scoring already unlocks most business asks.**

---

## 7. V1 / V1.5 / V2 Output-Contract Recommendations

- **V1 — single-channel scoring + full policy layer.** Long score table (`action_type=single`, `objective=conversion`, `score_type=prob`), minimal registry, assignment table. Policy layer delivers top-1/top-K/multiple/allowed-set/caps/no-contact as reads over single-channel scores. Champion/challenger via multiple `model_id`s.
- **V1.5 — richer scores, same shape.** Multiple objectives, multi-task heads, transformer-embedding hybrid (internal), optional uplift `score_type` + CIs. Registry growth + new rows only.
- **V2 — structured actions.** Unordered sets and ordered sequences (`action_type` + members bridge), policy-layer candidate-set generation, and a flagged future **timing/"when"** dimension. Core score-table columns unchanged.

---

## 8. Risks & Open Questions

1. **Score comparability** — probabilities, ranking scores, and uplifts are not on one scale; the policy layer must consult `score_type` and not compare across `model_id`/`objective` naively.
2. **Calibration** — if scores feed the optimizer, probabilities should be calibrated; ranking scores are not probabilities (ties to OQ8).
3. **Combinatorial cardinality** — bound sets/sequences via a policy-supplied candidate list; define who owns that universe each cycle.
4. **Deterministic `action_id`** — canonical hashing (sorted for sets, ordered for sequences) for stable, de-duplicated ids.
5. **`effective_date` semantics** — disambiguate scoring date vs decision period vs label horizon (ties to the non-temporal-split issue, OQ9/C6).
6. **No-contact representation** — explicit action vs missing row; recommend explicit. Confirm with business.
7. **Contract evolution** — additive-only (new rows, nullable columns, registry entries); deprecate via registry status, never drop/rename.
8. **Governance coupling** — each `model_id`/version needs an approval status; a new architecture still needs its own validation path (swap is technically free, not compliance-free).
9. **Reproducibility** — rows immutable per `(customer, model_id, candidate_action, objective, effective_date)`; append corrections as new versions.
10. **Scale (data-scale correction 2026-06-16b)** — the modeling population is **not** ~500K (that was the eval subset); the full source is ~10–15M customers (2022+). A 10–15M × channels × objectives × monthly-cycle score table makes the **long table even more clearly correct** (wide is untenable) and raises the importance of: `effective_date` **partitioning**, a **retention policy**, scoring only **policy-supplied candidate actions** (never the full power set) to bound row volume, and **serving-cost/throughput planning** at population scale.
11. **Dataset provenance** — the model/run registry should distinguish **scoring population vs training population vs eval subset vs the cleaned transformer-ready dataset** (see `transformer_practical_literature_and_repo_scan.md` §11.7) so a score row's provenance is unambiguous. Recommend a `dataset_provenance`/`training_dataset_id` field on the model-registry entry rather than on every score row.

---

## 9. Guidance for the Next Design Agent (avoid premature architecture lock-in)

1. **Design the contract before the model.** Treat the model as a pluggable producer of `(customer, effective_date, candidate_action, objective, score, score_type[, rank, CI])` rows. Validate against 2–3 concrete downstream query patterns first.
2. **Channels, objectives, and model versions are data (rows + registry), not columns.** The single most important rule against re-engineering.
3. **Structural complexity lives in the action registry** — single/set/sequence is `action_type` metadata, not separate schemas.
4. **Separate the score fact table from the assignment table.** Most "output" requests are policy-layer operations over scores; don't build a model per request.
5. **Carry `score_type` + nullable CI columns from day one** — future-proofs prediction, ranking, EV, and uplift without schema change, while staying neutral on whether uplift is produced.
6. **Mirror PRISM's long pattern in a parallel table** — reuse familiarity, avoid coupling.
7. **Stay architecture-neutral** — the contract is satisfiable by XGBoost, a transformer, a hybrid, a multi-task net, a ranker, or a combo scorer; pick the model on its merits later.
8. **Bound combinatorial scoring explicitly** before V2; never score the full power set.
9. **Don't foreclose the timing/"when" dimension** for ordered sequences — but don't build it in the spike.

> See the consolidated guidance for **Chat 1C (Consistency Audit / Design Input Snapshot)** and **Chat 2 (Transformer Delivery Planner)** in `transformer_practical_literature_and_repo_scan.md` §10.
