# Research Index

## Status

First research/method review completed 2026-06-15. See `04_outputs/2026-06-15_method_review.md` for the full report.

## How To Maintain

Add entries after each research or critique session.

Recommended entry format:

```text
Date:
Topic:
Summary:
Relevant files updated:
Key conclusions:
Open questions created or resolved:
```

## Entries

```text
Date: 2026-06-15
Topic: Full method review of Lumen AI (DR/CATE, attribution, NBA, optimization) + external literature scan.
Summary: Assessed the implemented LinearDRLearner + constrained optimizer against the literature.
  Identified the root cause of the underdetermined-covariance/zstat=-inf instability (rank-deficient
  final-stage design from one-vs-rest treatment-in-X collinearity, rare channels, and overlap
  violations). Reviewed Shapley vs causal MTA, uplift/CATE estimation and Qini/AUUC evaluation,
  off-policy evaluation (IPS/DR), causal forests/GRF, contextual bandits, Markov attribution, and the
  LiDDA transformer attribution paper.
Relevant files updated: 04_outputs/2026-06-15_method_review.md (new);
  03_research_memory/{literature_notes, reference_bank, method_critiques}.md; 01_current_state/open_questions.md.
Key conclusions:
  - Point/predictive scores are the trustworthy output; DR inference (CIs/p-values) is currently invalid.
  - No result to date licenses an incremental-uplift claim; OPE-vs-PRISM is ranking on a biased subset.
  - Time-based holdout, proper OPE, calibration, and (ideally) a champion/challenger test are the path forward.
  - Causal forests/GRF and uplift-native Qini/AUUC evaluation are the strongest near-term alternatives;
    transformer (LiDDA-style) solves attribution, not NBA, and should be a parallel research track, not v1.
Open questions created or resolved:
  - Created OQ20 (optimizer objective: conversion vs uplift), OQ21 (propensity calibration / AUC-tuning mismatch),
    OQ22 (defensible OPE to replace lucky-match). Sharpened OQ5/OQ6 root-cause diagnosis.
```

```text
Date: 2026-06-15
Topic: DEEP literature review — transformer / sequence-modeling for the PREDICTIVE next-best-channel path (not attribution).
Summary: Follow-up requested because the first review only cited LiDDA (attribution-only). Surveyed three layers a
  "Lumen transformer" actually needs: (1) sequence encoder (SASRec, BERT4Rec, BST, PinnerFormer, HSTU/generative rec);
  (2) causal/uplift head over time (RMSN -> CRN -> Causal Transformer; static CATE NN family + multi-treatment M3TN);
  (3) decision layer (constrained optimizer today; DRQN-attention RL for sequential NBA). Added temporal point
  processes (THP / EasyTPP) for the "when to contact" dimension, marketing deep-journey models (DeepMTA), usable
  libraries (Transformers4Rec, RecBole, EasyTPP), and the tabular-vs-DL evidence on when transformers beat XGBoost.
Relevant files updated: 03_research_memory/transformer_sequence_modeling_review.md (new, primary deliverable);
  reference_bank.md (transformer/sequence section appended); this index.
Key conclusions:
  - Off-the-shelf recommender transformers and LiDDA solve encoding/attribution, NOT causal uplift; the novel work
    is fusing a sequence encoder with a Causal-Transformer/CRN-style uplift head that emits per-channel
    counterfactuals (replacing EconML's fragile linear DR final stage).
  - Feasibility hinges on journey length, event richness, volume, and timestamp quality — transformers beat GBDT
    mainly at large scale + long sequences; on short sparse journeys expect parity, justified by timing/multi-step/
    reusable-representation, not accuracy.
  - Mature libraries exist for the encoder (Transformers4Rec/RecBole) and TPP (EasyTPP); the causal head is
    research-grade code only -> that's where the effort and risk concentrate. Separate architecture = separate
    compliance/validation path (schedule cost).
Open questions created or resolved:
  - Created OQ25-OQ30 (journey length, event richness, volume vs DL threshold, timestamp quality, timing/multi-step
    scope, label horizon) as the data facts needed before any effort estimate.
```

```text
Date: 2026-06-15b
Topic: Lighter-weight / pre-transformer models for the ACTUAL data (sparse, low-frequency bank journeys from 2022).
Summary: Tech lead clarified current Lumen collapses an April-July snapshot into a flat XGBoost vector (no sequence,
  no 2022+ history) and that event frequency is low/uneven. Researched models that fit this regime and added a
  simplest-to-transformer model ladder with effort/risk.
Relevant files updated: transformer_sequence_modeling_review.md (§0.6 data context, §6b Family F, §7 tooling,
  §10 effort ladder, §12 refs); literature_notes.md; reference_bank.md; method_critiques.md (C14); open_questions.md.
Key conclusions:
  - Transformer is the TOP of a ladder, not the next step. Evidence: GBDT not beaten by NN in financial classification;
    RNN/GRU beat transformers under data constraints; Markov does better on sparse than dense sequences.
  - Recommended order by value-per-effort: F0 temporal-feature XGBoost over full 2022+ history (low effort, keeps DR
    + enables time-based holdout) -> F2 Causal Survival Forest (native per-channel uplift on censored time-to-event,
    in grf) -> Markov/HMM + GRU baselines -> transformer paths only if volume/sequence length later justify.
  - The convert-or-not-over-a-journey outcome is really right-censored time-to-event; treating it as a static binary
    snapshot (C14) wastes data and mishandles non-converters.
Open questions: OQ25-31 still the gating data facts; reframed default away from transformer-first.
```

```text
Date: 2026-06-15c
Topic: Transformer implementation plan (manager-directed transformer path; good-enough + flexible; 2-4 week spike).
Summary: Manager is persisting on a transformer. Produced a focused, build-oriented shortlist plus a 2-4 week plan,
  centered on the business requirement that combos must be generated on demand (not pre-enumerated).
Relevant files updated: transformer_implementation_plan.md (NEW, primary deliverable); reference_bank.md;
  literature_notes.md; decision_register.md (D004 updated, D010 added); open_questions.md (OQ35-38); this index.
Key conclusions:
  - Architecture = treatment-conditional CORE model (action-set is an INPUT) + a thin PROCESS layer that, each month,
    scores only business-relevant candidate sets and runs constrained assignment. This is the g-computation /
    counterfactual-query pattern and decouples the model from changing business rules.
  - Combos handled COMPOSITIONALLY via a set-of-channel-embeddings pooled permutation-invariantly (Deep Sets /
    Set Transformer) -> generalizes to unseen combos, no 2^N heads. Single channel = set of size 1.
  - Pragmatic causality = S-learner (uplift = pred(A) - pred(no-contact)); rigorous = Causal Transformer / G-Transformer.
  - 5 buildable core options ranked by effort: A1 FT-Transformer/TabTransformer (pytorch-tabular, easiest) ->
    A2 Temporal Fusion Transformer (pytorch-forecasting; planned action = KNOWN FUTURE INPUT, best easy fit) ->
    A3 SASRec/BST via Transformers4Rec (rec stack) -> A4 Causal Transformer / G-Transformer (rigorous, code verified) ->
    A5 Set/Deep-Sets treatment head (the combo enabler, ~50 lines on any encoder).
  - Cross-domain data-fit checklist added (sequence length, per-channel/combo frequency, overlap/positivity,
    time-varying confounding, static/time-varying split, known-future-input availability, censoring, volume, leakage).
Open questions created: OQ35 (S-learner vs rigorous causal head), OQ36 (set-pooling combo generalization validation),
  OQ37 (process-layer / optimizer contract & differentiable ILP?), OQ38 (TFT static-vs-time-varying feature split).
```

```text
Date: 2026-06-16
Topic: CONSOLIDATION of Chat-2 work (independent transformer scan + lift-de-emphasis correction + output-contract review) merged with Chat-1 research memory.
Summary: Independent second-pass literature/repo scan (alphaXiv + GitHub + web), then an anti-anchoring
  correction reducing over-focus on lift/uplift/CATE, then an architecture-neutral production output-contract
  review. Reconciled with the Chat-1 sequence-modeling review, implementation plan, literature notes, method
  critiques, and method review. Produced two new consolidated research-memory files; updated reference_bank and
  this index. Source chat outputs retained in 04_outputs/ (2026-06-16_independent_transformer_research_scan.md,
  2026-06-16_transformer_scan_correction_deemphasize_lift.md, 2026-06-16_output_contract_review.md).
Relevant files updated/created:
  - 03_research_memory/transformer_practical_literature_and_repo_scan.md (NEW, primary consolidated scan)
  - 03_research_memory/production_score_contract_options.md (NEW, external interface)
  - 03_research_memory/reference_bank.md (Chat-2 section appended, sources marked ACADEMIC/INDUSTRY/CODE)
  - 03_research_memory/research_index.md (this entry)
Key conclusions:
  - Lift/uplift/CATE is NOT the default objective and NOT rejected — it is ONE optional scoring objective,
    computable from the same scorer (score(A)-score(∅)), worth keeping mainly at the contact/no-contact margin
    or once an experiment exists. Default the MVP to a PREDICTIVE/ranking score; this also lowers D005 exposure.
  - Reconciliation: Chat-1's "action-as-input core model + thin process layer" (D010) is objective-agnostic;
    relabel its output from uplift(A) to score(A) and the architecture + combo set-encoding + optimizer survive.
  - Convergent evidence: GBDT is the strong baseline (UpliftBench S-learner > Causal Forest at 14M rows);
    TIMeSynC (Capital One) is the closest fintech template but 100x our scale and predictive, not causal; on
    short/sparse/moderate-volume data expect a transformer to MATCH not beat XGBoost on accuracy.
  - 5 consolidated paths: CP1 temporal-feature XGBoost (baseline/floor) -> CP2 tabular/temporal transformer
    with action-as-input, predictive output (MVP) -> CP3 hybrid encoder->XGBoost (low-risk fallback/on-ramp) ->
    CP4 seq-rec encoder+head (if journeys long) -> CP5 pretraining/multi-task (prediction-first stretch);
    CP6 causal/uplift head = optional objective / Week-4 pilot, deferred. Combos (Set/Deep-Sets), ordered
    sequences, and RL = V2+.
  - Output contract: a generalized PRISM-style LONG score table (customer_id, effective_date, model_id,
    candidate_action_id, objective_id, score, score_rank, [CI]) + model/action/objective REGISTRY + a separate
    ASSIGNMENT table. Long beats wide; registry mandatory; every model family emits the same contract so the
    model can be swapped without downstream re-engineering. Most use cases (top-1/K, multiple, allowed-set, caps,
    no-contact) are DECISION-LAYER ops over single-channel scores -> V1 single-channel scoring unlocks most asks.
  - Guidance for Chat 1C (Consistency Audit / Design Input Snapshot) and Chat 2 (Transformer Delivery Planner) is
    in transformer_practical_literature_and_repo_scan.md §10 (well-supported / uncertain / not-to-assume / still-to-decide).
Open questions: existing OQ25-31 (data facts), OQ36 (combo generalization), OQ40-43 (feasibility, v1 scope,
  spike deliverable, baseline-comparison protocol) remain the gating items; the objective choice (predict vs
  rank vs uplift) is now an explicit design decision rather than an assumed default.
```

```text
Date: 2026-06-16b
Topic: DATA-SCALE CORRECTION — prior "moderate / ~500K-customer" framing was wrong.
Summary: 500K was the test/eval subset; the XGBoost/DR prototype trained on a filtered ~2-3M-customer slice;
  the full source (2022+) likely covers ~10-15M customers with rich touchpoints but is RAW, not model-ready.
  Revised only the scale/richness-dependent conclusions; did not redo the review.
Relevant files updated: transformer_practical_literature_and_repo_scan.md (§11 added; banner + §1.2/§7 revised);
  production_score_contract_options.md (risks #10-11 added); this index.
Key conclusions:
  - Volume is no longer a blocker; transformer feasibility rises in principle. BUT raw availability != sequence-
    readiness: journey RICHNESS (touches/customer, controllable-channel sparsity) is unconfirmed, and building the
    transformer-ready dataset (clean/identity-resolve/sequence-format) is itself substantial spike work.
  - More attractive now: CP5 self-supervised pretraining (feeds on large unlabeled journeys) -> moves toward MVP+;
    CP4 sequence encoder (if journeys also rich); CP2 case strengthens from "match" to "may beat" GBDT.
  - Still too complex for 2-4 wks: CP6 rigorous causal head, ordered sequences, RL/TPP, HSTU-scale; and cleaning
    all 10-15M customers -> run the spike on a representative cleaned SAMPLE.
  - MVP unchanged (CP2) with stronger rationale + a new first-class data-profiling/ETL workstream; fallback
    (CP3/CP1) unchanged. Lift-vs-prediction: prediction-first default unchanged; uplift becomes more ESTIMABLE at
    scale (still needs an experiment for causal claims). Contract: long-table choice REINFORCED; add partitioning,
    retention, candidate-set-bounded scoring, and dataset-provenance (prototype/test/full/transformer-ready).
  - Four datasets the design agent must label distinctly: (1) prototype slice ~2-3M, (2) test subset ~500K,
    (3) full source ~10-15M (raw), (4) transformer-ready dataset (to be built). Never quote 500K as the population.
Open questions: OQ25-31 re-pointed at the FULL source (not the prototype slice); new gating item = ETL throughput /
  cleaned-sequence yield; OQ40 (minimum data prep) now central.
```

## Consolidated Research-Memory Files (added 2026-06-16)

### `03_research_memory/transformer_practical_literature_and_repo_scan.md`

Purpose: primary consolidated literature/industry/repository/implementation findings; 5 viable implementation paths (CP1–CP6) with MVP / fallback / stretch; evidence to generate from our own data; what to avoid overengineering; and §10 guidance for Chat 1C and Chat 2. Objective-neutral on lift. Read first for the modeling direction.

### `03_research_memory/production_score_contract_options.md`

Purpose: architecture-neutral external output contract — long vs wide tradeoff, PRISM-style reuse, model/action/objective registry, channel/set/sequence representation, how every model family produces the same contract, and V1/V1.5/V2 staging. Read for productionization/interface design.

## Research Areas To Cover

- Multi-touch attribution — covered 2026-06-15 (Shapley limits, CausalMTA/DCRMTA)
- Shapley attribution limitations — covered 2026-06-15
- Selection bias in marketing channel assignment — covered 2026-06-15
- Doubly robust estimation — covered 2026-06-15
- Uplift modeling / CATE estimation — covered 2026-06-15 (meta-learners, causal forests, Qini/AUUC)
- Off-policy evaluation — covered 2026-06-15 (IPS/DR)
- Next-best-action / next-best-channel recommendation — covered 2026-06-15
- Constrained optimization — covered (objective-design open question raised)
- No-contact and negative-lift handling — partially covered (negative-ATE narrative still open)
- Markov / temporal baselines — covered 2026-06-15 (removal effect)
- Transformer / sequence-based journey modeling — covered 2026-06-15 (LiDDA)
- Contextual bandits and live experimentation — covered 2026-06-15
- Production ML governance and model-readiness — covered 2026-06-15
