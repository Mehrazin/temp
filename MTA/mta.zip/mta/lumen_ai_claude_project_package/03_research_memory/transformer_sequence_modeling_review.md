# Deep Literature Review — Transformer & Sequence Modeling for the Lumen AI Predictive Path

**Date:** 2026-06-15
**Purpose:** Technical, evidence-dense survey of the transformer / sequence-modeling direction for **predictive next-best-channel** (not attribution), gathered so the tech lead can later scope and estimate the engineering effort. This is *not* a manager note. OPE is intentionally de-emphasized per direction.
**Why this exists:** the prior method review only referenced LiDDA, which is an **attribution (credit-assignment) model, not a predictive / next-best-action model**. This document maps the predictive sequence-modeling landscape, the parts that LiDDA and off-the-shelf recommenders do *not* solve, and the usable code.

---

## 0. The one idea to anchor on

A Lumen "transformer version" is **not a single off-the-shelf model**. It is a composition of three layers, and the literature lives in three different communities:

1. **Sequence encoder** over the customer journey → a learned representation. *Solved well* by sequential-recommendation transformers (SASRec, BERT4Rec, BST, HSTU) and temporal point processes (THP). They predict the *next event*, not a *treatment effect*.
2. **Causal / uplift head** → per-channel **counterfactual** outcomes (what converts if we contact via channel X vs. not), correcting for time-varying confounding. *This is the hard part and the actual analogue of today's doubly-robust model.* Solved (in healthcare, mostly) by CRN, the Causal Transformer, RMSN, and the static-CATE neural family.
3. **Decision layer** → constrained assignment (today's optimizer) or sequential RL/bandit if multi-step "when + which channel" sequencing is wanted.

**Off-the-shelf recommender transformers give you layer 1 + next-item prediction. They do NOT give you layer 2.** LiDDA gives you attribution, also not layer 2. The novel work for Lumen is fusing a sequence encoder (layer 1) with a causal/uplift head (layer 2). Effort estimation should be organized around that gap.

---

## 0.6 Confirmed data context (added 2026-06-15b) — and why it changes the recommendation

Tech-lead clarification received after the first draft:
- **History depth:** customer journeys exist **from 2022** (≈4 years), but the **current Lumen model uses only an April–July snapshot**, which it **collapses (condenses) into a single flat feature vector** for XGBoost. So today's model already **discards temporal order and the multi-year history** — it is not a sequence model at all, it is a point-in-time aggregate.
- **Event frequency is low and uneven:** this is **bank journey data, not e-commerce** — far lower cardinality/frequency. **Digital channels can be frequent; Email, Direct Mail, Leads (the directly controllable ones) are sparse / "minty."**

**Implication — flip the default.** The earlier review left "transformer vs. XGBoost" open pending data facts; those facts now point away from a transformer-first move. Sparse, low-frequency, short journeys are precisely the regime where **(a) gradient boosting is not outperformed by neural nets** (especially in financial classification), **(b) RNN/GRU beat transformers under data constraints**, and **(c) Markov-type models do *better* on sparse than dense sequences**. The transformer is the *top* of a ladder, not the first rung. **The highest-value, lowest-effort next step is not a transformer at all — it is to stop collapsing the journey into one vector** and instead either (i) engineer multi-window temporal features for the existing XGBoost stack, or (ii) move to a light sequence-aware model (GRU, Markov, or a survival/time-to-event model). See the **model ladder in §6b and the revised effort table in §10.**

This also dovetails with two prior-review findings: using only April–July instead of the 2022+ history both **wastes data** and **prevents the time-based holdout** the method review called for (C6); and the **causal head** problem (need per-channel uplift, not just prediction) is now answerable with a **causal survival forest** that fits sparse censored data far better than a deep sequence model (§6b).

---

## 1. Does our data fit a sequence model at all? (feasibility first)

What Lumen has, per the snapshot: per-customer **timestamped channel×interaction events** (`channel_Email_CLICK`, `channel_Leads_contacted`, …), ~10 static PRISM scores + CC indicator (static context), a binary conversion label, and prospective `t_channel_*` treatments. Formally this is a **marked event sequence with irregular inter-event times + static covariates + a terminal binary outcome** — a canonical input for both sequential recommenders and temporal point processes. So the data *shape* fits.

Two viable representations:
- **Token-sequence view** (recommender style): journey = ordered list of touchpoint tokens; position/time encoded. Backbones: SASRec / BERT4Rec / BST.
- **Marked temporal point process view**: events have type + continuous timestamp; model the intensity of the next event and the outcome. Backbones: THP / neural TPP. Better when **timing** ("when to contact") is in scope and gaps are irregular — which they are.

**The central feasibility risk for effort estimation:** sequential transformers earn their keep on **long, dense behavioral histories with high item cardinality** (e-commerce: dozens–hundreds of events, millions of items). Credit-card marketing journeys are likely **short and sparse** (a handful of touches across a few controllable channels). The tabular-vs-transformer evidence (§8) is blunt: **gradient boosting still wins at small/medium scale; transformers pull ahead mainly at large scale and long sequences.** So before committing, two numbers must be pulled from the data:
- average / distribution of **touches per customer** (sequence length), and
- **volume** (Lumen has ≈500K customers / ≈2.8M train rows — moderate, not "internet-scale").

If journeys are short, the transformer's value is **not accuracy over XGBoost** but (a) reusable representations, (b) timing decisions (TPP/RL), and (c) a path to multi-step sequencing — those should be the justification, not a hoped-for AUC bump.

---

## 2. Family A — Sequential-recommendation transformers (the encoder backbones)

These are mature, well-documented, and have production-grade code. They model "given the sequence so far, what's the next item/action," which maps to "next channel the customer engages with" — useful, but **predictive of engagement, not of incremental causal effect.**

| Model | Core idea | Why relevant / notable | Code |
|---|---|---|---|
| **GRU4Rec** (Hidasi et al., 2016) | RNN/GRU over session events; session-based rec | The RNN baseline everyone compares against; cheap | In RecBole |
| **SASRec** (Kang & McAuley, ICDM 2018; arXiv 1808.09781) | **Causal (left-to-right) self-attention**, next-item prediction; no recurrence/conv | The default sequential-transformer baseline; dominates at larger param counts | github.com/kang205/SASRec; RecBole |
| **BERT4Rec** (Sun et al., CIKM 2019; arXiv 1904.06690) | **Bidirectional** self-attention, **Cloze/masked-item** objective | Often ~tied with SASRec in practice (replicability study, arXiv 2207.07483; "Dross into Gold," arXiv 2309.07602) — loss/setup matters more than direction | RecBole; antklen/sasrec-bert4rec-recsys23 |
| **BST — Behavior Sequence Transformer** (Alibaba, DLP-KDD 2019; arXiv 1905.06874) | Self-attention over behavior seq for **CTR**; **learned time-difference positional embeddings** for irregular gaps | Closest to a marketing/CTR setting; the time-gap embedding trick directly addresses our irregular journeys; +7.57% online CTR | community PyTorch impls |
| **PinnerFormer** (Pinterest, KDD 2022; arXiv 2205.04507) | Sequence model producing a **user representation** predicting **long-term future engagement**; "dense all-action loss"; batch (not real-time) infra | Shows how to build a reusable customer embedding on **batch** infra — matches a monthly/weekly scoring job; long-horizon objective fits acquisition | paper only |
| **HSTU / Generative Recommenders** (Meta, ICML 2024; arXiv 2402.17152) | Recast rec as **generative sequence transduction**; new HSTU attention; **scaling laws**; 1.5T params, +12.4% online | The current frontier / "industry standard direction"; likely overkill for Lumen scale but defines where the field is going | github.com/meta-recsys/generative-recommenders; NVIDIA/recsys-examples |

**Takeaway for A:** pick SASRec or BST as the encoder reference. BST is the better template because it is CTR-oriented and already handles irregular time gaps. None of these is a causal model — that's Family B.

---

## 3. Family B — Causal / counterfactual sequence models (the uplift head) — **MOST RELEVANT, hardest, what LiDDA & recommenders don't give you**

This family is the true sequence-model analogue of today's doubly-robust CATE model: it estimates **counterfactual outcomes under treatment sequences over time** while correcting **time-varying confounding** (the fact that who gets contacted on which channel depends on history). Most of it comes from **healthcare** (treatment-response over time), which transfers conceptually to "marketing-contact-response over time."

**The lineage (study in this order):**

- **RMSN — Recurrent Marginal Structural Networks** (Lim et al., NeurIPS 2018). LSTM + **inverse-probability-of-treatment weighting** to adjust for time-dependent confounders. The first deep sequential causal model; conceptually closest to today's DR/IPW thinking, just sequential.
- **CRN — Counterfactual Recurrent Network** (Bica et al., **ICLR 2020**; arXiv 2002.04083; **code: github.com/ioanabica/Counterfactual-Recurrent-Network**). Encoder–decoder LSTM that builds **treatment-invariant (adversarially balanced) representations** so history can't predict the next treatment → enables reliable counterfactual prediction, including **multiple treatments over time** and **when to start/stop**. This is the cleanest "uplift over time, multi-treatment" reference and it has real code.
- **Causal Transformer** (Melnychuk, Frauen, Feuerriegel, **ICML 2022**; arXiv 2204.07258). **The transformer version of CRN.** Three separate transformer subnetworks (covariates / treatments / outcomes) interacting via **cross-attention**, trained with a **counterfactual domain-confusion loss** to remove confounding; captures long-range dependencies CRN's LSTM misses. **This is the direct answer to "is there a transformer uplift-over-time model?" — yes, this is it.** Code released with the paper.
- **Continuous-time / newer variants** (context, not v1): neural-CDE counterfactuals (arXiv 2206.08311), informative-sampling-aware forecasting (arXiv 2306.04255), causal diffusion models for counterfactual distributions (arXiv 2604.12992). Useful if irregular sampling / full outcome distributions matter later.

**Static-CATE neural family** (for the head design, if we treat each scoring as one-shot rather than a full sequence of treatments):
- **TARNet / CFRNet** (Shalit et al., 2017) — shared representation + per-treatment heads + balancing; the canonical NN-CATE design.
- **Dragonnet** (Shi et al., 2019) — adds a propensity head + targeted regularization (DR-flavored) onto a shared trunk.
- **M³TN** (arXiv 2401.14426) — **multi-valued treatment** uplift via mixture-of-experts; relevant because Lumen has several channels (multi-treatment), not binary.
- **Transformer CATE estimators:** **TransTEE**, **DAG-aware Transformer** (arXiv 2410.10044), **CausalPFN** (in-context/amortized CATE, arXiv 2506.07918). Frontier; mostly cross-sectional, but show attention applied to effect estimation.

**Takeaway for B:** the realistic "transformer uplift" target is a **Causal-Transformer-style head (or CRN if we want a lighter LSTM)** that consumes the Family-A journey encoding and PRISM context and emits **per-channel potential outcomes** — exactly the `conversion_{ch}_0/_1` the optimizer already wants, but learned end-to-end with a balancing/confounding correction instead of EconML's linear DR final stage. Caveats: research-grade code, healthcare provenance (transfer unproven for marketing), data-hungry, and — like the DR model — **still cannot prove incremental lift without an experiment.**

---

## 4. Family C — Event-sequence / temporal point process (TPP) models (the "when," not just "which")

If timing ("when is the next best moment to contact, and on which channel") becomes in-scope, TPPs are the right formalism for **irregular, continuous-time marked events**.

- **Transformer Hawkes Process — THP** (Zuo et al., **ICML 2020**; arXiv 2002.09291; **code: github.com/SimiaoZuo/Transformer-Hawkes-Process**). Self-attention over event history with **continuous-time positional encodings**; models the intensity (rate) of the next event type and time. Captures both short- and long-range temporal dependence.
- **Neural TPP baselines:** RMTPP (RNN + time), Neural Hawkes Process (continuous-time LSTM), SAHP, AttNHP.
- **EasyTPP** (Ant Research, **ICLR 2024**; arXiv 2307.08097; **code: github.com/ant-research/EasyTemporalPointProcess**). A clean PyTorch **benchmark library** with reference implementations of RMTPP, NHP, SAHP, THP, AttNHP — the fastest way to prototype the TPP angle without writing models from scratch.

**Takeaway for C:** orthogonal capability. Lumen today answers "which channel"; TPP adds "when." Worth a spike only if timing/cadence optimization is a product goal.

---

## 5. Family D — Sequential decisioning (RL / NBA) — the optimizer layer, sequential version

(OPE de-emphasized per direction; included briefly because it's the natural decision layer if Lumen moves from one-shot channel choice to multi-step sequencing.)

- **Customer Acquisition via Explainable Deep RL** (Song, Wang, Yao; SSRN 4802411). **DRQN + attention** for **sequential targeting in a digital bank** — directly on-domain: optimizes long-term acquisition reward and uses attention for explainability over which ad/channel exposure drives conversion. Best single on-domain reference for RL-based NBA in banking.
- **Multi-step journey optimization** (Grid Dynamics NBA-with-RL writeup; Braze RL-for-marketing): industry framing of optimizing the *whole journey* rather than one CTR/CR step — explicitly calls out **retail banking / telecom** long relationships.

**Takeaway for D:** RL is the multi-step generalization of the current constrained optimizer. Higher engineering + governance lift; a v3 consideration, not v1.

---

## 6. Family E — Marketing-specific deep journey models (mostly attribution/conversion, same gap as LiDDA)

These are predictive of **conversion**, useful as conversion backbones, but — like LiDDA — they are **attribution / prediction, not uplift**:

- **DeepMTA** / **Interpretable Deep Learning for Online MTA** (Du et al.; arXiv 2004.00384): **phased-LSTM** conversion model + additive (Shapley) attribution; models event order, frequency, and time-decay. A good reference for encoding journey order+timing+frequency into a conversion predictor.
- **UMD "AI for Customer Journeys: A Transformer Approach"** (R.H. Smith School): transformer for digital customer-behavior prediction across multi-touch journeys; industry-facing evidence that transformers beat traditional MTA at *prediction*.
- **LSTM touchpoint/sequence prediction** (various practitioner works): conversion as binary time-series classification over touchpoints; beam search to find high-conversion sequences.

**Takeaway for E:** reuse their journey-encoding tricks (phased-LSTM time-decay, time-gap embeddings) but remember these solve the same problem LiDDA does — they don't replace the causal head in Family B.

---

## 6b. Family F — Lighter-weight / pre-transformer models (try these FIRST on sparse, low-frequency journeys)

Given the confirmed data context (§0.6), these are the models that actually fit sparse, low-frequency, multi-year bank journeys, ordered roughly by effort. Several also solve the causal/uplift head — which a vanilla recommender transformer does not.

### F0 — Temporal feature engineering + XGBoost (keep the stack, stop collapsing)
The current model condenses April–July into one vector. The cheapest improvement is to **keep XGBoost but engineer temporal structure**: multi-window aggregates (e.g., 0–30 / 30–90 / 90–365 days), **recency-frequency (RFM-style)** features per channel, time-since-last-touch, inter-touch gaps, trend/last-state features — computed over the **full 2022+ history**, not one snapshot. Evidence: temporally-engineered XGBoost won the WSDM 2018 churn challenge (arXiv 1802.03396); time-varying RFM is "the backbone of customer behavior forecasting" (Annals of OR 2024); **tree-based GBMs are not outperformed by NNs in financial classification**. This preserves the existing DR/uplift wiring and compliance path. **Effort: low. Risk: low. Causal: yes (current DR setup unchanged).** This should be the first move.

### F1 — Markov / higher-order Markov / Hidden Markov Models (interpretable journey states)
First-order Markov **removal-effect** attribution; **higher-order Markov** (Anderl et al.) for richer transitions; **Hidden Markov Models** where latent states = customer intent/engagement levels (Netzer et al., "HMM of Customer Relationship Dynamics"; HMMs-in-marketing literature). **Markov models do better on sparse than dense sequences** — a direct fit. Interpretable and low-data. **Caveat: these are correlational / descriptive (attribution & state dynamics), not uplift.** Good diagnostic baseline and sanity check against DR ATEs; not a next-best-action engine on its own. **Effort: low–med. Risk: low. Causal: no (attribution only).**

### F2 — Survival / time-to-event models (the natural frame for "from 2022, did/when they convert") — STRONG FIT
A bank journey from 2022 with conversion-or-not is a textbook **right-censored time-to-event** problem; collapsing it to a binary snapshot throws away the *when* and mishandles not-yet-converted customers. Options by weight:
- **Classical:** Cox proportional hazards, **discrete-time survival** (logistic on person-period), **Random Survival Forests** — robust on modest data, interpretable.
- **Deep (only if data supports):** **DeepHit** (discrete-time, competing risks) and **Dynamic-DeepHit** (RNN, time-varying covariates) for longitudinal journeys.
- **Causal survival (the uplift answer):** **Causal Survival Forests** (Cui, Kosorok, Sverdrup, Wager, Zhu, **JRSS-B 2023**; arXiv 2001.09887; **`causal_survival_forest` in grf**, practitioner guide arXiv 2312.02482) estimate **heterogeneous treatment effects with right-censored data** using doubly-robust/orthogonal estimating equations — i.e., **per-customer per-channel uplift on time-to-conversion, handling censoring natively.** Benchmark: **SurvHTE-Bench** (arXiv 2603.05483). This is the most promising middle path: it gives the causal uplift Lumen needs, fits sparse data far better than a transformer, and **reuses the causal-forest recommendation already in the method review (OQ24).** **Effort: med. Risk: med. Causal: yes (native).**

### F3 — RNN / GRU sequence models (the neural step before transformers)
**GRU4Rec** (Hidasi et al., ICLR 2016; arXiv 1511.06939) and LSTM journey models. Under data-constrained / short-sequence conditions, **RNNs with their strong sequential inductive bias consistently outperform transformers** and are far cheaper to train. If a neural sequence model is wanted at all, **GRU is the right first neural rung, not a transformer.** Comparative churn evidence: arXiv 1909.11114, 2304.00575. Note: still predictive, not causal — would need a balancing/uplift head (CRN is itself GRU-based, see §3) to produce per-channel counterfactuals. **Effort: med. Risk: med. Causal: no by default (CRN-style head adds it).**

### F4 — Classical Hawkes / point processes (sparse self-exciting events)
If timing matters but data is too sparse for neural TPP (§4), **classical multivariate Hawkes processes** (self-exciting, interpretable, estimable on small data via penalized MLE; tutorial arXiv 1708.06401) model clustered, irregular events with far fewer parameters than THP. A lightweight alternative to the neural TPP path. **Effort: med. Risk: med. Causal: no (intensity model).**

**Bottom line of Family F:** on this data, the ranking by expected value-per-effort is roughly **F0 (temporal features + XGBoost) → F2 (causal survival forest) → F1/F3/F4 → then** the transformer paths (§2–§3) only if data volume/sequence length later justify them.

---

## 7. Tooling, libraries, and repos (effort-estimation inputs)

| Tool | What it gives you | Maturity | Link |
|---|---|---|---|
| **Transformers4Rec** (NVIDIA Merlin, RecSys 2021) | Production library: SASRec/BERT4Rec/etc. on PyTorch, **HuggingFace integration**, + **NVTabular** preprocessing + **Triton** serving; won Booking.com & Coveo challenges | Production | github.com/NVIDIA-Merlin/Transformers4Rec |
| **RecBole** (RUCAIBox) | Reproducible benchmark with **SASRec, GRU4Rec, BERT4Rec** + many more; fastest A/B of backbones | Mature, research | github.com/RUCAIBox/RecBole |
| **EasyTPP** (Ant Research, ICLR 2024) | TPP benchmark: RMTPP, NHP, SAHP, **THP**, AttNHP | Mature, research | github.com/ant-research/EasyTemporalPointProcess |
| **CRN** (Bica) | Reference impl. of counterfactual-over-time (uplift head) | Research code | github.com/ioanabica/Counterfactual-Recurrent-Network |
| **Causal Transformer** (Melnychuk) | Transformer counterfactual-over-time | Research code | released w/ arXiv 2204.07258 |
| **SASRec** (kang205) | Original SASRec | Research code | github.com/kang205/SASRec |
| **Generative Recommenders / HSTU** (Meta) + **NVIDIA recsys-examples** | Frontier generative-rec, scaled training | Research→prod | github.com/meta-recsys/generative-recommenders |
| **grf** (R) | `causal_survival_forest`, `causal_forest` — causal uplift incl. censored | Mature | grf-labs.github.io/grf |
| **scikit-survival / lifelines** (Py) | Cox, RSF, discrete-time survival | Mature | scikit-survival.readthedocs.io |
| **pycox** (Py) | DeepHit, Dynamic-DeepHit, DeepSurv | Research→prod | github.com/havakv/pycox |
| **tick / tsfresh** (Py) | Classical Hawkes (tick); automated temporal feature extraction (tsfresh) | Mature | github.com/X-DataInitiative/tick · tsfresh.readthedocs.io |

**Effort read:** Family A and C have **mature libraries** → prototyping is days–weeks. Family B (the causal head — the part that matters) has **research-grade code only** → integration, adaptation to marketing data, and validation is the bulk of the effort and risk.

---

## 8. When does a sequence transformer actually beat XGBoost? (the gating evidence)

Honest, effort-relevant findings from the tabular-DL literature:
- **GBDT still dominates transformers on tabular data at small/medium scale** ("When Do Neural Nets Outperform Boosted Trees," arXiv 2305.02997).
- Transformers (e.g., TabPFN) excel on **very small** data via priors but **are not competitive with GBDTs on medium/large** sets due to context limits.
- Transformers **do** overtake tuned XGBoost at **large scale + sequential structure** — e.g., discretized tokenization on **600K entities / 5M examples beat tuned XGBoost by ~10.8%** (arXiv 2603.07448); tabular transformers competitive at **fraud detection, Booking.com** (arXiv 2405.13692).
- **Hybrids** (PFN-Boost, LLM-Boost; arXiv 2502.02672) beat both across sizes.

**Implication for Lumen:** the transformer path is justified by **sequence richness + scale + new capabilities (timing, multi-step, reusable embeddings, end-to-end causal head)** — *not* by an assumed accuracy win over the current DR+XGBoost on a short-journey, moderate-volume dataset. If the journeys turn out short and sparse, expect the transformer to **match, not beat**, XGBoost on point accuracy, and to justify itself on the other axes.

---

## 9. Candidate composite architecture for a "Lumen transformer" (for scoping)

```
[ Static context: PRISM scores, CC indicator ] ──┐
                                                  ├─► fusion ─► per-channel potential outcomes
[ Journey events: channel×interaction tokens, ]   │            conversion_{ch}_0 / _1  (uplift)
[ with time-gap / continuous-time encoding   ] ──►│                     │
        (Family A encoder: SASRec/BST-style,      │                     ▼
         or Family C THP if timing matters)       │        [ Decision layer ]
                                                   │     constrained optimizer (today)
        (Family B head: CRN / Causal-Transformer- ┘     or RL/bandit (multi-step, later)
         style balanced-representation + treatment heads,
         multi-treatment per M³TN)
```

- **Encoder:** BST-style self-attention with **learned time-gap embeddings**, PRISM features fused as static context (PinnerFormer-style batch scoring fits a monthly job).
- **Head:** Causal-Transformer / CRN-style **balanced representation + per-treatment outcome heads**, multi-treatment (M³TN) → emits the same `conversion_{ch}_0/_1` the optimizer already consumes, but learned end-to-end with confounding correction replacing EconML's fragile linear DR final stage (this also sidesteps the underdetermined-covariance failure from the prior review).
- **Decision:** keep today's constrained optimizer initially; RL only if multi-step sequencing becomes a goal.
- **Governance note (from snapshot/D004):** a transformer is a **separate architecture → separate model-validation/compliance path**; it cannot inherit the XGBoost approval. This is a schedule cost, not a modeling cost, and should be priced into any effort estimate.

---

## 10. Effort & risk per path (qualitative, for later estimation)

Ordered simplest → most ambitious. On the confirmed sparse/low-frequency data (§0.6), value-per-effort is highest at the top.

| Path | What it is | Effort | Novelty/Risk | Gives causal uplift? | Notes |
|---|---|---|---|---|---|
| **P0 — Temporal features + XGBoost** (F0) | Stop collapsing to one vector; multi-window/RFM/recency features over 2022+ history | **Low** | **Low** | **Yes** (keeps DR) | **Recommended first move**; preserves compliance path; also enables time-based holdout (C6) |
| **P0b — Causal Survival Forest** (F2) | grf `causal_survival_forest`: per-channel uplift on time-to-conversion w/ censoring | **Med** | Low–Med | **Yes (native)** | Best fit for sparse censored bank data; reuses causal-forest rec (OQ24) |
| **P0c — Markov / HMM baseline** (F1) | Removal-effect / latent-state journey model | Low–Med | Low | No (attribution) | Interpretable diagnostic; sanity-check vs DR ATEs |
| **P1 — Rec-sys backbone as conversion model** | SASRec/BST via Transformers4Rec/RecBole, predict conversion/next channel | Low–Med | Low | **No** | Fast win for representation/ranking; same limitation as LiDDA; needs volume |
| **P1b — GRU/RNN sequence model** (F3) | GRU4Rec/LSTM — the neural rung before transformers | Med | Med | No (CRN head adds it) | Beats transformers under data constraints; cheaper |
| **P2 — Causal sequence head** | CRN / Causal Transformer producing per-channel counterfactuals | **High** | **High** | **Yes** | The real "transformer uplift"; research-grade code; healthcare→marketing transfer unproven |
| **P3 — TPP for timing** | THP/EasyTPP (or classical Hawkes, F4) for "when to contact" | Med | Med | No (timing) | Orthogonal capability; classical Hawkes if too sparse for neural |
| **P4 — Full composite (encoder+causal head+optimizer)** | §9 architecture | **Highest** | **High** | **Yes** | Ambitious v2/v3; biggest validation + compliance cost; only if data later justifies |
| **P5 — RL/bandit decisioning** | DRQN-attention sequential targeting | High | High | (policy value) | Multi-step generalization of optimizer; on-domain banking precedent exists |

---

## 11. Evidence gaps to close from our own data before estimating effort

1. **Journey length distribution** (touches/customer) — the single biggest determinant of whether sequence models help.
2. **Event richness** — how many distinct channel×interaction types actually populate journeys (DM sparsity issue from the snapshot directly hurts a sequence model).
3. **Volume** — confirm the ≈500K-customer / ≈2.8M-row scale vs. what these models need to beat GBDT (§8).
4. **Timestamp availability/quality** — needed for time-gap embeddings (BST) or TPP (THP); confirm `efectv_dt`/event-time granularity.
5. **Is timing/multi-step in product scope?** — decides whether C/D (TPP/RL) are in or out.
6. **Label horizon** — PinnerFormer-style long-term objective vs. next-touch conversion.

---

## 12. Reference bank (this review)

Sequential-recommendation transformers:
- SASRec — Kang & McAuley, ICDM 2018 — arXiv 1808.09781 — https://arxiv.org/abs/1808.09781 — code github.com/kang205/SASRec
- BERT4Rec — Sun et al., CIKM 2019 — arXiv 1904.06690 — https://arxiv.org/pdf/1904.06690
- BERT4Rec replicability — arXiv 2207.07483; "Turning Dross into Gold Loss" arXiv 2309.07602; code github.com/antklen/sasrec-bert4rec-recsys23
- BST — Chen et al., Alibaba, DLP-KDD 2019 — arXiv 1905.06874 — https://arxiv.org/pdf/1905.06874
- PinnerFormer — Pancha et al., Pinterest, KDD 2022 — arXiv 2205.04507 — https://arxiv.org/abs/2205.04507
- HSTU / Generative Recommenders — Zhai et al., Meta, ICML 2024 — arXiv 2402.17152 — https://arxiv.org/abs/2402.17152 — code github.com/meta-recsys/generative-recommenders
- GRU4Rec — Hidasi et al., 2016 (in RecBole)

Causal / counterfactual sequence & CATE models:
- RMSN — Lim et al., NeurIPS 2018
- CRN — Bica et al., ICLR 2020 — arXiv 2002.04083 — code github.com/ioanabica/Counterfactual-Recurrent-Network
- Causal Transformer — Melnychuk, Frauen, Feuerriegel, ICML 2022 — arXiv 2204.07258 — https://arxiv.org/abs/2204.07258
- Neural-CDE counterfactuals — arXiv 2206.08311; informative sampling — arXiv 2306.04255; causal diffusion — arXiv 2604.12992
- TARNet/CFRNet (Shalit et al. 2017); Dragonnet (Shi et al. 2019); M³TN multi-valued uplift — arXiv 2401.14426; TransTEE; DAG-aware Transformer — arXiv 2410.10044; CausalPFN — arXiv 2506.07918

Temporal point processes:
- THP — Zuo et al., ICML 2020 — arXiv 2002.09291 — code github.com/SimiaoZuo/Transformer-Hawkes-Process
- EasyTPP — Xue et al., ICLR 2024 — arXiv 2307.08097 — code github.com/ant-research/EasyTemporalPointProcess

RL / NBA in marketing & banking:
- Customer Acquisition via Explainable Deep RL (DRQN-Attention) — Song, Wang, Yao — SSRN 4802411 — https://doi.org/10.2139/ssrn.4802411
- Grid Dynamics NBA-with-RL; Braze RL-for-marketing (industry writeups)

Marketing deep journey / attribution-prediction:
- DeepMTA / Interpretable DL for Online MTA — Du et al. — arXiv 2004.00384 — https://arxiv.org/pdf/2004.00384
- UMD "AI for Customer Journeys: A Transformer Approach" (R.H. Smith School)

Lighter-weight / pre-transformer models (Family F):
- Temporal-feature XGBoost for churn — Gregory, WSDM Cup 2018 — arXiv 1802.03396 — https://arxiv.org/pdf/1802.03396
- Time-varying RFM for churn (DNN) — Annals of Operations Research 2024 — https://ideas.repec.org/a/spr/annopr/v339y2024i1d10.1007_s10479-023-05259-9.html
- Churn with sequential data & DNN: comparative analysis — arXiv 1909.11114; retail churn deep sequential — arXiv 2304.00575
- HMM of Customer Relationship Dynamics (Netzer, Lattin, Srinivasan); higher-order Markov journeys (Anderl et al.); HMMs in Marketing (Columbia chapter)
- GRU4Rec — Hidasi et al., ICLR 2016 — arXiv 1511.06939 — https://arxiv.org/pdf/1511.06939
- RNN/GRU beat transformers under data constraints (sequential-rec evidence; see §1/§6b search trail)
- Survival: DeepHit (Lee et al., AAAI 2018); Dynamic-DeepHit; continuous/discrete-time NN survival — Kvamme & Borgan (Lifetime Data Analysis 2021); deep survival review — Artif. Intell. Rev. 2023
- **Causal Survival Forests** — Cui, Kosorok, Sverdrup, Wager, Zhu, JRSS-B 2023 — arXiv 2001.09887 — https://arxiv.org/abs/2001.09887; practitioner guide arXiv 2312.02482; `causal_survival_forest` in grf
- SurvHTE-Bench (HTE in survival) — arXiv 2603.05483
- Hawkes processes tutorial (sparse self-exciting events) — Rizoiu et al. — arXiv 1708.06401 — https://arxiv.org/abs/1708.06401

Tooling & tabular-vs-DL evidence:
- Transformers4Rec — de Souza Pereira Moreira et al., RecSys 2021 — github.com/NVIDIA-Merlin/Transformers4Rec
- RecBole — github.com/RUCAIBox/RecBole
- "When Do Neural Nets Outperform Boosted Trees on Tabular Data?" — arXiv 2305.02997
- Discrete tokenization tabular forecasting — arXiv 2603.07448; Tabular transformers @ Booking.com — arXiv 2405.13692; Transformers boost trees across sample sizes — arXiv 2502.02672
- LiDDA (attribution baseline, for contrast) — arXiv 2505.09861
