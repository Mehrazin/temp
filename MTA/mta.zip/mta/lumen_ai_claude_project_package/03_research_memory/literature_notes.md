# Literature Notes

## Status

First literature pass added 2026-06-15 (method review). Entries below; full source list in `reference_bank.md`.

## Entry Template

```text
Source / Paper:
Topic:
Main idea:
Relevance to Lumen AI:
Assumptions:
Limitations:
Production implication:
Citation / link:
```

---

## Entries (2026-06-15)

### EconML `LinearDRLearner` — underdetermined covariance / invalid inference

- **Topic:** Why DR inference fails numerically.
- **Main idea:** EconML warns "Co-variance matrix is underdetermined. Inference will be invalid!" when the rank of the final-stage feature matrix < number of parameters. That matrix = featurizer(X) + intercept column, then interacted with the treatment. Triggered by (near-)collinear X columns or fewer informative obs than features per treatment arm. Default inference is HC1 robust SEs → CIs/z-stats/p-values become unreliable when underdetermined.
- **Relevance:** This is exactly Lumen's `zstat=-inf` / "Co-variance matrix is underdetermined" symptom (Paid_Search persists after Tree-VIF removed Social_CT). Root cause: one-vs-rest puts t_channel_* in both X/W and as T (collinearity), plus rare channels (low positive counts) and propensity-overlap problems.
- **Limitations / production implication:** Inference layer cannot be trusted until rank deficiency fixed; point predictions from cross-fitted regressions are less affected. Fix: drop treatment cols from X/W, shrink final-stage dimension, pool/threshold rare channels, trim/stabilize extreme propensity weights or use overlap weights.
- **Citation:** EconML docs (LinearDRLearner, Inference spec), GitHub issue #262.

### Doubly-robust estimation under positivity/overlap violations

- **Main idea:** DR = direct method (outcome model) + IPW on residuals; consistent if either nuisance is correct. But IPW component explodes with extreme/near-zero propensities (positivity violations), making variance and inference unstable even when point estimates survive. Overlap weights (ATO) and the e-score are bounded alternatives that bypass extreme weights.
- **Relevance:** Lumen has poor channel overlap (some customers ~0 prob of some channels) → extreme weights → unstable ATEs and the covariance failure.
- **Production implication:** Consider overlap/ATO weighting or trimming; report on overlap diagnostics before trusting effects.
- **Citation:** arXiv 2406.00853 (DR tutorial); arXiv 2006.04038 (overlap, limited overlap); arXiv 1807.09148 (e-score); Matsouaka 2024 (overlap weights).

### Cross-fitting / DML

- **Main idea:** Fitting nuisance models out-of-fold and averaging removes own-observation overfitting bias; foundational to valid DR/DML.
- **Relevance:** Lumen's 5-fold StratifiedKFold cross-fitting is correct and worth keeping.
- **Citation:** arXiv 2007.02852 (cross-fitting and averaging); Chernozhukov et al. DML.

### Shapley & causal multi-touch attribution

- **Main idea:** Shapley fairly distributes credit over observed co-occurring touchpoints but reflects correlation, not causation, and is confounded by user selection into journeys. Causal MTA methods (CausalMTA, DCRMTA, causally-driven incremental MTA) add confounding correction.
- **Relevance:** Supports Lumen's choice of DR over naive Shapley (D007); documented Shapley-vs-DR sign flips are consistent with Shapley's correlational bias.
- **Citation:** arXiv 2201.00689 (CausalMTA), 2401.08875 (DCRMTA), 1902.00215 (causally-driven incremental MTA).

### Uplift modeling / CATE — meta-learners, causal forests, Qini/AUUC

- **Main idea:** Uplift = CATE; evaluate with Qini coefficient / AUUC (area under uplift curve), which measure incremental targeting efficiency vs random — not raw AUC. Large marketing comparisons find X-/DR-learners competitive with causal forests. Multi-treatment uplift benefits from score-ranking + calibration.
- **Relevance:** Lumen is a next-best-action system; it should evaluate with Qini/AUUC, not response-model AUC. Optimizer should target lift, not conversion.
- **Citation:** arXiv 2604.06123 (meta-learners vs causal forests, marketing), 2408.13628 (multi-treatment uplift ranking + calibration).

### Causal forests / GRF (Wager–Athey)

- **Main idea:** Non-parametric CATE with honest splitting; pointwise consistent, asymptotically Gaussian → valid confidence intervals; native multi-arm support. Splits maximize treatment-effect difference.
- **Relevance:** Strong alternative to LinearDRLearner that avoids the rank-deficient linear final stage; available as CausalForestDML in EconML.
- **Citation:** arXiv 1510.04342 (Wager & Athey, JASA 2018); grf-labs.github.io/grf.

### Off-policy evaluation (IPS / DR / contextual bandits)

- **Main idea:** Estimate a target policy's value from logged data via IPS (unbiased, high variance), Direct Method (biased, low variance), or DR (hybrid, consistent if either component correct). The principled way to compare policies offline.
- **Relevance:** Replaces Lumen's "lucky match" comparison, which conditions on agreement (selection bias) and only measures ranking. DR-OPE gives a policy-value estimate with CIs.
- **Citation:** Dudík et al. "Optimal and adaptive off-policy evaluation in contextual bandits" (ICML 2017); off-policy DR literature.

### Contextual bandits for causal marketing

- **Main idea:** Combine uplift + bandits (e.g., Thompson sampling) to both serve next-best-action and gather randomized exploration data that supports future causal estimates.
- **Relevance:** Natural production evolution; directly addresses Lumen's "no experiment" gap. Medium-term, higher governance lift.
- **Citation:** arXiv 1810.01859 (contextual MAB for causal marketing).

### Champion/challenger & efficient targeting-policy evaluation

- **Main idea:** Randomized champion-vs-challenger field tests are the gold standard for comparing targeting policies; more efficient variants exist.
- **Relevance:** The eventual validation that would license an incremental-uplift claim for Lumen.
- **Citation:** Simester et al., "Efficiently Evaluating Targeting Policies," Management Science 66(8), 2020.

### Markov-chain attribution (removal effect)

- **Main idea:** Models journeys as transitions; channel value = drop in conversion when the channel is removed. Interpretable but correlational.
- **Relevance:** Cheap diagnostic baseline / sanity check for the attribution lens; not an NBA engine.
- **Citation:** Standard MTA practitioner literature (removal effect).

### LiDDA — transformer attribution at LinkedIn

- **Topic:** Transformer/attention attribution.
- **Main idea:** Unified transformer that handles member-level + aggregate data, integrates DDA (bottom-up) with MMM (top-down), single attention layer, incrementality-validated online.
- **Relevance to Lumen:** Architecture reference for a future sequence model. BUT it solves attribution (credit assignment), not next-best-action — a Lumen transformer would need a predictive/uplift head + optimizer on top. Compliance path cannot transfer from XGBoost.
- **Limitations:** Different problem framing; large infra; aggregate calibration assumptions.
- **Citation:** arXiv 2505.09861 (v3); authors Bencina et al., submitted 2025-05-14.

---

## Entries (2026-06-15b) — Lighter-weight / pre-transformer models for sparse, low-frequency journeys

Context: tech lead confirmed the data is **bank journeys from 2022**, with **low/uneven event frequency** (digital frequent; Email/DM/Leads sparse), and that **current Lumen collapses an April–July snapshot into a flat XGBoost vector** (no sequence, no full history). This regime favors simpler models. Full ladder + repos in `transformer_sequence_modeling_review.md` §0.6, §6b, §10.

### Temporal feature engineering + XGBoost (F0)

- **Main idea:** keep GBDT; replace the single collapsed vector with multi-window / RFM / recency / inter-touch-gap features over the full 2022+ history.
- **Relevance:** lowest-effort, highest value-per-effort; preserves DR/uplift wiring and compliance path; enables the time-based holdout (method-critique C6).
- **Evidence:** temporally-engineered XGBoost won WSDM 2018 churn (arXiv 1802.03396); time-varying RFM is the backbone of churn forecasting (Annals of OR 2024); tree GBMs not outperformed by NNs in financial classification.

### Markov / Higher-order Markov / HMM (F1)

- **Main idea:** removal-effect attribution / latent customer-state dynamics; Markov does **better on sparse than dense** sequences.
- **Relevance:** interpretable, low-data diagnostic baseline and sanity check vs DR ATEs. **Attribution/descriptive, not uplift.**
- **Citation:** Netzer et al. HMM of Customer Relationship Dynamics; Anderl et al. higher-order Markov; HMMs-in-Marketing (Columbia).

### Survival / time-to-event, incl. Causal Survival Forests (F2) — strong fit

- **Main idea:** a 2022-onward journey with convert-or-not is right-censored time-to-event. Classical (Cox, discrete-time, Random Survival Forest) → deep (DeepHit, Dynamic-DeepHit) → **causal (Causal Survival Forests): per-customer per-channel uplift on time-to-conversion with censoring, via doubly-robust/orthogonal estimating equations.**
- **Relevance:** gives the causal uplift Lumen needs, fits sparse censored data far better than a transformer, available in grf; reuses the causal-forest recommendation (OQ24).
- **Citation:** Cui, Kosorok, Sverdrup, Wager, Zhu, JRSS-B 2023 (arXiv 2001.09887); grf practitioner guide arXiv 2312.02482; SurvHTE-Bench arXiv 2603.05483; DeepHit (Lee et al. AAAI 2018).
- **Production implication:** classical/forest variants are low-risk and interpretable; deep survival only if data volume supports.

### RNN / GRU (F3)

- **Main idea:** GRU4Rec/LSTM. Under data constraints / short sequences, **RNNs consistently beat transformers** and train cheaper; the correct neural rung before a transformer. Still predictive (CRN adds the causal head, §3).
- **Citation:** Hidasi et al. GRU4Rec (ICLR 2016, arXiv 1511.06939); churn DNN comparisons arXiv 1909.11114, 2304.00575.

### Classical Hawkes processes (F4)

- **Main idea:** self-exciting point processes for sparse, clustered, irregular events; estimable on small data via penalized MLE; far fewer params than neural TPP (THP).
- **Relevance:** lightweight "when to contact" option if data too sparse for neural TPP.
- **Citation:** Rizoiu et al. tutorial, arXiv 1708.06401.

---

## Entries (2026-06-15c) — Transformer implementation (manager-directed); treatment-conditional core + process

Context: manager persisting on transformer; goal good-enough + flexible; combos must be generated on demand. Full plan in `transformer_implementation_plan.md`.

### Design pattern — treatment-conditional core model + process layer (the key idea)

- **Main idea:** make the proposed action-set an **input** to one core model (not 2^N output heads); a thin **process** scores only business-relevant candidate sets each month and runs constrained assignment. = g-computation / counterfactual query.
- **Combos:** represent action-set as a **set of channel embeddings** with permutation-invariant pooling (Deep Sets / Set Transformer) → generalizes to unseen combos; single channel = size-1 set.
- **Causality:** S-learner `uplift(A)=pred(A)−pred(∅)` for v1; Causal/G-Transformer for rigor.
- **Relevance:** directly satisfies "core model + process generates combo scores, aligns with changing business needs."

### Temporal Fusion Transformer (A2) — best easy fit

- **Main idea:** separates static covariates / past observed / **known future inputs**; planned channel goes in the known-future slot → query any plan/combo. Variable selection + interpretable attention; quantile outputs.
- **Relevance/limit:** treatment-as-input with no custom architecture; needs adapting to binary conversion; sequence-aware but OK on modest data. Pkg pytorch-forecasting. arXiv 1912.09363.

### FT-Transformer / TabTransformer (A1) — easiest

- **Main idea:** feature-tokenizer + transformer over tabular features; action enters as multi-hot. Closest drop-in to current XGBoost vector; robust on sparse/short data.
- **Relevance/limit:** fast baseline; not a true sequence model; weak S-learner causality. Pkg pytorch-tabular. arXiv 2106.11959.

### Causal Transformer / G-Transformer (A4) — rigorous causal, treatment-as-input

- **Main idea:** estimate counterfactual outcomes under arbitrary treatment strategies over time with confounding adjustment; g-computation simulates any plan forward.
- **Relevance/limit:** directly delivers flexible counterfactual combo scoring + the causal head; research-grade code, healthcare provenance (see data-fit checklist), highest effort. Code: Valentyn1997/CausalTransformer (arXiv 2204.07258); konstantinhess/G_transformer (arXiv 2405.21012); g-computation variant arXiv 2406.05504.

### Set Transformer / Deep Sets (A5) — combo enabler

- **Main idea:** permutation-invariant set encoding; universal approximator of set functions via attention pooling (PMA).
- **Relevance:** the ~50-line component that makes any encoder score arbitrary combos compositionally. arXiv 1810.00825.

### Process / assignment layer

- **Main idea:** multi-treatment uplift + constrained budget allocation; differentiable ILP allocation layer exists (arXiv 2408.11623); classic multi-treatment cost-optimization in CausalML (arXiv 1908.05372).
- **Relevance:** the swappable decision layer that consumes per-customer×candidate-set uplift and assigns under monthly business rules.
