# Reference Bank

## Status

Populated 2026-06-15 (first method review). "Supports / Challenges" is relative to Lumen's current method.

## Entry Template

```text
Reference:
Type: Academic paper / industry article / documentation / internal reference
Topic:
Why it matters:
Supports current method: Yes / No / Partially
Challenges current method: Yes / No / Partially
Citation / link:
```

---

## EconML / Doubly-Robust tooling

- **EconML `LinearDRLearner` docs** — Documentation. DR estimator API. Supports method choice. https://econml.azurewebsites.net/_autosummary/econml.dr.LinearDRLearner.html
- **EconML Inference spec** — Documentation. Explains HC1 robust inference and when the covariance becomes underdetermined. Challenges current inference validity. https://www.pywhy.org/EconML/spec/inference.html
- **EconML issue #262 "Co-variance matrix is undetermined"** — Documentation/issue. Confirms root cause (rank < df from collinearity / too few obs). Challenges current inference. https://github.com/microsoft/EconML/issues/262
- **EconML doubly-robust spec** — Documentation. https://www.pywhy.org/EconML/spec/estimation/dr.html (logged in prior package note)
- **Causal Inference for the Brave and True, ch.12 (Doubly Robust)** — Primer. https://matheusfacure.github.io/python-causality-handbook/12-Doubly-Robust-Estimation.html (logged previously)

## Doubly-robust theory & positivity/overlap

- **A Tutorial on Doubly Robust Learning for Causal Inference** — arXiv 2406.00853. Partially supports (validates DR); challenges (extreme-weight sensitivity). https://arxiv.org/abs/2406.00853
- **Propensity score weighting under limited overlap** — arXiv 2006.04038. Challenges (overlap/positivity). https://arxiv.org/pdf/2006.04038
- **Doubly robust estimators under positivity violations (e-score)** — arXiv 1807.09148. Challenges; offers bounded-weight fix. https://arxiv.org/pdf/1807.09148
- **Causal inference in the absence of positivity: overlap weights (Matsouaka 2024)** — Biometrical Journal. Challenges; ATO alternative. https://onlinelibrary.wiley.com/doi/10.1002/bimj.202300156
- **Cross-Fitting and Averaging for ML estimation of HTE** — arXiv 2007.02852. Supports (cross-fitting design). https://arxiv.org/pdf/2007.02852

## Attribution (Shapley & causal MTA)

- **CausalMTA: Eliminating User Confounding Bias** — arXiv 2201.00689. Supports DR-over-Shapley rationale. https://arxiv.org/pdf/2201.00689
- **DCRMTA: Unbiased Causal Representation for MTA** — arXiv 2401.08875. Supports. https://arxiv.org/pdf/2401.08875
- **Causally Driven Incremental Multi-Touch Attribution** — arXiv 1902.00215. Supports. https://arxiv.org/pdf/1902.00215

## Uplift / CATE / evaluation

- **Empirical Comparison of Meta-Learners and Causal Forests for HTE in Marketing Uplift** — arXiv 2604.06123. Supports alternatives (X-/DR-learner, causal forest). https://arxiv.org/html/2604.06123
- **Enhancing Uplift Modeling in Multi-Treatment Campaigns (score ranking + calibration)** — arXiv 2408.13628. Partially challenges (calibration matters for multi-treatment). https://arxiv.org/html/2408.13628
- **Estimation and Inference of HTE using Random Forests (Wager & Athey)** — arXiv 1510.04342 / JASA 2018. Offers alternative with valid CIs. https://arxiv.org/pdf/1510.04342
- **Generalized Random Forests (grf)** — Documentation. https://grf-labs.github.io/grf/

## Off-policy evaluation & bandits

- **Optimal and adaptive off-policy evaluation in contextual bandits (Dudík et al.)** — ICML 2017. Replaces "lucky match" OPE. https://dl.acm.org/doi/10.5555/3305890.3306052
- **Contextual Multi-Armed Bandits for Causal Marketing** — arXiv 1810.01859. Production-evolution option. https://arxiv.org/abs/1810.01859
- **Efficiently Evaluating Targeting Policies: Improving on Champion vs. Challenger (Simester et al.)** — Management Science 66(8), 2020. Gold-standard validation path. https://pubsonline.informs.org/doi/10.1287/mnsc.2019.3379

## Sequence / transformer attribution

- **LiDDA: Data Driven Attribution at LinkedIn** — arXiv 2505.09861 (v3). Architecture reference; solves attribution, not NBA. https://arxiv.org/abs/2505.09861

## Lighter-weight / pre-transformer models for sparse journeys (2026-06-15b)

- **Predicting Customer Churn: XGBoost with Temporal Data** — arXiv 1802.03396. Supports F0 (temporal features + GBDT). https://arxiv.org/pdf/1802.03396
- **Exploiting time-varying RFM for churn** — Annals of OR 2024. Supports F0. https://ideas.repec.org/a/spr/annopr/v339y2024i1d10.1007_s10479-023-05259-9.html
- **Churn with sequential data & DNN: comparative analysis** — arXiv 1909.11114; retail deep sequential churn — arXiv 2304.00575. Context (RNN vs alternatives).
- **HMM of Customer Relationship Dynamics** (Netzer, Lattin, Srinivasan); higher-order Markov journeys (Anderl et al.); HMMs in Marketing (Columbia chapter). Supports F1; attribution/descriptive only.
- **GRU4Rec** — Hidasi et al., ICLR 2016 — arXiv 1511.06939. Supports F3 (RNN before transformer). https://arxiv.org/pdf/1511.06939
- **Causal Survival Forests** — Cui, Kosorok, Sverdrup, Wager, Zhu, JRSS-B 2023 — arXiv 2001.09887. **Strongly supports F2**; causal uplift on censored time-to-event; in grf. https://arxiv.org/abs/2001.09887
- **Treatment heterogeneity with right-censored outcomes using grf** (practitioner guide) — arXiv 2312.02482.
- **SurvHTE-Bench** — arXiv 2603.05483. Benchmark for HTE in survival.
- **DeepHit** — Lee et al., AAAI 2018; Dynamic-DeepHit (RNN, time-varying). Supports F2 deep variant.
- **A Tutorial on Hawkes Processes** — Rizoiu et al. — arXiv 1708.06401. Supports F4 (classical Hawkes, sparse events). https://arxiv.org/abs/1708.06401
- **When Do Neural Nets Outperform Boosted Trees on Tabular Data?** — arXiv 2305.02997. Supports keeping GBDT at small/medium scale.
- Tooling: **grf** (causal_survival_forest), **scikit-survival**/**lifelines** (Cox/RSF/discrete-time), **pycox** (DeepHit), **tick** (Hawkes), **tsfresh** (temporal features).

## Transformer implementation — treatment-conditional core + process (2026-06-15c)

- **Temporal Fusion Transformer** — Lim et al. — arXiv 1912.09363. Supports A2; "known future input" = treatment slot. Pkg: pytorch-forecasting.
- **FT-Transformer / Revisiting DL for Tabular Data** — Gorishniy et al. — arXiv 2106.11959. Supports A1. Pkg: pytorch-tabular (manujosephv/pytorch_tabular); TabTransformer: lucidrains/tab-transformer-pytorch.
- **Causal Transformer** — Melnychuk et al., ICML 2022 — arXiv 2204.07258 — **code github.com/Valentyn1997/CausalTransformer**. Supports A4 (rigorous, treatment-as-input counterfactual).
- **G-Transformer (CAPO over time)** — Hess, Melnychuk, Feuerriegel — arXiv 2405.21012 — **code github.com/konstantinhess/G_transformer**. Supports A4.
- **G-Transformer (g-computation, dynamic regimes)** — arXiv 2406.05504. Supports A4; forward-simulate any treatment strategy.
- **Set Transformer** — Lee et al., ICML 2019 — arXiv 1810.00825 (Deep Sets: Zaheer et al. 2017). Supports A5 / compositional combo scoring (permutation-invariant set pooling).
- **Uplift Modeling for Multiple Treatments with Cost Optimization** — Zhao & Harinen — arXiv 1908.05372. Supports process layer; in Uber **CausalML**.
- **End-to-End Incentive Recommendation under Budget Constraint (differentiable ILP)** — arXiv 2408.11623. Supports process/optimizer layer.
- **Multi-Treatment Multi-Task Uplift** — arXiv 2408.12803. Context for multi-channel uplift heads.
- Tooling: **pytorch-forecasting** (TFT), **pytorch-tabular** (FT-Transformer), **Transformers4Rec**/**RecBole** (rec encoders A3), **CausalML** / **scikit-uplift** (multi-treatment uplift + Qini/AUUC), CausalTransformer & G_transformer repos.

## Consolidation pass additions (2026-06-16) — Chat-2 independent scan, lift-de-emphasis, output contract

Sources are marked **[ACADEMIC] / [INDUSTRY] / [CODE]**. "Supports/Challenges" is relative to Lumen's current method and to the prior chat's lift-anchored framing.

### Prediction-first & next-best-action models (non-causal)
- **[ACADEMIC] TIMeSynC — Temporal Intent Modelling, Capital One** — arXiv 2410.12825. Closest fintech multi-channel customer-journey transformer (encoder-decoder, time-aware ALiBi). Predictive/recall, not causal; trained on 30M+ sequences. Supports prediction-first NBA framing; **challenges** transformer-beats-GBDT-at-our-scale (modest lifts, 100× our volume). https://arxiv.org/abs/2410.12825
- **[ACADEMIC] Personalized Next-Best-Action with Multi-Party Interaction Learning (Cao & Zhu, UTS)** — arXiv 2108.08846. RNN/RL scorer with the **action as input + top-k** selection; academic precedent for the D010 action-as-input pattern. Supports. https://arxiv.org/abs/2108.08846
- **[ACADEMIC] SRP4CTR — Sequential Recommendation Pre-training for CTR** — arXiv 2407.19658. Self-supervised pretrain → fine-tune improves conversion prediction. Supports prediction-first pretraining (CP5). https://arxiv.org/abs/2407.19658
- **[ACADEMIC] Abacus — Self-Supervised Pretraining for Sequential User Modeling** — arXiv 2512.16581. Supports CP5 in sparse-positive regimes.
- **[ACADEMIC] Markovian Pre-Trained Transformer (MPT)** — arXiv 2601.08275. Pretraining aids transfer with little labeled data. Supports CP5.
- **[ACADEMIC] Pairwise Ranking Loss for Multi-Task Learning in RecSys (Huawei)** — arXiv 2406.02163; **[ACADEMIC] Cross-Task Knowledge Distillation in MTL (Tencent)** — arXiv 2202.09852; **[ACADEMIC] DHEN CTR/CVR (Pinterest)** — arXiv 2504.08169. Support multi-task scorer (CP5).
- **[ACADEMIC] SASRec** — arXiv 1808.09781; **BERT4Rec** — arXiv 1904.06690; replicability/critique — arXiv 2207.07483, 2309.07602. Encoder canon; BERT4Rec edge over SASRec is fragile (use SASRec default).

### Tabular DL vs GBDT reality check
- **[ACADEMIC] Revisiting Deep Learning Models for Tabular Data (FT-Transformer)** — arXiv 2106.11959. Competitive on some tasks, not consistently. Partially supports CP2; **challenges** assumed accuracy win.
- **[ACADEMIC] UpliftBench — Meta-learners vs Causal Forest, 13.98M Criteo** — arXiv 2604.06123. **S-Learner over GBDT wins on Qini.** Strongly **challenges** the need for a fancy causal model; supports keeping GBDT as the bar. Public eval harness: github.com/Aman12x/UpliftBench. https://arxiv.org/abs/2604.06123
- **[INDUSTRY] "Tree models still win on tabular" consensus** (Grinsztajn et al. line; deeplearning.ai The Batch coverage). Supports CP1 baseline.

### Decision / optimization layer (scores → assignment, kept separate)
- **[ACADEMIC] A Unified Framework for Marketing Budget Allocation (Alibaba)** — arXiv 1902.01128.
- **[ACADEMIC] Direct Heterogeneous Causal Learning for Resource Allocation (Meituan)** — arXiv 2211.15728.
- **[ACADEMIC] Decision-Focused Causal Learning for Counterfactual Marketing Optimization (Meituan)** — arXiv 2407.13664.
- **[ACADEMIC] End-to-End Marketing Effectiveness under Budget Constraint (Kuaishou)** — arXiv 2302.04477; **constrained user-item allocation** — arXiv 2606.09623; **offline constrained deep RL budget allocation (Ant)** — arXiv 2309.02669; **contextual bandits for causal marketing** — arXiv 1810.01859. Support keeping the optimizer as a separate, reusable config-driven layer (D010/D011).

### Marketing-attribution transformers (adjacent; attribution ≠ NBA)
- **[ACADEMIC] NNN — Transformer marketing measurement (Google)** — arXiv 2504.06212; **CAMTA causal attention** — arXiv 2012.11403; **dual-attention MTA** — arXiv 1808.03737; **DeepMTA-with-attention** — arXiv 1809.02230. Architecture/feature references only; do not produce a channel recommendation.

### Multi-treatment / combo uplift (for the combo path, V2)
- **[ACADEMIC] Heterogeneous Multi-treatment Uplift (short video)** — arXiv 2511.18997; **[ACADEMIC] Cross-Treatment Effect, multi-valued (Didi)** — arXiv 2511.01641; **[ACADEMIC] Debiased CTR + Uplift for coupons** — arXiv 2602.12972. Encouraging for multi-channel; platform-scale, recent — references, not turnkey.

### Repositories inspected this pass (maturity)
- **[CODE] NVIDIA-Merlin/Transformers4Rec** — production; SASRec/XLNet, NVTabular, Triton. github.com/NVIDIA-Merlin/Transformers4Rec
- **[CODE] jdb78/pytorch-forecasting** — mature; TFT with known-future input slot.
- **[CODE] Valentyn1997/CausalTransformer** — research-grade; cancer-sim/MIMIC-III data layer; reference only for the causal head.
- **[CODE] Aman12x/UpliftBench** — lightweight; reusable Qini/AUUC/policy-sim/SHAP eval + GBDT baselines.
- **[CODE] grf / EconML / CausalML / scikit-uplift / RecBole** — mature components (causal survival/forest, DR, multi-treatment uplift, quick SASRec baselines).

### Output-contract / interface references
- **[INTERNAL] PRISM-style long score table** (`customer_id, model_id, model_score, model_score_rank, effective_date`) — the schema pattern Lumen's contract should generalize. See `production_score_contract_options.md`.
- **[ACADEMIC] Set Transformer / Deep Sets** — arXiv 1810.00825 — permutation-invariant set encoding for compositional combo scoring (single = size-1 set). Supports the action registry's set representation.
