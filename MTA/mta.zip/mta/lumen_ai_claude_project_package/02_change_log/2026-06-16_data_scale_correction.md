# Change Log — 2026-06-16 Data-Scale Correction

## Source & Trigger

Tech-lead review of `04_outputs/transformer_design_input_snapshot.md`. That file (and, by inheritance, several scale-dependent statements) **misinterpreted the data scale**: it treated the prototype experiment/evaluation slice as if it were the full available data, and on that basis described the project as "~500K customers / ~2.8M rows … moderate volume … ~100× below transformer precedents," which fed a conclusion that a transformer would likely only *match* XGBoost. **That scale premise is incorrect.** This entry corrects the record. It does **not** change the confirmed direction.

All counts below are **approximate** unless explicitly confirmed.

## Corrected Data Context — Four Distinct Layers

These four things must not be conflated:

1. **Prototype experiment subset** — the *filtered* slice the XGBoost/DR baseline was trained on (prototype/experimental only, not the full source). **≈2–3M customers (approx).** Window roughly **April → (July *or* January, depending on the experiment version)**; the exact end date is **(needs confirmation)**. The previously noted "~2.8M train rows" cleaned table corresponds to this layer.
2. **Prototype test / evaluation set** — the held-out evaluation subset of the prototype, **≈500K customers (approx)** (consistent with the observed ~521K test rows; the ~100K "Sample1" optimizer sample is a further sub-sample of this). **500K is a test/evaluation subset, not the modeling population.**
3. **Full available rich source data** — timestamped touchpoint history going back to **≈2022**, likely **≈10–15M customers (approx)** with many historical touchpoints. **Not yet used for modeling.**
4. **Cleaned, transformer-ready training dataset** — **does not yet exist.** Producing it requires profiling, cleaning, sequence construction, timestamp validation, channel-coverage checks, and label-window design.

## What Was Wrong, and the Correction

- **Wrong:** "the project / data is ~500K customers" and "moderate volume." → **Correct:** 500K is the prototype *test* subset; the prototype experiment was ≈2–3M customers; the full source is ≈10–15M customers since ≈2022.
- **Wrong (as a settled premise):** "expect a transformer to only *match*, not beat, XGBoost because the data is moderate-volume / ~100× below transformer precedents." → **Correct:** that inference rested on the prototype-slice scale. The **full source data may be substantially more suitable for sequence/transformer modeling** than the prototype slice implied. The match-not-beat expectation is therefore **re-opened**, pending profiling of the full data (it is not refuted either — it must be re-evaluated on real numbers).
- **Not changed / explicitly retained:** the full source data is **not** automatically "transformer-ready." Layer 4 must be built first.

## Implications

- **Do not** describe Lumen as limited to 500K customers, and **do not** call the data "moderate volume" based on the prototype test set.
- The transformer feasibility case is **plausibly stronger** than the prior snapshot implied — but is **gated on building the cleaned transformer-ready dataset (Layer 4)** from the full source (Layer 3). This data-engineering work sits underneath the 2–4 week spike timeline and is a real dependency/risk for it.
- Scale-dependent conclusions in `transformer_design_input_snapshot.md` (notably §5 data-regime claims, §12 path feasibility, and §16 item 5 "expect match, not beat") are flagged as **under re-evaluation** against the full data.

## Direction Preserved (unchanged)

- Transformer remains the **manager-directed primary direction** (D004).
- XGBoost/DR remains the **baseline / fallback** (D001).
- Package-first remains **deferred / secondary** (D003).
- Flexible config-driven outputs remain a **confirmed requirement** (D010/D011).
- Claim discipline (D005) unchanged.

## Files Updated

- `01_current_state/current_snapshot.md` — added the four-layer data taxonomy; removed "500K = population" / "moderate volume" framing.
- `01_current_state/decision_register.md` — dated notes on D001 and D004 (baseline used the prototype subset; full-data fit + Layer-4 dependency).
- `01_current_state/open_questions.md` — reworked the scale-reconciliation and volume questions; added cleaned-dataset and count/window-confirmation questions.
- `01_current_state/context_index.md` — indexed this change-log; flagged the corrected design-input snapshot.
- `04_outputs/transformer_design_input_snapshot.md` — added a correction banner and fixed the erroneous scale statements (§5, §9); scale-dependent conclusions flagged for re-evaluation.
