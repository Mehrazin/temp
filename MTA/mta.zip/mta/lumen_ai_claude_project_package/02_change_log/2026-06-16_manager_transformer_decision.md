# Change Log — 2026-06-16 Manager/Team Decision: Transformer Direction Confirmed

## Source

A manager/team discussion held after the 2026-06-15 context update and method/research review. This entry records the confirmed direction; it builds on (and versions, not replaces) the 2026-06-15 entries and the research files produced by the method-review work.

Caveat: the transformer is confirmed as the **direction**, not as a proven or built model. Nothing here implies the transformer works, beats the baseline, or is production-ready. The spike's outcome is unknown.

## Confirmed Decisions

- **Transformer-based model is now the confirmed primary modeling direction** (manager insisting; team aligned). Previously this was "manager-directed to pursue / planning spike" (D004, 2026-06-15c); it is now confirmed.
- **Timeline:** roughly **2–4 weeks** to produce a model, run experimentation, and finalize the design ("good enough," not perfect).
- **XGBoost + Doubly Robust (the implemented MTA/TMIA work) is repositioned as the baseline / comparison**, no longer the main direction. It remains valuable as a benchmark and fallback.
- **Package-first is deferred / secondary** (not dropped). The model is the priority (D009); a reusable package remains a later goal.

## Confirmed Requirement: Flexible, Config-Driven Business Outputs

The model/design must support flexible business use cases — not only "one next channel." Future business requests may require any of:

- top-1 channel,
- top-K channels,
- multiple channels per customer,
- capacity constraints,
- allowed-channel filters,
- no-contact logic,
- different objectives.

To meet this, the agreed design intent is a **reusable scorer** (a single core model) plus a **separate, config-driven scoring/optimization layer** that produces the business-specific outputs each cycle without retraining. This confirms the design pattern already proposed as D010 (treatment-conditional core model + thin assignment process): the proposed action-set is an **input** to the scorer, not pre-enumerated output heads, and combos are handled compositionally (permutation-invariant set encoding). See `03_research_memory/transformer_implementation_plan.md`.

## What Changed vs. the 2026-06-15 State

- D004 status: "manager-directed to pursue (spike)" → **Confirmed (primary direction)**.
- D001 (XGBoost/DR): "Confirmed/Implemented baseline" → **repositioned as baseline/comparison**, not the primary direction.
- D003 (package-first): explicitly **Deferred / Secondary** (retained, not deleted).
- D010 (treatment-conditional core + process layer): the requirement it serves is now a **confirmed manager/team requirement**; the specific realization (set-pooled core, S-learner uplift, config-driven process) remains a proposed/prototyping design.
- New **D011**: the flexible, config-driven business-output requirement, recorded as a confirmed mandate.

## Carried-Forward Caveats (still in force)

- No live validation; the separate compliance/model-validation path for a new architecture still applies (a transformer cannot inherit the XGBoost approval path).
- Data-foundation issues remain unresolved (MTA vs TMIA vs hybrid, direct-mail sourcing, scale, non-temporal split) and sit underneath the 2–4 week timeline — see `open_questions.md`.
- The research review's "lighter-models-first" ladder (temporal-feature XGBoost, causal survival forest, GRU/Markov baselines) remains valid as baselines/fallbacks even though the transformer is the directed path.
- Claim discipline (D005) is unchanged: do not present the +11.18% OPE AUC as "beating PRISM," and do not cite DR confidence intervals until the underdetermined-covariance issue (OQ5) is fixed.

## Pointers

- Design & shortlist: `03_research_memory/transformer_implementation_plan.md`
- Feasibility review: `03_research_memory/transformer_sequence_modeling_review.md`
- Method review & claim guidance: `04_outputs/2026-06-15_method_review.md`
- Decisions: `01_current_state/decision_register.md` (D001, D003, D004, D009, D010, D011)
- Open questions: `01_current_state/open_questions.md`
