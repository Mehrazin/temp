# Change Log — 2026-06-20 Data Observability Update

## Source & Scope

Tech-lead data-reality update. This entry records **what is actually observed per channel today, what can likely be added, and what is missing** — as source-of-truth project context. It does **not** design a model or recommend an MVP. The confirmed direction is unchanged (transformer/sequence-model focused; other families may serve as baselines or supporting components).

This refines (does not replace) the data picture in `02_change_log/2026-06-16_data_scale_correction.md` (the four scale layers) by adding the **observability / event-type** dimension.

## Temporal Coverage

- **Customer touchpoint history:** 2022 → current (June 2026).
- **Propensity (PRISM) scores:** **September 2024 → June 2026 only.** The score-feature window is **shorter** than the touchpoint history; sequences spanning before Sept 2024 have no propensity-score features for those periods.

## Core Data Principle (must be preserved)

The project must distinguish these event/state types and **not** mix targeted-universe records with reaction records as if they were the same kind of touchpoint:

`targeted · assigned · sent · shown · contacted · opened · clicked · viewed · interested · not-interested · follow-up-later · no-action · applied · converted`

If a targeted universe is added for **some** channels but not others, the dataset becomes **asymmetric across channels**. This can still be useful, but the asymmetry must be made **explicit** in dataset design and evaluation (e.g., "absence of an event" means different things for different channels).

## 1. Current Touchpoint Coverage by Channel

| Group | Channel | Observed today | Event nature |
|---|---|---|---|
| Inbound | **Branch** | reaction touchpoints only (interested / not-interested / follow-up-later) | reaction-only |
| Inbound | **Phone (inbound)** | reaction touchpoints only (interested / not-interested / follow-up-later) | reaction-only |
| Inbound | **Mobile (app)** | offers shown/loaded + no-action events | exposure-like |
| Inbound | **Web** | offers shown/loaded + no-action events | exposure-like |
| Outbound | **Email** | only customers who opened or clicked | reaction-only (today) |
| Outbound | **Direct mail (DM)** | only customers who applied via EasyApply URL/QR | reaction-only (applied) |
| Outbound | **Leads** | customers contacted by phone | contact (outbound) |
| Outbound | **OBTM** | targeted/list universe addable; **reaction not available** | targeted/list (no reaction) |
| Digital | **Paid search** | click only | reaction/exposure (click) |
| Digital | **SEO** | click only | reaction/exposure (click) |
| Digital | **Display** | view and click | exposure + reaction |

## 2. Channels That Can Add a Targeted / Fuller Universe

- **Email** — full **sent / targeted** universe can likely be added. (Plus a separate **email opt-out** signal: exact opt-out date may be unavailable; **month of opt-out** may be available.)
- **Direct mail** — full list of **DMs sent** by the bank can likely be added.
- **Leads** — full **assigned leads** list can likely be added.
- **OBTM** — full **targeted/list** universe can be added.
- **Digital (paid search / SEO / display)** — no clean targeted universe; a possible proxy is **treating all of Canada as targeted** (to be validated/decided, not confirmed).
- **Inbound branch / phone** — a true targeted universe is **not currently possible**.
- **Inbound mobile / web** — no **separate** targeted universe is possible; the targeted universe is **probably very close to the exposed/shown universe**, but this should be validated.

## 3. Reaction-Only Channels

- **Branch, Phone (inbound):** reactions only (interested / not-interested / follow-up-later). We do **not** observe eligible customers, offers loaded, or offers that could have been presented; if an employee does not open/present the offer workflow, **no touchpoint is created** (selection/observability gap → missing "negatives").
- **Email, Direct mail:** currently reaction-only (opened/clicked; applied) **until** the sent universe is added (see §2).
- **Paid search, SEO:** click-only.

## 4. Channels With Exposure-Like Events

- **Mobile, Web:** offers shown/loaded **and** no-action events (exposure + non-response observed).
- **Display:** view (+ click).
- **Email (once sent universe added):** "sent" becomes the exposure event.

## 5. Channels With Inferred (Not Directly Observed) Contact

- **Leads:** ~**95–97%** of assigned leads are usually contacted → contact can be **inferred** for most assigned records.
- **OBTM:** actual contact is **not directly observed**, but most assigned records are **probably** contacted.

(These are probabilistic/assumed states, not observed events — must be flagged as inferred wherever used.)

## 6. Missing / Unavailable Signals

- **Targeted universe** for inbound **branch/phone** and for **digital** (no clean version; only a possible all-Canada proxy).
- **Branch/phone non-presented offers:** customers who visited/called but were never shown an offer are invisible (no touchpoint).
- **Email opt-out exact date** (month-only granularity likely).
- **OBTM reaction** (none available) and **OBTM/Leads direct contact confirmation** (inferred only).
- **Propensity scores before September 2024** (touchpoints exist back to 2022; scores do not).
- The fuller universes for **email (sent), DM (sent), leads (assigned), OBTM (targeted)** are **not yet integrated** (likely addable, not yet added).

## 7. Why This Matters for Transformer Dataset Design and Observational Evaluation

(Implications only — not a design or MVP recommendation.)

- **Event-type taxonomy is load-bearing.** The targeted/sent/shown/contacted/opened/clicked/viewed/reaction/applied/converted states are distinct event semantics. For a sequence/transformer dataset, these would need to be encoded as **distinct event types**, not collapsed; conflating a targeted-universe record with a reaction record would corrupt sequence construction and labels.
- **"Absence of a touch" is channel-dependent.** With targeted universes on some channels and reaction/exposure-only on others, a missing event can mean *not targeted*, *targeted but no reaction*, or *presented but no action* — different per channel. This **asymmetry** must be explicit in both dataset construction and evaluation.
- **Observational evaluation is constrained by missing universes.** Without a targeted/exposed universe for inbound (branch/phone) and digital, clean exposed-vs-unexposed contrasts cannot be formed for those channels, which limits positivity/overlap and any uplift / off-policy evaluation there. Branch/phone selection (offers not presented → invisible) means **missing negatives**, a known bias source.
- **Temporal feature asymmetry.** Touchpoints run from 2022 but propensity scores only from Sept 2024; any score-conditioned features are unavailable for the earlier history, which bears on sequence windows and label-horizon design.
- **Inferred states reduce label/feature reliability.** Leads/OBTM contact is inferred (~95–97% / "probably"), and email opt-out is month-granular — these introduce approximation that must be tracked, not silently treated as observed truth.
- **Channel coverage will be uneven.** Adding fuller universes for outbound (email/DM/leads/OBTM) while inbound/digital stay reaction/exposure-only changes the per-channel event vocabulary and density — relevant to event-richness and the cleaned-dataset (Layer 4) construction already flagged in the open questions.

## Files Updated

- `01_current_state/current_snapshot.md` — added a per-channel observability section, the propensity-score window, and the event-type/asymmetry principle.
- `01_current_state/open_questions.md` — added a Data Observability & Universe Construction section; cross-referenced existing data questions.
- `01_current_state/context_index.md` — indexed this change-log.
