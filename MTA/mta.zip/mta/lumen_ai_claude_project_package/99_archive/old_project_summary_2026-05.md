# Lumen AI / Multi-Touch Attribution Project Summary

## Project Title

**Lumen AI: Multi-Touch Attribution and Next-Best-Channel Optimization for Credit Card Marketing**

---

## Context & Problem Definition

This project is a new machine learning and marketing optimization initiative at TD Bank, started around **November 2025** and actively developed through **May 2026**. The broader initiative included two related workstreams:

1. **Multi-Touch Attribution (MTA)** — focused on understanding how different customer marketing touchpoints contribute to conversion and how future channel decisions could be improved.
2. **Media Mix Modeling (MMM)** — intended as a future or parallel initiative for higher-level media/channel budget allocation, replacing or improving an existing third-party solution.

The first active focus was **Multi-Touch Attribution** for credit card acquisition campaigns, especially under the broader **DCR / Deepening Customer Relationship** campaign umbrella.

The original business problem was attribution-oriented: explain which marketing channels contributed to past customer conversions. However, the project evolved into a broader decision system with both diagnostic and predictive objectives:

- **Diagnostic path:** Explain historical conversion outcomes and estimate the contribution of each channel.
- **Predictive path:** Recommend the next best marketing channel for each customer.
- **Optimization path:** Allocate channels under operational constraints such as channel capacity.
- **Strategic path:** Build a reusable package or framework that other teams can use for attribution and channel decisioning.

The motivation came from the fact that existing channel assignment logic was largely rule-based rather than data-driven. For example, in a credit card campaign, customers might be ranked by a general credit-card propensity score, and then business rules determine channels:

- Top-ranked customers may receive expensive channels such as **Leads**.
- Broader decile groups may receive email or direct mail.
- Mobile, web, phone, and branch channels may be used according to campaign-specific rules.

These rules are not dynamically optimized based on individual channel effectiveness, customer journey, prior engagement, or estimated incremental lift. The project aimed to move from static rule-based marketing delivery toward a data-driven system that could explain, predict, and optimize channel decisions.

---

## Business Context & Constraints

### Business Setting

The project sits within TD Bank's marketing analytics and campaign decisioning ecosystem. The immediate use case was **credit card acquisition**, but the longer-term vision is broader: support channel decisioning across products and lines of business.

The marketing workflow involves preparing customer lists for campaigns. For a credit card campaign, business stakeholders may specify:

- Which card products are in scope.
- Product mix constraints, such as 30% of recommendations going to a specific card.
- Caps on certain products.
- Whether the objective is acquisition, NPV, or another business value metric.

The existing product-assignment process already uses ML-driven propensity and optimization logic. However, the **channel assignment** side remained much more rule-based.

A typical rule-based channel strategy might look like:

- Top 50k customers receive Leads.
- Top several deciles receive direct mail.
- Most customers receive email and reminder email.
- Inbound channels such as mobile, branch, phone, and web may surface offers when customers interact with TD.

The project asked: **Can we use customer journey data and machine learning to decide not only what product to offer, but how to reach the customer?**

### Main Stakeholders

The primary stakeholder group is **Marketing Delivery**, which acts as the operational bridge between the ML/science team and product-specific business units such as credit cards. The Measurement team was also an important partner because they had already built data assets and rule-based attribution processes.

Other relevant stakeholders include:

- Marketing Delivery teams.
- Measurement team.
- Campaign execution teams.
- Senior leaders such as AVPs and eventually VPs.
- Potential downstream teams that may use a reusable Lumen AI package.

### Business Objectives

The project supports multiple business objectives:

- Improve acquisition rates.
- Lower cost per acquisition.
- Improve channel mix.
- Reduce over-contacting and customer fatigue.
- Provide better attribution reporting.
- Support campaign planning.
- Enable customer-level next-best-channel recommendation.
- Provide a reusable analytics / decisioning framework for other teams.

The project does not directly replace business decision-makers immediately. Instead, the team is building a data-driven technique, demonstrating its value, and creating a reusable framework that business partners can adopt.

### Organizational Reality

The project is not a direct business request with a fixed specification. Instead, the ML team is proactively identifying opportunities to improve decision-making and then selling the method to business partners. This creates a need for both technical rigor and strong executive storytelling.

A project identity was created around **Lumen AI**, using a lighthouse metaphor. The intended message is that Lumen AI can illuminate historical customer journeys and guide future channel decisions.

The positioning was approximately:

- **PRISM tells us what product to offer and to whom.**
- **Lumen AI helps tell us how to reach the customer through the right channel.**

---

## Data

## Initial Dataset

The project first used an existing credit-card campaign dataset with limited channel information. This dataset contained customer-level indicators for whether each customer received treatment from different channels.

The initial data included binary exposure indicators for channels such as:

- Leads
- Email
- Direct mail
- Phone
- Mobile
- Branch
- Web

The dataset also included whether the customer opened a new credit card. The conversion label was granular enough to identify which credit card was opened, but for the initial MTA use case, the team treated the label as a binary indicator of whether the customer acquired any credit card.

The major limitation of this first dataset was that it had no timestamps and no customer reaction details. It only indicated whether a customer was exposed to a channel, not when the exposure happened or how the customer responded.

## Rich Touchpoint Dataset

After initial experimentation, the team engaged with the Measurement team and discovered that a much richer customer touchpoint dataset existed. This dataset contained customer marketing touchpoints and customer reactions over a long history, approximately from 2021 or 2022 to the present.

This richer dataset contained:

- Customer-level marketing touchpoints.
- Channel type.
- Timestamp of each touchpoint.
- Customer reaction or interaction type.
- Conversion information.
- Third-party digital interactions.

The richer dataset enabled the team to move from simple binary channel exposure to a more detailed customer journey representation.

### Channels and Touchpoint Types

The final feature representation focused on credit-card-related touchpoints. The touchpoints came from the credit card line of business, although the underlying offer could be related to:

- New credit card acquisition.
- Credit limit increase.
- Balance transfer.
- Second credit card offers.

The conversion label, however, was restricted to **new credit card acquisition**.

The final channels / reaction types included approximately:

### Email

- Email open
- Email click

The data did not include simple email sent exposure in the final modeling representation. It included engagement signals such as open and click.

### Mobile, Branch, Phone, and Web

These inbound channels had similar interaction types, such as:

- Interested
- Not interested
- No response
- Follow up later

Web also had an additional click-like interaction type.

### Leads

- Contacted
- Claimed sale

The team removed **claimed sale** because it had very low support and appeared to leak conversion-related information. It had only roughly 500 examples and an extremely high positive rate, around 80–90%, making it unsuitable as a clean treatment feature.

### Third-Party / Digital Channels

- Display click
- Paid search click
- SEO click
- Facebook / Meta-related ad signal, although some Meta-related data had low count or incomplete coverage due to reporting limitations.

An additional channel called **Affiliate** had very low support, around 100 touchpoints, and was removed from the main analysis.

### Feature Encoding

For phase 1, all channel and reaction features were encoded as binary indicators.

Examples:

- `email_open = 1` if the customer had at least one opened email touchpoint.
- `mobile_interested = 1` if the customer had at least one mobile touchpoint with an interested response.
- `branch_no_response = 1` if the customer had at least one branch touchpoint with no response.

Multiple touches in the same channel-reaction category were collapsed into one binary indicator. Counts, frequency, recency, and intensity were not used in the first XGBoost phase.

This was a deliberate simplification to build a baseline quickly before moving into sequence-aware models.

---

## Cohort Definition

The first major rich-data study used a fixed analysis window:

- Touchpoint history from approximately **April 2025 through July 2025**.
- Conversion label defined over **June 2025 through July 2025**.

The cohort contained about **1.5 million customers** with at least one credit-card-related marketing touchpoint.

The dataset excluded customers with no credit-card-related touchpoints. This is important because the analysis is focused on exposed customers rather than the full eligible population.

### Positive Label

A positive label was defined as:

- Customer opened any new TD credit card during June–July 2025.

The conversion did not have to be for the exact marketed card. It was any new credit card acquisition.

### Negative Label

A negative label was defined as:

- Customer did not open a new TD credit card during June–July 2025.

The team discussed adding buffer windows, such as excluding customers who converted shortly after July, but for the first phase, customers who converted after July were not treated specially. The label window ended at July.

### Existing Credit Card Customers

Initially, the team considered removing customers who already had a credit card. Later, the team decided to keep them and add a binary **credit card indicator** feature. This allowed the model to account for prior credit card ownership without removing potentially relevant customers.

### Touchpoint Filtering for Converted Customers

For customers who converted during the conversion window, only touchpoints before conversion were kept. This was done to reduce post-conversion leakage.

For non-converted customers, all touchpoints through the end of the analysis period were kept. This creates a potential distributional difference: non-converted customers may have longer observed journeys than converted customers because converted customers are censored at conversion time.

This is a known limitation and an area for future improvement.

---

## Methodology

The methodology evolved through several stages.

## Stage 1: Reproducing Historical Shapley-Based Attribution

The team began by looking at prior attribution work from around 2019 or 2020. That work used Shapley values, but there was no reusable code or robust pipeline available. The team attempted to reproduce and modernize a similar approach.

Classical Shapley attribution requires observing enough examples for many combinations of channels. With 8 channels, there are 2^8 = 256 possible channel combinations. In practice, the observed data only contained around 30 distinct combinations with meaningful support. This made direct empirical Shapley unreliable.

To address this, the team trained a response model to simulate counterfactual combinations.

## Stage 2: XGBoost Response Model for Counterfactual Channel Combinations

The first response model used:

- Customer features: PRISM credit-card propensity scores.
- Treatment features: binary channel indicators.
- Label: whether the customer converted.

Instead of constructing a large customer feature vector from raw banking attributes, the team used PRISM propensity scores as compressed customer-level representations. These scores captured existing knowledge about the customer’s likelihood of acquiring different credit card products.

During inference, the team turned channels on and off for the same customer set to estimate the model-predicted response under different channel combinations. This allowed the team to simulate combinations that were sparse or missing in the observed data and then compute Shapley-style contributions.

The initial results gave very high contribution to Leads, around 60%, which appeared directionally plausible because Leads had historically high response rates. However, further analysis showed this was largely driven by selection bias.

## Stage 3: Selection Bias Discovery

The team discovered that Leads appeared extremely effective because it was selectively assigned to very high-propensity customers.

For example:

- Only around 10% of customers may have received Leads.
- Around 80% may have received email.
- Leads recipients had much higher response rates, potentially around 50%.
- Email recipients had much lower response rates, perhaps around 5%.

The raw response-rate difference did not mean Leads was intrinsically much more effective. It meant the business had already targeted Leads to high-value/high-propensity customers.

This was a critical methodological insight. A naive attribution method would incorrectly attribute customer quality to channel effectiveness.

## Stage 4: Doubly Robust Estimation

To address selection bias, the team introduced doubly robust estimation.

The logic was:

1. Train a response model to estimate conversion probability under treatment and no treatment.
2. Train a separate channel propensity model to estimate the probability that a customer receives a particular channel.
3. Use the doubly robust correction formula to adjust treatment effect estimates for selection bias.

For each channel, a separate channel propensity model was trained. For a target channel such as Leads, the model used:

- PRISM propensity scores.
- Other channel / journey features.
- Credit card ownership indicator.
- Excluded the target channel itself.

The label was whether the customer received the target channel.

For a given customer and channel, the response model estimated:

- `mu1`: predicted conversion probability if the channel is turned on.
- `mu0`: predicted conversion probability if the channel is turned off.

The difference `mu1 - mu0` represented a model-based lift estimate. The doubly robust method corrected this using the channel propensity score.

In early iterations, the team implemented the doubly robust logic directly. Later, for the predictive version, the team used **EconML**.

The project used DR pragmatically as a debiasing and treatment-effect estimation tool, while recognizing that true causal validity depends on assumptions that may not fully hold.

---

## Causal Assumptions and Limitations

The team discussed the assumptions behind using doubly robust estimation, although not every possible hidden confounder could be fully enumerated.

The implicit assumptions included:

- Conditional on PRISM scores, observed customer journey, and known channel history, channel assignment is sufficiently explainable.
- Customers with similar observed features could plausibly receive different channels.
- Observed outcomes are informative for counterfactual estimation.
- The available features capture enough of the decision logic behind channel assignment to reduce major selection bias.

The team recognized several limitations:

- Offline or unobserved exposures such as TV commercials, outdoor ads, word-of-mouth, or conversations with friends are not captured.
- Different campaign teams may use different hidden business rules that are not fully documented.
- Some campaign assignment practices may already use customer history or business logic that is not visible in the modeling data.
- Channel propensity models may have weak overlap for highly selective channels such as Leads.
- DR improves over naive comparisons but does not magically solve unobserved confounding.

The practical stance was: use doubly robust estimation as a stronger and more defensible method than raw Shapley or response-rate comparisons, while clearly acknowledging assumptions and limitations.

---

## Diagnostic Model

The diagnostic model focused on explaining past conversions.

### Inputs

The diagnostic response model used:

- PRISM credit-card propensity scores, frozen as of end of April 2025.
- Historical journey / touchpoint features.
- Credit card ownership indicator.

The final diagnostic feature vector was roughly 30 dimensions:

- 8–9 PRISM scores.
- Around 20 journey features.
- 1 credit card indicator.

### Outputs

The diagnostic model supported multiple attribution views:

1. **XGBoost SHAP feature contributions**
   - Used to interpret feature importance / contribution from the response model.
   - Some SHAP values were negative, especially when observed combinations had sparse or imbalanced support.

2. **Doubly robust average incremental lift per channel**
   - Used to estimate channel-level contribution after correcting for selection bias.
   - Could be reported as raw incremental lift or converted into percentage contribution.

3. **Selection-bias diagnostics**
   - Used plots showing exposure distributions across PRISM propensity deciles.
   - Demonstrated that certain channels, especially Leads, were concentrated among high-propensity customers.

### Interpretation

The diagnostic path is intended to answer questions such as:

- Which channels contributed most to conversion historically?
- Which channels appear strong only because they were assigned to high-propensity customers?
- How different are raw, SHAP-based, and doubly robust views of attribution?
- Where are business rules creating biased exposure patterns?

---

## Predictive Model

The predictive model reframed the problem as a next-best-channel recommendation task.

The team simulated a decision point at **June 1, 2025**.

At that point, the model assumes it knows:

- PRISM scores from end of April.
- Customer journey features before June 1.
- Credit card ownership indicator.

The model then evaluates potential future treatment choices during June–July and predicts conversion.

### Predictive Input Blocks

The predictive model used:

1. **Customer features**
   - PRISM credit-card propensity scores.
   - Credit card ownership indicator.

2. **Historical journey features**
   - Touchpoint / reaction features observed before June 1.

3. **Future treatment features**
   - Candidate channel or channel-reaction treatment during June–July.

### Two Predictive Treatment Representations

The team developed two variants:

#### 1. Channel-Reaction-Level Treatment Model

This model treats future treatment features at the same level of granularity as the journey representation.

Examples:

- mobile_interested
- mobile_not_interested
- email_open
- email_click
- branch_no_response

This representation is detailed but less practical for recommendation because the team cannot directly choose the customer’s reaction. The business can choose a channel, but not whether the customer will respond as interested or not interested.

#### 2. Channel-Level Treatment Model

This model treats the future treatment as the channel itself.

Examples:

- mobile
- branch
- phone
- web
- email
- leads
- display
- SEO
- paid search

This is the more practical recommendation model because the output is a next-best-channel recommendation.

### Approximate Feature Dimensions

For the predictive model:

- Channel-reaction-level treatment version: around 50 dimensions.
  - PRISM scores + credit card indicator.
  - Journey features.
  - Treatment features at reaction level.

- Channel-level treatment version: around 40 dimensions.
  - PRISM scores + credit card indicator.
  - Journey features.
  - Treatment features at channel level.

### Output

For each customer, the model can score candidate channels. This creates a customer × channel score table. Each row is a customer, and each column is a possible channel score.

The score may represent:

- Predicted conversion probability under that channel.
- Estimated incremental lift for that channel.
- Doubly robust / CATE-style adjusted lift.

The team is exploring which score definition is most appropriate for optimization and executive communication.

---

## Optimization / Ranking Logic

The predictive model outputs a channel score for each customer-channel pair. An optimization layer is then applied to assign channels to customers.

### Optimization Objective

The objective can be configured depending on the score definition:

- Maximize total predicted conversion probability.
- Maximize total incremental lift.
- Maximize constrained acquisition.

In the first phase, the optimization is not yet based on NPV. It is focused on conversion or lift.

### Optimization Type

The optimization is framed as an **integer programming** problem with a linear objective.

Each customer is assigned one recommended next channel.

### Constraints

The first supported constraint is channel capacity.

Example:

- Leads can be assigned to at most 30k or 50k customers.

The optimizer can be run in two modes:

1. **Unconstrained scenario**
   - Allows the model to choose the best channel without operational caps.

2. **Constrained scenario**
   - Applies channel capacity constraints to produce a more realistic allocation.

Future constraints may include:

- Channel eligibility.
- Opt-out policies.
- Contact frequency limits.
- Budget constraints.
- Customer eligibility constraints.
- Compliance or governance constraints.
- Product-level campaign constraints.

At the current stage, customer-level channel eligibility and opt-out constraints have not yet been fully incorporated. The team is working to obtain opt-out data.

### Negative Lift

Some estimated channel lifts are negative. This may indicate:

- Modeling artifact.
- Data sparsity or imbalance.
- Negative reaction patterns such as not interested or no response.
- Customer fatigue or over-contacting.
- Implicit opt-out risk.

The team has not yet fully diagnosed the negative lift issue. However, if validated, negative lift could become an important signal: the model may not only recommend what to do, but also identify customers who should not be contacted.

---

## Evaluation & Experimentation

## Model Evaluation

The first evaluation metric was AUC.

AUC is especially relevant because these models are used for ranking. In this context, AUC can be interpreted as the probability that the model ranks a positive example above a negative example.

Approximate AUC values:

- PRISM credit-card propensity baseline: around **0.79**.
- MTA response model: around **0.86–0.87**.

The MTA model performs better because it uses campaign and journey information that PRISM does not include. PRISM is a general propensity model, while the MTA model is trained on campaign touchpoint and conversion data.

At the current stage, the team mainly used AUC. Other metrics such as calibration, PR-AUC, lift charts, Brier score, and decile response curves could be future additions.

### Train/Test Split

The model used a random customer-level train/test split, not a time-based split.

A time-based split may be a stronger future validation approach, especially for production-readiness.

---

## Diagnostic Evaluation

For the diagnostic path, the main validation was qualitative and diagnostic rather than purely metric-based.

The team compared:

- Raw channel exposure and conversion patterns.
- XGBoost SHAP feature contributions.
- Doubly robust channel lift estimates.
- Exposure distributions across PRISM propensity deciles.

A key validation plot showed that Leads exposure was concentrated in high-propensity deciles, making raw response-rate comparisons biased. This supported the need for causal or debiasing methods such as doubly robust estimation.

The team used this reasoning to argue that DR results are more credible than naive Shapley or raw conversion-rate attribution.

---

## Predictive Recommendation Evaluation

Evaluating next-best-channel recommendations is difficult because the model is recommending counterfactual actions. The team does not observe what would have happened if a different channel had been assigned.

The team developed an offline evaluation strategy based on agreement and disagreement between model recommendations and historical BAU channel assignment.

### Match / Lucky Match Group

The **match group** contains customers where:

- Model-recommended channel = historical BAU channel.

For this group, the actual outcome is observed under the same channel the model would have chosen. Therefore, this group provides a partial validation of the model’s predictive ranking.

The evaluation approach:

1. Rank matched customers by model-predicted lift or score.
2. Split into deciles.
3. Check whether actual converters are concentrated in the top deciles.

If converters are concentrated in high-score deciles, this supports the claim that the model can rank customers effectively when the model agrees with historical treatment.

### Non-Match Group

The **non-match group** contains customers where:

- Model-recommended channel ≠ historical BAU channel.

For this group, the actual counterfactual outcome is unobserved. The team currently compares:

- Model-predicted score under the recommended channel.
- Model-predicted score under the historical BAU channel.

The optimizer chooses the model-recommended channel because it has higher predicted value than BAU under the model.

The team considered a more empirical nearest-neighbor / clustering-based strategy:

- For a customer whose recommendation differs from BAU, find similar customers in the test set who historically received the recommended channel.
- Use their observed outcomes to approximate what might have happened.

However, the team recognized that XGBoost may already be learning similar local patterns internally, so the current approach relies on model score comparisons.

### Potential Uplift Estimation

The team intends to estimate a potential improvement such as:

- If the model’s recommended channel allocation had been used, expected conversion would improve by X% compared with BAU.

This estimate is currently model-based and should be communicated carefully because it relies on counterfactual predictions rather than randomized experiment results.

---

## Executive Plots and Communication

The team condensed a large amount of analysis into a small set of executive-ready plots with clear business messaging.

### Plot 1: Diagnostic Channel Contribution

Purpose:

- Show the estimated contribution or lift of each channel.
- Compare raw / SHAP / doubly robust views where appropriate.
- Communicate which channels appear most influential after adjustment.

Message:

- Channel impact should not be inferred from raw response rates alone.
- Adjusted attribution gives a more credible picture of channel contribution.

### Plot 2: Channel Exposure by PRISM Propensity Decile

Purpose:

- Rank customers into 10 deciles based on general credit-card PRISM propensity.
- Show the percentage of customers exposed to each channel in each decile.

Message:

- Historical channel assignment is not random.
- Expensive channels such as Leads are disproportionately assigned to top-propensity customers.
- This creates selection bias and motivates causal adjustment / doubly robust estimation.

### Plot 3: Predictive Model Agreement with BAU

Purpose:

- Focus on customers where model recommendation matches historical BAU channel.
- Rank by predicted lift / score and show actual conversion concentration by decile.

Message:

- When the model agrees with BAU, its scores successfully rank actual converters toward the top deciles.
- This supports the predictive validity of the model.

### Plot 4: Model Recommendation vs BAU in Non-Match Cases

Purpose:

- Compare the model-predicted score under recommended channel vs BAU channel for customers where model and BAU differ.

Message:

- For disagreement cases, the model recommends a different channel because it predicts higher conversion or lift.
- This suggests potential incremental improvement over rule-based historical assignment.

### Plot 5: Recommended Channel Distribution vs Historical Distribution

Purpose:

- Compare historical BAU channel allocation with model-recommended allocation.
- Show unconstrained and constrained optimization scenarios.

Message:

- The model recommends a different, data-driven channel mix.
- Capacity constraints materially affect practical allocation.
- Lumen AI can support channel planning and optimization rather than only attribution reporting.

---

## Architecture / System Design

### Current Implementation Environment

The project is implemented primarily in:

- Databricks
- PySpark
- Python notebooks
- scikit-learn-style workflows
- XGBoost internal package
- EconML
- Optimization tooling

The workflow is currently a research/prototype and decision-support pipeline rather than a fully productionized model system.

### Modular Notebook Design

Although not production-grade yet, the notebooks are structured in a modular and readable way:

- Cell-by-cell organization.
- Clear section titles.
- Separate stages for data construction, feature engineering, modeling, evaluation, optimization, and plotting.
- Executive-quality plots.

The team’s longer-term plan is to package the work into a reusable **Lumen AI package**, analogous to internal packages already used for XGBoost modeling and optimization.

### Package Vision

A strategic shift occurred in the plan: before jumping directly to the transformer version, the team now intends to first create a package around the current XGBoost / DR / optimization approach.

The package would allow other teams to use Lumen AI-style MTA and channel decisioning methods without rebuilding the methodology from scratch.

The envisioned package would likely include:

- Input data schema expectations.
- Feature construction utilities.
- Diagnostic attribution modules.
- Channel propensity model training.
- Response model training.
- Doubly robust / treatment effect estimation.
- Predictive channel scoring.
- Optimization under channel constraints.
- Standard plots and reporting templates.
- Example notebooks.

This packaging strategy also helps with adoption because teams can use the toolkit while owning their own model governance and deployment responsibilities.

---

## Productionization & Deployment Status

The project is currently in the research/prototype and executive-deck phase.

Current deliverables include:

- Executive deck.
- Offline results.
- Prototype recommendation table.
- Modular analysis notebooks.
- Early framework design for a reusable Lumen AI package.

The project has been shown to the AVP and is being prepared for VP-level communication.

It has not yet become a fully registered production model. Model governance and risk management have not deeply entered the process yet because the system is still pre-production.

A key strategic consideration is whether the team builds a package that other teams can use, rather than registering a centralized model directly. If other teams adopt the package and build their own models, governance responsibility may sit with the adopting team.

---

## Key Challenges

## 1. Sparse Channel Combinations

Direct Shapley value estimation required enough examples for many channel combinations. With 8 channels, there are 256 possible combinations, but the observed data had far fewer meaningful combinations. This made direct empirical Shapley unreliable.

## 2. Selection Bias

Historical channel assignment was strongly biased by customer propensity and business rules. Leads appeared very effective partly because it was assigned to high-propensity customers. This required moving beyond raw attribution and toward doubly robust estimation.

## 3. Limited Initial Data

The initial dataset only contained binary channel exposure and conversion. It lacked timestamps and reaction data, making it insufficient for robust journey modeling.

## 4. Data Access and Cross-System Validation

One of the biggest engineering and operational bottlenecks was data access. The Measurement team had useful data in its own analytics environment, while the ML team worked in a different environment.

Access required formal requests, reviews, follow-ups, and repeated approvals as more source tables were identified. It took roughly a month to obtain and reconstruct the required data.

The team also had to validate that the reconstructed data matched what the Measurement team had in their environment.

## 5. Counterfactual Evaluation Difficulty

For predictive recommendations, the team cannot observe what would have happened if the model had chosen a different channel. This makes evaluation inherently difficult and requires off-policy or counterfactual reasoning.

## 6. Hidden Confounding

Not all customer influences are captured in the data. Examples include:

- TV ads.
- Outdoor ads.
- Word of mouth.
- Customer conversations.
- Hidden campaign rules.
- Team-specific delivery practices.

This limits causal claims and requires careful framing.

## 7. Practicality vs Rigor Tradeoff

The team had to balance:

- Fast delivery.
- Executive communication.
- Technical rigor.
- Causal validity.
- Data limitations.
- Broader workload and competing business-critical projects.

The result was a pragmatic baseline-first approach using XGBoost and DR before investing in transformers.

---

## Tradeoffs & Design Decisions

## XGBoost Before Transformer

The team chose XGBoost for the first phase because:

- It is fast to train.
- It does not require GPU access.
- The team already had an internal package that made XGBoost modeling easy.
- It performs well on tabular data.
- It is familiar to business and internal stakeholders.
- It supports SHAP-based interpretability.
- It integrates better with current causal / EconML experimentation.
- The current data maturity is better suited to tabular modeling than sequence modeling.

The transformer approach remains a future phase but requires more data, GPU access, sequence modeling infrastructure, and stronger evaluation design.

## Binary Features Before Counts / Sequences

The team collapsed touchpoints into binary indicators for phase 1. This made the model simpler, faster, and easier to interpret.

The tradeoff is that binary features ignore:

- Frequency.
- Recency.
- Temporal order.
- Time gaps.
- Repeated exposures.
- Customer fatigue dynamics.

These are expected to be addressed in the transformer / sequence-model phase.

## DR as Pragmatic Debiasing

Doubly robust estimation was used as a practical improvement over naive attribution. The team recognized that it depends on causal assumptions and does not eliminate all hidden confounding.

The tradeoff was between:

- Delivering something materially better than raw attribution.
- Not over-investing in a fully causal framework before stakeholder value was proven.

## Channel-Level Recommendation Instead of Reaction-Level Recommendation

The model can be built at channel-reaction level, but the more actionable version recommends channels only. This is because the business can decide to send a customer through mobile, email, branch, etc., but cannot directly choose whether the customer will respond as interested or not interested.

## Package Before Transformer

The team recently shifted the plan to build a reusable package first, before moving to transformer modeling. This is because other teams may already need a practical version of this capability.

This decision prioritizes adoption and reuse over immediately pursuing the most advanced modeling approach.

---

## Transformer / LIDA-Style Future Phase

The team identified research such as LinkedIn’s LIDA-style framework, which uses transformer-based models to process customer touchpoint sequences and support prediction / recommendation.

The future transformer model may use:

- Ordered touchpoint sequences.
- Timestamps.
- Time gaps.
- Channel type.
- Action / reaction type.
- PRISM scores.
- Customer features.
- Conversion label.

The intended outputs may include:

- Conversion prediction.
- Next-best-channel recommendation.
- Attention-based attribution.
- Customer journey understanding.

The team may expand the training window from four months to one or two years. Initially, the model may still focus on credit cards, but the longer-term vision is to generalize across lines of business.

A useful intermediate step may be a sequence-aware but simpler model, such as a Markov-chain baseline or another temporal model, before jumping directly from XGBoost to transformers. This would separate two modeling jumps:

1. From static tabular modeling to time-series / sequence modeling.
2. From interpretable classical ML to neural sequence models.

---

## Impact

The project is still pre-production, so final business impact has not yet been realized through live deployment. However, it has already created significant analytical and strategic value.

### Current Impact

- Established a data-driven framework for moving beyond rule-based channel attribution.
- Identified and demonstrated selection bias in historical channel assignment.
- Built a stronger attribution methodology using doubly robust estimation.
- Developed a predictive next-best-channel framework.
- Created prototype customer-channel recommendation tables.
- Built executive-ready analysis and narrative around Lumen AI.
- Positioned the team to offer a reusable package to other groups.
- Created a roadmap from XGBoost baselines to transformer-based journey modeling.

### Expected Future Impact

If adopted, Lumen AI could support:

- Higher credit card acquisition rates.
- Lower cost per acquisition.
- Better channel capacity utilization.
- Reduced over-contacting.
- Improved attribution reporting.
- More data-driven campaign planning.
- Customer-level channel personalization.
- A scalable internal framework for marketing decision intelligence.

---

## My Role & Contributions

The project team consisted of four people:

- A more senior / highly experienced teammate at the same formal level, functioning as a high-level technical lead.
- The user, functioning as a second-layer technical lead, integrator, and execution driver.
- Another same-level technical teammate focused heavily on modeling.
- A lower-level scientist who contributed significantly to data processing and analysis, with guidance.

The senior teammate provided high-level direction and feedback but was not always deeply hands-on due to other responsibilities. The hands-on progress accelerated once the user became more deeply involved around one and a half to two months before the current summary.

### Main Role

The user functioned as an **enablement layer** and **second-layer technical lead**.

This included:

- Technical integration across modeling, data, attribution, optimization, and storytelling.
- Helping maintain the big-picture system design when individual components became too narrow or technique-focused.
- Translating vague business and technical goals into concrete experiments and plots.
- Guiding teammates on data validation and interpretation.
- Helping debug whether numbers made sense.
- Supporting stakeholder communication and executive narrative.
- Contributing to methodology design, especially progression from Shapley to DR and predictive optimization.
- Preparing or heavily contributing to many of the presentation materials and executive plots.

### Specific Contributions

The user contributed to:

- Initial Shapley-based analysis and reproduction of prior attribution thinking.
- Identifying the limitations of direct Shapley due to sparse channel combinations.
- Helping reason through selection bias in Leads and other channels.
- Supporting the shift toward doubly robust estimation.
- Designing and interpreting diagnostic plots showing channel exposure by PRISM propensity decile.
- Helping define diagnostic vs predictive paths.
- Helping design the predictive setup with pre-June journey and June–July treatment window.
- Helping reason through channel-level vs channel-reaction-level treatment representations.
- Supporting optimization framing for customer-channel assignment with capacity constraints.
- Helping design offline evaluation based on match / non-match groups.
- Guiding data sanity checks and encouraging inspection of actual customer-level examples, not just aggregate code outputs.
- Mentoring the lower-level scientist on data processing, validation, and analysis thinking.
- Acting as a technical clarifier for teammates when model outputs or percentages needed interpretation.
- Building the executive narrative around Lumen AI and helping make the analysis understandable to senior stakeholders.

### Leadership Style

The user’s leadership was not formal people management. It was technical and integrative leadership:

- Seeing the whole system across data, modeling, causal assumptions, optimization, evaluation, and business messaging.
- Helping others avoid getting lost in narrow technical implementation details.
- Asking whether numbers make sense and what they mean.
- Driving clarity in ambiguous situations.
- Bridging business value and technical methodology.
- Mentoring through practical debugging and data inspection.

---

## Senior-Level Signals

## Ownership

The user demonstrated ownership by becoming a central force in making the project coherent and actionable. Once more deeply involved, the project made faster progress because the user helped connect fragmented pieces into a clear methodology and communication plan.

## Ambiguity Handling

The project began with vague goals, incomplete prior work, limited data, and no reusable code. The user helped navigate ambiguity by:

- Starting with a reproducible baseline.
- Identifying why the baseline was insufficient.
- Moving to richer data.
- Reframing the project from attribution to prediction and optimization.
- Creating a clear diagnostic/predictive framework.

## Systems Thinking

The user connected many layers of the problem:

- Campaign strategy.
- Product recommendation.
- Channel assignment.
- Attribution.
- Causal inference.
- Customer journey representation.
- Optimization.
- Offline evaluation.
- Executive communication.
- Future packaging and productionization.

## Technical Judgment

The project required several important technical judgments:

- Recognizing that high Leads attribution was caused by selection bias.
- Understanding that raw response rates and naive Shapley were misleading.
- Choosing XGBoost as a practical first-stage baseline.
- Recognizing the limitations of binary journey features.
- Choosing channel-level treatment as the more actionable predictive representation.
- Being cautious about causal assumptions and counterfactual claims.
- Considering stronger future baselines before jumping to transformers.

## Cross-Functional Coordination

The user contributed to coordination across:

- Internal ML/science teammates.
- Measurement team.
- Marketing Delivery.
- Data access and approval processes.
- Senior stakeholders.

The user also helped communicate technical results in a way that could be adopted by business stakeholders.

## Mentorship

The user mentored and guided a lower-level scientist, especially around data validation and analysis discipline:

- Inspect small data examples.
- Do not rely only on code or aggregate outputs.
- Validate whether the data makes sense.
- Understand what a metric or percentage actually means.
- Use plots and examples to debug logic.

## Strategic Product Thinking

The user contributed to the productization narrative around Lumen AI:

- Naming and positioning the project.
- Framing diagnostic and predictive paths.
- Connecting PRISM product propensity to Lumen AI channel decisioning.
- Supporting the shift toward a reusable package before transformer development.

---

## Lessons Learned

1. **Attribution is not just feature importance.**
   Raw SHAP or Shapley values can be misleading when treatment assignment is biased.

2. **Selection bias dominates marketing channel analysis.**
   Expensive channels often appear effective because they are assigned to better customers.

3. **Data quality and access are as important as modeling.**
   Getting access to the right touchpoint data and validating it across environments was one of the hardest parts.

4. **Counterfactual evaluation is inherently hard.**
   Recommendation systems for marketing actions require careful off-policy evaluation or experimentation.

5. **Pragmatic baselines are necessary.**
   XGBoost + DR provided a useful and explainable baseline before moving to transformer models.

6. **Business adoption requires narrative.**
   Executive plots, product naming, and clear messaging are essential for adoption.

7. **A package can scale impact faster than a one-off model.**
   Building reusable tooling may allow multiple teams to adopt the methodology before the most advanced model is ready.

---

## Optional Future Improvements / Extensions

### Data Improvements

- Expand the data window to one or two years.
- Include customers with no touchpoints to better model treatment vs no treatment.
- Add buffer windows around conversion labels.
- Include opt-out data.
- Add contact frequency and recency features.
- Include customer-level features beyond PRISM scores.
- Better capture campaign identity and offer type.
- Include product-specific conversion mapping.

### Modeling Improvements

- Add calibration metrics and probability calibration.
- Compare XGBoost against logistic regression, random forest, causal forest, uplift models, and sequence-aware baselines.
- Add Markov-chain or temporal baselines before transformer.
- Incorporate treatment interactions more explicitly.
- Model negative lift and do-not-contact decisions.
- Explore CATE estimation more rigorously.
- Diagnose overlap and positivity per channel.
- Clip or regularize propensity scores where needed.

### Evaluation Improvements

- Use time-based validation.
- Add PR-AUC, Brier score, calibration curves, lift charts, and decile response analysis.
- Build stronger off-policy evaluation.
- Use nearest-neighbor or matching-based counterfactual validation.
- Run a small randomized experiment or champion/challenger test.
- Compare against existing rule-based channel assignment in a controlled A/B test.

### Optimization Improvements

- Add channel budget constraints.
- Add customer-level eligibility.
- Add opt-out and contact-policy constraints.
- Add product/channel joint optimization.
- Optimize NPV rather than only conversion.
- Support multiple-channel sequences instead of one next channel.
- Incorporate customer fatigue and long-term value.

### Productization Improvements

- Build a reusable Lumen AI package.
- Define a standard input schema.
- Add reusable plotting/reporting utilities.
- Add model governance documentation templates.
- Create example notebooks for adopting teams.
- Provide interfaces for diagnostic attribution and predictive channel recommendation.

### Transformer Phase

- Use ordered customer journeys.
- Encode timestamps and time gaps.
- Include channel and reaction embeddings.
- Include PRISM and customer features.
- Predict conversion and next-best-channel.
- Explore attention-based attribution.
- Compare against XGBoost, DR, and simpler temporal baselines.

---

## Short Reusable Description

Lumen AI is a multi-touch attribution and next-best-channel optimization initiative for TD Bank’s credit card marketing campaigns. The project began as an attribution reporting effort to explain historical channel contribution, but evolved into a broader decisioning framework combining diagnostic attribution, causal debiasing, predictive channel recommendation, and constrained optimization. The system uses PRISM propensity scores, credit-card touchpoint and reaction history, XGBoost response models, channel propensity models, doubly robust treatment-effect estimation, and integer optimization to estimate channel impact and recommend customer-level next-best channels under business constraints. The project addresses key marketing challenges such as selection bias, sparse channel combinations, rule-based channel assignment, counterfactual evaluation, and executive communication. The current phase focuses on offline validation, executive storytelling, and packaging the methodology into a reusable Lumen AI toolkit before moving toward transformer-based customer journey modeling.

---

## Resume / Interview Positioning Notes

This project can be positioned around several themes depending on the target audience.

### For Causal ML / Applied Science Roles

Emphasize:

- Selection bias in marketing channels.
- Doubly robust estimation.
- Treatment effect / uplift modeling.
- Counterfactual evaluation.
- Causal assumptions and limitations.

### For Recommendation / Ranking Roles

Emphasize:

- Customer × channel scoring.
- Next-best-channel recommendation.
- Optimization under channel capacity constraints.
- Offline evaluation of recommendations.
- Future transformer-based journey modeling.

### For Marketing Analytics / Decision Science Roles

Emphasize:

- Attribution reporting.
- Channel mix optimization.
- Campaign planning.
- Acquisition and cost-per-acquisition objectives.
- Business adoption and executive communication.

### For Senior ML Engineer / Staff-Level Signals

Emphasize:

- Technical integration across data, modeling, causal inference, optimization, and communication.
- Ambiguous problem framing.
- Cross-functional coordination.
- Mentorship and guidance.
- Reusable package/product thinking.
- Practical tradeoffs between rigor and delivery.

---

## Potential Resume Bullet Seeds

These are not final polished resume bullets, but raw material for future resume tailoring:

- Helped develop Lumen AI, a multi-touch attribution and next-best-channel optimization framework for credit card marketing, combining XGBoost response modeling, doubly robust treatment-effect estimation, and constrained customer-channel assignment.

- Identified and addressed selection bias in historical marketing channel attribution, showing that high-performing channels such as Leads were concentrated among high-propensity customers and required causal adjustment beyond raw response rates or naive Shapley attribution.

- Designed diagnostic and predictive modeling workflows using PRISM propensity scores, customer touchpoint history, channel reaction signals, and conversion labels to estimate channel contribution and recommend next-best channels.

- Contributed to an integer optimization layer that assigns customer-channel recommendations under channel capacity constraints, enabling data-driven alternatives to rule-based campaign delivery.

- Built executive-ready analysis and visualization narratives to communicate attribution, selection bias, model validation, and expected channel-allocation improvements to senior stakeholders.

- Acted as a second-layer technical lead and integrator across data engineering, modeling, causal inference, optimization, evaluation, and stakeholder storytelling for a cross-functional four-person project team.

- Guided junior and peer teammates on data validation, model interpretation, debugging, and experimental framing, improving project clarity and accelerating delivery of prototype results.

---

## Open Questions for Future Deep Dives

1. How should negative channel lift be diagnosed and operationalized?
2. Should the model recommend no-contact as an explicit action?
3. How should opt-out risk and customer fatigue be modeled?
4. Is DR sufficient, or should causal forests/uplift models be explored?
5. How should channel interactions be modeled beyond independent binary treatments?
6. What is the best off-policy evaluation design before live testing?
7. How should the team transition from binary features to full journey sequences?
8. What governance requirements will apply if this becomes production decisioning?
9. Should optimization target conversion, NPV, CLTV, or cost-adjusted acquisition?
10. How can Lumen AI and MMM be connected into one marketing decision framework?

