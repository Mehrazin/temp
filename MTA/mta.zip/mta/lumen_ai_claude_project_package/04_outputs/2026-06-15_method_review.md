# Lumen AI — Research & Method Review

**Date:** 2026-06-15
**Author role:** Applied scientist / agentic research-system review
**Scope:** Multi-touch attribution, next-best-channel recommendation, XGBoost response modeling, channel propensity models, doubly-robust / CATE estimation, customer × channel scoring, constrained optimization.
**Sources of truth:** `01_current_state/current_snapshot.md`, `02_change_log/2026-06-15_update.md`. External literature cited in the Reference Bank.

**Status label legend used throughout:** *Implemented* · *Planned* · *Defensible* · *Needs validation* · *Production blocker* · *Communication caveat*.

---

## 1. Executive Summary

Lumen AI is an **implemented but not yet production-validated** predictive system: an EconML `LinearDRLearner` (XGBoost propensity + outcome, 5-fold cross-fitting, one-vs-rest treatments) produces per-customer per-channel potential outcomes that feed a constrained one-channel-per-customer optimizer. The diagnostic/attribution lens (doubly-robust ATEs, Shapley-vs-DR comparison) is supporting context; the predictive/next-best-channel lens is the manager-directed priority.

The method is **directionally sound and a real improvement over naive last-touch or Shapley attribution**: it corrects for channel-assignment selection bias and produces an actionable, channel-level lift score. That is a legitimately valuable position to be in, and the team should be able to say so.

However, three things are true at once and must be kept separate in all communication:

1. **The point predictions (the scores the optimizer actually consumes) are the most trustworthy output.** They are ordinary XGBoost regressions over potential outcomes; their quality is an empirical question answerable with proper validation.
2. **The causal inference layer is numerically broken right now.** The recurring `Co-variance matrix is underdetermined. Inference will be invalid!` / `zstat=-inf` messages mean the standard errors, confidence intervals, and p-values on the ATE/CATE estimates **cannot be trusted at all** — not "are wide," but "are invalid." This is a **production blocker for any causal claim** and a methodological red flag, though it does not by itself invalidate the deployable point scores.
3. **No result to date — the +~10% optimizer lift or the +11.18% AUC vs PRISM — licenses an incremental-business-uplift claim.** Both are model-estimated / exploratory. The OPE-vs-PRISM comparison measures *ranking on a small selection-on-agreement subset*, not incremental causal lift, and is not significance-tested.

**Bottom line for managers:** the method is a credible v1 candidate and a defensible methodological choice, but it is gated by (a) a fixable-but-unresolved numerical instability in the causal layer, (b) the absence of a time-based holdout or any experimental/defensible-OPE validation, and (c) unresolved data-foundation and direct-mail-sourcing issues. The honest current claim is *"we can rank who is most responsive on which channel better than the status quo, and an offline simulation suggests a meaningful lift we now need to validate"* — not *"we will deliver +10% incremental conversions."*

---

## 2. Current Method Assessment

### 2.1 Attribution / diagnostic lens — *Implemented, Defensible as direction, Needs validation as numbers*

The team compared naive Shapley attribution against doubly-robust ATEs and documented sign flips, then chose DR. This is the right instinct and is supported by the literature: **Shapley value attribution distributes credit fairly across observed co-occurring touchpoints but reflects correlation, not causation**, and is known to be confounded by user-level selection into journeys (CausalMTA, DCRMTA, the Causally-Driven incremental-MTA line of work). Preferring a selection-bias-correcting estimator over Shapley for an attribution narrative is defensible (D007).

Caveats:
- The diagnostic ATEs **vary run-to-run** and some channel-level signs (Email and Mobile negative at channel level, Email-CLICK positive) are not yet explained or wrapped in a narrative. Run-to-run instability of a *causal point estimate* is itself a symptom of the overlap/conditioning problems discussed in §3.
- A negative ATE is a substantive finding (a channel that, conditional on context, reduces conversion or cannibalizes other touches), not a bug — but it must be interpreted, not silently dropped. This is a *communication caveat* and a *research improvement*, not a blocker.

### 2.2 Predictive / next-best-channel lens — *Implemented (canonical: grouped channel-level)*

The grouped channel-level DR model (one lift score per controllable channel, `max` over interaction types) is the canonical predictive granularity (D006). For each channel it fits, via one-vs-rest, a propensity (XGBClassifier) and outcome (XGBRegressor) model under 5-fold cross-fitting, then stores `conversion_{ch}_0/_1` potential outcomes. At scoring time other treatments `W_test` are zeroed.

Assessment:
- **Cross-fitting is correct and important** — fitting nuisance models out-of-fold is exactly the design that gives DR/DML its bias guarantees (Chernozhukov et al. DML; the cross-fitting-and-averaging literature). Good.
- **Reusing a single `overall_best_params` across all channels and both nuisance models** is a pragmatic shortcut. It is acceptable for v1 but means propensity and outcome models are not individually tuned; for rare channels this contributes to the instability in §3.
- **`W_test = zeros` ("all other channels off") is a strong and probably unintended counterfactual.** It defines the scenario in which the scores are valid. Whether the business wants "lift of channel X assuming no other contact" vs. "lift of X given the realistic contact mix" is an open design question (open_questions #7) and materially shapes what the optimizer optimizes.
- **One lift score per channel that the business controls is the right actionable unit.** This is the correct decision (D002).

### 2.3 Propensity models — *Implemented, partially appropriate*

XGBoost propensity with `binary:logistic` + AUC tuning ranks well but is **not necessarily well-calibrated**, and DR weighting depends on calibrated *probabilities*, not rankings. Tuning the propensity model to AUC rather than log-loss/Brier is a subtle mismatch: a model can rank perfectly yet produce miscalibrated propensities that generate extreme inverse-propensity weights. This interacts directly with the overlap problem in §3.

### 2.4 Doubly-robust / CATE estimation — *Implemented, currently numerically invalid for inference*

`LinearDRLearner` is a sound, mainstream choice (EconML's own recommended DR estimator, double-robustness: consistent if *either* the propensity or the outcome model is correct). The problem is not the estimator choice; it is the **conditioning of the final-stage linear model** (§3.1).

### 2.5 Customer × channel scoring → constrained optimization — *Implemented*

The optimizer (linear/integer assignment of one channel per customer under capacity caps) is methodologically straightforward and the right tool. Two important framing points are already handled well: the **unconstrained scenario is correctly labeled illustrative** (it dumps 93–96% of customers into Leads, which is the classic symptom of optimizing an unconstrained objective against a single dominant arm), and the **constrained scenario is the only operationally meaningful one**. The canonical Sample1 (~100K, preserving all Leads) is a reasonable evaluation construct.

The deeper unresolved question is the **objective**: the optimizer currently maximizes predicted conversion. It should eventually maximize *incremental* conversion (lift), and ideally cost-adjusted acquisition or NPV/CLTV (open_questions #12). Maximizing predicted conversion rather than uplift can systematically misallocate budget toward "sure things" who would have converted anyway — the exact failure mode uplift modeling exists to prevent.

---

## 3. Key Methodological Risks

### 3.1 Underdetermined covariance / `zstat=-inf` — *Production blocker (for causal claims); root cause identified*

**Root cause (confirmed against EconML documentation and issue tracker):** EconML emits `Co-variance matrix is underdetermined. Inference will be invalid!` when the **rank of the final-stage feature matrix is less than the number of parameters** it must estimate. That final matrix is built by taking `X` (the featurizer output), appending an intercept column, and **interacting it with the treatment**. The warning therefore fires when (a) columns of `X` are collinear / near-collinear, or (b) there are effectively fewer informative observations than parameters for a given treatment arm.

In Lumen's setup this is over-determined to happen for several compounding reasons:
- **One-vs-rest with `t_channel_*` columns living in both `X`/`W` and as the treatment `T`** creates near-collinearity between the treatment indicator and conditioning columns (open_questions #6). If a channel's treatment column is also (nearly) reconstructable from the other channel columns, the interacted design is rank-deficient by construction. The team's own "training an s-learner effectively… evaluations are resulting from undetermined matrices" note is pointing at exactly this.
- **Rare channels** (low positive counts) mean some treatment arms have very few treated units, so the per-arm effective sample is below the parameter count. This is why the Tree-VIF scan (drop near-deterministic / ≤250-positive channels) helped but **did not fully fix it** — it removed `Social_CT` but channels like Paid_Search still trip the warning.
- **Propensity overlap / positivity violations** (some customers have ~0 probability of some channels) produce extreme inverse-propensity weights, which is the well-documented source of unstable DR variance/inference even when point estimates survive.

**What it does and does not invalidate:**
- It **invalidates** every standard error, CI, z-stat, and p-value on the ATE/CATE. Any significance statement built on these is unusable. *Production blocker for causal/uplift claims.*
- It **does not automatically invalidate the point potential-outcome predictions** the optimizer consumes — those come from the cross-fitted regression models, not the broken final-stage covariance. But run-to-run ATE variability suggests the point estimates are also less stable than is comfortable.

### 3.2 No causal validation of the deployed scores — *Important validation gap → blocker for uplift claims*

There is currently **no experiment and no defensible off-policy evaluation**. The DR/CATE estimates are observational; their validity rests on unconfoundedness (no unmeasured confounders driving both channel assignment and conversion), overlap, and correct nuisance models — none of which is established. *We can claim better ranking; we cannot claim incremental causal uplift.*

### 3.3 OPE-vs-PRISM comparison is not what it appears — *Communication caveat + validation gap*

The +11.18% AUC (0.831 vs 0.719) result has four independent problems:
1. **It measures ranking (AUC/KS), not incremental uplift.** A better-ranking response model is not the same as a policy that causes more conversions.
2. **Selection-on-agreement bias.** Keeping only the ~7,070 "lucky match" rows where the observed action equals the model's recommendation conditions on the outcome of the policy and is not a representative or unbiased evaluation set. This is precisely the bias that proper off-policy evaluation (IPS / doubly-robust OPE) is designed to remove.
3. **No significance test** on a small subset (7,070 of 521,231 test rows).
4. **Confounded comparison:** Lumen and PRISM may have access to different features/data, so the comparison is not apples-to-apples ("captures responders better because it has more data" is an admission of this).

This result is **suggestive internal evidence**, suitable for a "promising, to be validated" note — not for any external or manager-facing performance claim.

### 3.4 Non-temporal train/test split — *Important validation gap*

The random 60/20/20 split (stratified on `converted`) leaks future-into-past information relative to a deployment that scores forward in time, and likely contributes to the unrealistic test-set channel mix. **A time-based / windowed holdout is mandatory before any performance claim** (open_questions #9). This is standard for any model that will be scored prospectively.

### 3.5 Direct-mail sourcing / data-foundation ambiguity — *Important; partly blocker*

Historical `channel_Direct_Mail_Contacted` is effectively empty (the other team's MTA-DM code failed), so DM enters only via TMIA, producing a DM≫Email imbalance and an unrealistic raw channel mix. Combined with the unresolved MTA-vs-TMIA-vs-hybrid decision (open_questions #1–2), this means **the model is partly learning a data-collection artifact rather than channel behavior**. Any channel-level comparison involving DM should be heavily caveated until this is fixed.

### 3.6 Objective mismatch: conversion vs. uplift — *Research improvement → important*

As noted in §2.5, optimizing predicted conversion rather than predicted *incremental* conversion risks targeting "sure things." Since the DR machinery already produces potential outcomes `_0/_1`, switching the optimizer objective to the difference (lift) is mostly a wiring change and should be prioritized.

### 3.7 Calibration disabled — *Communication caveat / to revisit*

Calibration was trialed and disabled (little effect, possibly learning identity). Because the optimizer consumes predicted probabilities and because DR weighting needs calibrated propensities, this should be **re-examined with proper calibration metrics (Brier/reliability curves), not just "did the number move"** — especially since AUC-tuned XGBoost is a classic source of miscalibration.

---

## 4. Production-Readiness Gaps

| Gap | Severity | Note |
|---|---|---|
| DR inference numerically invalid (underdetermined covariance) | **Critical blocker (causal claims)** | Fixable; see §3.1 and §5. Does not block deployable point scores per se. |
| No experimental / defensible-OPE validation | **Critical blocker (uplift claims)** | Cannot claim incremental business impact without it. |
| Non-temporal split | Important validation gap | Must adopt time-based holdout before any metric is reported as predictive of production. |
| Data foundation (MTA/TMIA/hybrid) + DM sourcing unresolved | Important; partial blocker | Model partly fits a collection artifact. |
| Models not persisted; notebooks messy/unversioned | **Critical for registration** | Cannot register/govern a model that is not reproducibly serialized. |
| Optimizer objective = conversion, not uplift | Important | Mostly a wiring change; high value. |
| Calibration off; optimizer consumes raw probabilities | Communication caveat / revisit | Re-evaluate with calibration metrics. |
| Output table / one-vs-N channel contract undefined | Important (deployment) | Define before the scoring job is built. |
| Long compliance / model-validation cycle; architecture lock-in | Strategic dependency | XGBoost approval path cannot transfer to a transformer (D004). |

---

## 5. Recommended Validation Steps

In rough priority order:

1. **Fix the final-stage rank deficiency before trusting any inference.** Concretely: (a) remove `t_channel_*` treatment columns from `X`/`W` so the treatment is not reconstructable from the conditioning set, or confirm via EconML's expected API that they belong only in `T`; (b) reduce the final-stage feature dimension (`fit_cate_intercept` behavior, simpler featurizer) so rank ≥ parameters; (c) raise the rare-channel positive-count threshold or pool rare channels; (d) check propensity overlap and trim/stabilize extreme weights, or adopt overlap/ATO weighting which is bounded by construction. Re-run and confirm the underdetermined warning and `zstat=-inf` are gone before reporting any CI.
2. **Adopt a time-based / windowed holdout** (e.g., train on months *t−k…t*, test on *t+1…t+m*) and re-report all metrics. Treat the current random-split numbers as provisional.
3. **Calibrate propensity and outcome models and evaluate with Brier/reliability**, not AUC alone; verify the optimizer is fed calibrated probabilities.
4. **Replace the "lucky match" comparison with a proper off-policy estimator** — inverse-propensity-scored and/or doubly-robust OPE of the Lumen *policy* against the logged/BAU policy, with confidence intervals (e.g., the Dudík et al. DR-OPE framework for contextual bandits). This is the strongest claim available short of an experiment.
5. **Re-target the optimizer to incremental conversion (lift = `_1` − `_0`)** and re-run the constrained scenario; report lift, not raw conversion.
6. **Plan a champion/challenger field experiment** (BAU policy vs. Lumen policy, randomized) as the eventual gold standard for an incremental-uplift claim. Even a small-arm pilot on the directly controllable channels (Email, Direct Mail, Leads, OBTM) would convert "model-estimated" into "experiment-validated."
7. **Stabilize reproducibility:** persist models (MLflow registry), version the notebooks, and freeze the data-foundation decision — prerequisites for the registration/compliance path.

---

## 6. Alternative Methods Worth Considering

These are framed as options, with fit to Lumen's constraints — not recommendations to switch.

- **Causal forests / GRF (Wager–Athey).** Non-parametric CATE with *honest* splitting and asymptotically valid pointwise confidence intervals, native support for multiple treatment arms. Strong candidate if the team wants trustworthy heterogeneity + inference without hand-built linear final stages — and it sidesteps the specific underdetermined-linear-final-stage failure. EconML exposes `CausalForestDML`. Worth a head-to-head against the current `LinearDRLearner` once the data foundation is fixed.
- **Meta-learners (T-/X-/DR-learner) with gradient-boosted bases.** Large-scale marketing comparisons find X-learner and DR-learner competitive with causal forests; cheap to trial inside the existing XGBoost stack and a good robustness check on the current estimates.
- **Uplift-native evaluation (Qini / AUUC).** Regardless of estimator, the team should evaluate with **Qini curves / AUUC** (uplift-specific), which measure incremental targeting efficiency rather than raw ranking — a far better fit than AUC for a next-best-action system. Score-ranking + calibration techniques for *multi-treatment* uplift are an active, directly relevant literature.
- **Off-policy evaluation (IPS / DR / switch estimators).** The principled replacement for the "lucky match" comparison; gives an estimate of the Lumen policy's value with CIs from logged data, before committing to a live test.
- **Contextual bandits (Thompson sampling).** The natural *production* evolution: a bandit both serves next-best-channel and continuously gathers the randomized exploration data that makes future causal estimates defensible — directly addressing the "no experiment" gap. Higher engineering/governance lift; a medium-term option, not a v1.
- **Markov-chain attribution (removal effect).** A cheap, interpretable diagnostic baseline for the *attribution* lens; useful as a sanity check against DR ATEs, but it is correlational and not a next-best-action engine.
- **Transformer / sequence journey models (LiDDA-style).** Already under consideration (D004). Important framing: **LiDDA solves attribution (credit assignment), not next-best-action.** A Lumen transformer would need a predictive/uplift head and the optimizer layered on top. Given the long, non-transferable compliance path, going transformer-first means deferring any production model by at least one full validation cycle. Recommend productionizing the XGBoost DR model as v1 and scoping the transformer as a parallel research track, not a replacement for v1.

---

## 7. What Can Be Claimed Now vs. What Should Not Be Claimed Yet

**Can be claimed now (defensible):**
- Lumen AI is an *implemented* predictive next-best-channel system: doubly-robust potential-outcome scoring + constrained optimization, built on PRISM scores and journey features.
- The method *corrects for channel-assignment selection bias* and is a principled improvement over last-touch and naive Shapley attribution (with documented Shapley-vs-DR sign flips as supporting evidence).
- In an *offline historical simulation*, the constrained optimizer reallocates contacts in a way that is *model-estimated* to improve conversion (~1.31% → ~1.44%), **explicitly pending live validation**.
- Internal checks *suggest* Lumen ranks responders better than the status quo, motivating a validation effort.
- The team has a clear, prioritized path to production readiness.

**Should NOT be claimed yet (not supported):**
- ❌ Any *incremental business uplift* number ("+10% more conversions", "+137 conversions") as a forecast of production impact — it is a model-estimated simulation, not an experiment or defensible OPE.
- ❌ That Lumen *beats PRISM by 11.18%* — that is ranking AUC on a small, outcome-conditioned, non-significance-tested subset, and the two systems use different data.
- ❌ Any statement relying on the DR confidence intervals, p-values, or "statistically significant" effects — the inference is currently numerically invalid.
- ❌ That specific channels have a *causal* positive/negative effect of a given magnitude — point estimates vary run-to-run and the inference layer is broken.
- ❌ That the model is *production-ready* — it is not persisted, not validated on a temporal holdout, and the data foundation is unsettled.

**Recommended one-line framing for managers:**
*"Lumen AI is a working, methodologically sound prototype that ranks customers' channel responsiveness better than today's approach and, in offline simulation, points to a meaningful conversion lift. Before we attach a number to business impact, we need to fix a known numerical issue in the causal layer, validate on a forward-in-time holdout, and ideally run a small randomized test."*

---

*Cross-references: methodological detail in `03_research_memory/method_critiques.md`; sources in `03_research_memory/reference_bank.md`; literature summaries in `03_research_memory/literature_notes.md`; new/updated open questions in `01_current_state/open_questions.md`.*
