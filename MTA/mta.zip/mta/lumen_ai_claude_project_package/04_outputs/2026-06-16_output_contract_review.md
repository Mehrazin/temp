# Production Output-Contract Review — Lumen AI

**Date:** 2026-06-16
**Author:** Applied-science review pass (interface / output-contract focus)
**Scope guardrails (from the request):** This pass does **not** design the model architecture and does **not** assume any architecture is correct. It evaluates how *different* modeling approaches could all serve one **stable production output contract**, so that swapping models later does not force downstream re-engineering. The design principle throughout: **bind downstream consumers to a data contract, not to a model.**

**Anchor fact provided:** PRISM-style scores already live in a familiar **long table**: `customer_id, model_id, model_score, model_score_rank, effective_date`, historized monthly by `effective_date`, one row per `(customer, model_id, effective_date)`, extended by **adding rows, not columns**.

---

## 1. Recommended Output-Contract Options

The core recommendation is to split the contract into **two tables plus a registry**, and to make the score table a generalization of the PRISM long pattern.

**Table 1 — Score fact table (the scorer's output; append-only, PRISM-shaped):**

```
customer_id
effective_date          -- scoring cycle (monthly), historized like PRISM
model_id                -- which scorer/version produced this row (FK -> model registry)
candidate_action_id     -- what was scored: a channel, a set, or a sequence (FK -> action registry)
objective_id            -- what the score means semantically (FK -> objective registry)
score                   -- numeric: probability | ranking score | expected value | uplift
score_rank              -- optional rank within (customer, effective_date, model_id, objective)
score_lower, score_upper-- optional, nullable; only populated for interval-bearing scores (e.g. uplift CIs)
```

**Table 2 — Assignment / decision table (the config-driven policy layer's output):**

```
customer_id
effective_date
policy_run_id           -- which config/policy produced this decision (FK -> policy registry)
assigned_action_id      -- channel / set / sequence chosen (FK -> action registry)
position                -- ordering slot; NULL for single/unordered, 1..k for sequences/top-K
selected                -- boolean / reason code (e.g. capacity, eligibility, no_contact)
```

**Why two tables:** the score table is *what the model believes*; the assignment table is *what the business decided to do this cycle*. Keeping them separate is what lets the same scores feed top-1, top-K, capacity-constrained, allowed-set, and no-contact decisions **without rescoring or schema change** — the entire flexible-output requirement (D011) becomes reads/joins over Table 1 producing Table 2.

**Three packaging options for these:**

- **Option A (recommended): Generalized long score table mirroring PRISM + registry + separate assignment table.** Maximum future-compatibility; minimal schema churn; reuses PRISM operational muscle memory.
- **Option B: Option A as system-of-record, plus materialized *wide* views** per downstream consumer that wants a pivoted shape (one column per channel). Adds query convenience without sacrificing the append-only core.
- **Option C: New custom wide table** (one column per channel/objective). Only defensible if V1 is frozen to a single, never-changing use case — which contradicts the stated business reality. Not recommended.

---

## 2. Long-Table vs Wide-Table Tradeoff

| Dimension | Wide table (column per channel/objective/model) | Long table (row per score) |
|---|---|---|
| Add a channel / objective / model version | **Schema migration** (ALTER, backfill, downstream contract break) | **Add rows** — no schema change |
| Unordered sets / ordered sequences | Column explosion (→ 2^N for sets) | Natural — one row per candidate action |
| Sparse / variable candidate sets | NULL-heavy, wasteful | Native (only score what exists) |
| Single-use-case query ("rank channels for customer C") | Trivial, one row read | Needs filter + pivot |
| Row volume / storage | Low | High → must partition by `effective_date`, index `(customer_id, effective_date)` |
| Score semantics | Implicit in column name | **Must be explicit** via `score_type`/registry |
| Match to existing PRISM ops | Poor | **Exact** — reuses tooling, jobs, consumer habits |
| Future model swap | Often forces column/contract change | Transparent (new `model_id` rows) |

**[INTERPRETATION]** For a system whose defining requirement is *"the business will ask for different outputs over time,"* the long table wins decisively. The wide table optimizes for a frozen single use case; Lumen is the opposite of frozen. The one real cost of long — query inconvenience and row volume — is fully mitigated by Option B (materialized wide views) and standard `effective_date` partitioning. **Recommendation: long as system-of-record; wide only as derived views.**

---

## 3. Whether / How To Reuse the PRISM-Style Schema

**Reuse the *pattern*, in a *parallel* Lumen table — do not write into PRISM's own table.**

- **Keep:** the long shape, `effective_date` historization, `model_id`, `score`, `score_rank`, the row-extensible philosophy. Downstream teams and scoring-job infrastructure already understand this shape — that operational familiarity is a real, bankable benefit and lowers the governance/onboarding cost of a new model.
- **Add:** `candidate_action_id` and `objective_id` (and optional `score_lower/upper`). PRISM scores a *customer against a model*; Lumen scores a *customer against a candidate action under an objective*. Those two extra dimension keys are the whole difference, and they are exactly what makes the table action- and objective-agnostic.
- **Why parallel, not shared:** Lumen actions are structured (sets/sequences) and its scores carry heterogeneous semantics (probability vs uplift vs ranking score). Forcing that into PRISM's table risks polluting a governed, widely-consumed asset. A separate `lumen_scores` table that *looks and behaves like* PRISM — ideally sharing a common registry convention — gives the familiarity without the coupling.
- **[INTERPRETATION]** A tempting middle option — register Lumen outputs as additional `model_id`s inside the existing PRISM framework — is operationally seductive but couples Lumen's faster iteration cadence to PRISM's governance. Prefer a parallel table now; revisit consolidation once Lumen's schema is stable.

---

## 4. Is a Model / Action / Objective Registry Needed?

**Yes — it is not optional once `candidate_action_id` and `objective_id` exist.** Without it, `model_score = 0.42` for `candidate_action_id = 7` under `objective_id = 2` is uninterpretable, and the score table cannot be safely consumed or audited. PRISM already implicitly relies on a `model_id` lookup; Lumen needs a richer, explicit one.

Three small dimension tables:

- **Model registry:** `model_id → name, version, score_type (prob | rank_score | uplift | ev), objective_id, training_window, approval/validation status, champion|challenger flag`. Enables champion/challenger to coexist as different `model_id`s on the same `effective_date` (exactly how PRISM holds multiple models) and gives compliance a per-version status field.
- **Action registry + members bridge:** `action_id → action_type (single | set | sequence)`, plus `action_members(action_id, channel_id, position)` where `position` is NULL for single/sets and `1..k` for sequences. This is what lets single channels, unordered sets, and ordered sequences all be referenced by one `candidate_action_id` in the score table **without schema change**.
- **Objective registry:** `objective_id → definition, direction (max/min), score_type, label horizon`. Distinguishes conversion vs engagement vs uplift vs NPV cleanly.

**[INTERPRETATION]** The registry is the linchpin of model-replaceability: it lets the *meaning* of a score live in metadata, so a new model is just new rows + a new registry entry, never a downstream change. Build a minimal version in V1 even if it holds one model, a handful of channels, and one objective.

---

## 5. Representing Candidate Channels, Sets, and Sequences

The score table never changes shape; the **action registry** absorbs all structural complexity.

- **Single channel:** `action_type=single`, one member, `position=NULL`. (`Email` → one `action_id`.)
- **Unordered set `{email, leads, direct_mail}`:** `action_type=set`, members with `position=NULL`. Generate a **canonical, deterministic `action_id`** by sorting member `channel_id`s and hashing — so the same set always resolves to the same id and never duplicates.
- **Ordered sequence `email → leads → direct_mail`:** `action_type=sequence`, members with `position=1..k`; `action_id` = hash of the *ordered* member list. The same three channels in a different order are a *different* `action_id` — which is the point.
- **No-contact:** represent as an **explicit** `action_id` (`action_type=none`), not as the absence of a row. Explicit no-contact is scoreable, assignable, and auditable — important for governance and for ever computing a contact-vs-no-contact margin.

**Cardinality discipline (critical for sets/sequences):** never enumerate all 2^N sets or all permutations. The **policy layer supplies the candidate-action list** each cycle (the business-relevant universe), and the scorer only scores those. The long table then holds a bounded number of rows per customer, not a combinatorial blow-up. This is also why the wide table fails for combos and the long table does not.

---

## 6. Which Output Design Best Supports Future Model Replacement

**Option A (long score table + registry + separate assignment table).** Downstream binds to the tuple semantics `(customer, effective_date, candidate_action, objective, score[, rank, CI])`, resolved through the registry. Consequences:

- Swapping the model (XGBoost → transformer → hybrid) = **new `model_id` rows, same schema**. Downstream sees nothing change.
- Champion/challenger and A/B run **side by side** as different `model_id`s on the same `effective_date` — no parallel pipelines, no schema fork.
- New objectives, channels, sets, or sequences arrive as **new rows / new registry entries**, never as migrations.
- The one rule that makes this hold: **downstream must read `score_type` from the registry and must not naively compare scores across `model_id`/`objective`** (a probability, a ranking score, and an uplift are not on the same scale). Enforce comparability inside the policy layer, where `score_type` is known.

---

## 7. Per-Approach Fit to the Same Contract

For each modeling approach: can it emit the same external structure? what changes internally? what does downstream see? does switching to it later require re-engineering? realistic stage?

| Approach | Same external structure? | Internal change | Downstream sees | Re-engineering to adopt later? | Stage |
|---|---|---|---|---|---|
| **Plain conversion prediction** | Yes — one row, `action=no-contact/baseline` | Single model, no action input | A baseline `∅` score per customer | None (new `model_id` rows) | **V1** (baseline / `∅` reference) |
| **Customer × candidate-channel scoring** | **Yes — canonical producer** (`action=single` channel) | Action enters as input | One score row per (customer, channel) | None | **V1** (primary) |
| **Sequential recommendation / ranking** | Yes — populate `score` (rank_score) + `score_rank` | Ranking objective/loss | Same rows; `score_type=rank_score` | None — but policy layer must respect rank-score semantics | **V1 / V1.5** |
| **Transformer representation + downstream model** | Yes — downstream model emits the rows | Encoder is internal only | Identical | **None — encoder swap is invisible** | **V1.5** |
| **Multi-task model** | Yes — multiple rows per (customer, channel) keyed by `objective_id` | Shared encoder, multiple heads | More objective rows | Additive (new `objective_id`s) | **V1.5 / V2** |
| **Uplift / CATE** | Yes — `score_type=uplift`, optional `score_lower/upper` | Needs `∅` baseline + (optionally) CIs | Same rows, uplift semantics | Additive; needs `∅` action scored | **V1.5 / V2 (optional)** |
| **Unordered combination scorer** | Yes — rows with `action_type=set` | Set encoder / set candidate input | Same rows; action resolves to a set | None to the table; policy layer must supply candidate sets | **V2** |
| **Ordered sequence scorer** | Yes — rows with `action_type=sequence` | Sequence-aware scoring | Same rows; ordered members in registry | None to the table; may later need a *timing/when* dimension | **V2** |

**[INTERPRETATION] Headline finding:** every approach on the list emits into the *same* two-table contract. The differences are entirely **internal** (what the model is) or in **registry metadata** (`score_type`, `action_type`, `objective_id`). **No approach on the list forces a schema change** — provided the contract is built generalized from V1. That is the whole payoff of designing the interface before the model.

**Second finding (reassuring for scope):** the bulk of the "different outputs over time" list — **top-1, top-K, multiple channels per customer, allowed-channel set, capacity constraints, no-contact** — are **decision-layer operations over single-channel scores.** They need *no new model and no new schema*; they are queries/optimizations over Table 1 that write Table 2. Only genuine **combinations (sets) and sequences** require the model to score structured actions. So V1 single-channel scoring already unlocks most business asks through the policy layer.

---

## 8. On Uplift (Neutral Assessment)

Schema-wise, uplift is **free**: it is just `score_type=uplift` with two optional nullable CI columns. So the contract should be **uplift-ready** regardless of whether V1 produces uplift.

- **Where uplift genuinely helps:** the **contact-vs-no-contact margin** (avoiding "sleeping dogs"), and incremental-budget ranking where you must prioritize *persuadables*. There it changes the decision, not just the score.
- **Where it adds unnecessary complexity:** "which channel given we will contact" (predicted conversion ranking is decision-equivalent when the `∅` baseline is similar across channels); regimes with poor overlap/positivity (the current data) where causal estimates are unreliable; and any setting with no experiment to validate the uplift offline.
- **Contract implication:** carry the `score_type` field and the nullable CI columns from day one so uplift can be added as *one more objective* later without re-engineering — but do **not** make uplift a structural assumption of the contract or a V1 requirement.

---

## 9. V1 / V1.5 / V2 Staging

- **V1 — single-channel scoring + full policy layer.** Long score table (`action_type=single`, one `objective_id=conversion`, `score_type=prob`), minimal registry (channels + one model + one objective), assignment table. Policy layer delivers top-1, top-K, multiple-per-customer, allowed-set, capacity caps, and no-contact — all as reads over single-channel scores. Champion/challenger via multiple `model_id`s. **This is most of the business value.**
- **V1.5 — richer scores, same shape.** Multiple objectives (`objective_id`), multi-task heads, transformer-embedding hybrid (internal only), optional uplift `score_type` + CIs. No schema change — only registry growth and new rows.
- **V2 — structured actions.** Unordered sets and ordered sequences (`action_type=set|sequence` + members bridge), policy-layer candidate-set generation, and — flagged for design — a possible **timing/"when"** dimension for sequences. Still no change to the core score-table columns.

---

## 10. Risks and Open Questions

1. **Score comparability.** Probabilities, ranking scores, and uplifts are not on one scale. Downstream must never compare across `model_id`/`objective` without consulting `score_type`. Enforce comparison logic in the policy layer; consider forbidding cross-`score_type` comparison at the query layer.
2. **Calibration.** If scores feed a constrained optimizer, probabilities should be **calibrated**; ranking scores are not probabilities. The contract should record `score_type` so the policy layer knows whether calibration assumptions hold. (Ties to the existing calibration open question, OQ8.)
3. **Combinatorial cardinality.** Sets/sequences must be bounded by a policy-supplied candidate list, never enumerated. Define who owns the candidate-set universe each cycle.
4. **Deterministic `action_id` generation.** Need a canonical hashing rule (sorted members for sets, ordered for sequences) so ids are stable and de-duplicated across cycles and teams.
5. **`effective_date` semantics.** Disambiguate scoring date vs decision period vs label horizon — three different dates that are easy to conflate (relates to the non-temporal-split issue, OQ9).
6. **No-contact representation.** Recommend an explicit `no_contact` action over "missing row," for scoreability and audit — confirm with the business.
7. **Contract evolution policy.** Commit to **additive-only** changes (new rows, new nullable columns, new registry entries); deprecate via registry status, never by dropping/renaming columns. Define how downstream consumers version against the contract.
8. **Governance / approval coupling.** Each `model_id`/version needs an approval-status field; a new architecture still needs its own model-validation path (it cannot inherit another model's approval). The contract makes *swapping* painless technically, but not free from a compliance standpoint.
9. **Reproducibility.** Rows should be immutable per `(customer, model_id, candidate_action, objective, effective_date)`; never update in place — append corrections as new rows/versions.

---

## 11. Guidance for the Next Design Agent (Avoid Premature Architecture Lock-In)

1. **Design the contract before the model.** Treat the model as a pluggable producer of `(customer, effective_date, candidate_action, objective, score, score_type[, rank, CI])` rows. Validate the contract against 2–3 concrete downstream query patterns *before* committing to any architecture.
2. **Do not encode channels, objectives, or model versions as columns.** They are *data* (rows + registry), not schema. This is the single most important rule for avoiding re-engineering.
3. **Keep structural complexity in the registry.** Single channel, unordered set, and ordered sequence must be `action_type` metadata, not three different tables or schemas.
4. **Separate the score fact table from the assignment table.** Most business "output" requests are policy-layer operations over scores — resist the urge to build a new model for each.
5. **Carry `score_type` (and nullable CI columns) from day one.** This future-proofs prediction, ranking, expected-value, and uplift outputs without schema change — while staying neutral on whether uplift is produced.
6. **Mirror PRISM's long pattern in a parallel table.** Reuse the operational familiarity; avoid coupling to PRISM's governed asset.
7. **Stay architecture-neutral.** The contract above is satisfiable by XGBoost, a transformer, a hybrid encoder+GBDT, a multi-task net, a ranker, or a combo scorer. Pick the model on its merits later; the interface must not presuppose the choice.
8. **Bound combinatorial scoring explicitly.** Define candidate-set ownership before V2; never score the full power set.
9. **Remember the timing dimension exists.** Ordered sequences hint at an eventual "when to contact" question — don't design the action model in a way that forecloses it, but don't build it now either.
