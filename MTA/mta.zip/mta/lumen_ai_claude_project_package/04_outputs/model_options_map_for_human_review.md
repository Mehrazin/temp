# Model Options Map — For Human Review

**Date:** 2026-06-16
**Purpose:** A scannable map of the model/design options that are **actually supported by the existing Lumen AI artifacts** (the `transformer_mvp_design/` set, the research-memory scan, the contract analysis, and the design-input snapshot). This is an **extraction, not a new design.** It does not invent options, does not pick a final MVP, and does not privilege uplift over prediction. Where the artifacts already lean a certain way (e.g., they nominate CP2 as the primary MVP candidate and CP1 as the mandatory floor), that lean is reported as the artifacts' stance, not asserted here.

**Claim-discipline reminders carried throughout (from the source files):**

- **Predictive diagnostics ≠ causal attribution.** Feature importance, SHAP, and ablations explain *what the model keys on*; they are **not** incremental/causal effect estimates. Only an uplift/CATE design (CP6) or a *repaired* DR baseline yields causal attribution — and the current DR inference is numerically broken (rank-deficient, `zstat=-inf`).
- **Attention weights are not attribution.** A transformer's contribution is a better encoder/scorer; "attention over touchpoints" is not a channel-credit or incremental-effect claim.
- **Uplift is one optional `score_type`, not the objective.** Every option below defaults to a predictive/ranking score; `uplift(A) = score(A) − score(∅)` is a derivation that is reachable but off by default.

---

## 1. The decision space in one paragraph

The artifacts frame every candidate as the same **three stacked layers** — (1) a sequence/representation **encoder** over the customer journey + static PRISM context, (2) an **action-conditioned scorer head** where the candidate channel is an *input* (not a fixed output), emitting `score(customer, action)`, and (3) a **config-driven decision/optimization layer** (caps, eligibility, top-1/top-K, no-contact) that turns scores into assignments without retraining. The real choices live in **Layer 1 + Layer 2**: how rich a representation to build (tabular features → temporal sequence → pretrained sequence encoder) and how to frame the head (predictive probability/ranking by default; uplift only at the contact/no-contact margin or once an experiment/defensible OPE exists). All options emit into the **same PRISM-style long score table + registry**, so the model family is swappable as new `model_id` rows rather than schema changes. The binding real-world constraints are the **2–4 week spike window**, the fact that the **cleaned transformer-ready dataset (Layer 4) does not exist yet**, and unconfirmed **journey richness** — so the artifacts treat "transformer matches vs. beats a strengthened GBDT" as *re-opened, pending profiling*, not settled.

---

## 2. Compact comparison table

| Option | What it is | Role per artifacts | Predictive scoring | Diagnostics it supports | Diagnostics source | Long-table / PRISM contract | 2–4 wk feasibility |
|---|---|---|---|---|---|---|---|
| **CP1** | Temporal-feature XGBoost, action-as-feature | **Mandatory baseline / floor / fallback** | Yes (default) | Predictive (feature importance/SHAP); causal only via the *separate, currently-broken* DR stage | Predictive from model; causal from separate DR layer | Yes — canonical producer | **Yes** |
| **CP2** | Tabular/temporal transformer (FT-Transformer **or** TFT), action-as-input | **Primary MVP candidate** | Yes (default) | Predictive (attention/SHAP — *not* attribution); uplift via S-learner difference | Predictive from model; uplift = same model, differenced | Yes — canonical producer | **Yes** (spike grade) |
| **CP3** | Hybrid: transformer encoder → existing XGBoost/DR | **Co-MVP / low-risk fallback** | Yes (default) | Predictive (marginal-value ablation); causal via existing DR layer | Predictive from model; causal from separate DR layer | Yes — encoder swap is invisible downstream | **Yes, comfortably** |
| **CP4** | Sequence-rec encoder (SASRec/BST) + action head | **Conditional** (only if journeys long/dense) | Yes (ranking-native) | Predictive (ranking, recency); no native causal | Predictive from model | Yes (`score_type=rank_score`) | **Partial** |
| **CP5** | Self-supervised pretraining / multi-task scorer | **Stretch / "MVP+" at full scale** | Yes (default) | Predictive, multi-signal (next-touch, engagement) | Predictive from model (multi-head) | Yes (rows per objective) | **Partial** |
| **CP6** | Causal/uplift head (Causal/G-Transformer; grf Causal Survival Forest; or S-learner difference) | **Deferred / Week-4 pilot at most** | Indirectly (via baseline `score(∅)`) | **Causal/attribution** (CATE/uplift) — the only option built for it | Causal from the same model (own head) | Yes (`score_type=uplift` + CIs) | **No** (rigorous); S-learner difference only |
| **A5** *(primitive, not a standalone path)* | Deep-Sets / Set-Transformer treatment encoder for channel combos | Build only if combos are V1 scope; else V2 | n/a (enables CP2/CP4/CP6 to score sets) | n/a | n/a | Yes (`action_type=set`) | Yes (~50 lines) **if** combos in scope |
| *Deferred* | Ordered sequences / sequential RL-bandit / TPP "when-to-contact" | **V2/V3 — assess realism, do not build** | — | — | — | Contract kept from foreclosing them | No |

---

## 3. Option detail

### CP1 — Temporal-feature XGBoost (action-as-feature)

- **Plain English:** Stop collapsing the journey into one flat snapshot. Engineer multi-window / RFM / recency / inter-touch-gap features over the full 2022+ history; train XGBoost to predict conversion with the candidate channel included as a feature. This is the *strengthened* version of today's baseline, not a strawman — UpliftBench shows GBDT is a genuinely hard bar.
- **Diagram:**
  `journey history → temporal/RFM features ── + ── candidate channel (feature) → XGBoost → P(convert) → decision layer`
- **Input data:** existing tables + timestamps; ~10 PRISM scores + CC indicator; per-channel multi-window counts/recency/gaps. No new modality, no positivity prerequisites.
- **Sequence/time use:** time is **summarized** into engineered windows/recency/gap features; order is not modeled as a sequence.
- **Output:** calibrated conversion probability + ranking score (`score_type=prob`).
- **Predictive scoring:** yes — this is the default and the floor.
- **Diagnostic/attribution:** **predictive diagnostics only** (gain/SHAP/ablations = what the model keys on). Causal attribution is *not* native — it would come from the *separate* DR stage, which is currently rank-deficient and cannot license CIs/p-values until fixed.
- **Diagnostics: same model or separate layer?** Predictive diagnostics from the model itself; any causal/attribution reading requires the **separate DR layer**.
- **Contract compatibility:** full — canonical single-channel producer; unblocks the mandatory time-based holdout.
- **Feasibility (2–4 wk):** **Yes.** Highest value-per-effort; also the fair-comparison baseline, so the work is never wasted.
- **Main risks:** does not satisfy the transformer mandate (D004), so it is the floor, not the deliverable; ceiling limited if journeys turn out long/rich.
- **Key references/repos:** XGBoost-with-temporal-data (arXiv 1802.03396); time-varying RFM churn (Annals of OR 2024); UpliftBench, S-learner-over-GBDT bar (arXiv 2604.06123; repo `Aman12x/UpliftBench`); "When Do Neural Nets Outperform Boosted Trees" (arXiv 2305.02997). Tooling: XGBoost/LightGBM, EconML, scikit-uplift.

### CP2 — Tabular/temporal transformer, action-as-input *(artifacts' primary MVP candidate)*

- **Plain English:** A genuine transformer, but a *tabular/temporal* one on mature libraries. Two interchangeable realizations chosen by profiling: **FT-Transformer** over engineered features (robust when journeys are short/sparse), or **TFT** treating the journey as a time-varying sequence with the **proposed action as a "known-future input"** (preferred if journeys are longer/denser). The candidate channel is always an *input*, never a fixed output head.
- **Diagram:**
  `journey (features or events) → transformer encoder → h_c ── ⊕ ── action embedding a → MLP head → score(c,a) → decision layer`
- **Input data:** static PRISM block + journey block (FT: aggregated features; TFT: ordered `(ts, channel, interaction)` events) + candidate-action embedding + binary conversion label. Needs the Layer-4 cleaned sequence dataset (or a representative cleaned sample).
- **Sequence/time use:** FT path = coarse temporal signal via engineered windows; TFT path = explicit temporal sequence with optional learned time-gap embeddings (BST-style) if timestamps are fine-grained.
- **Output:** calibrated conversion probability / ranking score (`score_type=prob`). `uplift(A)=score(A)−score(∅)` is derivable but **off by default**.
- **Predictive scoring:** yes — the default.
- **Diagnostic/attribution:** **predictive diagnostics** (SHAP, ablations, and attention — *attention is explicitly not attribution*). Causal attribution is **not** produced; it is reachable only by turning on the S-learner uplift difference (which is a causal *framing*, defensible only when overlap/positivity hold).
- **Diagnostics: same model or separate layer?** Predictive diagnostics from the model; the optional uplift difference is the **same model**, differenced against the explicit ∅ action — no separate model.
- **Contract compatibility:** full — canonical producer; one row per (customer, channel).
- **Feasibility (2–4 wk):** **Yes, spike grade** — *assuming* a usable Layer-4 sample and GPU/library compatibility. Spend the spike on the head + evaluation + leakage discipline, not on reimplementing attention.
- **Main risks:** may only **match** CP1 at this scale (a legitimate, valuable outcome per the artifacts — judge on full-data, not the prototype slice); GPU/library friction on Databricks/Azure (early-week risk → pivot to CP3); treatment leakage if the action also appears as a journey feature (the exact collinearity that broke the DR baseline — hard leakage guard required).
- **Key references/repos:** FT-Transformer (arXiv 2106.11959; `pytorch-tabular`); TFT (arXiv 1912.09363; `pytorch-forecasting`); TIMeSynC, fintech journey transformer (arXiv 2410.12825; supports the framing, *challenges* beats-GBDT-at-our-scale); Cao & Zhu NBA action-as-input (arXiv 2108.08846); BST time-gap embeddings (arXiv 1905.06874).

### CP3 — Hybrid: transformer encoder → existing XGBoost/DR

- **Plain English:** Train/pretrain an encoder, export journey embeddings, append them to the existing tabular features that today's XGBoost/DR scorer already consumes. A clean with/without-embedding ablation answers the cheap, management-relevant question: *does the transformer representation add anything over current features?*
- **Diagram:**
  `journey → transformer encoder → embedding ─┐`
  `existing tabular features ─────────────────┴→ XGBoost/DR scorer → score → decision layer`
- **Input data:** existing feature set **plus** the encoder's journey embedding.
- **Sequence/time use:** time/order captured inside the encoder; downstream model stays tabular.
- **Output:** same as the current scorer (probability / ranking; DR potential outcomes if the DR wiring is reused).
- **Predictive scoring:** yes (default).
- **Diagnostic/attribution:** **predictive diagnostics** plus a direct **marginal-value ablation** of the embedding. Causal attribution only via the existing DR layer (subject to the same rank-deficiency caveat).
- **Diagnostics: same model or separate layer?** Predictive from the downstream model; causal from the **separate DR layer**; the encoder's value is measured by ablation, not by attention.
- **Contract compatibility:** full — the **encoder swap is invisible** downstream (same `model_id`-style rows).
- **Feasibility (2–4 wk):** **Yes, comfortably.** Lowest compliance disruption (reuses the existing approval lineage). The artifacts' designated fallback if CP2 friction is high.
- **Main risks:** the embedding may add little — but that is itself a cheap, useful finding.
- **Key references/repos:** any encoder (SASRec/BST/FT-Transformer/TFT) + existing XGBoost/EconML stack; encoder refs as in CP2/CP4.

### CP4 — Sequence-rec encoder (SASRec/BST) + action-conditioned head

- **Plain English:** A production rec-stack encoder over the event sequence produces a customer-state vector; a small head scores `state ⊕ candidate-channel`. This is the "long, dense journeys" option.
- **Diagram:**
  `event sequence → SASRec/BST encoder → state vector ── ⊕ ── channel embedding → head → score → top-k → decision layer`
- **Input data:** ordered touchpoint event sequences + channel taxonomy + conversion label; PRISM as side features.
- **Sequence/time use:** **native sequence modeling** (causal self-attention; BST adds learned time-gap embeddings for irregular journeys) — the most sequence-dependent option.
- **Output:** ranking-native score (`score_type=rank_score`) / conversion probability; top-k.
- **Predictive scoring:** yes — ranking-native.
- **Diagnostic/attribution:** **predictive diagnostics** (ranking quality, recency effects). No native causal/attribution; attention is not attribution.
- **Diagnostics: same model or separate layer?** Predictive from the model; no causal layer here.
- **Contract compatibility:** full (`score_type=rank_score`; policy must respect rank semantics).
- **Feasibility (2–4 wk):** **Partial** — a prototype is feasible; a fairly tuned comparison may slip. Justified **only if profiling confirms long/dense journeys**; sparse controllable channels (Email/DM/Leads) degrade it.
- **Main risks:** sparse-journey degradation; cold-start on rare channels; more infra than CP2 for uncertain gain.
- **Key references/repos:** SASRec (arXiv 1808.09781); BERT4Rec (arXiv 1904.06690 — its edge over SASRec is fragile; SASRec is the pragmatic default); BST (arXiv 1905.06874). Tooling: NVIDIA-Merlin `Transformers4Rec`, `RecBole`.

### CP5 — Self-supervised pretraining / multi-task scorer

- **Plain English:** Pretrain the encoder on large **unlabeled** journeys (next-touch / masked-channel), then fine-tune for conversion; optionally a shared encoder with heads for conversion + next-channel + engagement. The biggest beneficiary of the corrected full-scale data, because pretraining feeds on unlabeled volume and helps the sparse-positive-label regime.
- **Diagram:**
  `unlabeled journeys → pretrain encoder → fine-tune ── ⊕ ── action → head(s) → score(s) → decision layer`
- **Input data:** large unlabeled journey corpus for pretraining + the labeled set for fine-tuning.
- **Sequence/time use:** native sequence pretraining objectives (next-touch / masked-channel).
- **Output:** conversion probability (+ optional auxiliary objective rows).
- **Predictive scoring:** yes (default); multi-task adds more predictive signals.
- **Diagnostic/attribution:** **predictive, multi-signal** diagnostics (e.g., next-channel propensity). No native causal attribution.
- **Diagnostics: same model or separate layer?** Predictive from the model (multi-head); no causal layer.
- **Contract compatibility:** full (more objective rows; additive).
- **Feasibility (2–4 wk):** **Partial** — scope-creep risk; time-box pretraining. The artifacts move it up toward "MVP+" *only if* a usable Layer-4 sequence dataset materializes early.
- **Main risks:** scope creep; depends on the (unbuilt) sequence dataset.
- **Key references/repos:** SRP4CTR (arXiv 2407.19658); Abacus (arXiv 2512.16581); Markovian Pre-Trained Transformer (arXiv 2601.08275); multi-task: Huawei pairwise-ranking MTL (arXiv 2406.02163), Tencent cross-task distillation (arXiv 2202.09852), Pinterest DHEN (arXiv 2504.08169). Tooling: `Transformers4Rec`, `RecBole`.

### CP6 — Causal / uplift head *(the only attribution-native option)*

- **Plain English:** Add a rigorous confounding-adjusted counterfactual head (Causal/G-Transformer), or use a non-DL **Causal Survival Forest** for sparse censored data, or — the cheap version — simply emit the **S-learner difference** `score(A) − score(∅)` from CP2. This is the only family *built* to estimate incremental effect (CATE/uplift).
- **Diagram:**
  `journey + context → encoder → counterfactual head → {score(A), score(∅)} → uplift(A)=score(A)−score(∅) (+CIs) → decision layer`
- **Input data:** same journey/context/action inputs **plus** an explicit ∅ baseline and adequate per-channel overlap/positivity (currently unconfirmed/poor).
- **Sequence/time use:** depends on the encoder; the causal machinery is in the head, not the time encoding.
- **Output:** `score_type=uplift` with confidence intervals (nullable CI columns already carried in the contract).
- **Predictive scoring:** indirectly — it produces the per-action scores whose *difference* is the uplift; prediction is a by-product, not the goal.
- **Diagnostic/attribution:** **this is the causal-attribution option** (incremental effect per channel) — and the only one that legitimately supports an attribution-style reading. Useful specifically at the **contact/no-contact margin**, where ranking by incremental return diverges from ranking by predicted conversion.
- **Diagnostics: same model or separate layer?** Causal estimate from the **same model's own counterfactual head** (vs. CP1/CP3 where causal reads come from a separate DR layer).
- **Contract compatibility:** full (`score_type=uplift` + CIs; additive).
- **Feasibility (2–4 wk):** **No** for rigorous DL (research-grade code, healthcare→marketing transfer unproven, adversarial-training instability) — a **Week-4 pilot question at most**. The **S-learner difference** is the only "good-enough" v1 uplift if forced; the Causal Survival Forest is a Medium-effort non-DL route.
- **Main risks:** the data's overlap/positivity is currently too poor to defend a causal estimate (the regime that produced the rank-deficient DR `zstat=-inf`); **no incremental-uplift claim is licensed without an experiment or defensible OPE** (D005); separate compliance path.
- **Where uplift is genuinely useful (not dismissed):** when the decision includes *whether to contact at all* ("sleeping dogs"), when budget is scarce enough to demand ranking by incremental return, or once a champion/challenger experiment or defensible OPE exists to validate it.
- **Key references/repos:** Causal Transformer (arXiv 2204.07258; repo `Valentyn1997/CausalTransformer`); G-Transformer (arXiv 2405.21012; repo `konstantinhess/G_transformer`); Causal Survival Forests (arXiv 2001.09887; `grf`). Tooling: EconML, CausalML, scikit-uplift; UpliftBench for Qini/AUUC.

### A5 — Deep-Sets / Set-Transformer treatment encoder *(cross-cutting primitive)*

- **Plain English:** A ~50-line permutation-invariant set-pooling component so CP2/CP4/CP6 can score arbitrary channel **combos** compositionally (a single channel = a size-1 set), without enumerating 2^N combinations. Not a standalone model — an add-on to the action block.
- **Diagram:**
  `{channel embeddings} → permutation-invariant pool (Deep Sets / Set Transformer PMA) → set embedding a → existing head`
- **Input data:** the candidate set's member channel embeddings; deterministic `action_id` = hash of sorted member ids.
- **Output:** a `score` for a set (`action_type=set`).
- **Contract compatibility:** full — structural complexity lives in the action registry, not the score table.
- **Feasibility (2–4 wk):** **Yes** to build, **but only if combos are confirmed near-term V1 scope** (decision-needed, OQ41); else defer to V2.
- **Main risks:** combo generalization to **held-out unseen combos** is unproven (OQ36) — must be tested before relied upon.
- **Key references/repos:** Set Transformer / Deep Sets (arXiv 1810.00825).

### Deferred (assess realism, do not build in the spike)

- **Ordered multi-channel sequences, sequential RL/bandit serving, TPP "when-to-contact," frontier generative recommenders (HSTU-scale).** These add a timing/decisioning dimension out of current scope with high engineering + governance cost. The action representation and the output contract are deliberately kept from foreclosing them, but the artifacts are explicit: **V2/V3, not the spike.** (RL/bandit is also noted as the natural future path to gather randomized data for a defensible causal estimate.)

---

## 4. Cross-option notes the artifacts insist on

- **The decision layer is shared and model-agnostic.** Top-1, top-K, multiple-channels-per-customer, caps, allowed-set filters, and no-contact are **decision-layer operations over single-channel scores** — no new model, no new schema. So **V1 single-channel scoring already unlocks most confirmed business asks** regardless of which option above produces the score.
- **The output contract is the same for all of them.** Every option emits into the two-table PRISM-style contract (long score fact table + assignment table + registry). Swapping CP1 → CP2 → CP3 is new `model_id` rows, not a migration. This is what makes the model-family choice low-stakes and reversible.
- **Predictive vs. causal, restated:** CP1–CP5 are **predictive** scorers (their "diagnostics" explain the prediction, not the incremental effect). **CP6 is the only causal/attribution-native option.** A predictive ranking is *decision-equivalent* to uplift for "which channel given we contact" when the ∅ baseline is similar across channels; they diverge at the **contact/no-contact margin** — that margin is where uplift earns its place.
- **What is still unsettled (data, not reading):** journey length/richness (FT vs TFT vs sequence-rec), whether a transformer beats or merely matches CP1 at full scale, whether set-pooling generalizes to held-out combos, and whether overlap/positivity even permits a defensible uplift estimate. These gate the choice and must be measured on the full source while Layer 4 is built.

*Sources: `04_outputs/transformer_mvp_design/{transformer_mvp_design, data_and_sequence_schema, training_objective_and_labels, experiment_plan, evaluation_plan, scoring_output_contract_and_downstream_design, risks_and_deferred_items}.md`; `03_research_memory/{transformer_practical_literature_and_repo_scan, production_score_contract_options, reference_bank}.md`; `04_outputs/transformer_design_input_snapshot.md`; `01_current_state/{current_snapshot, open_questions}.md`. No new research performed; options limited to those the artifacts support.*
