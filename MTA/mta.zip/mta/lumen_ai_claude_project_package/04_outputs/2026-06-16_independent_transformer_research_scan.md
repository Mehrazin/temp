# Independent Transformer Research Scan — Lumen AI

**Date:** 2026-06-16
**Author:** Applied-science research pass (independent)
**Scope:** Practical transformer-based approaches for a customer-journey / next-best-channel model, deliverable in a ~2–4 week spike, supporting a reusable scorer + config-driven downstream layer (D004/D010/D011).
**Independence note:** This is a *fresh* scan. It deliberately does **not** read or rely on the prior Chat-1 research outputs (`transformer_implementation_plan.md`, `transformer_sequence_modeling_review.md`, `literature_notes.md`, `reference_bank.md`). Overlap with those files, where it exists, is convergent evidence — not copying. A reconciliation against Chat-1 can be done as a later step.

**How to read the evidence labels.** Throughout, claims are tagged:
- **[ACADEMIC]** — peer-reviewed / arXiv result.
- **[INDUSTRY]** — vendor blog, engineering post, or applied case study (weaker evidence; often unaudited).
- **[CODE]** — an actual repo I inspected, with a maturity judgment.
- **[INTERPRETATION]** — my own inference for Lumen, not established fact.

---

## 1. Independent Literature / Repo Scan

### 1.1 The shape of the problem (and why naming matters)

A "Lumen transformer" is really **three stacked layers**, and most of the literature only solves one of them:

1. **Sequence encoder** — turn a customer's history of touches/events into a representation. *Well-solved.*
2. **Action-conditioned head** — score a candidate channel/action (or set of channels) against that representation. *Partially solved; mostly as prediction, rarely as causal uplift.*
3. **Decision/optimization layer** — turn scores into assignments under caps, eligibility, no-contact, objectives. *Solved separately, in the optimization/bandit literature.*

**[INTERPRETATION]** The single most important framing discipline for the spike: a transformer gives you a better **encoder** and possibly a better **predictive scorer**. It does **not**, by itself, give you **incremental uplift** or **causal validity**. Those come from the head design and the evaluation design, not from the architecture. Most of the risk in this project lives in layers 2–3, not layer 1.

### 1.2 Sequence encoders (layer 1) — mature, low-risk

- **[ACADEMIC]** SASRec (self-attention, causal/unidirectional; arXiv 1808.09781) and BERT4Rec (bidirectional, masked; arXiv 1904.06690) are the canonical transformer sequence recommenders. Note the well-documented replicability caveat: **[ACADEMIC]** "Turning Dross into Gold" (2309.07602) and the Glasgow replicability study (2207.07483) find BERT4Rec's claimed edge over SASRec is fragile and training-budget-dependent. Takeaway: SASRec is the pragmatic default; don't over-invest in bidirectional masking.
- **[ACADEMIC]** Behavior Sequence Transformer / BST (Alibaba) and PinnerFormer (Pinterest) are the industrial reference encoders; TransAct V2 (2506.02267) is the current Pinterest production lineage.
- **[ACADEMIC]** Most directly analogous to Lumen: **TIMeSynC (Capital One, 2410.12825)** — an encoder-decoder transformer for **multi-channel financial-services customer journeys** (transactions, payments, rewards, servicing messages, product enrollment), predicting next intent / next-best-action. It introduces time-aware attention (ALiBi-style relative-time bias) and field/domain embeddings for heterogeneous tabular-sequence data. **Caveats I want to flag loudly:** (a) it trains on **30M+ user sequences** and **500+ intents** — roughly two orders of magnitude more sequences than Lumen's ~500K customers; (b) it is a **prediction/ranking** model (Recall@1/5/10), **not** a causal/uplift model; (c) reported lifts over a strong SASRec+tabular baseline are **modest** (~+2 to +8% relative recall). So it is an excellent architectural template and a fintech proof-of-existence, but it is *not* evidence that a transformer beats GBDT on Lumen's scale or on an uplift objective.

### 1.3 Tabular reality check — does a transformer even beat XGBoost here?

- **[ACADEMIC]** FT-Transformer / TabTransformer (2106.11959, 2012.11403) are competitive with GBDTs on *some* tabular tasks but not consistently. Grinsztajn et al. and the broader 2024 consensus: **tree ensembles still match or beat deep nets on typical tabular data**, especially with irregular targets, uninformative features, and modest sample sizes.
- **[ACADEMIC]** Strongest skeptical datapoint for us: **UpliftBench (2604.06123)** benchmarks S-/T-/X-Learner (LightGBM) and Causal Forest on the **13.98M-row Criteo uplift** set. The **S-Learner with gradient-boosted trees wins** (Qini 0.376; top-20% captures 77.7% of incremental conversions; 3.9× over random), beating X-Learner and Causal Forest. **[INTERPRETATION]** This is a direct, recent, large-scale signal that the project's *existing* S-learner-over-GBDT instinct is not naive — it is the empirically strong baseline that the transformer must beat on an **uplift** metric, not just on AUC/recall.

### 1.4 Action-conditioned heads (layer 2) — the actually-novel part

- **[ACADEMIC]** Next-best-action with action-as-input + top-k selection is exactly the Cao & Zhu "Reinforced Coupled Recurrent Network" (2108.08846): a sequence encoder produces a customer state, a **reward-prediction head takes a candidate action as input** and scores it, and the system returns top-k actions. This is an **RNN/RL**, research-grade, debt-collection study (61K clients), but it is a clean academic precedent for the D010 "scorer with the action as an input" pattern. **[INTERPRETATION]** It validates the *pattern*, not a transformer realization of it.
- **[ACADEMIC]** Rigorous causal head over sequences: the **Causal Transformer (2204.07258, ICML'22)** estimates counterfactual outcomes under time-varying confounding using three sub-networks + an adversarial "counterfactual domain confusion" balancing loss. It is the principled answer to "what if we turn channel X on." **But** it is healthcare (tumor sim, MIMIC-III), research-grade, and its marketing transfer is unproven.
- **[ACADEMIC]** Multi-/combo-treatment uplift exists and is active: Heterogeneous Multi-treatment Uplift for short-video (2511.18997), Cross-Treatment Effect for multi-valued treatments via dynamic neural masking (2511.01641, Didi), and debiased-CTR+uplift for coupons (2602.12972). These are encouraging for the "multiple channels / combos" requirement but are platform-scale and recent — references, not turnkey.

### 1.5 Marketing-attribution sequence models (adjacent, attribution not NBA)

- **[ACADEMIC]** Deep/attention attribution: Dual-attention MTA (1808.03737), DeepMTA-with-attention (1809.02230), **CAMTA causal attention (2012.11403)**, CausalMTA (2201.00689, Alibaba). **[ACADEMIC/INDUSTRY]** **LiDDA (LinkedIn, 2505.09861)** and **NNN (Google, 2504.06212)** are the newest transformer-for-marketing-measurement papers. **[INTERPRETATION]** All of these solve **attribution/measurement** (credit assignment, removal effects), *not* next-best-channel decisioning. They are useful for the diagnostic lens and for the encoder design, but they do not produce a deployable per-customer channel recommendation. Treat as architecture/feature references only.

### 1.6 Decision/optimization layer (layer 3) — keep it separate, reuse existing ILP

- **[ACADEMIC]** Strong, directly reusable line of work treating "scores → assignment under budget/caps" as its own layer: A Unified Framework for Marketing Budget Allocation (Alibaba, 1902.01128), Direct Heterogeneous Causal Learning for Resource Allocation (Meituan, 2211.15728), Decision-Focused Causal Learning (Meituan, 2407.13664), End-to-End Marketing under Budget Constraint (Kuaishou, 2302.04477), constrained user-item allocation for campaigns (2606.09623). Contextual-bandit-for-causal-marketing (1810.01859) and offline constrained RL budget allocation (Ant, 2309.02669) cover the sequential/"when" variant.
- **[INTERPRETATION]** This literature strongly supports the D010/D011 architecture choice: **keep the scorer and the policy/optimizer decoupled.** The existing Lumen ILP/constrained optimizer is the right home for caps, eligibility, no-contact, and top-1/top-K — no transformer needed there. "Decision-focused" learning (training the scorer to optimize the downstream decision) is a *stretch* refinement, not an MVP requirement.

### 1.7 Repositories inspected

- **[CODE] NVIDIA-Merlin/Transformers4Rec** — *mature, production-oriented.* PyTorch, HuggingFace backbones (XLNet/GPT-2/etc.), NVTabular preprocessing, Triton serving, tutorials. Built for **session/sequential next-item** prediction. Best fit for a fast transformer encoder MVP **if** journeys are long enough. Caveat: item-prediction framing; you bolt the action-conditioned/uplift head on yourself; GPU-oriented.
- **[CODE] jdb78/pytorch-forecasting** — *mature, well-maintained.* Implements **Temporal Fusion Transformer (TFT)** with explicit static / time-varying-observed / known-future feature typing — the known-future slot maps naturally to "the planned channel action." Good fit for the tabular-temporal regime and easier to reason about than a from-scratch transformer.
- **[CODE] Valentyn1997/CausalTransformer** — *research-grade.* PyTorch-Lightning + Hydra + MLflow, MIT, has tests/CI, but **datasets are cancer-sim and MIMIC-III**; the data adapters and the whole harness assume the medical longitudinal format. Reusable as a reference implementation of the causal head; **not** a drop-in for marketing data in 2–4 weeks.
- **[CODE] Aman12x/UpliftBench** — *lightweight, reproducible.* LightGBM S/T/X-learners + EconML Causal Forest + Qini/AUUC/policy-sim/SHAP on Criteo. **[INTERPRETATION]** This is essentially a ready-made **evaluation harness and baseline** for Lumen's uplift comparison — adopt its metric code directly.
- **[CODE] (well-known, not re-inspected this pass)** EconML (CausalForestDML, DR/X-learners), CausalML (Uber), scikit-uplift (Qini/uplift curves), RecBole (SASRec/BERT4Rec implementations). All MIT/BSD, all production-usable as components.

---

## 2. Candidate Implementation Paths

Five paths, ordered roughly from lowest to highest risk/ambition. Each is scored for a **2–4 week spike whose goal is "a model + an experimental comparison vs the XGBoost/DR baseline + a design decision," not a production model.**

### Path A — Sequence-feature XGBoost (the "honest baseline upgrade", non-transformer)

- **Method:** Stop collapsing the April–July snapshot into one flat vector. Engineer **recency / frequency / inter-touch-gap / multi-window** features over the full 2022+ history; keep XGBoost + S-learner uplift (`pred(channel) − pred(∅)`), action as a feature. Reuse the existing DR machinery and optimizer.
- **Required data:** Existing tables + event timestamps to compute windows/gaps. No new modality.
- **Difficulty:** **Low.** Days, not weeks.
- **Likely value:** **High value-per-effort.** Directly attacks the known "flat snapshot" weakness; **[ACADEMIC]** UpliftBench shows GBDT S-learner is genuinely hard to beat on uplift.
- **Risks:** Doesn't satisfy the manager's *transformer* mandate; ceiling limited if journeys are genuinely long/rich.
- **Repos/tools:** XGBoost/LightGBM, EconML, scikit-uplift, UpliftBench eval code.
- **2–4 week realistic?** **Yes, comfortably** — and it's the fair, strengthened baseline the transformer must beat.

### Path B — TFT / FT-Transformer scorer with the action as an input (recommended MVP)

- **Method:** A **single reusable scorer**: encode the journey + customer features with a Temporal Fusion Transformer (or, if journeys are short, an FT-Transformer over windowed-tabular features), with the **proposed channel action(s) as a known-future input**. Predict conversion; derive uplift via **S-learner difference** `score(A) − score(∅)`. Feed scores to the existing config-driven ILP for top-1/top-K/caps/eligibility/no-contact. Combos handled by a permutation-invariant set encoding of channel embeddings (size-1 set = single channel).
- **Required data:** Per-customer event sequence with timestamps; channel/action taxonomy as embeddings; PRISM scores as static features; conversion label. Needs the **journey-length and event-richness facts** (see §7) to choose TFT vs FT-Transformer.
- **Difficulty:** **Medium.** TFT via pytorch-forecasting is configuration-heavy but documented; the action-as-input and S-learner uplift wrapper are straightforward.
- **Likely value:** **Medium-high.** Satisfies the transformer mandate, the reusable-scorer requirement, and the flexible-output requirement in one architecture; gives a genuine transformer-vs-GBDT comparison.
- **Risks:** May **not beat Path A on uplift** at Lumen's scale (the honest, expected outcome per §1.3); S-learner uplift is biased under confounding; set-pooled combo generalization is unproven (must test).
- **Repos/tools:** **pytorch-forecasting (TFT)**, FT-Transformer (rtdl), Transformers4Rec (if going sequence-native), EconML/scikit-uplift for eval.
- **2–4 week realistic?** **Yes**, for a *spike-grade* model + comparison. Not production-hardened.

### Path C — SASRec/Transformers4Rec sequence encoder + action-conditioned head

- **Method:** Use a Merlin/Transformers4Rec **SASRec-style encoder** on the touch sequence to produce a customer-state vector; add a small **action-conditioned scoring head** (state ⊕ candidate-channel embedding → conversion), top-k selection (the Cao & Zhu pattern, transformer-ized). Decision layer unchanged.
- **Required data:** Reasonably **long, dense** journeys (this path's value scales with sequence length); channel-as-token vocabulary.
- **Difficulty:** **Medium-high.** Encoder is library-supported; the bespoke head, the uplift framing, and GPU plumbing add effort.
- **Likely value:** **Conditional.** High **if** journeys are long/rich; low if they're short/sparse (then it underperforms Path A/B).
- **Risks:** Sparse-journey regime (Email/DM/Leads are sparse) directly degrades it; cold-start on rare channels; more infra than B for uncertain gain.
- **Repos/tools:** **Transformers4Rec** (XLNet/SASRec backbones, Triton serving), RecBole (quick SASRec/BERT4Rec baselines).
- **2–4 week realistic?** **Partially.** A prototype encoder+head is feasible; a *fair, tuned* comparison may slip past 4 weeks if data plumbing is heavy.

### Path D — Multi-treatment / set-conditioned uplift head (the combo path)

- **Method:** Extend B/C so the scorer accepts a **set of channels** (Deep Sets / Set Transformer pooling of channel embeddings) and returns combo-level uplift on demand — directly serving "multiple channels per customer" and "next-N." S-learner uplift v1.
- **Required data:** Enough **observed channel combinations** with conversions to train and, critically, to **hold out unseen combos** for a generalization test.
- **Difficulty:** **High.** The set encoder is the easy part; *validating* combo generalization and combo-level uplift is the hard part.
- **Likely value:** **High if the business genuinely wants combos soon; otherwise premature.** Combinatorial was already shelved once (D008).
- **Risks:** Combo data is sparse → generalization claims may not hold (OQ36); uplift-on-combos is doubly hard to validate offline.
- **Repos/tools:** Set Transformer impls; same eval stack.
- **2–4 week realistic?** **No, not as a validated capability.** Feasible only as an architectural *hook* in B, with combo validation deferred.

### Path E — Causal Transformer head (rigorous counterfactual, stretch)

- **Method:** Adopt the CT/CRN-style sequence head with adversarial balancing (counterfactual domain confusion) to estimate channel counterfactuals under time-varying confounding — the principled fix for the confounding that makes S-learner uplift biased.
- **Required data:** Sequential covariates/treatments/outcomes with **time-varying confounding** structure; enough overlap/positivity per channel.
- **Difficulty:** **High.** Research-grade code, adversarial training instability, healthcare→marketing transfer unproven.
- **Likely value:** **High *if* it works** — it's the only path that directly addresses causal validity (D005). But payoff is uncertain.
- **Risks:** Time sink; may not converge or beat the S-learner on a defensible offline metric within the spike; new-architecture compliance burden.
- **Repos/tools:** **Valentyn1997/CausalTransformer** (reference only — must rewrite data layer), EconML CausalForestDML as the non-transformer rigorous comparator.
- **2–4 week realistic?** **No** as a deliverable; **yes** as a small Week-4 pilot question ("do CT counterfactuals differ materially from the S-learner's?").

---

## 3. Recommended MVP Path

**Path B — TFT/FT-Transformer reusable scorer with the action as an input, S-learner uplift, feeding the existing config-driven ILP** — run head-to-head against **Path A** as the strengthened baseline.

**Why:** It is the only option that simultaneously (a) honors the confirmed transformer direction (D004), (b) realizes the reusable-scorer + config-driven-layer requirement (D010/D011) in one architecture, (c) is buildable to spike grade in 2–4 weeks on mature libraries, and (d) produces the exact artifact the spike needs — a fair transformer-vs-GBDT comparison on an **uplift** metric. **[INTERPRETATION]** The honest expectation, given §1.3, is that B may only *match* A on uplift at this scale; that is still a successful, decision-useful spike outcome, because it tells the team whether the transformer's added complexity is justified *now* or should wait for more data.

---

## 4. Strong Fallback Path

**Path A — sequence-feature XGBoost + S-learner uplift.** If TFT plumbing, GPU access, or the data-foundation blockers (§7) overrun, Path A still delivers a materially improved, defensible model on the existing approval lineage, unblocks the time-based holdout, and keeps the optimizer intact. **[ACADEMIC]** UpliftBench gives this fallback real credibility rather than treating it as a consolation prize. It is also the correct **baseline** in all scenarios — so the work is never wasted.

---

## 5. Stretch Path

**Path E (Causal Transformer head)** as a **Week-4, time-boxed pilot question**, optionally with **Path D** combo-scoring as an architectural hook in B (not a validated capability). The stretch goal is *evidence about whether rigor changes the decision*, not a production causal model. Pair it with an **EconML CausalForestDML** run as a non-transformer rigorous comparator (cheaper, gives valid CIs, sidesteps the rank-deficient linear final stage that broke the current DR inference).

---

## 6. Sequencing Summary

| Path | Role | Build effort | Beats GBDT uplift? | 2–4 wk? |
|---|---|---|---|---|
| A — seq-feature XGBoost | **Baseline / fallback** | Low | (is the bar) | Yes |
| B — TFT/FT-T action-as-input | **MVP** | Medium | Uncertain (maybe match) | Yes (spike grade) |
| C — SASRec encoder + head | Alt MVP if journeys long | Med-high | Only if long/rich seqs | Partial |
| D — set/combo uplift | Hook now, capability later | High | N/A | No (validated) |
| E — Causal Transformer | Stretch / rigor pilot | High | Unknown | No (pilot only) |

---

## 7. Evidence To Generate From Our Own Data *Before* Committing

These are gating facts; **[INTERPRETATION]** the architecture choice should not be finalized until they are known, because they determine whether a transformer can add value at all.

1. **Journey-length distribution** — touches per customer (median, p90, max). Short/sparse journeys → Path A/B(FT-Transformer); long/dense → Path B(TFT)/C justified. This single fact most determines transformer value.
2. **Event richness & per-channel frequency** — how many distinct `channel×interaction` types actually populate journeys; confirm Email/DM/Leads sparsity and the broken direct-mail sourcing. Sparse controllable channels degrade every sequence model.
3. **Volume vs DL threshold** — confirm the real scale (~500K customers / ~2.8M rows). **[ACADEMIC]** TIMeSynC's gains came at 30M+ sequences; transformers beating tuned GBDT mainly shows up at large scale + long sequences. Lumen is two orders of magnitude smaller → temper expectations.
4. **Timestamp quality/granularity** — resolution of event times; needed for any time-aware attention (ALiBi/TimeAliBi) or gap features. If timestamps are coarse, much of the transformer's temporal edge evaporates.
5. **Combo support in the data** — count of distinct observed channel combinations and their conversion volume; whether enough exists to hold out unseen combos. Gates Path D (OQ36).
6. **Overlap / positivity per channel** — is every channel plausibly assignable across the covariate space? Drives whether *any* uplift estimate (S-learner or causal) is defensible, and is the root of the current DR instability.
7. **A defensible offline evaluation design, fixed up front** — a **time-based holdout** (not the current random split), **Qini/AUUC** as the primary metric (not response AUC), and an **IPS/DR off-policy estimate of the policy's value vs BAU** with CIs. **[INTERPRETATION]** This must be decided *before* modeling so the transformer-vs-baseline comparison is fair and not circular — adopt UpliftBench's metric code to avoid reinventing it.

---

## 8. Most Useful Sources / Repos

**Build-now repos:**
- **pytorch-forecasting** (TFT, known-future input slot) — MVP scorer.
- **NVIDIA Transformers4Rec** (SASRec/XLNet encoder, Triton serving) — if going sequence-native.
- **UpliftBench (Aman12x)** — adopt its Qini/AUUC/policy-sim/SHAP **evaluation harness and GBDT baselines** directly.
- **EconML** (CausalForestDML, DR/X-learners) + **scikit-uplift** — rigorous comparators and uplift metrics.
- **CausalTransformer (Valentyn1997)** — reference only for the stretch causal head.

**Must-read papers:**
- **TIMeSynC (2410.12825)** — the closest fintech multi-channel-journey transformer; architecture template + sober scale caveat.
- **UpliftBench (2604.06123)** — the GBDT-S-learner-wins-on-uplift reality check.
- **Cao & Zhu NBA (2108.08846)** — action-as-input + top-k scorer pattern (matches D010).
- **Causal Transformer (2204.07258)** — the rigorous counterfactual head.
- **Marketing budget allocation / decision-focused causal learning** (1902.01128, 2211.15728, 2407.13664) — keep the optimizer as a separate, reusable layer.
- Encoder canon: SASRec (1808.09781), BERT4Rec + its replicability critiques (1904.06690, 2309.07602); tabular reality: FT-Transformer/Revisiting DL for Tabular (2106.11959).

---

## 9. What To Avoid Overengineering

1. **Don't build a from-scratch bespoke transformer.** Use TFT/Transformers4Rec; the spike's scarce time should go to the head and the evaluation, not to reimplementing attention.
2. **Don't chase bidirectional/BERT4Rec-style sophistication.** **[ACADEMIC]** Its edge over SASRec is fragile and budget-dependent.
3. **Don't enumerate combos or pre-train 2^N heads.** Keep action(s) as an *input* (set encoding). Combos are a hook, not a v1 capability.
4. **Don't put caps/eligibility/no-contact/objectives into the model.** They belong in the config-driven ILP layer — that decoupling is the whole point of D010/D011 and is well-supported by the allocation literature.
5. **Don't reach for the Causal Transformer / decision-focused learning as v1.** Rigorous causal heads are a Week-4 pilot question, not the MVP; healthcare→marketing transfer is unproven.
6. **Don't claim uplift from AUC/recall.** A better Recall@k (TIMeSynC-style) is *not* incremental business value. Hold the line on D005: report Qini/AUUC + a defensible OPE with CIs, on a time-based split, before any uplift claim.
7. **Don't let "transformer" become the goal.** The goal is a *reusable, decision-useful scorer*. If the data facts in §7 say journeys are short/sparse and small-scale, the honest spike result may be "Path A is sufficient for now; revisit the transformer when data depth grows" — and that is a legitimate, valuable finding.

---

## 10. Caveats On This Scan

- This pass did not re-read the Chat-1 research files by design; convergence with them (if any) is independent corroboration, and a reconciliation pass is recommended next.
- Repo maturity judgments are from inspecting structure/README this session; exact version compatibility (GPU, library pins) is unverified against TD's Databricks/Azure environment.
- All cited lifts (TIMeSynC recall, UpliftBench Qini, Cao & Zhu reward lift) are **the authors' results on their data**, not predictions for Lumen.
- No new-architecture compliance/model-validation path is assessed here; it remains a real dependency (a transformer cannot inherit the XGBoost approval lineage).
