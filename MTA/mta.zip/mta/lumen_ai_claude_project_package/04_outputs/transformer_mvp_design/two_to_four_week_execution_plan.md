# 2–4 Week Execution Plan — Lumen AI Transformer Spike

**Date:** 2026-06-16
**Status:** Proposed phased plan for the manager-directed spike (D004). Goal: **a model + a fair comparison + a finalized design** — "good enough," not perfect. **Companion:** `experiment_plan.md`, `risks_and_deferred_items.md`.

**Two parallel tracks throughout:** **Track A — model spike** (on a representative cleaned sample / prototype subset) and **Track B — Layer-4 data build** (the gating dependency). Track A must never be blocked waiting on Track B.

---

## 1. Phased plan

### Phase 0 — Setup & protocol freeze (Days 1–3)
- **Freeze the evaluation protocol** *before* modeling: time-based split, primary metrics (predictive), data layer, leakage audit (OQ43). *Prevents a circular comparison.*
- Confirm **environment**: GPU/runtime on Databricks/Azure, library compatibility (pytorch-tabular / pytorch-forecasting). Retire the GPU-availability risk early — it decides CP2-first vs CP3-first.
- Confirm **MVP scope** with manager/team: V1 use cases (OQ41), source MTA/TMIA/hybrid (OQ1), label horizon H.
- Stand up the **decision-layer skeleton** against *current* XGBoost scores so the assignment pipeline exists independent of the new model.

### Phase 1 — Baseline + data profiling (Days 3–7) — *Week 1*
- **Track A:** build **CP1 strengthened temporal-feature XGBoost** (multi-window/RFM/recency, action-as-feature) on the time-based split. This is the floor, the fallback, and unblocks the holdout (C6).
- **Track B:** run the **profiling checklist** on the full source (journey length, richness, identity resolution, timestamp quality, positives-per-channel, combo support, ETL throughput). Produce the **data-fit verdict** that selects FT vs TFT and sets H.
- Begin the **Layer-4 representative-sample** build.

### Phase 2 — Primary transformer (Days 8–12) — *Week 2*
- **Track A:** stand up **CP2** (FT-Transformer or TFT per the verdict), action-as-input, predictive output, **leakage-guarded**. Train S-learner-style; produce calibrated `score(c, a)`.
- Wire CP2 scores into the **decision layer**; demonstrate top-1/top-K/no-contact as config.
- Sanity-check single-channel scores vs current DR scores (agreement/sign).
- **If CP2 friction is high:** pivot to **CP3 hybrid** (encoder → existing XGBoost) — reuses the lineage, answers the marginal-value question.

### Phase 3 — Validation + flexibility (Days 13–17) — *Week 3*
- **Headline comparison:** CP2 vs CP1 (B1) on the time-based split; calibration curves; NDCG/Recall@k. Re-run on the **Layer-4 sample** as soon as it's ready.
- Run priority **ablations** (journey block, temporal features, encoder family, embedding-hybrid, calibration).
- **If combos confirmed in scope (OQ41):** build the **A5 set head** and run the **held-out-combo generalization** test (OQ36).
- Draft the **external scoring contract** (long table + minimal registry + assignment table) in skeleton form.

### Phase 4 — Optional rigor + write-up (Days 18–20) — *Week 4*
- **Optional CP6 pilot (time-boxed):** does a confounding-adjusted counterfactual (Causal/G-Transformer) or grf Causal Survival Forest differ materially from the S-learner difference? If not, the cheaper CP2 is "good enough."
- **Finalize the design doc:** chosen architecture, the core-model + decision-layer design, validation results (labeled by data layer), effort/risk to productionize (incl. the separate compliance path), and the explicit list of decisions still needing confirmation.

---

## 2. What can be done in 2 weeks

A **defensible, protocol-validated result on a representative/prototype sample**:
- CP1 strengthened baseline on a **time-based split** (the floor + the fair comparison unblocked).
- One transformer-bearing model: **CP2** (or **CP3** if friction is high).
- **Decision-layer skeleton** proving flexible single-channel outputs (top-1/top-K/no-contact) as config.
- Data-profiling verdict + Layer-4 build *in progress*.
- **Honest 2-week claim:** *"On a forward-in-time holdout (prototype/sample), the transformer [matches/beats] a strengthened XGBoost on predictive metrics; flexible outputs work via the decision layer. Full-data verdict pending Layer-4."* No uplift/business-impact claim.

## 3. What can be done in 4 weeks

The full spike artifact:
- Headline **CP2-vs-CP1 comparison on a Layer-4 sample** (the scale/richness verdict on real full-data numbers, not the prototype slice).
- Ablations + (if in scope) **combo-generalization** result.
- **External contract** skeleton (long table + registry + assignment).
- **Optional CP6 pilot** outcome.
- **Finalized design recommendation** with a clear go/iterate/fallback call and the decisions-needing-confirmation list.

## 4. Dependencies (critical path)

1. **Layer-4 data build (gating).** Profiling + cleaned representative sample. If it overruns, Track A falls back to the prototype subset and the data dependency is reported. *Binding constraint on the spike.*
2. **Evaluation protocol freeze** before modeling (else the comparison is circular).
3. **GPU/runtime availability** (gates CP2-first vs CP3-first).
4. **Scope confirmation** (OQ41) — whether combos/A5 are in the spike.
5. **Source decision** (OQ1) + **DM sourcing** clarity (OQ2) — affect data validity.
6. **Decision-layer skeleton** — needed for the end-to-end flexible-output demo (can start against current scores).

## 5. Risks against the timeline (summary; full list in `risks_and_deferred_items.md`)

- **Layer-4 ETL overrun** (highest) → fall back to prototype subset; report dependency.
- **Journeys too short/sparse** → standardize on CP2-FT; transformer justified on flexibility, not accuracy.
- **GPU/library friction** → pivot to CP3 hybrid.
- **Overlap/positivity too poor for any uplift** → keep prediction-first; defer CP6.
- **Scope creep** (combos, pretraining, causal head) → enforce stop rules; these are stretch/deferred.
- **New-architecture compliance** path cannot inherit XGBoost approval → treat productionization as post-spike.

## 6. Decisions needing manager/team confirmation (plan-level)

1. **(decision-needed, OQ40)** Is 2–4 weeks realistic given the Layer-4 dependency, and what is the accepted fallback if data work overruns?
2. **(decision-needed, OQ42)** End-of-spike deliverable + evidence bar that counts as "good enough" to finalize.
3. **(decision-needed, OQ41)** V1 scope: single-channel only vs include combos (gates A5 in the plan).
4. **(decision-needed, OQ35)** Whether the CP6 pilot runs in Week 4.
5. **(decision-needed)** GPU/runtime provisioning timing.
