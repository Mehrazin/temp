# Risks & Deferred Items — Lumen AI Transformer MVP

**Date:** 2026-06-16
**Status:** Proposed risk register + deferral plan for the spike. **Companion:** all other docs in this package. Severity: **Critical / High / Medium / Low**.

---

## 1. Technical risks (modeling)

| Risk | Severity | Why | Mitigation |
|---|---|---|---|
| **Journeys too short/sparse for a sequence encoder** | High | Controllable channels (Email/DM/Leads) sparse per customer; sequence models need signal across steps | Profile first (§7); default to **CP2-FT (tabular)** if mostly 0–2 touches; justify transformer on flexibility, not accuracy |
| **Transformer only matches (not beats) GBDT** | Medium | UpliftBench shows GBDT is a hard bar; re-opened, not settled | Treat "match" as a **legitimate, valuable outcome**; keep CP1 as floor; judge on **Layer-4**, not prototype |
| **Treatment leakage (action also in journey features)** | High | This collinearity broke the baseline's DR inference (`zstat=-inf`, C1/C2) | **Hard leakage guard**: action only via the action block; build-failing assertion test |
| **Set-pooled combo generalization fails** | Medium | Compositional set encoding to unseen combos is unproven (OQ36) | Test on **held-out combos** before relying on it; defer combos if it fails |
| **Miscalibrated probabilities feeding the optimizer** | Medium | AUC-tuned models can rank well yet be miscalibrated (OQ8) | Calibrate (Platt/isotonic); evaluate with Brier/reliability, not "did the number move" |
| **GPU/library incompatibility on Databricks/Azure** | Medium | Version/GPU compat unverified | Retire in Phase 0; pivot to **CP3 hybrid** if friction is high |
| **Rigorous causal head instability** | Medium | Causal/G-Transformer is research-grade, adversarial-training unstable, healthcare→marketing transfer unproven | Keep CP6 a **Week-4 pilot only**; S-learner difference is the v1 fallback |

## 2. Productionization risks

| Risk | Severity | Why | Mitigation |
|---|---|---|---|
| **New-architecture compliance path** | High (strategic) | A transformer **cannot inherit** the XGBoost approval; needs its own model-validation/compliance cycle | Treat productionization as **post-spike**; design contract so swap is technically cheap (not compliance-free); per-version approval status in the registry |
| **Reproducibility gaps** | High | Current models not persisted; notebooks messy/unversioned | Persist (e.g., MLflow), version code, freeze data-foundation before any registration |
| **Serving cost/throughput at 10–15M scale** | Medium | Population-scale scoring × channels × objectives × monthly cycles | Long-table partitioning by `effective_date`; retention policy; **score only policy-supplied candidate actions** (never the power set) |
| **Decision-layer/optimizer contract undefined** | Medium | One-vs-N channel use cases need a defined interface | Define the candidate-set/caps/eligibility contract; reuse the existing constrained ILP |

## 3. Governance / causal-claim risks (D005 — non-negotiable)

| Risk | Severity | Why | Mitigation |
|---|---|---|---|
| **Overclaiming incremental uplift** | Critical | No experiment / defensible OPE exists; offline numbers are model-estimated | **No "+X% conversions" claim** without an experiment or defensible OPE |
| **Presenting ranking AUC as "beating PRISM"** | Critical | +11.18% is ranking on a biased ~7,070-row selection-on-agreement subset, different data, not significance-tested | Never frame as "beats PRISM"; describe as suggestive internal ranking evidence only |
| **Citing DR CIs / p-values** | Critical | DR inference numerically invalid (underdetermined covariance) until C1/OQ5 fixed | No causal CI/p-value until the rank-deficiency is fixed and re-verified |
| **Confusing "must not claim uplift" with "model must produce uplift"** | High | These are distinct; conflation drives wrong design choices | Architecture keeps uplift **reachable**; MVP does not **depend** on it |
| **DM-artifact-driven channel conclusions** | Medium | DM sourcing broken (DM≫Email); model partly fits a collection artifact (OQ2/C9) | Caveat all DM comparisons; fix sourcing before any DM channel claim |

## 4. Data-readiness risks

| Risk | Severity | Why | Mitigation |
|---|---|---|---|
| **Layer-4 build overruns the spike** | **Critical (gating)** | Cleaned transformer-ready dataset does not exist; ETL competes for the 2–4 week budget | Two-track plan; run the model spike on a **representative sample / prototype subset**; report the dependency; do not force an unready run |
| **Identity resolution across 2022+ unreliable** | High | Touchpoints may not stitch into one journey per customer | Profile early; if unreliable, the sequence path (TFT/CP4) is undermined → fall back to CP2-FT |
| **Non-temporal split leaks future-into-past** | High | Current random 60/20/20 (C6) | **Time-based holdout is mandatory** before any predictive claim |
| **Overlap/positivity too poor for uplift** | High | Root of the DR instability | Keep prediction-first; defer CP6; restrict eligible sets in the policy rather than extrapolate |
| **Unconfirmed layer counts / window end date** | Medium | ≈2–3M / ≈500K / ≈10–15M and July-vs-January are approximate | Confirm during profiling (OQ45/OQ46); label every metric with its data layer |
| **Source ambiguity (MTA/TMIA/hybrid)** | Medium | Affects what the model learns (OQ1) | Decide before the headline run |

## 5. Deferred items (explicitly NOT in the MVP)

**V1.5 (richer scores, same architecture & contract):**
- Multiple objectives + multi-task heads (conversion + next-channel + engagement).
- Transformer-embedding **hybrid (CP3)** as a richer internal encoder.
- **Optional uplift `score_type` + CIs** — turned on only at the contact/no-contact margin or once an experiment/OPE exists.
- Self-supervised **pretraining (CP5)** on unlabeled journeys (moves up if Layer-4 sequence data matures early).

**V2 (structured actions & rigor):**
- Unordered **channel sets** and the A5 set head (if not already pulled into V1 by scope).
- **Rigorous causal/uplift head (CP6)** — Causal/G-Transformer or grf Causal Survival Forest, post a Week-4 pilot.
- **Ordered channel sequences** (introduces a timing dimension).
- Survival / censored time-to-event label reframing.

**V2/V3 (decisioning & timing — assess realism, do not build in the spike):**
- **Sequential RL / bandit** serving (also the natural path to gathering randomized data for defensible causal estimates).
- **"When-to-contact" timing** via temporal point processes (TPP).
- Frontier generative recommenders (HSTU-scale) — overkill regardless of data scale.

**Validation milestones deferred to post-spike:**
- **Champion/challenger field experiment** (the gold standard for an incremental-uplift claim) — even a small randomized arm on directly controllable channels (Email/DM/Leads/OBTM) converts "model-estimated" to "experiment-validated."
- **Defensible IPS/DR off-policy evaluation** with CIs as the principled replacement for the "lucky match" comparison.
- Full **compliance/model-validation** cycle for the new architecture.

## 6. Decisions needing manager/team confirmation (risk-level)

1. **(decision-needed, OQ40/OQ44)** Accepted fallback if the Layer-4 build overruns; minimum viable Layer-4 for the spike.
2. **(decision-needed, OQ41)** V1 scope (gates whether A5/combos move from V2 into the spike).
3. **(decision-needed, OQ35)** Whether CP6 earns a Week-4 pilot (contingent on profiled overlap/positivity + prospect of an experiment).
4. **(decision-needed)** Whether/when a champion-challenger experiment can be scheduled — the only path to a defensible uplift claim.
5. **(decision-needed)** Productionization ownership and the compliance-path timeline for a new architecture.
