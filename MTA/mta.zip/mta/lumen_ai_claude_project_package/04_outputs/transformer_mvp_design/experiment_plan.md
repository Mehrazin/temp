# Experiment Plan — Lumen AI Transformer MVP

**Date:** 2026-06-16
**Status:** Proposed experiment plan for the 2–4 week spike. The spike artifact is **a model + a fair comparison + a design decision**, not a production model. **Companion:** `evaluation_plan.md` (metrics/splits), `two_to_four_week_execution_plan.md` (timeline).

---

## 1. Experiment design principles

- **Fix the evaluation design *before* modeling** so the comparison is fair and not circular (OQ43). Time-based split, metrics, and data layer are frozen first (see `evaluation_plan.md`).
- **Compare like-for-like:** every model is trained and evaluated on the **same time-based split, same data source, same metric**, and — where feasible — on the **full-data Layer-4 sample**, not the prototype slice.
- **Label every result with its data layer** (prototype subset #1 / eval set #2 / full source #3 / cleaned Layer-4 #4). Never cite 500K as the population.
- **Reuse the existing eval harness** (UpliftBench: Qini/AUUC/policy-sim + GBDT baselines) for metric code and baselines.

---

## 2. Baselines (the bar the transformer must clear)

| Baseline | Role | Notes |
|---|---|---|
| **B0 — current XGBoost/DR (as-is)** | Historical reference | On the prototype slice; **non-temporal split** → provisional only, for context not for the headline comparison |
| **B1 — strengthened temporal-feature XGBoost (CP1)** | **Primary baseline / floor** | Multi-window/RFM/recency features over 2022+, action-as-feature, **time-based split**. This is the honest, hard bar (UpliftBench shows GBDT is hard to beat). |
| **B2 — popularity / rules / current-policy (BAU)** | Naive floor + OPE reference | Most-frequent channel, current targeting rules; also the logged policy for any OPE. |

The headline comparison is **CP2 transformer vs B1**, both on the same time-based split and (ideally) the same Layer-4 sample.

---

## 3. Core experiments

**E1 — Strengthened baseline (CP1 / B1).** Build temporal-feature XGBoost with action-as-feature on the time-based split. *Deliverable:* the floor metrics + an unblocked, fair split. *Also a fallback model if the transformer underdelivers.*

**E2 — Primary MVP transformer (CP2).** FT-Transformer **or** TFT (chosen by §6 profiling), action-as-input, predictive output, leakage-guarded. Train S-learner-style; produce calibrated `score(c, a)`. *Deliverable:* transformer-vs-B1 on predictive metrics; calibration curves; single-channel score agreement/sign-consistency vs current DR scores (sanity, not validation).

**E3 — Hybrid (CP3) as co-MVP / fallback.** Train/pretrain an encoder; export journey embeddings; append to the existing tabular features consumed by the current XGBoost scorer. *Deliverable:* the cheap, management-relevant answer — **does the transformer representation add anything over current features?** Lowest compliance disruption.

**E4 — Decision-layer integration.** Wire CP1/CP2 scores into the config-driven decision layer (caps, allowed-set, top-1/top-K, no-contact). *Deliverable:* end-to-end "scores → assignment" demonstrated; flexible-output use cases shown as config changes, no retrain.

---

## 4. Ablations

| Ablation | Question it answers | Priority |
|---|---|---|
| **A-ablate journey block** (static-only vs +journey) | Does journey history add signal over PRISM scores alone? | High |
| **A-ablate temporal features** (snapshot vs multi-window/RFM) | Does "stop collapsing the journey" help (F0 hypothesis)? | High |
| **A-encoder family** (FT-Transformer vs TFT) | Tabular vs sequence-aware, conditional on journey length | High (only if length distribution is ambiguous) |
| **A-embedding hybrid** (CP3 with vs without encoder embedding) | Marginal value of the transformer representation | High |
| **A-calibration** (raw vs Platt/isotonic) | Does calibration matter for the optimizer's probabilities? | Medium (revisits OQ8) |
| **A-time encoding** (gap embeddings vs none) | Does fine-grained timing help? | Medium (TFT/seq path only) |
| **A-combo generalization** (held-out unseen combos) | Does set-pooling generalize? (gates A5) | **Only if combos in scope** (OQ36) |
| **A-uplift-vs-prediction** (rank by score vs by score−score(∅)) | Do they diverge materially, and where? | Low/stretch (informs the contact-margin question) |

---

## 5. Minimum viable experiment set (if time collapses)

If the timeline compresses, the **non-negotiable** experiments are:

1. **E1 (CP1/B1 on the time-based split)** — the floor + the fair split. Without this there is no honest comparison.
2. **E2 (CP2 transformer)** *or* **E3 (CP3 hybrid)** — at least one transformer-bearing model. Prefer E3 if GPU/library/data-prep friction is high (it reuses the lineage and answers the marginal-value question cheaply).
3. **E4 (decision-layer integration)** at skeleton level — proves the flexible-output story end-to-end.

Everything else (TFT-vs-FT, combos, pretraining, causal pilot) is **droppable** without invalidating the spike's core deliverable.

---

## 6. How to use the prototype subset vs the full source data

This is a deliberate **two-track** approach so the model spike is never blocked by the Layer-4 ETL:

- **Track A — model spike on a representative cleaned sample.** Build CP1/CP2/CP3 and the eval harness on a **representative cleaned sample of Layer 4** (or, if Layer 4 isn't ready, the **prototype subset, Layers 1–2**), with the **time-based split**. This validates the *method and the comparison protocol* quickly. **Clearly label every metric with its layer.**
- **Track B — Layer-4 build in parallel.** Profile the full source (Layer 3) and construct the cleaned, transformer-ready dataset (sequence construction, timestamp validation, identity resolution, channel coverage, label window). This is the **gating dependency** and the binding constraint on what's achievable in 2–4 weeks.
- **Convergence:** as soon as a usable Layer-4 sample exists, **re-run the headline E1-vs-E2 comparison on it** — because the prototype slice cannot answer the scale/richness question, and the re-opened "match-vs-beat" verdict must be decided on full-data numbers.
- **Prototype subset is for protocol validation and fallback, not for the final feasibility verdict.** A transformer matching XGBoost on the prototype slice is **not** evidence about the full data.

**Stop rule:** if the Layer-4 build overruns the spike, deliver the protocol-validated result on the prototype subset, the floor (CP1), and an explicit **data-readiness dependency report** — do not force an unready full-data run or overclaim.

---

## 7. Decisions needing manager/team confirmation (experiment-level)

1. **(decision-needed, OQ43)** Baseline-comparison protocol: confirm CP2-vs-B1 on a time-based split as the headline, and the data layer used.
2. **(decision-needed, OQ40/OQ44)** Whether a representative Layer-4 sample can be ready in time, and the agreed fallback (prototype subset).
3. **(decision-needed, OQ41)** Whether the combo-generalization ablation (A5) is in scope for the spike.
4. **(decision-needed, OQ35)** Whether the CP6 causal pilot runs in Week 4.
