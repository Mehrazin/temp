# Data & Sequence Schema — Lumen AI Transformer MVP

**Date:** 2026-06-16
**Status:** Proposed schema + corrected data-scale interpretation for the transformer spike. Counts are **approximate** unless confirmed.
**Companion:** `transformer_mvp_design.md`. Data-scale authority: `02_change_log/2026-06-16_data_scale_correction.md`.

---

## 1. Required input data

The MVP scorer needs four logical blocks, all per customer, all available as of a scoring `effective_date`:

1. **Static context** — ~10 PRISM scores + credit-card indicator (+ any stable customer attributes). **(confirmed available)**
2. **Journey history** — timestamped `channel × interaction` touchpoint events back to ≈2022. The full source holds this; the cleaned form does not exist yet (Layer 4). **(source confirmed; cleaned form does not exist)**
3. **Candidate action** — the proposed channel (or, later, set/sequence) the model is asked to score. Enters as an **input**, never as a journey feature. The prospective `t_channel_*` actions in the current tables are the seed for this. **(confirmed concept; representation proposed)**
4. **Label** — conversion within a defined horizon from `effective_date` (binary for MVP; censored time-to-event is a deferred reframing). **(label exists; horizon design needed)**

Controllable channels (the action universe): **direct** — Email, Direct Mail, Leads, OBTM; **semi/inbound** — branch/phone/Radar_* prompts; **MTA-only digital** — likely no control **(uncertain)**. Exact mapping of TMIA names (Radar_*, Ebank_Telemarketing, EasyLine__IVR) to controllable actions is **not finalized** (OQ4).

---

## 2. Corrected data-scale interpretation (read this before quoting any number)

There are **four distinct data layers**. Conflating them is the single most consequential error to avoid. **Every number, metric, or feasibility claim must state which layer it refers to.**

| # | Layer | Size (approx) | What it is | Status |
|---|---|---|---|---|
| 1 | **Prototype experiment subset** | ≈2–3M customers (~2.8M-row cleaned table) | Filtered slice the XGBoost/DR baseline trained on | Exists; experimental only. Window ~April → (July **or** January; end date **uncertain**) |
| 2 | **Prototype test / eval set** | ≈500K customers (~521K rows; Sample1 ≈100K is a sub-sample) | Held-out eval subset of the prototype | Exists; an eval scope, **never** the modeling population |
| 3 | **Full available rich source** | ≈10–15M customers since ≈2022 | Timestamped touchpoint history | Exists; **not yet used for modeling**; availability ≠ readiness |
| 4 | **Cleaned, transformer-ready dataset** | TBD (≤ Layer 3, after cleaning) | Identity-resolved, sequence-formatted, timestamp-validated, label-windowed, time-split | **Does not exist yet — a deliverable to be built** |

Consequences for this design:

- **Do not** call Lumen "~500K customers" or "moderate volume" — that was the prototype *eval* slice. **(corrected)**
- **Data scale and data readiness are separate issues.** Layer 3 is large (favorable in principle for sequence/transformer modeling — within ~2× of TIMeSynC's ~30M, not two orders below), **but raw volume is not sequence-readiness.** **(corrected; re-opened, not settled)**
- **More customers ≠ longer/denser journeys.** Controllable channels (Email/DM/Leads) can still be sparse *per customer* across 10–15M customers. **Journey richness, not headcount, is the open question** (§5).
- **The Layer-4 build is the gating dependency** under the 2–4 week timeline. If it overruns, fall back to the prototype subset and report the dependency (see `risks_and_deferred_items.md`).

---

## 3. Sequence representation

Chosen *from profiling* (§6), with two interchangeable realizations behind the same action-as-input interface:

**Option FT (default if journeys are short/sparse — mostly 0–2 controllable touches):**
A per-customer **feature vector / feature-token set** summarizing the 2022+ history:
- Multi-window aggregates (e.g., 30/90/180/365-day and lifetime) of touch counts per channel.
- **RFM-style** features: recency (days since last touch per channel), frequency (touch counts), monetary/engagement proxies where available.
- **Inter-touch-gap** features (mean/min/last gap) to retain coarse temporal signal without a full sequence.
- Static context appended.
→ consumed by **FT-Transformer**. Robust to sparsity; closest to today's XGBoost vector.

**Option TFT (preferred if journeys are longer/denser):**
An explicit **event sequence**: ordered touchpoint events `(timestamp, channel, interaction_type, [attributes])`, plus:
- **Static covariates:** PRISM scores, CC indicator.
- **Time-varying observed:** the journey events.
- **Known-future input:** the **proposed action** for the next period — TFT's known-future slot is exactly the treatment-as-input mechanism.
→ consumed by **Temporal Fusion Transformer**. Requires per-feature static/observed/known typing (OQ38); start by treating PRISM as static.

**Time encoding:** if timestamps are fine-grained, use **learned time-gap embeddings** (BST-style) on the TFT/sequence path; coarse `efectv_dt`-only timestamps erode the temporal edge and push toward Option FT. **(decision gated on timestamp profiling, §6 item 4)**

**Sequence length policy (proposed):** cap at a max length (e.g., last N events or trailing K months) with padding/truncation; record the truncation rate. **(proposed; tune from the length distribution)**

---

## 4. Candidate action representation

- **Single channel:** a learned **per-channel embedding** `a = emb(channel)`. A single channel is a **size-1 set**.
- **No-contact (∅):** an **explicit** action token/embedding — scoreable, assignable, auditable, and the baseline for any later uplift difference. Never represented as an absent input. **(proposed; confirm explicit-vs-absent with business)**
- **Unordered set {Email, Leads, DM} (deferred to V2):** pool member embeddings **permutation-invariantly** (Deep Sets sum/mean or Set Transformer PMA) — the A5 primitive — so unseen combos remain valid without 2^N enumeration. Deterministic `action_id` = hash of sorted member ids.
- **Ordered sequence Email→Leads→DM (deferred to V2):** order-aware pooling; `action_id` = hash of the ordered list (different order = different id). Introduces a timing dimension out of MVP scope.

**Leakage guard (hard constraint).** The action enters the model **only** through this block. It must never also appear among journey features. This is the treatment-in-X collinearity that broke the baseline's DR inference (C1/C2). Enforce in the feature contract; assert with a test that fails the build if a `t_channel_*`/action column appears in the journey/static blocks.

---

## 5. Feature blocks (summary table)

| Block | Examples | Type | Notes |
|---|---|---|---|
| **Static context** | ~10 PRISM scores, CC indicator, stable attributes | static | Confirmed available; start all as static for TFT typing |
| **Journey — aggregated (FT path)** | per-channel multi-window counts, recency, frequency, inter-touch gaps | static-tabular | Computed over full 2022+ history, not the April–July snapshot |
| **Journey — sequential (TFT/seq path)** | ordered `(ts, channel, interaction)` events | time-varying observed | Needs identity resolution + timestamp validation |
| **Candidate action** | channel embedding; ∅ token; (later) set/sequence pooling | input ("known-future" in TFT) | **Leakage-guarded**; only entry point for treatment |
| **Label** | conversion within horizon H | target | Binary for MVP; censored TTE deferred |

**Do NOT include as features:** the action itself anywhere outside the action block; any post-`effective_date` information (future leakage); anything that encodes the realized outcome.

---

## 6. Data gaps and assumptions

**Assumptions in use (to be validated):**
- Per-customer timestamped `channel×interaction` events can be **stitched into one journey per customer** across 2022+ via reliable identity resolution. **(uncertain — critical)**
- ~10 static PRISM scores + CC indicator + binary conversion label + prospective `t_channel_*` actions are available and aligned to a scoring date. **(largely confirmed)**
- The conversion label has a definable horizon that is not right-censored to the point of distortion. **(uncertain)**

**Known gaps (sit *underneath* the 2–4 week timeline):**
- **(critical dependency)** Layer 4 does not exist; must be built from Layer 3.
- **(gap)** Direct-mail sourcing broken: historical MTA DM effectively empty; DM via TMIA only → DM≫Email imbalance, partly a collection artifact (OQ2/C9). Any DM channel comparison must be caveated until fixed.
- **(gap)** Current split is non-temporal random 60/20/20 → leaks future into past; a **time-based holdout is mandatory** before any predictive claim (OQ9/C6).
- **(uncertain)** Exact counts per layer; prototype window end date (July vs January); MTA vs TMIA vs hybrid source (OQ1).
- **(needed-from-data)** Per-channel overlap/positivity; label horizon/censoring; combo support.

---

## 7. Immediate data-profiling checklist (run on the FULL source while building Layer 4)

These facts gate both the architecture and the objective and **cannot be settled by reading** — measure them on Layer 3. Ordered by leverage:

1. **Population funnel** — counts at each stage: raw source → joinable/identity-resolved → cleanable → modelable sequences. Quantifies the gap between "10–15M available" and "N usable." Confirms the ≈2–3M / ≈500K / ≈10–15M figures and the prototype window end date.
2. **Journey-length distribution** (touches/customer over 2022+). The single biggest determinant of FT (tabular) vs TFT/sequence encoders. *The prototype slice cannot answer this.*
3. **Event richness / per-channel frequency** — distinct `channel×interaction` types populated; confirm Email/DM/Leads sparsity and the broken DM sourcing (OQ2).
4. **Timestamp quality / granularity** — event-time resolution; gates time-gap embeddings (BST) and whether a temporal edge exists at all.
5. **Customer-identity resolution** — can touchpoints be reliably stitched into one journey per customer across years? (New, critical for any sequence model.)
6. **Label & timing** — positive rate, **positives-per-channel**, conversion-timing/censoring, candidate label horizon.
7. **Overlap / positivity per channel** — gates any uplift estimate's defensibility; root of the current DR instability.
8. **Combo support** — distinct observed channel combinations + their conversion volume; whether enough exists to **hold out unseen combos** (gates the set head, OQ36).
9. **ETL feasibility & cost** — throughput to produce the sequence dataset; whether a **representative cleaned sample** is needed to start the model spike without waiting for all 10–15M.

**Output of profiling:** a one-page data-fit verdict that selects FT vs TFT, confirms (or defers) combos, sets the label horizon, and states the usable Layer-4 sample size for the spike.

---

## 8. Decisions needing manager/team confirmation (data-level)

1. **(decision-needed, OQ1)** MTA vs TMIA vs hybrid as the scorer's source.
2. **(decision-needed, OQ2)** Direct-mail sourcing fix — when/how, and whether DM is in-scope for the MVP comparison given the artifact.
3. **(decision-needed, OQ40/OQ44)** Minimum viable Layer-4 build (representative sample size, label horizon, channel coverage) acceptable for the spike.
4. **(decision-needed, OQ45/OQ46)** Confirm layer counts and the prototype window end date.
5. **(decision-needed)** No-contact representation: explicit action (recommended) — confirm with business.
