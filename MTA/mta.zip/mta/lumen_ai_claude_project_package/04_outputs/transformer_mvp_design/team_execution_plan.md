# Team Execution Plan — Lumen AI Transformer Spike

**Date:** 2026-06-16 · **Horizon:** first 10 working days of the 2–4 week spike (D004)
**Status:** Execution plan derived from the MVP design package. All gains remain model-estimated; hold claim discipline (D005).
**Two parallel tracks:** Track A (model spike, on a representative/prototype sample) must never block on Track B (Layer-4 data build).

---

## 1. Day-by-day plan (Days 1–10)

| Day | Focus | Owner(s) | Exit criteria |
|---|---|---|---|
| **1** | Kickoff; **freeze eval protocol** (time-based split, predictive metrics, data layer); confirm GPU/runtime + library compat | Integrator + modeling | Protocol doc signed off; env smoke-test passes |
| **2** | Lock MVP scope w/ manager (V1 single-channel?, source MTA/TMIA/hybrid, label horizon H); start data profiling | Integrator + data | Decisions logged; profiling jobs running |
| **3** | Profiling: journey length, richness, identity resolution, positives-per-channel, timestamp quality | Data | First-cut **data-fit verdict** (FT vs TFT) |
| **4** | Build CP1 strengthened temporal-feature XGBoost (multi-window/RFM/recency, action-as-feature) on time split | Modeling | CP1 trains; floor metrics on holdout |
| **5** | Decision-layer skeleton wired to *current* scores (top-1/top-K/caps/no-contact); begin Layer-4 representative sample | Downstream + data | Scores→assignment runs end-to-end |
| **6** | Stand up CP2 (FT-Transformer or TFT per verdict), action-as-input, **leakage guard + test** | Modeling | CP2 trains; leakage assertion passes |
| **7** | CP2 calibration; sanity vs current DR scores (agreement/sign); start CP3 hybrid as fallback | Modeling | Calibrated `score(c,a)`; CP3 scaffold |
| **8** | **Headline comparison** CP2 vs CP1 on time split (sample); calibration curves, NDCG/Recall@k | Evaluation | Comparison table v1 (labeled by data layer) |
| **9** | Priority ablations (journey block, temporal features, embedding-hybrid); wire CP2 into decision layer | Modeling + downstream | Ablation results; flexible outputs as config |
| **10** | Consolidate results; draft scoring-contract skeleton; **prep manager update** | Integrator | Update deck/notes ready (see §7) |

If Layer-4 sample isn't ready by Day 8, run the headline comparison on the prototype subset and **label it as such**; re-run on Layer-4 when available.

---

## 2. Workstream split

- **Data** — profiling (the §7 checklist of the design); Layer-4 representative-sample build; identity resolution; DM-sourcing clarity; time-based split construction. *Binding constraint; staff it first.*
- **Modeling** — CP1 baseline; CP2 transformer (FT/TFT); CP3 hybrid fallback; calibration; leakage guard.
- **Evaluation** — protocol freeze; metric harness (reuse UpliftBench); headline comparison + ablations; offline-limitation caveats.
- **Scoring / output contract** — long score table + minimal registry + assignment table (skeleton); `score_type`/`action_id`/provenance fields.
- **Downstream decision logic** — config-driven decision layer over single-channel scores (top-1/top-K/multiple/caps/allowed-set/no-contact); reuse the constrained ILP.
- **Communication** — decisions log; manager-update prep; claim-discipline review of every external statement.

---

## 3. Minimum viable experiment set

Non-negotiable if time collapses:
1. **E1 — CP1 on the time-based split** (the floor + the fair comparison unblocked).
2. **E2 (CP2) or E3 (CP3)** — at least one transformer-bearing model; prefer CP3 if GPU/library/data friction is high.
3. **E4 — decision-layer integration (skeleton)** — proves flexible single-channel outputs as config.

Droppable without invalidating the spike: TFT-vs-FT bake-off, combo/A5, pretraining (CP5), causal-head pilot (CP6).

---

## 4. Required decisions from manager/team

- **Scope (OQ41):** single-channel V1, or combos/sets in scope (gates building A5 now)?
- **Data (OQ1/OQ2/OQ40/OQ44):** MTA vs TMIA vs hybrid; DM-sourcing fix; minimum viable Layer-4 + accepted fallback if ETL overruns.
- **Comparison (OQ43):** confirm CP2-vs-CP1, predictive metric, time-based split, data layer.
- **Deliverable bar (OQ42):** what evidence counts as "good enough" to finalize.
- **Objective (OQ12/OQ20/OQ35):** optimizer objective (conversion vs lift at contact margin vs NPV); does CP6 earn a Week-4 pilot?
- **Environment:** GPU/runtime provisioning (gates CP2-first vs CP3-first).
- **Contract:** no-contact as explicit action (recommended); candidate-universe ownership; PRISM consolidation timing.

---

## 5. Your focus as technical integrator (Mehrazin)

- **Own the eval protocol freeze** (Day 1) — the single thing that keeps the comparison from being circular.
- **Enforce the leakage guard** (action only via the action block) and the **data-layer labeling discipline** across all results — these are where this project has historically gone wrong (C1/C2; ~500K-as-population).
- **Hold the architecture seam:** keep the external contract decoupled from the model so swaps stay cheap.
- **Own claim discipline (D005)** in everything that leaves the team.
- **Run the manager interface:** drive the §4 decisions to closure; integrate cross-workstream results into the Day-10 update.
- **Be the unblock path** for the Track-A / Track-B handoff (don't let modeling stall on the Layer-4 build).

---

## 6. What can be delegated

- **Data eng:** profiling jobs, Layer-4 sample build, identity resolution, split construction.
- **Modeling IC:** CP1 feature engineering + training; CP2/CP3 implementation on the chosen libraries; calibration.
- **Eval IC:** metric harness, ablation runs, comparison tables.
- **Platform/eng:** score-table + registry skeleton; decision-layer config plumbing over the existing optimizer.

You review/integrate; you personally own only the protocol, the leakage/labeling guards, the architecture seam, and the manager interface.

---

## 7. Ready for the next manager update

1. **Architecture recommendation** — CP2 (action-as-input transformer, prediction-first) + decision layer + contract; one-slide three-layer diagram.
2. **Baseline-vs-transformer comparison** — CP2 vs strengthened CP1 on a time-based split, **labeled by data layer**, with calibration/ranking metrics. (Prototype-sample result acceptable Day 10; Layer-4 to follow.)
3. **Flexible-output demo** — top-1/top-K/no-contact produced as config changes over single-channel scores.
4. **Data-readiness status** — Layer-4 build progress; gating risk + fallback stated plainly.
5. **Decisions needed** — the §4 list, with recommended defaults.
6. **Honest claim line** — *"On a forward-in-time holdout, the transformer [matches/beats] a strengthened XGBoost on predictive metrics; flexible outputs work via the decision layer. Offline and model-estimated; an incremental-uplift claim needs an experiment or defensible OPE."*
