# Training Objective & Labels — Lumen AI Transformer MVP

**Date:** 2026-06-16
**Status:** Proposed objective/label design for the spike. Holds claim discipline (D005). **Companion:** `transformer_mvp_design.md`, `evaluation_plan.md`.

---

## 1. Recommended training objective

**Default V1 objective = predictive conversion scoring (probability / ranking).** **(proposed; aligns with snapshot §13/§17.3)**

Train the action-conditioned scorer to predict **P(conversion within horizon H | journey, static context, candidate action)** with the candidate action as an **input**. Loss: **binary cross-entropy** (S-learner-style), optionally with a **ranking-aware auxiliary** (pairwise/listwise) if the downstream decision is rank-driven.

- Output semantics: `score_type = prob`, a **calibrated probability**, plus a `score_rank` within `(customer, effective_date, model_id, objective)`.
- This output is **decision-useful as-is** for top-1/top-K/multiple-channel/allowed-set/caps/no-contact via the decision layer (most confirmed business asks are decision-layer operations over single-channel scores).

**Why prediction-first (not uplift) for the MVP:**
- **Measurable** on a plain time-based holdout (AUC/PR-AUC/calibration, NDCG/Recall@k) — no positivity/confounding prerequisites.
- The data's overlap/positivity is currently **too poor** to defend a causal estimate (the regime that produced the rank-deficient DR `zstat=-inf`).
- For "which channel given we contact," **predicted-conversion ranking is decision-equivalent to uplift** when the ∅ baseline is similar across channels; they diverge only at the contact/no-contact margin.
- A calibrated probability is **easier to validate and defend to compliance** than a causal estimate, lowering D005 risk.

## 2. Labels

- **MVP label:** binary `converted` within a fixed **horizon H** from `effective_date` (e.g., H = 30/60/90 days — **set from profiling**, §6 item 6 of `data_and_sequence_schema.md`). **(proposed; H decision-needed)**
- **Label window discipline:** the label horizon must be **fully observable** for every training/eval row given the time-based split — i.e., only score customers whose H-window closed before the cutoff, to avoid right-truncation bias.
- **`effective_date` semantics:** disambiguate (a) scoring date, (b) decision period, (c) label horizon. Carry all three explicitly; the contract's `effective_date` is the scoring cycle. **(decision-needed; ties to OQ9/C6)**
- **Deferred reframing — censored time-to-event.** "Convert-or-not over a multi-year journey" is arguably right-censored time-to-event, not a static binary (C14/F2). For the MVP, fix H and treat as binary; flag survival framing (grf Causal Survival Forest) as a V1.5/V2 option if censoring proves material.

## 3. Negative examples

- **Primary negatives:** customers who, under the given candidate action and observed context, did **not** convert within H. This is the natural S-learner negative set (no synthetic sampling needed for the core conversion head).
- **Class imbalance:** conversion is rare (baseline ~1.31%). Handle via **class weighting / focal loss / scale_pos_weight-equivalent**, and **evaluate on PR-AUC + calibration**, not accuracy. Do **not** rebalance by discarding negatives in a way that distorts the base rate the optimizer consumes; if subsampling negatives for training speed, **re-calibrate** to the true prior before scoring. **(proposed)**
- **No-contact (∅) examples:** include observed no-contact-then-outcome rows so the ∅ action is learnable — this is what makes a later uplift difference `score(A) − score(∅)` meaningful and gives the contact/no-contact margin a real baseline.
- **(Deferred) contrastive/SSL negatives:** masked-channel / next-touch negatives are only relevant if CP5 pretraining is pursued.

## 4. Candidate generation (what actions get scored)

The model scores **only policy-supplied candidate actions per customer per cycle** — never the full power set. **(well-supported; bounds row volume at 10–15M scale)**

- **MVP:** the candidate set per customer = the **allowed single-channel universe** for that cycle (a handful of controllable channels) **+ the explicit ∅ action**. Tens of rows per customer at most.
- **Who owns the universe:** the **decision/policy layer** supplies the allowed channels, per-customer eligibility, and caps each cycle — a config change, not a model change. **(decision-needed: who owns the candidate-action universe each cycle)**
- **(Deferred) combos/sequences:** the policy layer would supply a bounded list of business-relevant sets/sequences; the A5 set head scores them compositionally. Only build if combos are confirmed V1 scope (OQ41).

## 5. Is uplift/lift included, deferred, or rejected?

**Verdict: DEFERRED for the MVP, kept as a reachable optional objective — NOT rejected.** **(confirmed framing, snapshot §13/§17.3)**

- **Reachable, not structural.** The same scorer yields `uplift(c, A) = score(c, A) − score(c, ∅)` (S-learner difference). We **carry `score_type` + nullable CI columns from day one** so uplift can be emitted later with **zero downstream re-engineering**.
- **Turn it on when** the decision genuinely includes *whether to contact at all* (no-contact / "sleeping dogs"), budget is scarce enough to demand ranking by *incremental* return, **or** an experiment / defensible OPE exists to validate it. Then evaluate with **Qini/AUUC + IPS/DR-OPE with CIs** (not before).
- **Do not turn it on by default because** prediction is more accurate and measurable; for "which channel given contact" it is decision-equivalent; and the current overlap/positivity cannot defend a causal estimate.
- **If forced to ship an uplift number in the spike:** the **S-learner difference is the only "good-enough" v1**; rigorous confounding-adjusted heads (Causal/G-Transformer) are a **Week-4 pilot question**, not V1. A grf **Causal Survival Forest** is the non-DL option for sparse censored data.
- **Claim discipline (D005, non-negotiable):** no causal CI/p-value until the baseline's rank-deficiency (C1/OQ5) is fixed; **no incremental-uplift claim without an experiment or a defensible OPE**; never present a ranking-AUC gap (e.g., the +11.18% vs PRISM) as "beating PRISM."

## 6. Decisions needing manager/team confirmation (objective-level)

1. **(decision-needed)** Label horizon H and `effective_date`/decision-period/label-horizon semantics.
2. **(decision-needed, OQ41)** Whether the V1 objective stays single-channel prediction or must include an uplift `score_type` at launch.
3. **(decision-needed, OQ35)** Whether a rigorous causal head (CP6) earns a Week-4 pilot — contingent on profiled overlap/positivity and the prospect of an experiment.
4. **(decision-needed)** Optimizer objective: predicted conversion (MVP) vs incremental lift at the contact margin vs cost-adjusted/NPV (OQ12/OQ20).
5. **(decision-needed)** Who owns the candidate-action universe each cycle.
