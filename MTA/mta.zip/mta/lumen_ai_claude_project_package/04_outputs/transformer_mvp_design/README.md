# Lumen AI — Transformer MVP Design Package

**Date:** 2026-06-16
**Author role:** Senior applied scientist / transformer model designer / ML system architect
**Primary input:** `04_outputs/transformer_design_input_snapshot.md`. Authority order: `01_current_state/decision_register.md` + 2026-06-16 change logs > snapshot > older research files.
**Status:** Proposed design for the manager-directed 2–4 week transformer spike (D004). Not implemented, not approved. Reported gains elsewhere are model-estimated/exploratory.

## The recommendation in one line

Build **one objective-agnostic action-conditioned scorer** — MVP = a **tabular/temporal transformer with the candidate channel as an input** (CP2), output a **calibrated conversion probability / ranking score (not uplift)** — feeding a **config-driven decision layer** and a **PRISM-style long score table + registry**, benchmarked against a **strengthened temporal-feature XGBoost (CP1)** on a **time-based holdout**, with a **hybrid encoder→XGBoost (CP3)** as the low-risk fallback. Uplift, combos, sequences, and rigorous causal heads are kept reachable but **deferred**.

## Documents

1. **`transformer_mvp_design.md`** — recommended architecture (three-layer: encoder → action-conditioned scorer → decision layer), why CP2, alternatives (CP1/CP3/CP4/CP5/CP6/A5), MVP vs stretch, stop rules.
2. **`data_and_sequence_schema.md`** — required input data, the **four-layer data-scale correction**, sequence + candidate-action representation, feature blocks, gaps/assumptions, the immediate data-profiling checklist.
3. **`training_objective_and_labels.md`** — prediction-first objective, labels/horizon, negatives, candidate generation, and the **uplift = deferred-but-reachable, not rejected** verdict.
4. **`experiment_plan.md`** — baselines (B0/B1/B2), core experiments (E1–E4), ablations, minimum viable set, and **prototype-subset vs full-source** two-track usage.
5. **`evaluation_plan.md`** — predictive metrics primary; Qini/AUUC/OPE conditional; **time-based split**; baseline comparison protocol; offline-evaluation limitations.
6. **`scoring_output_contract_and_downstream_design.md`** — two tables + registry; **mirror PRISM's long pattern in a parallel table**; model/action/objective registry; how downstream converts scores into top-1/top-K/sets/sequences.
7. **`two_to_four_week_execution_plan.md`** — phased plan, 2-week vs 4-week scope, dependencies, timeline risks.
8. **`risks_and_deferred_items.md`** — technical / productionization / governance-causal / data-readiness risks; V1.5 and V2 deferrals.

## Decisions that still need manager/team confirmation (consolidated)

- **Scope (OQ41):** single-channel scoring for V1, or include combos/sets (gates building the A5 set head in the spike)?
- **Data (OQ1, OQ2, OQ40, OQ44–46):** MTA vs TMIA vs hybrid; DM-sourcing fix; minimum viable Layer-4 build + fallback if it overruns; confirm layer counts + prototype window end date.
- **Comparison (OQ43):** headline metric (predictive), split (time-based), and data layer for CP2-vs-baseline.
- **Deliverable bar (OQ42):** what evidence counts as "good enough" to finalize the design.
- **Objective (OQ12/OQ20/OQ35):** optimizer objective (conversion vs lift at the contact margin vs NPV); whether a rigorous causal head (CP6) earns a Week-4 pilot.
- **Environment:** GPU/runtime on Databricks/Azure (gates CP2-first vs CP3-first).
- **Contract:** no-contact as an explicit action (recommended); candidate-universe ownership; packaging Option A vs A+wide-views; PRISM consolidation timing.
- **Validation:** when a champion/challenger experiment can be scheduled — the only path to a defensible incremental-uplift claim.

## Non-negotiable discipline carried through every document

- **Data scale ≠ data readiness.** Four layers; never cite ~500K as the population; the cleaned transformer-ready dataset (Layer 4) does not exist yet and is the gating dependency.
- **Match-vs-beat is re-opened**, decided on full-data numbers — not pre-judged, not on the prototype slice.
- **Claim discipline (D005):** no causal CI/p-value until the DR rank-deficiency is fixed; no incremental-uplift claim without an experiment or defensible OPE; never "beats PRISM."
- **Separate the external contract from the internal model**, so the model family and objective can change without downstream re-engineering.
