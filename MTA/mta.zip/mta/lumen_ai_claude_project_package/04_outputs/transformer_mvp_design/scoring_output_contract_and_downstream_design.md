# Scoring Output Contract & Downstream Design — Lumen AI

**Date:** 2026-06-16
**Status:** Proposed external contract + downstream design. **Architecture-neutral by design** — specifies the interface so the internal model (any of CP1–CP6) can change without downstream re-engineering. **Companion:** `03_research_memory/production_score_contract_options.md` (the source analysis this mirrors).

**Core principle:** **bind downstream consumers to a data contract, not a model.** Decide the contract *before* locking the model.

---

## 1. Recommended design: two tables + a registry

### Table 1 — Score fact table (scorer output; append-only; generalizes the PRISM long pattern)

```
customer_id
effective_date           -- scoring cycle, historized like PRISM
model_id                 -- which scorer/version produced this row  (FK -> model registry)
candidate_action_id      -- channel | set | sequence that was scored (FK -> action registry)
objective_id             -- semantics of the score              (FK -> objective registry)
score                    -- probability | ranking score | expected value | uplift
score_rank               -- optional rank within (customer, effective_date, model_id, objective)
score_lower, score_upper -- optional/nullable; only for interval-bearing scores (uplift CIs)
```

### Table 2 — Assignment / decision table (config-driven policy-layer output)

```
customer_id
effective_date
policy_run_id            -- which config/policy produced this decision (FK -> policy registry)
assigned_action_id       -- channel / set / sequence chosen          (FK -> action registry)
position                 -- NULL for single/unordered; 1..k for top-K / sequences
selected                 -- boolean / reason code (capacity, eligibility, no_contact)
```

**The split is the whole point.** Table 1 is *what the model believes*; Table 2 is *what the business decided this cycle*. The same scores serve top-1, top-K, capacity-constrained, allowed-set, and no-contact decisions **without rescoring or schema change** — the flexible-output requirement (D011) becomes reads/joins over Table 1 producing Table 2.

---

## 2. Reuse / mirror the PRISM-style long table?

**Yes — reuse the PRISM *pattern* in a *parallel* Lumen table; do NOT write into PRISM's governed table.** **(recommended)**

- **Keep from PRISM:** the long shape, `effective_date` historization, `model_id`, `score`, `score_rank`, **row-extensibility** (add channels/objectives/model versions as **rows, not columns**). Operational familiarity is a real, bankable benefit — consumers and scoring jobs already understand this shape, lowering onboarding/governance cost.
- **Add for Lumen:** `candidate_action_id`, `objective_id` (+ optional CI columns). PRISM scores a *customer against a model*; Lumen scores a *customer against a candidate action under an objective* — those two extra dimension keys are the entire difference.
- **Why parallel, not shared:** Lumen actions are **structured** (sets/sequences) and Lumen scores carry **heterogeneous semantics** (prob vs uplift vs rank). Folding Lumen into PRISM as extra `model_id`s would couple Lumen's faster cadence to PRISM's governance. Defer any consolidation until Lumen's schema is stable.
- **Long beats wide decisively** for a system whose defining requirement is *changing outputs over time*; at 10–15M customers × channels × objectives × monthly cycles a wide table is untenable. Mitigate long-table costs with `effective_date` **partitioning**, a `(customer_id, effective_date)` index, and a **retention policy**.

**Packaging options:** **A (recommended)** = long table + registry + separate assignment table; **B** = A plus materialized **wide views** for consumers who want a pivoted shape; **C** = bespoke wide table — only for a frozen single use case, **not recommended**.

---

## 3. Registry design (required, not optional)

Once `candidate_action_id` and `objective_id` exist, a score is uninterpretable/unauditable without a registry. Three small dimension tables:

- **Model registry:** `model_id → name, version, score_type (prob | rank_score | uplift | ev), objective_id, training_window, approval/validation status, champion|challenger, dataset_provenance/training_dataset_id`.
  - Enables **champion/challenger** to coexist as different `model_id`s on the same `effective_date` (as PRISM already does).
  - Gives compliance a **per-version status field** — essential because a new architecture needs its own validation path.
  - **`dataset_provenance` distinguishes the four data layers** (prototype train #1 / eval subset #2 / full source #3 / cleaned transformer-ready #4) so a score row's lineage is unambiguous. Put this on the model-registry entry, not on every score row.
- **Action registry + members bridge:** `action_id → action_type (single | set | sequence | none)` + `action_members(action_id, channel_id, position)` (`position` NULL for single/sets, `1..k` for sequences). This is what lets single channels, unordered sets, ordered sequences, **and the explicit no-contact action** all be referenced by one `candidate_action_id` **without schema change**. Structural complexity lives here, not in the score table.
- **Objective registry:** `objective_id → definition, direction (max/min), score_type, label_horizon`.

**Build a minimal version in V1** even if it holds one model, a few channels, and one objective. The registry is the linchpin of model-replaceability: the *meaning* of a score lives in metadata, so a new model is just new rows + a registry entry.

---

## 4. How every model family produces the same contract

| Model family (CP path) | Same external structure? | Internal change | Downstream sees | Stage |
|---|---|---|---|---|
| Plain conversion prediction | Yes (`action=∅/baseline`) | single model | a ∅ baseline score | V1 (baseline) |
| **Customer × candidate-channel (CP2)** | **Yes — canonical producer** (`action=single`) | action as input | one row per (customer, channel) | **V1** |
| Sequential ranking (CP4) | Yes (`score=rank_score`) | ranking loss | same rows; `score_type=rank_score` | V1/V1.5 |
| Hybrid encoder → XGBoost (CP3) | Yes | encoder internal only | identical — **encoder swap invisible** | V1.5 |
| Multi-task (CP5) | Yes (rows per objective) | shared encoder, multi heads | more objective rows | V1.5/V2 |
| Uplift / CATE (CP6) | Yes (`score_type=uplift` + CIs) | needs ∅ baseline + CIs | same rows, uplift semantics | V1.5/V2 (optional) |
| Unordered combo scorer | Yes (`action_type=set`) | set encoder/input | same rows → set | V2 |
| Ordered sequence scorer | Yes (`action_type=sequence`) | sequence-aware scoring | same rows → ordered members | V2 |

**Headline:** every family emits into the **same** two-table contract; differences are internal or registry metadata. **No family forces a schema change** if the contract is built generalized from V1. Swapping XGBoost → transformer → hybrid = new `model_id` rows.

---

## 5. How downstream logic converts scores into business outputs

The decision/policy layer reads Table 1, applies this-cycle config, and writes Table 2. **All of the following are reads/joins over single-channel scores — no new model, no new schema:**

- **Top-1 next best channel:** per customer, pick the max-`score` row among allowed actions (excluding ∅ unless contact-margin logic applies).
- **Top-K channels:** take the K highest-ranked allowed actions; write `position=1..K`.
- **Multiple channels per customer:** select all allowed actions above a score/threshold or up to a per-customer budget; multiple rows in Table 2.
- **Capacity constraints / caps:** feed scores into the existing **constrained ILP optimizer** (one-channel-per-customer or budgeted multi-channel under caps, e.g., leads cap ~20K–30K). The optimizer is Layer 3, unchanged by the model.
- **Allowed-channel filters / eligibility / opt-out:** the policy supplies the per-customer eligible action set; ineligible actions simply aren't scored or are filtered pre-assignment.
- **No-contact action:** the explicit ∅ `action_id` competes like any other; assigning ∅ = "do not contact," with a reason code. Supports a future contact-vs-no-contact margin.
- **Different objectives:** switch `objective_id` (conversion prob → ranking score → EV → cost-adjusted/NPV → uplift). The policy must consult `score_type` and **not compare across `model_id`/`objective` naively** (scores aren't on one scale).

## 6. What is supported now vs deferred

- **Supported in V1 (single-channel scoring + full policy layer):** top-1, top-K, multiple-per-customer, caps, allowed-set filters, eligibility/opt-out, no-contact, alternative objectives over single-channel scores. **This already unlocks most confirmed business asks.**
- **V1.5 (richer scores, same shape):** multiple objectives, multi-task heads, transformer-embedding hybrid (internal), optional uplift `score_type` + CIs. Registry growth + new rows only.
- **V2 (structured actions):** unordered **sets** and ordered **sequences** (`action_type` + members bridge), policy-layer candidate-set generation, and a flagged future **timing/"when"** dimension. Core score-table columns unchanged. Only genuine sets/sequences need the model to score structured actions.

**Cardinality discipline:** never enumerate 2^N sets or all permutations. The **policy layer supplies the bounded candidate-action list each cycle**; the scorer only scores those. Deterministic `action_id` via canonical hashing (sorted for sets, ordered for sequences).

## 7. Contract risks & open questions

1. **Score comparability** — probabilities, ranking scores, and uplifts are not on one scale; policy must consult `score_type`.
2. **Calibration** — if scores feed the optimizer, probabilities must be calibrated; ranking scores are not probabilities (OQ8).
3. **`effective_date` semantics** — disambiguate scoring date vs decision period vs label horizon (ties to OQ9/C6).
4. **No-contact representation** — explicit action (recommended) vs missing row; **confirm with business**.
5. **Candidate-universe ownership** — **who owns the candidate-action universe each cycle** (decision-needed).
6. **Contract evolution** — additive-only (new rows, nullable columns, registry entries); deprecate via registry status, never drop/rename.
7. **Governance coupling** — each `model_id`/version needs an approval status; a swap is technically free, **not compliance-free**.
8. **Scale/serving** — at 10–15M × channels × objectives × monthly cycles, plan `effective_date` partitioning, retention, candidate-bounding, and serving throughput.

## 8. Decisions needing manager/team confirmation (contract-level)

1. **(decision-needed)** Packaging Option A vs A+B (wide views) for downstream consumers.
2. **(decision-needed)** No-contact as explicit action (recommended) — confirm.
3. **(decision-needed)** Candidate-action universe ownership and cadence.
4. **(decision-needed)** Whether/when to consolidate into PRISM's governed asset (recommend: defer until schema stable).
5. **(decision-needed, OQ41)** V1 action scope (single only vs include sets) — gates the members-bridge usage.
