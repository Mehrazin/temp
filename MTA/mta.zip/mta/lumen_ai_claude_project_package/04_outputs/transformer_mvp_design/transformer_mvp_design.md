# Transformer MVP Design — Lumen AI

**Date:** 2026-06-16
**Author role:** Senior applied scientist / transformer model designer / ML system architect
**Status:** Proposed design for the manager-directed 2–4 week transformer spike (D004). This is a **design proposal**, not an implemented or approved model. It chooses among the candidate paths in the consolidated snapshot using evidence, feasibility, data constraints, and the timeline.
**Primary input:** `04_outputs/transformer_design_input_snapshot.md`. Authority order: `01_current_state/decision_register.md` + the two 2026-06-16 change logs > snapshot > older research files.

**Marking convention (inherited from the snapshot):** **(confirmed)** = manager/team decided or implemented; **(proposed)** = design intent not yet validated; **(uncertain)** = not established / needs data; **(decision-needed)** = requires manager/team confirmation before build.

---

## 1. Design in one paragraph

Build **one objective-agnostic core scorer** that takes the customer's journey + static context **and a proposed action as an input**, and emits a numeric `score(customer, action)`. For the MVP, that core is a **tabular/temporal transformer with the candidate channel as an input feature** (CP2), defaulting its output to a **calibrated conversion probability / ranking score** — *not* uplift. A **thin, config-driven decision layer** sits on top and converts scores into business outputs (top-1, top-K, multiple channels, caps, allowed-set filters, no-contact) without retraining. The model writes into a **PRISM-style long score table + registry** (the external contract), so the model family and objective can change later as new rows, not schema migrations. A **strengthened temporal-feature XGBoost (CP1)** is the mandatory baseline/floor and the fallback; a **hybrid transformer-encoder → XGBoost (CP3)** is the low-risk co-MVP if GPU/library/data friction threatens the timeline. Uplift, ordered sequences, combos, and rigorous causal heads are kept *reachable* by the architecture but are **deferred** out of the MVP.

---

## 2. The three-layer decomposition (the spine of the design)

A "Lumen transformer" is **three stacked layers**, and keeping them separate is the single most important architectural decision (well-supported; convergent across both prior research chats and the allocation literature):

```
   ┌──────────────────────────────────────────────────────────────┐
   │ LAYER 1 — Sequence / representation encoder                    │
   │  customer journey (2022+ touchpoints) + static context (PRISM) │
   │  → journey representation h_c          [mature, low-risk]       │
   └──────────────────────────────────────────────────────────────┘
                       │  h_c
                       ▼
   ┌──────────────────────────────────────────────────────────────┐
   │ LAYER 2 — Action-conditioned scorer head                       │
   │  h_c  ⊕  action representation a        (action is an INPUT)    │
   │  → score(c, a)  = P(convert | journey, context, a)             │
   │      [this is the part that does the real work for Lumen]      │
   └──────────────────────────────────────────────────────────────┘
                       │  score(c, a) for each candidate a
                       ▼
   ┌──────────────────────────────────────────────────────────────┐
   │ LAYER 3 — Decision / optimization layer  (config-driven)       │
   │  caps, eligibility, allowed-set, no-contact, top-1/K, objective│
   │  → assignment            [reuse existing constrained optimizer]│
   └──────────────────────────────────────────────────────────────┘
```

Why this matters:

- **Layer 2 is objective-neutral.** `score(c, a)` can be read as a probability, a ranking score, an expected value, or — by differencing against the no-contact action, `score(c, a) − score(c, ∅)` — an uplift. The *framing is a choice, not a property of the architecture* (well-supported). This is what lets us default to prediction now and add uplift later without re-architecting.
- **Layer 3 is where the flexible-output requirement (D011) actually lives.** Top-1, top-K, multiple-channels-per-customer, caps, allowed-channel filters and no-contact are **decision-layer operations over single-channel scores** — no new model, no new schema (well-supported, contract §6). This is why **single-channel V1 scoring already unlocks most confirmed business asks.**
- **Layer 1 is the lowest-risk, most reusable part** and the part most affected by the (still-unknown) journey-length/richness facts. We choose its concrete form (tabular vs temporal vs sequence-rec) *from data*, not a priori.

This decomposition is also what makes the model **swappable**: every layer-1/layer-2 family (CP1–CP6) emits the same `score(c, a)` into the same contract, so changing the encoder is a `model_id` change downstream sees as new rows.

---

## 3. Recommended MVP architecture (CP2) — concrete spec

**Core model = action-conditioned tabular/temporal transformer scorer.**

**Inputs**

- **Static context block:** ~10 PRISM scores + credit-card indicator + any stable customer attributes. Treated as static covariates. **(confirmed feature availability)**
- **Journey block:** features summarizing the 2022+ touchpoint history. Two interchangeable realizations chosen by profiling (§6 of `data_and_sequence_schema.md`):
  - **CP2-FT (FT-Transformer):** multi-window / RFM / recency / inter-touch-gap features over the history → one feature-token sequence. Robust when journeys are short/sparse (mostly 0–2 controllable touches). Closest drop-in to today's XGBoost vector.
  - **CP2-TFT (Temporal Fusion Transformer):** the journey as a time-varying-observed sequence, PRISM as static covariates, and **the proposed action as a "known-future input"** — TFT's known-future slot *is* the treatment-as-input requirement with no custom architecture. Preferred if profiling shows longer/denser journeys.
- **Action block (the key design element):** the candidate action enters as an **input**, never as a fixed output head. A single channel is a size-1 set; the representation is a learned per-channel embedding. For combos (deferred), pool member embeddings permutation-invariantly (Deep Sets / Set Transformer) — the A5 primitive — so unseen combos remain valid without 2^N enumeration. **No-contact (∅) is an explicit action token**, not an absent input.

**Head & output**

- A small MLP head over `[h_c ⊕ a]` → **conversion logit**. Default training/serving output = **calibrated conversion probability** with an associated **ranking score**. `score_type = prob`.
- **Uplift is derivable but off by default:** `uplift(c, a) = score(c, a) − score(c, ∅)` from the same S-learner-style scorer. We carry `score_type` + nullable CI columns in the contract so uplift can be turned on later with **zero downstream re-engineering**, but we do **not** make it a structural assumption of the MVP (rationale §5 + `training_objective_and_labels.md`).

**Leakage guard (hard constraint).** The treatment/action enters **only** through the action block — never also as a journey feature. This is the exact collinearity (treatment-in-X) that produced the baseline's rank-deficient DR final stage (`zstat=-inf`, C1/C2). Enforce it in the feature contract and assert it in tests.

**Libraries (no from-scratch transformer).** pytorch-tabular (`FTTransformer`) for CP2-FT; pytorch-forecasting (`TemporalFusionTransformer` + `TimeSeriesDataSet`) for CP2-TFT. Spend the spike on the **head + evaluation + leakage discipline**, not on reimplementing attention. **(well-supported)** GPU/library compatibility against TD's Databricks/Azure is **(uncertain)** and is an early-week risk to retire.

---

## 4. Why this approach (evidence and reasoning)

1. **It honors the confirmed direction (D004) without betting the spike on the riskiest variant.** CP2 is a genuine transformer, but a tabular/temporal one with mature libraries — buildable to spike grade in the window, unlike a from-scratch sequence-rec or causal transformer.
2. **It directly realizes D010/D011 in one architecture.** Action-as-input + thin config layer = the reusable scorer + config-driven optimization layer the business confirmed it wants. Most flexible-output use cases fall out of the decision layer over single-channel scores.
3. **Prediction-first is measurable and low-risk *now*.** A predictive/ranking score is checkable on a plain time-based holdout, has **no positivity/confounding prerequisites** — the very things currently broken in the data (overlap violations, rank-deficient DR) — and carries lower D005/compliance risk than a causal claim. Uplift stays one line away.
4. **The data-scale correction strengthens, not weakens, the case.** The full source (~10–15M customers since ~2022, approx) is plausibly within ~2× of fintech transformer precedents (TIMeSynC ~30M), not two orders below as the prototype slice implied. The "transformer will only match GBDT" expectation is **re-opened**, so CP2 has a real chance to *win*, not just match — pending profiling. **(under re-evaluation; do not assert either way)**
5. **GBDT remains a genuinely hard bar, so we keep it as the floor.** UpliftBench evidence (an S-learner over GBDT beating Causal Forest at ~14M rows) means CP1 is not a strawman baseline; "transformer matches but doesn't beat a strengthened GBDT" is a legitimate, valuable spike outcome — to be judged on the **full-data** comparison, not the prototype slice.
6. **It separates the external contract from the internal model.** Binding downstream consumers to a data contract (long PRISM-style table + registry) rather than to a model is what makes the architecture choice low-stakes: we can change our mind later as new `model_id` rows.

---

## 5. Objective stance for the MVP (prediction-first; uplift optional, not rejected)

- **Default V1 objective = predictive/ranking score (conversion probability).** **(proposed; aligns with snapshot §13/§17.3)**
- **Uplift/CATE is OPTIONAL, not the default and not rejected.** It is one legitimate objective computable from the same scorer, worth turning on at the **contact/no-contact margin**, where budget is scarce enough to demand ranking by *incremental* return, or once an experiment/defensible OPE exists. It is **deferred** for the MVP because (a) prediction is more accurate and *measurable*, (b) for "which channel given we contact," predicted-conversion ranking is decision-equivalent to uplift when the ∅ baseline is similar across channels, and (c) the data's overlap/positivity is currently too poor to defend a causal estimate.
- **Do not conflate** "we must not *claim* causal uplift without an experiment" (true, D005) with "the model must *produce* causal uplift" (false). The architecture keeps uplift reachable; the MVP does not depend on it.

Full treatment in `training_objective_and_labels.md`.

---

## 6. Alternatives considered

| Path | What it is | Verdict for MVP | Why |
|---|---|---|---|
| **CP1 — temporal-feature XGBoost, action-as-feature** | Stop collapsing the snapshot; multi-window/RFM/recency features over 2022+; XGBoost with action as a feature | **Mandatory baseline / floor / fallback — not the MVP itself** | Highest value-per-effort, unblocks the time-based holdout, reuses the compliance lineage; UpliftBench shows GBDT is the hard bar. Does not satisfy the transformer mandate, so it is the floor, not the deliverable. |
| **CP2 — tabular/temporal transformer, action-as-input** | FT-Transformer or TFT scorer | **PRIMARY MVP** | Honors D004; realizes D010/D011; measurable on a plain holdout; uplift optional; mature libraries. |
| **CP3 — hybrid: transformer encoder → existing XGBoost/DR** | Train/pretrain an encoder, export journey embeddings, append to the existing tabular features consumed by the current scorer | **Co-MVP / low-risk fallback** | Lowest compliance disruption (reuses approval lineage); directly measures the encoder's *marginal* value via a clean with/without-embedding ablation. Use if CP2 friction threatens the timeline. |
| **CP4 — sequence-rec encoder (SASRec/BST) + action head** | Production rec-stack encoder over event sequences | **Deferred / conditional** | Case is strong **only if** profiling confirms long/dense journeys. Sparse controllable channels (Email/DM/Leads) degrade it. More infra than CP2 for uncertain gain. Revisit after §12 profiling. |
| **CP5 — self-supervised pretraining / multi-task scorer** | Pretrain encoder on unlabeled journeys (next-touch/masked-channel), then fine-tune | **Stretch (more attractive at full scale)** | Large *unlabeled* journey volume is exactly its fuel; helps the sparse-positive-label regime. Scope-creep risk; time-box. Candidate "MVP+" only if a usable Layer-4 sequence dataset materializes early. |
| **CP6 — rigorous causal/uplift head** (Causal/G-Transformer; or grf Causal Survival Forest for censored data) | Confounding-adjusted counterfactual head | **Deferred; Week-4 pilot question at most** | Research-grade code, healthcare→marketing transfer unproven, needs overlap/positivity the data currently lacks, separate compliance path. S-learner difference is the only "good-enough" v1 uplift if forced. |
| **A5 — Deep-Sets/Set-Transformer treatment encoder** | ~50-line permutation-invariant combo enabler | **Build only if combos are near-term V1 scope (decision-needed, OQ41); else defer to V2** | Makes CP2/CP4/CP6 score arbitrary combos compositionally. |
| **Ordered sequences / RL / "when-to-contact" (TPP)** | Sequential decisioning, timing | **V2/V3 — assess realism, do not build** | Adds a timing dimension out of current scope; high engineering + governance. Keep the action representation/contract from foreclosing them. |

---

## 7. MVP vs stretch (scope line)

**MVP (must produce in the spike):**

- The three-layer design instantiated as **CP2 single-channel scorer** (FT-Transformer or TFT, chosen by profiling), action-as-input, **predictive output**, leakage-guarded.
- **CP1 strengthened-XGBoost baseline** on the *same* time-based split and data source.
- **CP3 hybrid** stood up at least as a fallback path / marginal-value probe (build if CP2 slips).
- The **decision layer skeleton** (caps, allowed-set, top-1/top-K, no-contact) wired against scores — first against current XGBoost scores, then the new model.
- The **external scoring contract** (long score table + minimal registry + assignment table) in at least skeletal form, so the model is a pluggable producer from day one.
- A **fair transformer-vs-baseline comparison** on predictive metrics over a time-based holdout (`evaluation_plan.md`), run on a **representative cleaned sample** of Layer 4 if the full build is incomplete.

**Stretch (only if MVP is on track):**

- **A5 set/combo head** + held-out-combo generalization test (if combos are confirmed in-scope, OQ41).
- **CP5 pretraining** on unlabeled journeys.
- **CP6 Week-4 pilot:** does a confounding-adjusted counterfactual differ materially from the S-learner difference? Paired with a grf causal-survival-forest / CausalForestDML comparator.
- **Uplift `score_type`** turned on at the contact/no-contact margin, reported with Qini/AUUC only if an uplift claim is on the table.

**Explicitly out of the spike (V2+):** ordered multi-channel sequences, RL/bandit serving, TPP "when-to-contact", frontier generative recommenders.

---

## 8. Stop rules / good-enough guardrails

- If **CP1/CP3 + the decision layer** already deliver the flexible single-channel outputs and CP2 only **matches** them on the time-based split, that is a **shippable v1 story** — do not block on a causal head or a sequence encoder. The transformer is then justified on flexibility/representation and the re-opened scale case, with the honest caveat that the accuracy win is not yet demonstrated.
- If profiling shows mostly **0–2 controllable touches/customer**, standardize on **CP2-FT (tabular)** and drop CP4/sequence encoders for the spike.
- If the **Layer-4 build overruns**, run the spike on the **prototype subset** (Layers 1–2) and **report the data dependency** rather than forcing an unready full-data run.

---

## 9. Decisions needing manager/team confirmation (architecture-level)

1. **(decision-needed, OQ41)** V1 use-case scope: is single-channel scoring + decision layer sufficient for v1, or must combos/sets be in scope (which triggers building A5 now)?
2. **(decision-needed, OQ43)** Baseline-comparison protocol: confirm metric (predictive primary), split (time-based), and data layer (representative Layer-4 sample vs prototype subset) so the comparison is fair and not circular.
3. **(decision-needed, OQ40/OQ44)** Minimum viable Layer-4 build for the spike, and the accepted fallback if it overruns.
4. **(decision-needed, OQ42)** "Finalize the design" evidence bar: what counts as good-enough to commit the architecture at end-of-spike.
5. **(decision-needed, OQ1)** Data source: MTA vs TMIA vs hybrid for the scorer.
6. **(decision-needed)** GPU/runtime availability on Databricks/Azure for transformer training (gates CP2 vs CP3-first).

---

*Companion documents: `data_and_sequence_schema.md`, `training_objective_and_labels.md`, `experiment_plan.md`, `evaluation_plan.md`, `scoring_output_contract_and_downstream_design.md`, `two_to_four_week_execution_plan.md`, `risks_and_deferred_items.md`. External contract detail mirrors `03_research_memory/production_score_contract_options.md`.*
