# Evaluation Plan — Lumen AI Transformer MVP

**Date:** 2026-06-16
**Status:** Proposed evaluation design for the spike. **Fix this before modeling** so the comparison is fair and not circular (OQ43). Holds claim discipline (D005). **Companion:** `experiment_plan.md`, `training_objective_and_labels.md`.

---

## 1. Primary metrics (predictive — the MVP default)

Because the MVP objective is a **predictive/ranking score**, predictive metrics are primary:

- **Discrimination:** **AUC** and, given the ~1.31% base rate, **PR-AUC** (more informative under heavy imbalance).
- **Calibration:** **Brier score** + **reliability curves**. The optimizer consumes probabilities, so calibration is a first-class metric, not an afterthought (revisits the disabled-calibration question, OQ8). Report calibration *per channel* where volume allows.
- **Ranking / recommendation:** **NDCG@k**, **Recall@k**, **MAP@k** over the per-customer candidate-channel ranking — this is the metric that matches "which channel(s) to pick" (§3).

## 2. Uplift / off-policy metrics (CONDITIONAL — only if an uplift claim is on the table)

**Not default spike metrics.** Use **only** if an uplift/policy-value claim is actually being made:

- **Qini curve / AUUC** — incremental targeting efficiency (the right lens for a next-best-action policy *if* uplift is the objective).
- **IPS / Doubly-Robust off-policy evaluation (OPE) with confidence intervals** — estimate the Lumen *policy's* value vs the logged/BAU policy from logged data. This is the **principled replacement** for the "lucky match" comparison.
- **Gating preconditions (all must hold first):** the baseline's rank-deficiency (C1/OQ5) fixed; profiled overlap/positivity adequate per channel; calibrated propensities. Without these, an uplift number is not defensible (D005).

## 3. Ranking / recommendation evaluation (detail)

- Build, per `(customer, effective_date)`, the model's ranking over the **candidate channel set + ∅**.
- Report **NDCG@k / Recall@k / MAP@k** against observed conversions on the **time-based test window**.
- Compare CP2 ranking against B1 (strengthened XGBoost) and B2 (BAU/rules) rankings on the identical candidate sets.
- **Caveat:** ranking quality ≠ incremental business value. A better Recall@k (TIMeSynC-style) is **not** an uplift claim (D005).

## 4. Validation split (mandatory design)

- **Adopt a time-based / windowed holdout:** train on ≤ month *t*, test on > *t* (e.g., train *t−k…t*, test *t+1…t+m*). **Replace the current random 60/20/20**, which leaks future-into-past and likely explains the unrealistic test-set channel mix (OQ9/C6).
- **Label observability:** only include rows whose **label horizon H fully closes before the cutoff** (no right-truncation).
- **Same split for every model** (B0/B1/B2/CP2/CP3) so the comparison is apples-to-apples.
- **Data layer discipline:** run the **headline comparison on a representative Layer-4 sample** where possible; if only the prototype subset is available, **label results as prototype-slice and treat the scale/richness verdict as unresolved.**
- **No-leakage audit:** assert the action enters only via the action block; assert no post-`effective_date` features; spot-check feature provenance.

## 5. Comparison against XGBoost / DR (the baseline protocol)

- **Headline:** **CP2 transformer vs B1 strengthened XGBoost**, same time split, same data source, same primary metric (predictive). **(decision-needed, OQ43)**
- **Marginal-value probe (CP3):** with-vs-without transformer embedding appended to the existing XGBoost features — isolates the encoder's contribution and reuses the approval lineage.
- **Sanity (not validation):** single-channel score agreement and **sign-consistency** between CP2 and the current DR scores. Disagreement is informative, not disqualifying.
- **Possible/legitimate outcomes, all valuable:**
  1. Transformer **beats** B1 on the full-data sample → strong case to proceed (judge on Layer-4, not prototype).
  2. Transformer **matches** B1 → justified on flexibility/representation + the re-opened scale case; the honest result, not a failure.
  3. Transformer **underdelivers** / Layer-4 not ready → ship CP1/CP3, report the data dependency. Per the stop rules.

## 6. Limitations of offline evaluation (state these in every manager-facing summary)

- **Offline ≠ incremental business impact.** Any offline metric (AUC, NDCG, even Qini) is **model-estimated/exploratory**, not experiment-validated. No offline result licenses a "+X% conversions" forecast (D005).
- **Observational confounding & overlap.** The data is observational; unconfoundedness and positivity are unverified. This caps any causal/uplift interpretation.
- **The "lucky match" pattern is biased.** Selection-on-agreement (keeping only rows where observed action = recommendation) conditions on the policy outcome and overstates performance; it is **not** a substitute for OPE.
- **Direct-mail artifact.** DM sourcing is broken (DM≫Email imbalance); any DM channel comparison is partly a collection artifact until fixed (OQ2/C9). Caveat heavily.
- **Prototype-slice non-representativeness.** Results on the prototype subset do **not** answer the full-data scale/richness question.
- **New-architecture compliance.** A favorable offline result does not shorten the separate model-validation/compliance path a transformer requires (cannot inherit XGBoost's approval).
- **The honest claim ceiling for the spike:** *"On a forward-in-time holdout, the transformer [beats / matches] a strengthened XGBoost on predictive ranking/calibration; flexible outputs work via the decision layer. This is offline and model-estimated; an incremental-uplift claim needs an experiment or defensible OPE."*

## 7. Decisions needing manager/team confirmation (evaluation-level)

1. **(decision-needed, OQ43)** Headline metric, split, and data layer for the CP2-vs-baseline comparison.
2. **(decision-needed, OQ42)** The "good-enough to finalize" evidence bar at end-of-spike.
3. **(decision-needed)** Whether any uplift/Qini/OPE evaluation is in scope (and thus whether the C1/overlap preconditions must be cleared in the window).
4. **(decision-needed)** Whether DM is included in the channel comparison given the sourcing artifact.
