# CP4 — Sequence-rec encoder (SASRec/BST) + action head — sample shapes

> Illustrative only. Time use = **strong / native** (causal self-attention over the ordered sequence; BST adds time-gap embeddings). Diagnostics = **predictive** (ranking, recency); no native causal layer.

## Input — ordered event sequence per customer (order matters)

```
C_1001 sequence (most recent last), capped at last N events:
  [ (Email, open,        gap=540d),
    (Leads, inbound_call, gap=420d),
    (Email, click,        gap=  0d) ]
PRISM scores + cc_ind carried as side features.
```

## Candidate action — channel embedding scored against the state vector

| customer_id | cand_channel | scored as |
|---|---|---|
| C_1001 | Email | state ⊕ emb(Email) |
| C_1001 | Direct_Mail | state ⊕ emb(Direct_Mail) |
| C_1001 | ∅ (no-contact) | state ⊕ emb(none) |

## Output — long score table (ranking-native)

| customer_id | effective_date | model_id | candidate_action_id | objective_id | score | score_rank |
|---|---|---|---|---|---|---|
| C_1001 | 2026-06-01 | cp4_sasrec_v1 | Email | conv_30d | 2.41 | 1 |
| C_1001 | 2026-06-01 | cp4_sasrec_v1 | Leads | conv_30d | 1.07 | 2 |
| C_1001 | 2026-06-01 | cp4_sasrec_v1 | Direct_Mail | conv_30d | 0.55 | 3 |

`score_type=rank_score` — a ranking score, **not** a probability; policy must respect rank semantics and not compare across `score_type`.

## Scoring flow (conceptual)

```python
state = sasrec_encoder(ordered_events, side_feats)   # customer-state vector
def rank_score(channel):
    return head(concat(state, channel_embedding(channel)))
ranked = sorted(candidate_channels, key=rank_score, reverse=True)
top_k = ranked[:K]            # ranking-native; emit score_rank = 1..K
```
