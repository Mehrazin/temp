# CP3 — Hybrid: transformer encoder → existing XGBoost/DR — sample shapes

> Illustrative only. Time use = **moderate** (lives inside the encoder; downstream stays tabular). Diagnostics = **predictive** + a direct with/without-embedding **ablation**; causal only via the existing DR layer (same rank-deficiency caveat).

## Input — existing tabular features PLUS the encoder's journey embedding

Encoder turns the journey into a fixed-width vector:

```
journey events  ->  transformer encoder  ->  emb = [0.12, -0.04, 0.91, ... ] (d=64)
```

Combined feature row consumed by the existing scorer:

| customer_id | prism_01 | email_cnt_90d | ...existing feats... | cand_channel | emb_0 | emb_1 | ... | emb_63 |
|---|---|---|---|---|---|---|---|---|
| C_1001 | 0.62 | 3 | ... | Email | 0.12 | -0.04 | ... | 0.07 |

## Candidate action — same as today's scorer (one row per candidate channel)

| customer_id | cand_channel |
|---|---|
| C_1001 | Email |
| C_1001 | Leads |
| C_1001 | ∅ (no-contact) |

## Output — identical score table, new model_id (encoder swap invisible)

| customer_id | effective_date | model_id | candidate_action_id | objective_id | score | score_rank |
|---|---|---|---|---|---|---|
| C_1001 | 2026-06-01 | cp3_hybrid_v1 | Email | conv_30d | 0.078 | 1 |
| C_1001 | 2026-06-01 | cp3_hybrid_v1 | Leads | conv_30d | 0.046 | 2 |

Downstream consumers see the same shape as `cp1_v3` — only `model_id` changes.

## Scoring flow (conceptual)

```python
emb = transformer_encoder(journey_events)        # frozen / exported embedding
x   = concat(existing_features, action_feat, emb)
score = xgboost_or_dr_scorer.predict(x)          # unchanged downstream stack
# cheap, management-relevant diagnostic — marginal value of the embedding:
delta_auc = eval(with_emb=True) - eval(with_emb=False)
```
