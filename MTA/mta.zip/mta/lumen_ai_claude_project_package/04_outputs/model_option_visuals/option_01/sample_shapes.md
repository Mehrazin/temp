# CP1 — Temporal-feature XGBoost — sample shapes

> Illustrative only. Tiny made-up rows to make the option concrete. Time use = **weak** (journey collapsed into features). Diagnostics = **predictive**; causal only via the separate (currently broken) DR layer.

## Input — one row per customer (journey already summarized into features)

| customer_id | prism_01 | prism_07 | cc_ind | email_cnt_90d | dm_recency_d | leads_cnt_lt | mean_gap_d | last_touch_ch |
|---|---|---|---|---|---|---|---|---|
| C_1001 | 0.62 | 0.41 | 1 | 3 | 220 | 0 | 34 | Email |
| C_1002 | 0.18 | 0.55 | 0 | 0 | NULL | 1 | 180 | Leads |

The raw touchpoints behind `C_1001` (collapsed into the columns above):

```
C_1001, 2022-03-11, Email,  open
C_1001, 2022-09-02, Leads,  inbound_call
C_1001, 2023-11-04, Email,  click
```

## Candidate action — entered as a FEATURE (one scored row per candidate channel)

| customer_id | ...features... | cand_channel (feature) |
|---|---|---|
| C_1001 | ... | Email |
| C_1001 | ... | Direct_Mail |
| C_1001 | ... | Leads |
| C_1001 | ... | ∅ (no-contact) |

## Output — long score table (PRISM-style)

| customer_id | effective_date | model_id | candidate_action_id | objective_id | score | score_rank |
|---|---|---|---|---|---|---|
| C_1001 | 2026-06-01 | cp1_v3 | Email | conv_30d | 0.071 | 1 |
| C_1001 | 2026-06-01 | cp1_v3 | Leads | conv_30d | 0.044 | 2 |
| C_1001 | 2026-06-01 | cp1_v3 | Direct_Mail | conv_30d | 0.038 | 3 |

`score` = calibrated conversion probability (`score_type=prob`). CI columns stay NULL.

## Scoring flow (conceptual)

```python
feats = build_features(journey_history, prism_block)   # RFM / windows / gaps
rows = []
for action in candidate_channels + ["none"]:
    x = concat(feats, encode_action_as_feature(action))
    rows.append((customer, action, xgb.predict_proba(x)))   # P(convert)
write_long_table(rows)        # one row per (customer, channel)
# diagnostics: shap(xgb, x)  -> what the model keys on (NOT attribution)
```
