# Model Option Visuals — Lumen AI

**Date:** 2026-06-17
**Purpose:** A fast, visual way to understand the main Lumen AI model/design options. This package **extracts and illustrates** the options already established in `04_outputs/model_options_map_for_human_review.md` — it does **not** invent a new design, write a manager memo, or redo the literature review.

## What's in this package

Each option below has its own folder with three files:

- **`overview.svg`** — the big-picture architecture: input data → journey/sequence representation → model/scorer → score table → decision layer (+ a diagnostic/attribution layer where applicable).
- **`data_flow.svg`** — a simpler view: raw touchpoints → sequence construction → train/score → score table → business output.
- **`sample_shapes.md`** — tiny concrete examples (input rows, candidate-action rows, output score rows) and a short conceptual scoring snippet.

**Colors are consistent across every diagram:** blue = input · cyan = journey/sequence · purple = model/scorer · amber = score table · green = decision layer · indigo = predictive diagnostics · rose/red = causal / attribution (and claim-discipline warnings).

### Scope choices (why these five)

The options map lists CP1–CP6 plus the A5 primitive and a deferred set. To keep this focused and within the 5-folder limit, the five **most distinct and viable** paths are shown — spanning weak→strong time use and predictive→causal. Two supported items are intentionally *not* given folders:

- **CP5 (self-supervised / multi-task)** is a *stretch variant* of the CP2/CP4 encoders (extra pretraining + heads), not an architecturally distinct path; same contract, more objective rows.
- **A5 (Deep-Sets / Set-Transformer)** is a *cross-cutting primitive* (an add-on to the action block for scoring channel *combos*), not a standalone model.

The deferred items (ordered sequences, RL/bandit serving, TPP "when-to-contact") are V2/V3 and out of scope per the source.

### Two distinctions the diagrams hold throughout

- **Predictive diagnostics ≠ causal attribution.** SHAP, gain, ablations, and attention explain *what a model keys on* — they are not incremental-effect estimates. Only **CP6** (or a *repaired* DR layer) yields attribution.
- **Attention weights are not attribution.** A transformer buys a better encoder/scorer; "attention over touchpoints" is not channel credit.

## Options at a glance

| Option | Folder | What it is | Time use | Predictive scoring | Diagnostic / attribution | Diagnostics source | 2–4 wk feasibility |
|---|---|---|---|---|---|---|---|
| **CP1** | [option_01](option_01/) | Temporal-feature XGBoost, action-as-feature | **Weak** | Yes (default, the floor) | Predictive only | From model; causal only via **separate** (broken) DR layer | **Yes** |
| **CP2** | [option_02](option_02/) | Tabular/temporal transformer (FT or TFT), action-as-input | **Moderate** (FT) → **Strong** (TFT) | Yes (default) | Predictive; optional uplift | Predictive from model; uplift = **same model**, differenced vs ∅ | **Yes** (spike grade) |
| **CP3** | [option_03](option_03/) | Hybrid: transformer encoder → existing XGBoost/DR | **Moderate** (inside encoder) | Yes (default) | Predictive + embedding ablation | From downstream model; causal via **separate** DR layer | **Yes, comfortably** |
| **CP4** | [option_04](option_04/) | Sequence-rec encoder (SASRec/BST) + action head | **Strong / native** | Yes (ranking-native) | Predictive only | From model; **no causal layer** | **Partial** |
| **CP6** | [option_05](option_05/) | Causal / uplift head (Causal/G-Transformer; CSF; or S-learner difference) | Depends on encoder | Indirectly (via `score(∅)`) | **Causal / attribution** (CATE/uplift) | **Same model's own counterfactual head** | **No** (rigorous); S-learner difference only |

## Option summaries

### CP1 — Temporal-feature XGBoost — [option_01](option_01/)

- **One line:** Strengthen today's baseline by engineering RFM/multi-window/recency/gap features over full 2022+ history and predicting conversion with the candidate channel as a feature.
- **Sequence/time use:** **Weak** — time is summarized into features; order is not modeled.
- **Predictive scoring:** Yes — this is the default and the mandatory floor.
- **Diagnostic/attribution:** Predictive only (gain/SHAP/ablations).
- **Diagnostics source:** Predictive from the model itself; any causal reading requires the **separate DR layer** (currently rank-deficient, `zstat=-inf`).
- **Feasibility (2–4 wk):** **Yes** — highest value-per-effort and the fair-comparison baseline, so the work is never wasted.
- **Most relevant refs/repos:** XGBoost-with-temporal-data (arXiv 1802.03396); time-varying RFM churn (Annals of OR 2024); UpliftBench / S-learner-over-GBDT bar (arXiv 2604.06123, repo `Aman12x/UpliftBench`); "When Do Neural Nets Outperform Boosted Trees" (arXiv 2305.02997).

### CP2 — Tabular/temporal transformer (action-as-input) — [option_02](option_02/)

- **One line:** A genuine but *tabular/temporal* transformer (FT-Transformer for short/sparse journeys, or TFT with the proposed action as a "known-future input" for longer/denser ones), candidate channel always an input.
- **Sequence/time use:** **Moderate** (FT, engineered windows) to **Strong** (TFT, explicit sequence + optional time-gap embeddings). *Artifacts' primary MVP candidate.*
- **Predictive scoring:** Yes — the default.
- **Diagnostic/attribution:** Predictive (SHAP/ablation/attention — *attention is not attribution*); uplift reachable but off by default.
- **Diagnostics source:** Predictive from the model; the optional uplift difference is the **same model**, differenced against an explicit ∅ — no separate model.
- **Feasibility (2–4 wk):** **Yes, spike grade** — assuming a usable cleaned (Layer-4) sample and GPU/library compatibility.
- **Most relevant refs/repos:** FT-Transformer (arXiv 2106.11959, `pytorch-tabular`); TFT (arXiv 1912.09363, `pytorch-forecasting`); fintech journey transformer / TIMeSynC (arXiv 2410.12825); Cao & Zhu action-as-input (arXiv 2108.08846); BST time-gap embeddings (arXiv 1905.06874).

### CP3 — Hybrid encoder → existing XGBoost/DR — [option_03](option_03/)

- **One line:** Export journey embeddings from a transformer encoder, append them to the features today's XGBoost/DR scorer already consumes, and run a with/without ablation.
- **Sequence/time use:** **Moderate** — time/order captured inside the encoder; downstream stays tabular.
- **Predictive scoring:** Yes (default).
- **Diagnostic/attribution:** Predictive plus a direct **marginal-value ablation** of the embedding; causal only via the existing DR layer.
- **Diagnostics source:** Predictive from the downstream model; causal from the **separate DR layer**; encoder value measured by ablation, not attention.
- **Feasibility (2–4 wk):** **Yes, comfortably** — lowest compliance disruption (reuses existing approval lineage); the designated fallback if CP2 friction is high.
- **Most relevant refs/repos:** any encoder (SASRec/BST/FT-Transformer/TFT) + existing XGBoost/EconML stack; encoder refs as in CP2/CP4.

### CP4 — Sequence-rec encoder (SASRec/BST) + action head — [option_04](option_04/)

- **One line:** A production rec-stack encoder over the event sequence produces a customer-state vector; a small head scores `state ⊕ candidate-channel`.
- **Sequence/time use:** **Strong / native** — causal self-attention; BST adds learned time-gap embeddings. The most sequence-dependent option.
- **Predictive scoring:** Yes — ranking-native (`score_type=rank_score`).
- **Diagnostic/attribution:** Predictive only (ranking quality, recency); no native causal.
- **Diagnostics source:** Predictive from the model; **no causal layer**.
- **Feasibility (2–4 wk):** **Partial** — a prototype is feasible; a fairly tuned comparison may slip. Justified *only if* profiling confirms long/dense journeys; sparse channels (Email/DM/Leads) degrade it.
- **Most relevant refs/repos:** SASRec (arXiv 1808.09781); BERT4Rec (arXiv 1904.06690 — SASRec is the pragmatic default); BST (arXiv 1905.06874); tooling `Transformers4Rec`, `RecBole`.

### CP6 — Causal / uplift head — [option_05](option_05/)

- **One line:** Add a confounding-adjusted counterfactual head (Causal/G-Transformer), use a non-DL Causal Survival Forest, or — the cheap version — emit the S-learner difference `score(A) − score(∅)`; the only family built to estimate incremental effect.
- **Sequence/time use:** Depends on the encoder; the causal machinery lives in the head.
- **Predictive scoring:** Indirectly — it produces the per-action scores whose *difference* is the uplift.
- **Diagnostic/attribution:** **This is the causal-attribution option** (CATE/uplift) — the only one that legitimately supports an attribution reading, especially at the contact/no-contact margin.
- **Diagnostics source:** Causal estimate from the **same model's own counterfactual head** (vs. CP1/CP3 where causal reads come from a separate DR layer).
- **Feasibility (2–4 wk):** **No** for rigorous DL (a Week-4 pilot question at most); the **S-learner difference** is the only "good-enough" v1; Causal Survival Forest is a medium-effort non-DL route. **No incremental claim is licensed without a randomized experiment or defensible OPE (D005)**, and current overlap/positivity is too poor to defend one.
- **Most relevant refs/repos:** Causal Transformer (arXiv 2204.07258, repo `Valentyn1997/CausalTransformer`); G-Transformer (arXiv 2405.21012, repo `konstantinhess/G_transformer`); Causal Survival Forests (arXiv 2001.09887, `grf`); tooling EconML, CausalML, scikit-uplift, UpliftBench (Qini/AUUC).

---

## Cross-option facts the diagrams rely on

- **One shared contract.** Every option emits into the same two-table PRISM-style contract (long score fact table + assignment table + registry). Swapping CP1 → CP2 → CP3 is new `model_id` rows, not a schema migration — which is what makes the model-family choice low-stakes and reversible.
- **The decision layer is shared and model-agnostic.** Top-1/top-K, caps, eligibility filters, and no-contact are decision-layer reads over single-channel scores — no new model, no new schema. V1 single-channel scoring already unlocks most confirmed business asks.
- **Still unsettled by data (not reading):** journey length/richness (FT vs TFT vs sequence-rec), whether a transformer beats or merely matches CP1 at full scale, and whether overlap/positivity even permits a defensible uplift estimate. These gate the choice and must be measured on the full source while the cleaned (Layer-4) dataset is built.

*Source of record: `04_outputs/model_options_map_for_human_review.md` (which in turn draws on the `transformer_mvp_design/` set, `03_research_memory/`, and `01_current_state/`). No new research performed; options limited to those the artifacts support. No final recommendation is made here — the source map nominates CP2 as primary candidate and CP1 as the mandatory floor, reported as the artifacts' stance, not asserted.*
