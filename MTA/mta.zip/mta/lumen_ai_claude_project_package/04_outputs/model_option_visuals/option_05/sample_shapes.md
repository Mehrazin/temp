# CP6 — Causal / uplift head — sample shapes

> Illustrative only. The **only attribution-native** option. Time use = depends on the encoder (causal machinery is in the head). Diagnostics = **causal/attribution** (CATE/uplift) from the *same model's own head*.
>
> ⚠ **Claim discipline:** no incremental-uplift claim is licensed without a randomized experiment or a defensible OPE (D005). Current overlap/positivity is too poor to defend a causal estimate. Rigorous DL is **not** 2–4 week feasible; the **S-learner difference** is the only "good-enough" v1.

## Input — journey/context PLUS an explicit ∅ baseline and a positivity check

```
C_1001 journey + PRISM context
factual treatment:        Email
counterfactual baseline:  ∅ (no-contact)
per-channel overlap:      Email=ok, Direct_Mail=THIN (positivity risk)
```

## Candidate action — each scored under treatment AND under ∅

| customer_id | action | score(A) | score(∅) |
|---|---|---|---|
| C_1001 | Email | 0.083 | 0.029 |
| C_1001 | Direct_Mail | 0.041 | 0.029 |

## Output — long score table with uplift semantics + confidence intervals

| customer_id | effective_date | model_id | candidate_action_id | objective_id | score | score_lower | score_upper |
|---|---|---|---|---|---|---|---|
| C_1001 | 2026-06-01 | cp6_uplift_v0 | Email | uplift_30d | 0.054 | 0.012 | 0.096 |
| C_1001 | 2026-06-01 | cp6_uplift_v0 | Direct_Mail | uplift_30d | 0.012 | -0.020 | 0.044 |

`score_type=uplift`; CI columns populated (nullable elsewhere). A CI spanning 0 (Direct_Mail) = no defensible incremental effect.

## Scoring flow (conceptual)

```python
# cheap "good-enough v1" — S-learner difference from a CP2-style model:
uplift = {A: score(A) - score("none") for A in candidate_channels}
# rigorous route (Week-4 pilot at most): counterfactual head + CIs
yA, y0, ci = causal_head(encoder(journey, context), treat=A, baseline="none")
# GATE: only report as causal AFTER an RCT or defensible OPE validates it
assert experiment_or_ope_exists, "no incremental claim licensed (D005)"
```
