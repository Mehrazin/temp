# CP2 — Tabular / temporal transformer (action-as-input) — sample shapes

> Illustrative only. Time use = **moderate** (FT path) to **strong** (TFT path). Diagnostics = **predictive** (SHAP/ablation/attention — *attention is not attribution*); uplift is the **same model** differenced vs ∅, off by default.

## Input — static block + journey block (TFT path shown as ordered events)

Static context (one row per customer):

| customer_id | prism_01 | prism_07 | cc_ind |
|---|---|---|---|
| C_1001 | 0.62 | 0.41 | 1 |

Journey block — ordered events fed to the encoder (TFT) or aggregated to tokens (FT):

```
C_1001, t=2022-03-11, channel=Email, interaction=open
C_1001, t=2022-09-02, channel=Leads, interaction=inbound_call
C_1001, t=2023-11-04, channel=Email, interaction=click
```

## Candidate action — entered ONLY as an input embedding (leakage-guarded)

| customer_id | action_id | action_embedding |
|---|---|---|
| C_1001 | Email | emb(Email) |
| C_1001 | Direct_Mail | emb(Direct_Mail) |
| C_1001 | ∅ (no-contact) | emb(none) |

## Output — long score table

| customer_id | effective_date | model_id | candidate_action_id | objective_id | score | score_rank |
|---|---|---|---|---|---|---|
| C_1001 | 2026-06-01 | cp2_ft_v1 | Email | conv_30d | 0.083 | 1 |
| C_1001 | 2026-06-01 | cp2_ft_v1 | Direct_Mail | conv_30d | 0.041 | 2 |
| C_1001 | 2026-06-01 | cp2_ft_v1 | ∅ | conv_30d | 0.029 | 3 |

`score_type=prob`. Optional uplift row is *derived*: `uplift(Email) = 0.083 − 0.029 = 0.054`.

## Scoring flow (conceptual)

```python
h_c = transformer_encoder(static_block, journey_block)    # journey state
def score(action):
    a = action_embedding(action)            # action enters ONLY here
    return mlp_head(concat(h_c, a))         # calibrated prob
rows = [(customer, A, score(A)) for A in candidate_channels + ["none"]]
# optional, OFF by default — same model, differenced:
uplift = {A: score(A) - score("none") for A in candidate_channels}
```
