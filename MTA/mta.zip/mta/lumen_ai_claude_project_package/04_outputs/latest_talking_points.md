# Latest Talking Points

## Status

Not yet generated from refreshed context.

## Target Structure

- 30-second summary
- 2-minute summary
- Manager discussion opener
- How to explain uncertainty
- How to explain production-readiness gaps
- How to ask for time/resources/support
- How to position package-first vs transformer-first
