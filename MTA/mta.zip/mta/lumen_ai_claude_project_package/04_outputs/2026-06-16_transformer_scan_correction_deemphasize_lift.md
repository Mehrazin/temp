# Corrective Broadening Pass — De-emphasizing Lift in the Lumen Transformer Scan

**Date:** 2026-06-16
**Author:** Applied-science research pass (anti-anchoring correction)
**Relationship to prior work:** This **extends, does not replace,** `2026-06-16_independent_transformer_research_scan.md`. That scan stands; this file corrects one anchoring bias in it. Evidence labels unchanged: **[ACADEMIC] [INDUSTRY] [CODE] [INTERPRETATION]**.
**Premise (from the user, accepted):** For the transformer phase, the deployable output does **not** need to be causal lift. Lift entered Lumen historically via the diagnostic/DR attribution work and was partially carried into the predictive version. The output can be a **probability, score, ranking, or candidate-action score** that feeds downstream decisioning. Lift/CATE is now **optional**, not the objective.

---

## 1. What Changes After De-emphasizing Lift

**Did the first scan over-weight lift / causal framing? Partly, yes — and it matters.**

To be fair to it: the first scan explicitly said *"a transformer gives you a better encoder/scorer, not incremental uplift,"* and its MVP (Path B) was technically a predictive model. So it was not wrong in substance. **But its framing still anchored on lift as the target** in four concrete ways:

1. The MVP's *output* was defined as an S-learner uplift difference `score(A) − score(∅)`, not as the conditional score itself.
2. The evaluation section **mandated Qini/AUUC + an IPS/DR off-policy estimate with CIs** as *the* metrics — a causal-validity bar.
3. The "evidence to generate before committing" list was **gated on causal prerequisites** (positivity/overlap per channel, time-varying confounding, OPE design).
4. It inherited the project's D005 lift-claim discipline as if producing lift were the goal, rather than treating "don't *claim* causal uplift" as separate from "the model must *produce* causal uplift."

**[INTERPRETATION] The correction is consequential because it changes the difficulty and feasibility calculus, not just the vocabulary.** A prediction-first scorer is dramatically easier to build, evaluate, and validate in 2–4 weeks:

| Dimension | Lift-anchored framing | Prediction-first framing |
|---|---|---|
| Output | `score(A) − score(∅)` (uplift) | `P(conversion \| history, channel)` or a ranking score |
| Primary metric | Qini / AUUC (needs control group logic) | AUC / PR-AUC / calibration / NDCG / Recall@k |
| Validation bar | Defensible OPE + CIs; experiment to confirm | Standard **time-based holdout**; directly checkable |
| Data prerequisites | Positivity/overlap, confounding structure | Just sequences + labels |
| Failure mode | Offline uplift is **unfalsifiable** without a test | Predictive error is **measurable today** |
| Compliance story | "Causal estimate" is harder to defend/validate | A calibrated probability is more defensible |
| D005 exposure | High (easy to overclaim) | **Low — sidesteps the overclaim risk entirely** |

Importantly, **de-emphasizing lift is consistent with D005, not in tension with it.** D005 says: do not *claim* incremental business uplift without an experiment or defensible OPE. Building a *predictive* scorer and ranking on it makes no causal claim at all, so it removes the overclaiming hazard rather than creating one. The two ideas were conflated; separating them is the cleanest path through the compliance constraint.

**What does NOT change:** the three-layer decomposition (encoder → action-conditioned scorer → config-driven decision layer) and the decoupling of scorer from policy (D010/D011) survive intact — they are objective-agnostic. The reusable scorer is the reusable scorer whether its output is a probability or a lift.

---

## 2. Best Prediction-First Transformer Paths

These map to your framings #1, #2, #4, #5, #6 — all non-causal.

- **Customer × candidate-channel conditional scoring (your #2) — the strongest fit.** Encode the journey + static features; pass the **candidate channel/action as an input**; predict `P(conversion | history, candidate channel)`. This *is* the reusable scorer the business asked for, with the action-as-input already matching D010. Top-1/top-K = sort channels by this score. **[ACADEMIC]** The action-as-input + top-k pattern is exactly Cao & Zhu (2108.08846); **[ACADEMIC]** TIMeSynC (2410.12825) is the fintech encoder template; both are predictive, not causal.
- **Plain conversion prediction from the sequence (your #1)** — simplest possible; useful as a sanity baseline and as the `∅` (no-additional-contact) reference if you ever *want* an optional lift later, but on its own it doesn't score channels.
- **Self-supervised pretraining then fine-tune (your #4 next-event / #5 masked-channel).** Pretrain an encoder on **unlabeled** journey data (next-touch or masked-channel objective), then fine-tune a small head for conversion or next-channel. **[ACADEMIC]** Direct support: SRP4CTR (2407.19658) pretrains a sequential recommender self-supervised and fine-tunes to improve CTR; Abacus (2512.16581) does self-supervised pretraining for sequential user/purchase modeling; BERT4Rec (1904.06690) is masked-event modeling; Markovian Pre-Trained Transformer (2601.08275) shows pretraining helps **transfer with little labeled data** — relevant given Lumen's sparse positive labels. **[INTERPRETATION]** This is the highest-value *prediction-first* idea for a small-label regime, but it adds a week of scope; keep it as an MVP+ option, not the first build.
- **Multi-task scorer (your #6):** shared encoder, heads for conversion + next-channel + engagement. **[ACADEMIC]** Multi-task recommendation is well-trodden (Huawei pairwise-ranking MTL 2406.02163; Tencent cross-task distillation 2202.09852; Pinterest DHEN CTR/CVR 2504.08169). **[INTERPRETATION]** Value: the auxiliary next-channel/engagement tasks **regularize** a sparse conversion label and yield extra signals the config layer can use. Cost: more heads to tune. Good *stretch within the prediction-first family.*

---

## 3. Best Ranking / Recommendation Paths

Maps to your #3.

- **Sequential next-best-action ranking (SASRec / Transformers4Rec).** Treat channels/actions as the item vocabulary; rank the candidate set against the journey representation. **[CODE]** NVIDIA Transformers4Rec is production-grade (SASRec/XLNet backbones, NVTabular, Triton); **[CODE]** RecBole gives quick SASRec/BERT4Rec baselines. Evaluate with **Recall@k / NDCG / MRR** — standard, fast, no causal machinery.
- **[INTERPRETATION] When ranking is the *right* frame:** when the operational question is *"given we will contact this customer, which channel ranks highest?"* — i.e., the contact decision is already made and only channel selection remains. This is decision-equivalent to scoring for most of the population and avoids the no-contact margin where causal reasoning would otherwise be needed.
- **Caveat:** pure next-item ranking optimizes "what the customer would do next," which can drift from "what the business wants to cause." For Lumen, the **conditional scorer (#2)** is usually a cleaner objective than item-style next-action ranking, because the candidate action is a controllable input rather than a predicted-next-token. I'd rank #2 above #3 for the MVP.

---

## 4. Best Hybrid Paths

Maps to your #8 and #9 — and these are underrated.

- **Transformer encoder as a frozen feature extractor → existing XGBoost/DR downstream (your #9).** Train (or pretrain) the encoder, export per-customer journey embeddings, append them to the existing tabular feature set, and let the **current XGBoost scorer + optimizer** consume them. **[INTERPRETATION] This is the lowest-risk way to introduce a transformer into Lumen:** it (a) reuses the existing, already-understood approval/model-validation lineage instead of standing up a brand-new architecture path, (b) lets you measure the embedding's marginal value directly (XGBoost with vs. without the embedding — a clean ablation), and (c) degrades gracefully — if the embedding adds nothing, you've lost little. **[INDUSTRY]** The "pretrained representation feeds a GBDT/linear downstream" pattern is standard practice; **[ACADEMIC]** SRP4CTR/PinnerFormer-style "learn a user representation, reuse it downstream" is the same idea.
- **Transformer representation + simpler downstream scorer/ranker (your #8).** Same spirit: a lightweight logistic/GBDT head per objective on top of a shared encoder. Keeps the heavy model stable and the heads cheap and reconfigurable — which dovetails with the config-driven layer.

---

## 5. Should Uplift / CATE Be MVP, Stretch, or Deferred?

**Verdict: DEFERRED — kept as an *optional objective* in the config layer, not built into the MVP.**

- **Keep lift/CATE when:** the decision genuinely includes **whether to contact at all** (no-contact logic, "sleeping dogs" who react negatively); budget is so scarce that you must rank by *incremental* rather than absolute response; or you have (or will run) an **experiment** to validate the uplift. In those cases the same scorer can emit `score(A) − score(∅)` on demand — no separate model needed for an S-learner version.
- **Drop / postpone lift/CATE when (mostly the current situation):** the question is "which channel, given we contact"; **positivity/overlap is poor and confounding is severe** (exactly the regime that produced the rank-deficient DR `zstat=-inf`), so causal estimates are unreliable and a prediction is the more honest output; or there is **no experiment** to falsify an offline uplift number within the spike. Forcing a causal head (Causal Transformer) into a 2–4 week build is the costliest option for the least verifiable payoff.
- **Does causal framing materially improve this MVP?** **[INTERPRETATION]** On the evidence, **no, not for this MVP:**
  - *Accuracy* — a predictive scorer is more accurate and, crucially, **measurably** so; uplift accuracy can't be checked offline here.
  - *Decision quality* — for "which of N channels given contact," ranking by predicted conversion is decision-equivalent to ranking by uplift whenever the `∅` baseline is similar across channels; the two **only diverge at the contact / no-contact margin**, which is a smaller, later problem.
  - *Interpretability / compliance* — a **calibrated probability is easier to validate and defend** than a causal estimate, not harder.
  So causal framing is a genuine *option* for one specific objective (the contact margin), not a property the MVP needs.

---

## 6. Revised Candidate Implementation Paths (Prediction-First View)

Re-ranked with lift de-emphasized. (Old labels in brackets for continuity.)

### R1 — Customer × candidate-channel conditional scorer *(new MVP; ≈ old Path B, predictive output)*
- **Method:** TFT/FT-Transformer (or SASRec encoder) with **candidate channel as input**, output `P(conversion | history, channel)`. Ranking/top-K/caps handled by the existing ILP. Output is a probability, not a lift.
- **Data:** sequences + timestamps + channel taxonomy + conversion label. No positivity/confounding prerequisites.
- **Difficulty:** Medium. **Value:** High — *is* the reusable scorer. **Eval:** AUC/PR-AUC + calibration + ranking metrics on a **time-based holdout**.
- **2–4 wk:** **Yes.**

### R2 — Hybrid: transformer embeddings → existing XGBoost/DR *(new fallback; old #8/#9)*
- **Method:** encoder produces journey embeddings; append to current tabular features; existing XGBoost scorer + optimizer consume them. Clean with/without-embedding ablation.
- **Difficulty:** Low–Medium. **Value:** High value-per-effort + lowest compliance disruption (reuses existing lineage). **Risk:** embedding may add little (which is itself a useful, cheap finding).
- **2–4 wk:** **Yes, comfortably.**

### R3 — Self-supervised pretraining + fine-tune *(MVP+; your #4/#5)*
- **Method:** pretrain encoder on unlabeled journeys (next-touch / masked-channel), fine-tune for conversion or next-channel.
- **Difficulty:** Medium-High. **Value:** High in the sparse-label regime. **Repos:** Transformers4Rec, RecBole; **[ACADEMIC]** SRP4CTR/Abacus/MPT.
- **2–4 wk:** **Partial** — feasible if pretraining is time-boxed; otherwise slips.

### R4 — Sequential NBA ranking *(your #3)*
- **Method:** SASRec/Transformers4Rec rank channels; Recall@k/NDCG.
- **Difficulty:** Medium. **Value:** Medium; best when "given contact, which channel." **Risk:** next-item objective can drift from business objective.
- **2–4 wk:** **Partial.**

### R5 — Optional uplift / multi-task objective head *(stretch; old Path D/E + your #6/#7)*
- **Method:** add `score(A) − score(∅)` uplift output and/or auxiliary heads (next-channel, engagement) to R1's encoder. Rigorous causal (Causal Transformer) only as a Week-4 pilot question, only if an experiment is on the horizon.
- **Difficulty:** High (rigorous) / Low (S-learner difference). **Value:** Conditional — see §5.
- **2–4 wk:** S-learner difference yes; rigorous causal **no**.

**Baseline floor (unchanged):** sequence-feature XGBoost + plain conversion prediction (old Path A) remains the comparison and ultimate fallback.

---

## 7. Revised MVP Recommendation

**R1 — the customer × candidate-channel conditional scorer, with a *predictive* output (`P(conversion | history, channel)`)**, run against the sequence-feature XGBoost baseline, with the existing ILP as the decision layer.

Why this over the previous (lift-flavored) MVP: it is the **same architecture** the first scan recommended, but by changing the *output and evaluation from uplift to prediction*, it becomes (a) easier to build, (b) checkable on a simple time-based holdout instead of an OPE design, (c) free of the positivity/confounding prerequisites that are currently broken in the data, and (d) lower D005/compliance risk. It still satisfies the transformer mandate, the reusable-scorer requirement, and every flexible-output use case (top-1/top-K/caps/eligibility/no-contact) via the config layer. **[INTERPRETATION]** Uplift remains one line of code away (`score(A) − score(∅)`) if and when an experiment justifies it — so nothing is lost by deferring it.

---

## 8. Revised Fallback Recommendation

**R2 — the hybrid (transformer embeddings feeding the existing XGBoost/DR scorer + optimizer).** It keeps a transformer in the story while reusing the existing approval lineage and the proven downstream stack, and it answers a question management will ask cheaply: *does the transformer representation actually add anything over our current features?* If TFT/GPU plumbing or data prep overruns, R2 still ships. Below R2, the floor is the non-transformer sequence-feature XGBoost (old Path A).

---

## 9. What To Tell Chat 2 (so it does not over-focus on lift)

1. **The deployable output is a score/ranking, not necessarily lift.** Default the MVP to `P(conversion | history, candidate channel)`. Treat lift/CATE as **one optional objective** the config layer can request, computable from the same scorer — not the target.
2. **Evaluate predictively first.** AUC/PR-AUC, calibration, and ranking metrics (NDCG/Recall@k) on a **time-based holdout**. Do **not** gate the MVP on Qini/AUUC or an OPE design; bring those in *only* if and when a business uplift *claim* is on the table.
3. **Separate two things that were conflated:** "we must not *claim* causal uplift without an experiment" (D005, still true) ≠ "the model must *produce* causal uplift" (false). Prediction-first honors D005 by making no causal claim.
4. **Causal framing is not a free accuracy/interpretability win here.** It helps materially only at the **contact / no-contact margin** (sleeping dogs); for "which channel given contact," predicted-conversion ranking is decision-equivalent and more defensible.
5. **Prefer the hybrid (encoder → existing GBDT) as the low-risk on-ramp.** It reuses the existing compliance lineage and gives a clean ablation of the transformer's marginal value.
6. **Keep the encoder / scorer / decision-layer decoupling and the optimizer reuse** regardless of score type — that design is objective-agnostic and already correct.
7. **Self-supervised pretraining is the prediction-first idea most worth a stretch** given sparse positive labels (SRP4CTR/Abacus/MPT) — but time-box it; don't let it crowd out R1.
8. **Do not build a Causal Transformer for the MVP.** It is a Week-4 pilot question contingent on an experiment, not a deliverable.

---

## 10. Net Effect on the Earlier Scan

The earlier scan's *architecture* conclusions are unchanged and still good. What changes is the **objective and evaluation lens**: swap "S-learner uplift output + Qini/OPE bar" for "conditional conversion score + predictive/ranking metrics + time-based holdout," and demote uplift/CATE from the MVP to an optional, deferred objective. This makes the 2–4 week spike materially more achievable and lower-risk, and — usefully — keeps it cleanly on the right side of D005.
