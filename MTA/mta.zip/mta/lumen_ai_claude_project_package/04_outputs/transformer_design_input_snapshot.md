# Transformer Design-Input Snapshot — Lumen AI

**Date:** 2026-06-16 (regenerated with the data-scale correction)
**Purpose:** A single, internally consistent consolidation of the current project knowledge, prepared as the **main input for Chat 2 (Transformer Delivery Planner)**. This is an audit/consolidation — not new research, not a final design, not a manager memo. It does not pick the model architecture.

**Authority rule:** where files conflict, the latest decision in `decision_register.md` and the latest change logs (`02_change_log/2026-06-16_manager_transformer_decision.md`, `02_change_log/2026-06-16_data_scale_correction.md`) win; older research files are interpreted in that light, but conflicts are still flagged (§16–17).

**Marking convention:** **(confirmed)** = manager/team decided or implemented; **(proposed)** = design intent not yet validated; **(uncertain)** = not established / needs data; **(approx)** = approximate count, to be confirmed; **(outdated)** = superseded.

> **Scale-correction note:** an earlier version of this file treated the prototype ~500K **evaluation** slice as the full population and called the regime "moderate volume / ~100× below transformer precedents," feeding a "transformer will likely only *match* XGBoost" conclusion. **That premise was wrong.** This regeneration corrects it (see §2–§3). Scale-dependent inferences are now stated as **re-opened, pending profiling of the full data** — not as settled findings.

---

## 1. Current Confirmed Project Direction

- Lumen AI is a multi-touch attribution + next-best-channel optimization initiative for TD credit-card marketing. Framing: **PRISM decides what product to offer; Lumen decides which channel to reach the customer.** The **predictive/next-best-channel lens is the priority.** **(confirmed)**
- **A transformer-based model is the confirmed primary modeling direction** (manager-directed, team-aligned; D004). This confirms a *direction only* — not a proven, built, or production-ready model; the spike's outcome is unknown. **(confirmed direction / outcome uncertain)**
- **Timeline:** ~**2–4 weeks** to produce a model, run experimentation, and finalize the design — explicitly "good enough," not perfect. **(confirmed)**
- **XGBoost + Doubly Robust is the baseline/benchmark and fallback**, no longer the main direction (D001). Retained, not deprecated. **(confirmed)**
- **Model-first over package-first** (D009); the package is deferred/secondary, not dropped (D003). **(confirmed)**
- **Flexible, config-driven business outputs are a confirmed requirement** (D011): support top-1, top-K, multiple channels per customer, capacity constraints, allowed-channel filters, no-contact logic, and different objectives — via a **reusable scorer + a separate config-driven scoring/optimization layer** that produces outputs each cycle without retraining. **(confirmed requirement; specific realization proposed)**

## 2. Corrected Data-Scale Interpretation

The single most important correction since the prior snapshot. The prototype's evaluation slice must **not** be read as the full data. All counts are **(approx)** unless confirmed.

- Lumen is **not** limited to ~500K customers, and the data must **not** be described as "moderate volume" on the basis of the prototype test set. ~500K is the prototype **test/evaluation** subset.
- The XGBoost/DR baseline was trained on a **filtered prototype experiment subset of ≈2–3M customers (approx)**, evaluated on **≈500K (approx)**.
- The **full available rich touchpoint source** goes back to **≈2022** and likely covers **≈10–15M customers (approx)** with many historical touchpoints.
- The full source is **plausibly more suitable for sequence/transformer modeling** than the prototype slice implied — so the earlier "match, not beat XGBoost" expectation is **re-opened (not refuted)**, pending profiling of the real data.
- **But the full source is not automatically "transformer-ready."** A cleaned, transformer-ready dataset **does not yet exist** and must be built first — that data-engineering work is a real dependency/risk under the 2–4 week spike timeline.

## 3. Four Data Layers (do not conflate)

| Layer | What it is | Scale (approx) | Status |
|---|---|---|---|
| **1. Prototype experiment subset** | Filtered slice the XGBoost/DR baseline trained on (experimental only) | **≈2–3M customers**; corresponds to the ~2.8M-row cleaned table | Exists; experimental. Window ~April → (July **or** January, depends on experiment version); **exact end date (uncertain)** |
| **2. Prototype test / evaluation set** | Held-out evaluation subset of the prototype | **≈500K customers** (≈521K rows; Sample1 ≈100K is a sub-sample of this) | Exists; an eval subset, **not** the modeling population |
| **3. Full available rich source data** | Timestamped touchpoint history since ≈2022 | **≈10–15M customers** with many touchpoints | Exists; **not yet used for modeling** |
| **4. Cleaned, transformer-ready training dataset** | Profiled, cleaned, sequence-constructed, timestamp-validated, channel-coverage-checked, label-window-designed data built from Layer 3 | — | **Does not exist yet**; must be built before the spike can use the full data |

## 4. Current Implementation State (the baseline)

- Two Databricks notebooks (Azure; cluster `AnalyticsCA0EDAMLDS…`): MTA `model_exploration` (diagnostic + predictive) and TMIA `model_exploration_tmia_final_predictive_only` (predictive-only). Partial/messy, poorly versioned; **models not persisted.** Built on the **prototype subset (Layer 1)**, evaluated on **Layer 2**.
- **Method:** econml `LinearDRLearner` (XGBClassifier propensity + XGBRegressor outcome, 5-fold cross-fitting, one-vs-rest treatments) producing per-customer per-channel potential outcomes `conversion_{ch}_0/_1` that feed a constrained optimizer. **Grouped channel-level is canonical** (D006); single-interaction retained; 8-state combinatorial built then **shelved** (D008).
- **Data:** MTA `mta_perm.mta_dm_predictive` (`efectv_dt=2025-04-30`); TMIA `mta_perm.tmia_final`. ~10 PRISM scores + CC indicator; historical `channel_*` flags; prospective `t_channel_*` actions. Cleaned tables under `vandad.*`.
- **Data hygiene:** manual bad-channel list + zero-variance drop + Tree-VIF deterministic-feature scan.
- **Optimizer:** linear/integer one-channel-per-customer under caps; constrained (usable) vs unconstrained (illustrative); Sample1 (~100K, a sub-sample of the Layer-2 test set) canonical; leads cap business-decided (~20K–30K).
- **Calibration:** trialed then disabled (~no effect).
- **The baseline collapses an April–July snapshot into a single flat XGBoost vector** — discards temporal order and the 2022+ history; it is not a sequence model (C14).
- **Results to date are model-estimated / exploratory, not experiment-validated:** optimizer BAU 1.31% → 1.44–1.45% (+~10% / +137 conversions); OPE-vs-PRISM "lucky match" AUC 0.831 vs 0.719 (+11.18%) on ~7,070 matched rows (ranking, biased subset, not significance-tested).

## 5. What Is Now Outdated or Secondary

- **(outdated)** The deck roadmap Shapley → DR → Atlantis package → Transformer; package now sits *after* the model (D003/D009).
- **(outdated)** "Lumen is ~500K customers / moderate volume" — corrected to the four-layer view (§2–§3).
- **(secondary)** Package-first / standalone "Lumen" package (host: "Atlantis"; another team would own it). Deferred, not dropped; the reusable-scorer + config-layer pattern delivers reusability without a standalone package.
- **(secondary)** The diagnostic/attribution lens (DR ATEs, Shapley-vs-DR) — supporting context.
- **(repositioned, not outdated)** XGBoost/DR = baseline/benchmark/fallback.
- **(superseded as directed path, retained as fallback)** The "lighter-models-first" ladder (F0 temporal XGBoost → causal survival forest → Markov/GRU).
- **(under re-evaluation)** Any prior scale-dependent inference that a transformer would "only match, not beat" XGBoost.

## 6. What XGBoost / DR Should Be Used For Now

- **The mandatory baseline / floor** the transformer is compared against — on the same data and same time-based split (OQ43).
- **The fallback** if the transformer spike underdelivers or the Layer-4 data build overruns.
- **A strengthened baseline is valuable work:** "stop collapsing the journey" → temporal-window/RFM/recency features over the 2022+ history (F0/CP1); keeps DR wiring + the existing compliance path; unblocks the time-based holdout (C6). UpliftBench evidence (S-learner over GBDT beats Causal Forest at ~14M rows) makes GBDT a genuinely hard bar.
- **Not for:** any causal CI/p-value (DR inference numerically invalid, C1), any incremental-uplift claim (C11), or "beating PRISM" (C7).

## 7. Transformer / Sequence-Modeling Design Constraints

- A "Lumen transformer" is **three stacked layers**: (1) sequence/representation encoder, (2) action-conditioned scorer head, (3) decision/optimization layer. Off-the-shelf recommender transformers and LiDDA give layers 1+2-as-prediction/attribution only; they do **not** supply a causal head — and a causal head may not be needed (§10/§13). **(well-supported)**
- **Action-as-input core model:** the proposed channel/action-set is an **INPUT** to one core model, **not** pre-enumerated output heads (D010). Combos handled **compositionally** via permutation-invariant set pooling (Deep Sets / Set Transformer); single channel = size-1 set; no 2^N enumeration. **(proposed; combo generalization unproven, OQ36)**
- **Data-regime fit is re-opened, not settled.** Earlier "short/sparse/moderate-volume → expect a transformer to only match XGBoost" rested on the prototype slice. The full source (≈10–15M customers since ≈2022, long histories — approx) is **plausibly favorable** for sequence/transformer modeling; whether journeys are long/dense enough is now a **profiling question** (§12), not a settled constraint. **(under re-evaluation)**
- **Hard dependency:** the transformer's access to the full-data advantage is **gated on building the Layer-4 cleaned, transformer-ready dataset** (sequence construction, timestamp validation, channel coverage, label-window). This sits underneath the 2–4 week timeline. **(confirmed dependency)**
- **No from-scratch transformer:** use mature libraries (pytorch-forecasting/TFT, pytorch-tabular/FT-Transformer, Transformers4Rec); spend the spike on the head + evaluation. The causal head is research-grade code only. **(well-supported)**
- **Separate architecture = separate compliance/model-validation path** — cannot inherit the XGBoost approval (schedule cost). **(confirmed caveat)**
- **Leakage guard:** treatment must enter only through the action-input, never also as a journey feature (the collinearity that broke DR inference, C1/C2).

## 8. Business Flexibility Requirements (D011, confirmed)

Must accommodate over time: **top-1, top-K, multiple channels per customer, capacity constraints, allowed-channel filters, no-contact logic, different objectives.** Means: a reusable scorer + a separate config-driven scoring/optimization layer, reconfigured each cycle without retraining. **Key finding:** most of these (top-1/top-K/multiple/allowed-set/caps/no-contact) are **decision-layer operations over single-channel scores** — no new model or schema. Only genuine unordered **sets** and ordered **sequences** need the model to score structured actions. **V1 single-channel scoring already unlocks most asks.** V1 subset undecided (OQ41).

## 9. Production Output-Contract Requirements (architecture-neutral)

Bind downstream consumers to a **data contract, not a model.** Recommended: **two tables + a registry.**

- **Score fact table** (append-only, generalizes the PRISM long pattern): `customer_id, effective_date, model_id, candidate_action_id, objective_id, score, score_rank, [score_lower, score_upper]`.
- **Assignment/decision table** (config-driven policy output): `customer_id, effective_date, policy_run_id, assigned_action_id, position, selected (reason code)`.
- **Registry (required):** model registry (`score_type` = prob | rank_score | uplift | ev, objective, training window, approval status, champion/challenger), action registry + members bridge (`action_type` = single | set | sequence; `position`), objective registry.
- **Properties:** long beats wide (add channels/objectives/model versions as **rows**, not schema migrations); every model family (CP1–CP6) emits the **same** contract → the model is swappable via new `model_id` rows with no downstream re-engineering; champion/challenger coexist as different `model_id`s on one `effective_date`; no-contact is an **explicit** action id; structured-action complexity lives in the action registry; carry `score_type` + nullable CI columns from day one. **(well-supported recommendation; not yet built)**

## 10. PRISM-Style Score-Table Reuse — Option & Tradeoffs

- **Reuse the PRISM *pattern* in a *parallel* Lumen table — do not write into PRISM's governed table.** Keep: long shape, `effective_date` historization, `model_id`, `score`, `score_rank`, row-extensibility. Add: `candidate_action_id`, `objective_id` (+ optional CI). **(recommended)**
- **Benefit:** operational familiarity (consumers and scoring jobs already understand the shape) lowers onboarding/governance cost; exact match to PRISM ops.
- **Tradeoff / why parallel not shared:** Lumen actions are structured (sets/sequences) and scores carry heterogeneous semantics (prob vs uplift vs rank); folding Lumen into PRISM as extra `model_id`s couples Lumen's faster cadence to PRISM's governance. Defer consolidation until Lumen's schema is stable.
- **Packaging options:** A (recommended) long table + registry + separate assignment table; B = A plus materialized wide *views*; C = bespoke wide table — only for a frozen single use case, **not recommended**.

## 11. Data Assumptions and Data Gaps

Assumptions in use:
- Per-customer timestamped `channel×interaction` events + ~10 static PRISM scores + CC indicator + binary conversion label + prospective `t_channel_*` actions.
- Controllable channels: Email, Direct Mail, Leads, OBTM (direct); branch/phone/Radar_* prompts (semi/inbound); some MTA-only digital (no control, **uncertain**).
- Four data layers per §3; the full source (Layer 3) is the modeling target, not the prototype slice.

Open gaps (these sit *underneath* the 2–4 week timeline):
- **(critical dependency)** The Layer-4 cleaned, transformer-ready dataset **does not exist** and must be built from Layer 3.
- **(uncertain)** Exact customer counts per layer; the prototype window **end date (July vs January)**.
- **(uncertain)** MTA vs TMIA vs hybrid data source (OQ1).
- **(gap)** Direct-mail sourcing broken: historical MTA DM effectively empty, DM via TMIA only → DM≫Email imbalance / unrealistic mix; model partly fits a collection artifact (OQ2, C9).
- **(gap)** Non-temporal random 60/20/20 split leaks future-into-past; a time-based holdout is mandatory before any predictive claim (OQ9, C6).
- **(needed-from-data)** Overlap/positivity per channel; label horizon / censoring (possibly right-censored time-to-event).

## 12. Data-Profiling Checklist (run before finalizing the architecture)

These facts gate both the architecture and the objective; they cannot be settled by reading — they must be measured on the **full source (Layer 3)** while building **Layer 4**:

1. **Journey-length distribution** (touches/customer) on the full data — the single biggest determinant of whether a sequence encoder beats a tabular model. (The prototype slice cannot answer this.)
2. **Event richness / per-channel frequency** — distinct `channel×interaction` types; confirm Email/DM/Leads sparsity and the broken direct-mail sourcing (OQ2).
3. **Confirmed volume per layer** — verify the ≈2–3M / ≈500K / ≈10–15M counts and the prototype window end date.
4. **Timestamp quality / granularity** — needed for time-gap embeddings (BST) / TPP; coarse timestamps erode the temporal edge.
5. **Combo support** — distinct observed channel combinations + their conversion volume; whether enough exists to **hold out unseen combos** (gates the set head / combos, OQ36).
6. **Overlap / positivity per channel** — gates any uplift estimate's defensibility; root of the current DR instability.
7. **Label horizon / censoring** — next-touch vs long-term engagement; whether the outcome should be time-to-event/censored (C14/F2).
8. **Is timing/multi-step in product scope?** — decides whether TPP/RL ("when", sequences) are in or out.
9. **Sequence-readiness of Layer 4** — confirm sequence construction, timestamp validity, channel coverage, and label-window design before trusting any sequence model.

## 13. Modeling Assumptions

- **Lift/uplift/CATE is OPTIONAL, not the default MVP objective.** It is one legitimate scoring objective computable from the same scorer (`score(A) − score(∅)`), worth keeping mainly at the **contact/no-contact margin**, where budget demands ranking by *incremental* return, or once an experiment exists. Default the MVP to a **predictive/ranking score** — more accurate, *measurable* on a plain time-based holdout, no positivity/confounding prerequisites (the very things currently broken), lower D005/compliance risk. Uplift stays one line away. **(confirmed framing)**
- **Do not conflate** "we must not *claim* causal uplift without an experiment" (true, D005) with "the model must *produce* causal uplift" (false).
- S-learner uplift is "good enough" for any v1 uplift derivation; rigorous confounding-adjusted heads (Causal/G-Transformer) are a Week-4 pilot question, not V1.
- Treatment-as-input only (leakage guard). `W_test = zeros` ("all other channels off") is a strong, possibly unintended counterfactual to revisit (OQ7, C3).
- Channel-level is the right actionable unit (D002/D006). Combos/ordered sequences/RL/"when-to-contact" are V2+ — assess realism, do not build in the spike.
- **Do not assume the data regime favors GBDT over a transformer** (or vice-versa) until §12 profiling is done; the prior "match not beat" default is re-opened.

## 14. Evaluation Requirements

- **Fix the evaluation design *before* modeling** so the comparison is fair and not circular (OQ43).
- **Adopt a time-based / windowed holdout** (train ≤ t, test > t), not the random split (C6).
- **Predictive metrics primary:** AUC / PR-AUC / calibration (Brier, reliability), NDCG / Recall@k.
- **Qini / AUUC and IPS/DR off-policy evaluation with CIs ONLY if an uplift business claim is on the table** — not by default; replace the "lucky match" comparison with a proper off-policy estimator if a policy-value claim is needed (C7/C11; OQ22).
- **Baseline comparison protocol:** transformer vs strengthened XGBoost/DR on the same time split, same data source, same metric — and, where possible, on the **full-data Layer-4** dataset so the comparison is not on the prototype slice.
- Reusable eval harness exists (UpliftBench: Qini/AUUC/policy-sim + GBDT baselines).
- **Claim discipline (D005):** no DR CI/p-value until C1/OQ5 fixed; do not present +11.18% AUC as "beating PRISM"; no incremental-uplift number without experiment or defensible OPE.

## 15. Candidate Implementation Paths (from research; design agent chooses)

Spike-grade (a model + a fair comparison + a design decision), 2–4 weeks. Effort labels reflect engineering; **accuracy-vs-GBDT expectations are now data-gated, not pre-judged.**

- **CP1 — Temporal-feature XGBoost, action-as-feature** *(F0/P0)* — baseline & floor; unblocks time-based holdout. **2–4 wk: yes.**
- **CP2 — Tabular/temporal transformer, action-as-input, predictive output** *(A1 FT-Transformer / A2 TFT)* — **primary MVP candidate.** Honors the transformer mandate + reusable-scorer/config-layer requirement; checkable on a plain holdout; no positivity prerequisites; uplift optional via difference. **2–4 wk: yes (spike), assuming a usable Layer-4 subset.**
- **CP3 — Hybrid: transformer encoder → existing XGBoost/DR** *(R2)* — **co-MVP / low-risk fallback.** Lowest compliance disruption (reuses approval lineage); directly measures the encoder's marginal value. **2–4 wk: yes.**
- **CP4 — Sequence-rec encoder (SASRec/BST) + action-conditioned head** — conditional alternative; its case is **stronger if §12 confirms long/dense journeys in the full data**. **2–4 wk: partial.**
- **CP5 — Self-supervised pretraining / multi-task scorer** — prediction-first stretch; the **larger full-data volume makes pretraining more attractive** than the prototype slice implied. **2–4 wk: partial.**
- **CP6 — Causal/uplift head** (Causal/G-Transformer rigorous; or grf Causal Survival Forest for censored data; or cheap S-learner difference) — **optional objective, stretch/deferred.** Rigorous DL not a 2–4 wk drop-in.
- **Cross-cutting primitive A5** — Deep-Sets/Set-Transformer treatment encoder (~50 lines) making CP2/CP4/CP6 score arbitrary combos compositionally. Build only if combos are near-term scope; else defer (V2).
- **Recommended sequencing:** build the Layer-4 dataset + CP1 (baseline + holdout + process-layer skeleton) → CP2 (or CP3 if GPU/library/data-prep friction) → A5 set head if combos in scope → optional CP6 Week-4 pilot. **The Layer-4 build is the gating item; if it overruns, fall back to CP1/CP3 on the prototype subset and report the data dependency.**

## 16. Conflicts / Inconsistencies Across the Files

1. **Data scale.** Older research files (`transformer_sequence_modeling_review.md`, `transformer_practical_literature_and_repo_scan.md`, `method_critiques.md` C14) repeatedly describe the data as "~500K customers / ~2.8M rows / moderate volume / ~100× below TIMeSynC" and conclude a transformer will "match, not beat" XGBoost. The 2026-06-16 data-scale correction (and the updated snapshot/decision register) establish the four-layer view: prototype subset ≈2–3M, test ≈500K, **full source ≈10–15M since ≈2022.** *Direct factual conflict.*
2. **Transformer match-vs-beat expectation.** Flows from conflict 1: the research files' "expect parity" is a scale-dependent inference now **re-opened**, not settled.
3. **Default objective: uplift vs prediction.** Older files (method review, critiques, implementation plan) center on uplift/CATE/lift; the 2026-06-16 scan de-emphasizes lift and defaults the MVP to a predictive/ranking score. *Emphasis conflict.*
4. **Recommended next step: transformer vs "lighter-models-first."** The 06-15b sequence review and C14 conclude a transformer is **not** the right next step for this data; D004 confirms the **transformer as the primary direction.** *Research recommendation vs management decision.*
5. **"uplift(A)" vs "score(A)" labeling** of the core-model output (implementation plan vs consolidated scan). *Labeling inconsistency on the same architecture.*
6. **Optimizer objective: conversion vs uplift.** Implemented optimizer maximizes predicted **conversion**; method review (C8) says **incremental lift**; the de-emphasis correction says predicted-conversion ranking is decision-equivalent for "which channel given contact." *Three-way tension.*
7. **OPE emphasis.** The sequence review de-emphasizes OPE; the method review/open questions push IPS/DR-OPE as the principled replacement for "lucky match." *Scope/emphasis inconsistency.*
8. **"Beating PRISM."** The deck/early narrative implies Lumen beats PRISM (+11.18% AUC); D005/C7 forbid the claim. *Resolved in the register; flagged because the number still circulates.*

## 17. Recommended Resolution For Each Conflict

1. **Data scale:** Adopt the **four-layer view (§2–§3)** as authoritative (latest change log + updated current-state files). Treat every "~500K / moderate volume" statement in older research files as **(outdated)**; read their *method* content as still valid but their *scale framing* as superseded.
2. **Match-vs-beat:** Treat as **re-opened, pending §12 profiling of the full data.** Neither assert a transformer will beat GBDT nor that it will only match — decide on measured journey-length/volume/richness.
3. **Objective:** Default MVP objective = **predictive/ranking score; uplift is optional**, derived from the same scorer when the decision includes contact/no-contact, scarce budget, or an experiment.
4. **Next step:** Honor **D004 (transformer is the directed path)** but keep CP1 (strengthened XGBoost) as the mandatory baseline/floor; "transformer matches but doesn't beat GBDT" remains a legitimate, valuable outcome — to be judged on the full-data comparison, not the prototype slice. Lighter ladder remains the documented fallback.
5. **Labeling:** Use **`score(A)`** as the architecture-neutral output; `uplift(A)` is one derivation. Architecture, set encoding, and optimizer are unchanged by the relabel.
6. **Optimizer objective:** Keep **predicted-conversion ranking for the MVP**; switch to lift only at the contact/no-contact margin or once an experiment validates it (a low-cost wiring change).
7. **OPE:** OPE/Qini/AUUC are **conditional** tools tied to an uplift/policy claim, not default spike metrics. Default spike metrics are predictive on a time-based split.
8. **PRISM:** Hold D005 — no "beats PRISM" claim; +11.18% AUC is suggestive internal ranking evidence on a biased subset only.

## 18. Remaining Open Questions for Chat 2

Gating (data facts; measure on the full source while building Layer 4 — see §12): journey-length distribution; event richness / per-channel frequency (OQ26); confirmed counts per layer + prototype window end date (OQ3); timestamp quality (OQ28); combo support / hold-out feasibility (OQ36); overlap/positivity per channel; label horizon / censoring (OQ30); is timing/multi-step in scope (OQ29).

Data engineering (new critical path): **building the Layer-4 cleaned, transformer-ready dataset** — minimum prep before the spike can produce a meaningful result, and the fallback if it overruns (OQ40).

Decision/scope: v1 use-case subset (OQ41); "finalize the design" deliverable + evidence bar (OQ42); baseline-comparison protocol — metric, split, data source/layer (OQ43); build the A5 set/combo primitive now or defer; whether a rigorous causal head (CP6) earns a Week-4 pilot (OQ35).

Data foundation (underneath the timeline): MTA vs TMIA vs hybrid (OQ1); direct-mail sourcing fix (OQ2); time-based split adoption (OQ9).

Baseline-only (affect a fair comparison): fix underdetermined covariance for any DR inference (OQ5/OQ6, C1/C2); `W_test=zeros` intent (OQ7); calibration (OQ8); optimizer objective conversion-vs-lift (OQ20).

Contract/interface: `effective_date` semantics (scoring vs decision vs label horizon); no-contact representation (explicit, confirm with business); who owns the candidate-action universe each cycle; score-comparability across `score_type`/`model_id`.

## 19. What Chat 2 Should Rely On As the Authoritative Interpretation

1. **Data scale is the four-layer view (§2–§3):** prototype subset ≈2–3M, prototype test ≈500K, full source ≈10–15M since ≈2022 (all approx); the cleaned transformer-ready dataset (Layer 4) **does not exist yet and must be built.** Do **not** call Lumen "~500K / moderate volume." Scale-dependent conclusions (architecture fit, match-vs-beat) are **re-opened pending profiling**, not settled. The full data is **not** transformer-ready until §12 profiling/cleaning confirms it.
2. **Transformer is the confirmed direction; XGBoost/DR is baseline/fallback; package is deferred; flexible config-driven outputs are a confirmed requirement** (D001/D003/D004/D009/D011 + both 2026-06-16 change logs).
3. **Separate the external output contract from the internal model architecture.** Design the contract (§9–§10: long PRISM-style score table + registry + separate assignment table) so any model family and objective can change without downstream re-engineering. Decide the contract before locking the model.
4. **Default the V1 objective to a predictive/ranking score; lift/uplift/CATE is OPTIONAL, not the default**, not rejected — keep it derivable (`score(A) − score(∅)`), carry `score_type` + nullable CI columns, but do not make it structural. Most flexible-output use cases are decision-layer operations over single-channel scores, so **V1 single-channel scoring unlocks most asks.**
5. **The final design agent decides among prediction-first, ranking-first, candidate-action scoring, hybrid, and uplift-style approaches** based on the **corrected data facts (§2–§3), §12 profiling, feasibility, and system constraints** — not a prior default. The "action-as-input core model + thin config-driven process/optimizer layer" (D010) is the objective-agnostic architecture to build around; combos via compositional set encoding, never 2^N enumeration.
6. **The Layer-4 data build is the gating dependency under the 2–4 week timeline.** If it overruns, fall back to CP1/CP3 on the prototype subset and report the dependency.
7. **Hold claim discipline (D005):** no causal CI/p-value until C1 is fixed; no incremental-uplift claim without experiment or defensible OPE; no "beats PRISM"; a separate compliance/validation path applies to any new architecture.
8. **Treat `01_current_state/` as source of truth and this file as the consolidated design input;** where this document and older research files differ, the resolutions in §17 govern, and the data-scale correction overrides any "~500K / moderate volume" framing.

---

*Sources consolidated: `01_current_state/{current_snapshot, decision_register, open_questions, context_index}.md`; `02_change_log/{2026-06-16_manager_transformer_decision, 2026-06-16_data_scale_correction}.md`; `03_research_memory/{research_index, literature_notes, reference_bank, method_critiques, transformer_sequence_modeling_review, transformer_implementation_plan, transformer_practical_literature_and_repo_scan, production_score_contract_options}.md`; `04_outputs/2026-06-15_method_review.md`. No new research performed; no facts invented; counts marked approximate; uncertain items marked. Scale-dependent conclusions in older research files are superseded by the data-scale correction.*
