# Decision Register

## Status Labels

Use these statuses: Proposed, Tentative, Confirmed, Revised, Deferred, Rejected, Outdated. Historical decisions are preserved with updated statuses rather than deleted.

Last reviewed: 2026-06-16. Supporting detail in `02_change_log/2026-06-15_update.md` and `02_change_log/2026-06-16_manager_transformer_decision.md`.

## Decisions

### D001 — Use XGBoost + Doubly Robust as the practical baseline

Status: **Confirmed / Implemented — now repositioned as baseline / comparison, not the primary direction** (was: confirmed/implemented as the practical baseline; seeded from archive). Caveat noted below.

**2026-06-16 update:** with the transformer confirmed as the primary direction (D004), the XGBoost/DR implementation is now the **baseline/benchmark and fallback** against which the transformer is evaluated, rather than the main modeling direction. It is retained, not deprecated.

**2026-06-16 (data-scale correction):** this baseline was trained on a **prototype experiment subset (≈2–3M customers, approx)** and evaluated on a **prototype test set (≈500K, approx)** — these are *not* the full population. The baseline therefore reflects the prototype slice, not the full ~2022+ source (≈10–15M customers, approx). See `02_change_log/2026-06-16_data_scale_correction.md`.

Interpretation: Implemented as econml `LinearDRLearner` with XGBClassifier propensity + XGBRegressor outcome, 5-fold cross-fitting, one-vs-rest treatments. Predicted potential outcomes feed the optimizer.

Rationale: fast, familiar, strong on tabular data, interpretable, pragmatic improvement over raw attribution/naive Shapley.

Risks / caveat: DR inference is numerically unstable (underdetermined covariance, `zstat=-inf`), so causal estimates/CIs are not yet trustworthy; observational confounding, overlap, and counterfactual-evaluation concerns remain. **2026-06-15 review:** root cause of the instability identified (rank-deficient final-stage design from one-vs-rest treatment-in-X collinearity + rare channels + overlap violations); the deployable point scores are less affected than the inference layer. A `CausalForestDML` benchmark is recommended as both a robustness check and an estimator that avoids the linear final stage (see OQ24, `method_critiques.md` C1).

### D002 — Prefer channel-level recommendations over reaction-level

Status: **Confirmed.**

Interpretation: Channel-level treatment is more actionable (the business chooses the channel, not the customer's reaction). The **grouped channel-level** model is the canonical predictive granularity (see D006).

### D003 — Sequencing of package vs. transformer

Status: **Revised → Deferred / Secondary** (was: package-first before transformer; then revised/superseded).

Interpretation: The archived "build a reusable package first" plan is superseded by the **manager-directed model-first** direction (see D009). The deck's roadmap that placed the package (Q3) before the transformer (Q4) is outdated and pending revision.

**2026-06-16 update:** package-first is explicitly **deferred / secondary, not dropped** — the package remains a later goal once a deployable model exists. Note the *reusable scorer + config-driven layer* now being pursued (D010/D011) delivers reusability at the model/serving level without a standalone package.

### D004 — Transformer / sequence modeling

Status: **Confirmed — manager/team-directed as the primary modeling direction** (was: manager-directed to pursue / planning spike; earlier: under active consideration; earlier: future research phase).

**2026-06-16 update (manager/team decision):** the transformer is now the **confirmed primary direction**, with a **~2–4 week spike** to produce a model, run experimentation, and finalize the design ("good enough," not perfect). This confirms the *direction* only — **not a proven, built, or production-ready model**; the spike's outcome is unknown. XGBoost/DR is the baseline (D001); the lighter-model ladder (temporal-feature XGBoost, causal survival forest, GRU/Markov) remains a valid fallback. Carried-forward caveats: no live validation; a new architecture needs its own compliance/model-validation path; data-foundation issues sit underneath the timeline. Plan in `03_research_memory/transformer_implementation_plan.md`.

**2026-06-16 (data-scale correction):** earlier feasibility framing (in `04_outputs/transformer_design_input_snapshot.md`) understated the data by treating the prototype ~500K test slice as the full population, which fed a "transformer will likely only *match* XGBoost (moderate volume)" inference. Corrected: the full source is **≈10–15M customers since ≈2022 with long touchpoint histories (approx)** — plausibly **more** favorable for sequence/transformer modeling, so that match-not-beat expectation is **re-opened** (not refuted) pending profiling. New hard dependency: the **cleaned, transformer-ready dataset does not exist yet** and must be built (sequence construction, timestamp validation, channel coverage, label-window) before the spike can use the full data — a real risk against the 2–4 week timeline. See `02_change_log/2026-06-16_data_scale_correction.md`.

Interpretation: A transformer (LiDDA-inspired; arXiv 2505.09861v3) is being considered, including the possibility of going transformer-first rather than productionizing the XGBoost model as v1 — partly because each delivery carries a long approval/model-validation/compliance cycle and the transformer cannot inherit the XGBoost approval path. Effort and fit are unknown; not decided. (LiDDA solves attribution, not next-best-action — architecture reference only; assessment to confirm.)

**2026-06-15c update:** the manager is **persisting on the transformer path**, so the team is now scoping a **2–4 week plan + initial experiments** (good-enough, not perfect). A build-oriented shortlist and plan are in `03_research_memory/transformer_implementation_plan.md` (5 ranked core options A1–A5; recommended start: FT-Transformer or TFT with the action as input, S-learner uplift, then a set-pooled combo head, then a Causal-Transformer/G-Transformer pilot). Note: this is a planning/experimentation spike, **not** an implemented or approved production decision; the prior caveats (no live validation, separate compliance path) still stand. Supersedes the 2026-06-15b "lighter-models-first" recommendation as the *directed* path, though those models remain valid fallbacks/baselines.

### D005 — Do not overclaim causal validity or business uplift before stronger validation

Status: **Active / Reaffirmed.**

Interpretation: Offline DR/CATE estimates, the deck's model-estimated +~10% lift, and the OPE +11.18% AUC vs PRISM are model-estimated/exploratory. Reinforced by: numerically invalid DR inference, run-to-run ATE variability, a non-temporal split, and an OPE based on a small (~7,070) selection-on-agreement subset that is not significance-tested. Live experiment or a defensible off-policy design is needed before claiming true incremental impact. **2026-06-15 review reaffirms this** and adds explicit claim guidance (what can / cannot be said) in `04_outputs/2026-06-15_method_review.md` §7 — notably: do not present the +11.18% AUC as "beating PRISM" (ranking on a biased subset, different data) and do not cite any DR confidence interval/p-value until OQ5 is fixed.

### D006 — Grouped channel-level as the canonical predictive granularity

Status: **Confirmed** (team). New (2026-06-15).

Interpretation: Of the three built granularities (single channel×interaction, grouped channel, 8-state combinatorial), the **grouped channel-level** DR model (one lift score per controllable channel) is the model used for the predictive/optimizer path.

### D007 — Prefer Doubly Robust over naive Shapley for attribution

Status: **Confirmed** (team), evidence-backed. New (2026-06-15).

Interpretation: A documented Shapley-vs-DR comparison shows disagreements and sign flips; DR is preferred for its selection-bias correction. Applies to the diagnostic lens.

### D008 — Combinatorial (multi-channel) treatment model

Status: **Deferred / Shelved.** New (2026-06-15).

Interpretation: An 8-state combinatorial treatment over {Email, Leads, Direct} was built and explored, then shelved (commented out in the TMIA final notebook). It remains the natural basis if the business later wants multi-channel ("next N channels") plans.

### D009 — Model-first over package-first

Status: **Confirmed — manager-directed.** New (2026-06-15).

Interpretation: The manager has directed that the deployable, registered model is the priority and the reusable package is secondary; predictive/next-best-channel is prioritized over diagnostic. The package would likely be named "Lumen" (undecided) and would be hosted in the "Atlantis" environment; another team would ultimately build/own the packaged model.

Risks: packaging/ownership and the long compliance/model-validation cycle remain dependencies; reproducibility gaps (models not persisted, messy notebooks) must be closed before registration.

### D010 — Treatment-conditional core model + assignment process (combo scoring on demand)

Status: **Proposed** (design pattern; reflects a stated business requirement). New (2026-06-15c).

Interpretation: To meet the business need that channel/combo assignments change monthly and should not be pre-enumerated, adopt a **single core model where the proposed action-set is an INPUT** (not 2^N output heads), plus a **thin, reconfigurable process layer** that each month scores only business-relevant candidate sets and runs constrained assignment. Combos are handled **compositionally** via a permutation-invariant set encoding of channel embeddings (Deep Sets / Set Transformer), so unseen combos remain valid; a single channel is a size-1 set. Pragmatic uplift via S-learner (`pred(A) − pred(∅)`); rigorous via Causal/G-Transformer. Detail in `03_research_memory/transformer_implementation_plan.md`.

Rationale: decouples the model from changing business rules (config change, no retrain); avoids the shelved combinatorial model's explosion (see D008); reuses the existing constrained optimizer.

Risks: offline uplift remains model-estimated (needs live validation, per D005); set-pooling combo generalization must be validated (OQ36); treatment must enter only via the action-input to avoid the leakage that broke DR inference (C1/C2).

**2026-06-16 update:** the **requirement** this pattern serves (a reusable scorer + a separate config-driven scoring/optimization layer) is now a **confirmed manager/team requirement** (see D011). The specific realization (set-pooled core, action-set-as-input, S-learner uplift v1, optional Causal/G-Transformer head) remains a **proposed/prototyping design** to be validated in the D004 spike.

### D011 — Flexible, config-driven business-output requirement

Status: **Confirmed — manager/team requirement.** New (2026-06-16).

Interpretation: The model/design must support flexible business use cases, not only "one next channel." Confirmed in-scope use cases that the design must accommodate over time: **top-1 channel, top-K channels, multiple channels per customer, capacity constraints, allowed-channel filters, no-contact logic, and different objectives.** The agreed means is a **reusable scorer** (single core model) plus a **separate config-driven scoring/optimization layer** that produces the business-specific outputs each cycle without retraining — realized via the D010 design pattern.

Rationale: future business requests are expected to vary; decoupling the scorer from the output policy lets the business reconfigure outputs (config change, no retrain) and reuses the existing constrained optimizer.

Risks / open: which subset of use cases is in scope for v1 vs later is undecided (OQ41); set-pooled combo generalization must be validated (OQ36); all offline outputs remain model-estimated pending validation (D005).
