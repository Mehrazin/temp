# Causal Next Best Action for Financial Marketing: A PhD-Level Literature Review

## TL;DR
- The single most promising direction is a **transformer-based, treatment-as-input (candidate-conditioned) two-tower/representation model trained to estimate conditional treatment effects on reaction-based journey data**, regularized with an R-learner / DR-learner (Neyman-orthogonal, doubly-robust) objective and evaluated with off-policy estimators (IPS/DR) and Qini/AUUC — this is the only family that simultaneously satisfies all three of the project's hard constraints: causal estimands, sequence/temporal modeling of the journey, and inference-time scoring of arbitrary candidate actions without retraining.
- Pure uplift meta-learners (S/T/X-learners) and tree-based causal forests give rigorous CATE estimation but do not natively consume long heterogeneous journeys and (T/X variants) do not scale to arbitrary action spaces at inference; pure sequential recommenders (SASRec/BERT4Rec/TIMeSynC/FinTRec) model the journey beautifully but are correlational and answer "what will the customer do next," not "what action causes the best incremental outcome."
- The defining research gap is causal NBA on **reaction-based (not exposure-based) observational journeys with no explicit no-treatment records**, which structurally threatens the positivity/overlap and unconfoundedness assumptions; the recommended architecture must be paired with explicit overlap diagnostics, sensitivity analysis for hidden confounding, and a candidate-scoring head, because the data limitation — not the model class — is the binding constraint.

## Key Findings

1. **The problem is a causal policy-learning problem disguised as a recommendation problem.** The objective ("recommend the action that maximizes incremental conversion") is an individual-treatment-effect / CATE optimization, not a next-item likelihood. This is the central distinction in the uplift-modeling literature (Radcliffe; Künzel et al. 2019) and the causal-recommendation surveys (Gao et al. 2022; Zhu et al. 2023).

2. **Treatment-as-input architectures are the bridge between causal estimation and flexible inference.** Putting the candidate action in as a model input (S-learner-style, or a dedicated treatment tower/token as in EFIN, DESCN, MTMT, M3TN) is precisely what enables scoring arbitrary candidate actions at inference without retraining — the user's explicit requirement. T-learner/X-learner-style per-arm models cannot do this for a large or growing action space.

3. **Reaction-based data is the binding constraint.** Because the data records customer reactions (email opened/clicked) and generally lacks "sent-but-no-reaction" and explicit no-treatment records, the control/exposure baseline is largely missing. This is a structural positivity/overlap problem (D'Amour et al. 2020; Matsouaka 2024) and a hidden-confounding problem, and it is the dimension on which methodological rigor matters most.

4. **Doubly-robust / orthogonal learners are the most defensible estimators under this data limitation.** The R-learner (Nie & Wager 2021) and DR-learner (Kennedy 2023), built on Double/Debiased ML (Chernozhukov et al. 2018), give Neyman-orthogonal estimators whose CATE error depends only on the product of nuisance errors — the right robustness property when propensity is hard to estimate from reaction data.

5. **Transformers already work for financial journeys but not yet causally.** TIMeSynC and FinTRec (Capital One) prove transformer sequence models deploy well on heterogeneous financial journeys at industrial scale and latency, but both are predictive/correlational (intent prediction, pCTR/pCVR), not causal — leaving an explicit gap the project can fill.

6. **Off-policy evaluation, not next-item recall, is the correct offline metric.** Since recommending a future action is choosing a policy, the project should evaluate with IPS/SNIPS/DR off-policy estimators (Dudík et al.; Swaminathan & Joachims 2015; Saito & Joachims 2022) and uplift-ranking metrics (Qini, AUUC), not Recall@k.

7. **RL/contextual bandits are out of scope for good reasons here.** Pure RL/bandits require either online exploration or well-defined logging propensities and no-action records, which the reaction-based observational data lacks; the causal-estimation + policy-extraction framing is more appropriate and is what the user requested.

## Details

### A. The causal formulation: potential outcomes, CATE, and why NBA is causal
The grounding framework is the Rubin/Neyman potential-outcomes model: for unit i and action (treatment) a, we posit potential outcomes Y_i(a), and the estimand for NBA is the conditional average treatment effect τ(x,a) = E[Y(a) − Y(0) | X=x], or more generally a contrast between candidate actions. Identification from observational data rests on three assumptions: (1) unconfoundedness/ignorability (no unmeasured confounders), (2) positivity/overlap (every covariate profile has nonzero probability of each action), and (3) SUTVA/consistency. The reaction-based journey data threatens (1) and (2) directly: customers who reacted are systematically different from those who did not, and "no-treatment" is largely unobserved. Uplift modeling is the marketing-specific instantiation of CATE estimation (Künzel et al. 2019; Gutierrez & Gérardy 2017), segmenting customers into persuadables / sure-things / lost-causes / sleeping-dogs.

### B. Uplift meta-learners (the user's focus area)
- **S-learner** (single model, treatment as feature; Künzel et al. 2019): one model μ(x,a); CATE = μ(x,1)−μ(x,0). Strength: treatment-as-input → natively scores arbitrary actions at inference without retraining. Weakness: can "ignore" a weak treatment feature and bias CATE toward zero (regularization bias). It is the conceptual ancestor of treatment-as-input deep nets.
- **T-learner** (two models): separate μ_0, μ_1. Strength: captures strong heterogeneity. Weakness: does not share data across arms; biased with imbalanced arms; does not scale to many/arbitrary actions at inference (one model per arm).
- **X-learner** (Künzel et al. 2019): cross-imputes treatment effects, then regresses on covariates; excels with treatment imbalance (e.g., few reactors).
- **R-learner** (Nie & Wager 2021, Biometrika): Robinson-style orthogonalization; minimizes the "R-loss" using estimated marginal outcome m(x) and propensity e(x). Robust to confounding structure; quasi-oracle rates.
- **DR-learner** (Kennedy 2023, EJS): doubly-robust pseudo-outcome regression; CATE consistent if either propensity OR outcome model is correct; bias depends on product of nuisance errors. Best choice when the CATE is simpler than the response surfaces and propensity is learnable, but can be unstable under extreme propensities (exactly the reaction-data risk).
- **Comparison consensus**: across empirical studies, X/R/DR-learners outperform S/T; DR/R are preferred when propensity is learnable and CATE is simpler than outcomes; X-learner is preferred under severe arm imbalance and weak overlap. For multi-treatment with cost, Zhao & Harinen (2019) extend X/R-learners.
- **Tree/forest methods**: Causal forests / Generalized Random Forests (Wager & Athey 2018; Athey, Tibshirani & Wager 2019) give nonparametric CATE with confidence intervals but rely on selection-on-observables and do not consume raw sequences.

### C. HTE deep nets and treatment-as-input architectures (the user's emphasized family)
- **TARNet / CFR** (Shalit et al. 2017): shared representation + per-treatment heads; CFR adds an IPM (MMD/Wasserstein) balance penalty to align treated/control distributions — directly relevant to reaction-vs-non-reaction imbalance.
- **Dragonnet** (Shi et al. 2019): three-headed net (two outcome heads + propensity head) with targeted regularization; data-efficient confounder representation.
- **DESCN** (Zhong et al. 2022, KDD, Alibaba): entire-space cross network jointly modeling propensity, response, and pseudo-treatment-effect to counter treatment bias and sample imbalance. DESCN was validated on Alibaba's Lazada (South-East Asia) voucher-distribution production data, achieving a 4.9% relative AUUC improvement and an ~84% reduction in εATT over CFRmmd (Zhong et al., KDD '22, arXiv:2207.09920).
- **EFIN** (Liu et al. 2023, KDD, Tencent FiT): explicitly encodes treatment features as input (treatment-aware interaction module), with an intervention-constraint module to balance ITE distributions under non-random intervention. EFIN's one-month online A/B test in Tencent FiT's credit card bill-payment scenario, involving hundreds of millions of users, delivered a 10% improvement in marketing ROI and an 8% increase in monthly active users (MAU) over the multi-head extended T-learner+XGBoost baseline (Liu et al., KDD '23, arXiv:2306.00315). Crucially it is designed so treatment options "may be binary, multi-valued, or continuous, without significantly increasing the size of the model" — the candidate-scoring property the project needs.
- **MTMT** (Wei et al. 2024, arXiv:2408.12803): MTMT was built by Tencent's ITE team and deployed on Tencent's gaming platform for personalized bonus allocation; per the paper it "separately encodes user features and treatments. The user feature encoder uses a multi-gate mixture of experts (MMOE) network." A self-attention user–treatment interaction module uses the treatment embedding as query. MTMT "identif[ies] the multi-treatment problem as a causal inference problem with a tiered response, comprising a base effect (from offering a treatment) and an incremental effect (from offering a specific type of treatment), where the base effect can be numerically much larger than the incremental effect" (Wei et al., arXiv:2408.12803). At deployment it permutes all possible combinations of treatments and ranks the resulting uplifts — explicit inference-time arbitrary-action scoring.
- **M3TN** (Sun & Chen 2024, ICASSP): multi-valued treatment network with reparameterization for uplift; reduces parameter blow-up of many heads.
- **DRNet / VCNet** (Schwab et al. 2020; Nie et al. 2021): continuous/dose treatments — relevant if "intensity" of a channel matters.
- **Causal Transformer** (Melnychuk et al. 2022, ICML): transformer with three sub-networks (covariates, past treatments, past outcomes) + counterfactual domain-confusion loss for counterfactual outcomes over time — the closest existing architecture to "transformer + treatment-as-input + temporal confounding," though developed for medicine.

### D. Transformer sequential recommendation (the journey backbone)
Foundational: Transformer (Vaswani et al. 2017); SASRec (Kang & McAuley 2018, causal self-attention next-item); BERT4Rec (Sun et al. 2019, bidirectional/Cloze). Industrial: BST (Alibaba), TransAct & PinnerFormer (Pinterest), Transformers4Rec (NVIDIA). These define the journey encoder but are correlational. For the project, the journey encoder is necessary but must be conditioned on a candidate action and trained against a causal objective.

### E. Heterogeneous tabular/temporal sequential modeling (financial data backbone)
TabBERT (Padhi et al. 2021), FATA-Trans (Zhang et al. 2023, CIKM — separates static vs dynamic fields, time-aware), UniTTab (Luetto et al. 2023 — row-type embeddings, time-dependent heterogeneous tabular). These handle exactly the project's data shape (timestamped, channel-typed, mixed categorical/numeric reactions + monthly propensity-vector snapshots). TIMeSynC and FinTRec are the direct financial-domain anchors (encoder–decoder, TimeAliBi temporal attention; FM-embedding context fusion; LoRA product adaptation).

### F. Off-policy evaluation & learning (the correct evaluation regime)
IPS/Horvitz–Thompson, SNIPS (Swaminathan & Joachims 2015), Doubly-Robust (Dudík et al. 2014), DR with shrinkage (Su et al. 2020), MIPS/MDR for large action spaces (Saito & Joachims 2022). Counterfactual Risk Minimization / POEM (Swaminathan & Joachims 2015) is the off-policy *learning* analog. These matter because (a) recommending future actions = choosing a policy, and (b) the project lacks randomized exposure, so propensity-weighted estimators (with their positivity caveats) are the honest offline evaluators.

### G. Why NOT RL/bandits as the primary approach
Contextual bandits and RL for NBA (e.g., deep-Q NBA frameworks; reinforced coupled recurrent networks) need online exploration or accurate logging propensities and explicit action/no-action records. The reaction-based data has neither reliable logging propensities nor no-treatment records, so off-policy RL would be high-variance and poorly identified. The causal-estimation-then-policy-extraction path is more defensible and is what the user scoped.

### Categorization by research direction
- **Causal NBA / causal recommendation**: Gao et al. 2022; Zhu et al. 2023; Wang et al. 2023 (Causal Recommendation: Progresses & Future Directions); NBA-RL/CRN (Cao et al.).
- **Uplift meta-learners**: Künzel et al. 2019; Nie & Wager 2021; Kennedy 2023; Zhao & Harinen 2019; Gutierrez & Gérardy 2017.
- **HTE estimation / DML / forests / deep nets**: Chernozhukov et al. 2018; Wager & Athey 2018; Athey et al. 2019; Shalit et al. 2017; Shi et al. 2019.
- **Treatment-as-input / two-tower causal**: EFIN 2023; DESCN 2022; MTMT 2024; M3TN 2024; HydraNet 2023; Causal Transformer 2022.
- **Transformer sequential rec**: Vaswani 2017; SASRec 2018; BERT4Rec 2019; BST; TransAct; PinnerFormer; Transformers4Rec.
- **Heterogeneous tabular sequential (finance)**: TabBERT 2021; FATA-Trans 2023; UniTTab 2023; TIMeSynC 2024; FinTRec 2025.
- **Off-policy eval/learning**: Dudík et al. 2014; Swaminathan & Joachims 2015; Su et al. 2020; Saito & Joachims 2022.

### Tier rankings
**Tier 1 — Must Read**
- Künzel et al. 2019 (Meta-learners, PNAS) — defines S/T/X-learners, the user's core interest.
- Nie & Wager 2021 (R-learner, Biometrika) — orthogonal CATE loss; backbone of the recommended objective.
- Kennedy 2023 (DR-learner, EJS) — doubly-robust CATE; best robustness story for reaction data.
- Shalit et al. 2017 (TARNet/CFR) — representation balancing for treated/control imbalance.
- EFIN (Liu et al. 2023) — treatment-as-input deep uplift in financial marketing with inference-time candidate scoring.
- Chernozhukov et al. 2018 (Double/Debiased ML) — orthogonalization + cross-fitting foundation.
- TIMeSynC (Katariya et al. 2024) & FinTRec (Katariya et al. 2025) — the financial-journey transformer anchors.
- Causal Transformer (Melnychuk et al. 2022) — transformer + treatment + temporal confounding.

**Tier 2 — Highly Relevant**
- Wager & Athey 2018; Athey, Tibshirani & Wager 2019 (causal/generalized random forests).
- Shi et al. 2019 (Dragonnet).
- DESCN (Zhong et al. 2022); MTMT (Wei et al. 2024); M3TN (Sun & Chen 2024) — multi-treatment, candidate-scoring.
- SASRec (2018), BERT4Rec (2019) — journey-encoder baselines.
- FATA-Trans (2023), UniTTab (2023), TabBERT (2021) — heterogeneous tabular sequence backbones.
- Swaminathan & Joachims 2015 (CRM/POEM); Dudík et al. 2014 (DR-OPE); Saito & Joachims 2022 (MIPS) — OPE/L.
- Gao et al. 2022; Zhu et al. 2023 (causal recommendation surveys).

**Tier 3 — Supporting**
- Zhao & Harinen 2019 (multi-treatment uplift w/ cost); Generalized Causal Tree 2022.
- DRNet/VCNet (continuous treatments); predict-then-optimize continuous uplift (2024).
- Positivity/overlap-weights literature (Matsouaka 2024; D'Amour et al. 2020; GP-prior positivity 2021).
- Qini/AUUC evaluation references (Radcliffe; Gutierrez & Gérardy 2017).
- BST/TransAct/PinnerFormer/Transformers4Rec (industrial sequence rec).

**Tier 4 — Background**
- Vaswani et al. 2017 (Transformer).
- Robinson 1988 (semiparametric regression, R-learner root).
- General NBA industry pieces (Pega, WWT); RL-for-NBA blogs/CRN.
- TabTransformer/TabNet (non-sequential tabular).

### Comparison table (most relevant methods)
| Method | Causal? | Treatment-as-input / candidate scoring | Sequential/temporal | Handles observational data | Inference-time arbitrary-action scoring w/o retrain | Financial-domain relevance | Evaluation methodology |
|---|---|---|---|---|---|---|---|
| S-learner | Yes (CATE) | Yes | No (tabular) | Yes (assumes ignorability) | Yes | Medium | Qini/AUUC |
| T-/X-learner | Yes | No (per-arm) | No | Yes | No (poor for many arms) | Medium | Qini/AUUC, PEHE |
| R-/DR-learner | Yes (orthogonal/DR) | Via base learner | No (unless base is seq.) | Yes (robust) | Depends on base learner | Medium | Qini/AUUC, PEHE, policy value |
| Causal forest/GRF | Yes | Partial | No | Yes + CIs | Partial | Medium | CATE CIs |
| TARNet/CFR | Yes | Heads per treatment | No | Yes (balancing) | Limited (fixed heads) | Medium | PEHE, policy risk |
| Dragonnet | Yes | Heads | No | Yes (+propensity) | Limited | Medium | ATE error |
| DESCN | Yes (ITE) | Partial | No | Yes (entire-space) | Limited | High (e-commerce) | AUUC/Qini |
| EFIN | Yes (ITE) | **Yes (treatment encoder)** | No | Yes (intervention constraint) | **Yes** | **High (fintech)** | Qini/AUUC + A/B |
| MTMT / M3TN | Yes | **Yes (treatment tower)** | Partial (attention) | Yes | **Yes (permute treatments)** | Medium-High | Qini/AUUC + A/B |
| Causal Transformer | Yes | Yes (treatment input) | **Yes** | Yes (balancing) | Yes | Low (medical) | Counterfactual RMSE |
| SASRec/BERT4Rec | **No** | Item-as-input | **Yes** | Correlational | Yes (item scoring) | Low-Medium | Recall@k/NDCG |
| TIMeSynC / FinTRec | **No** | Intent/ad-as-output | **Yes** | Correlational | Partial | **Very High** | Recall@k / LogLoss + A/B |
| **Recommended hybrid** | **Yes (R/DR-orthogonal)** | **Yes (treatment tower/token)** | **Yes (transformer)** | **Yes + overlap diagnostics** | **Yes** | **Very High** | **OPE (IPS/DR) + Qini/AUUC + A/B** |

### Research gaps
1. **Causal NBA on reaction-based observational journeys with no explicit no-treatment records.** No existing paper squarely addresses CATE/uplift when the "control"/exposure baseline is structurally missing and only reactions are logged. This is the project's signature gap.
2. **Transformer journey encoders trained against causal (orthogonal/DR) objectives.** TIMeSynC/FinTRec are correlational; Causal Transformer is medical and not action-catalog-flexible. A finance-domain transformer with a treatment-tower head and R/DR-loss is unoccupied territory.
3. **Inference-time arbitrary-action scoring + causal identification together.** EFIN/MTMT provide candidate scoring; orthogonal learners provide identification; no published system unifies both on long heterogeneous financial journeys.
4. **Positivity/overlap under reaction data.** Methodologies for overlap diagnostics, overlap weights, and hidden-confounding sensitivity analysis specifically for reaction-only logs are underdeveloped.

## Recommendations
**Recommended modeling direction:** Build a **candidate-conditioned (treatment-as-input) transformer that estimates conditional treatment effects, trained with a doubly-robust / R-learner orthogonal objective, and evaluated with off-policy DR estimators plus Qini/AUUC.** Concretely:

- **Stage 1 (encoder):** Reuse the TIMeSynC/FinTRec-style heterogeneous-tabular transformer to encode the reaction journey + monthly propensity-vector snapshots into a user-state representation h(x_t). Use time-aware attention (TimeAliBi) and field/product embeddings.
- **Stage 2 (treatment tower / candidate head):** Add a treatment tower (à la EFIN/MTMT) that embeds an arbitrary candidate action a (channel, predefined action, or ordered/unordered set via pooling/positional encoding). Score s(h, a) so new/unseen actions are embedded and scored at inference without retraining.
- **Stage 3 (causal objective):** Train the head with an R-learner/DR-learner loss: estimate nuisance functions (outcome m(x) and an action-propensity model e(x,a) from whatever exposure proxy exists) with cross-fitting, then fit the orthogonalized effect. Add a CFR-style IPM balance penalty to mitigate reaction-vs-non-reaction imbalance.
- **Stage 4 (evaluation & guardrails):** Offline OPE with SNIPS + Doubly-Robust (with weight clipping/shrinkage and explicit overlap diagnostics); uplift ranking via Qini/AUUC; then staged online A/B with guardrail metrics.

**Staged next steps & thresholds:**
1. *Feasibility (weeks 1–6):* Establish whether any no-treatment / exposure proxy exists for Email/Direct Mail/Leads/OBTM. **Threshold:** if usable exposure logs can be added, prefer a full DR-learner with estimated propensities; if not, fall back to S-learner-style treatment-as-input with strong sensitivity analysis and treat results as policy-ranking, not point ATE.
2. *Baseline (weeks 6–12):* Implement S-learner (treatment-as-input) on the existing transformer encoder; benchmark Qini/AUUC vs current targeting. **Threshold to advance:** positive, stable Qini uplift on a held-out temporally-split set.
3. *Rigor upgrade (weeks 12–20):* Add R/DR-learner orthogonalization + CFR balancing + treatment tower for multi/arbitrary actions. **Threshold:** DR-OPE policy value exceeds logged policy with confidence intervals excluding zero.
4. *Deploy (weeks 20+):* Online A/B with overlap monitoring and hidden-confounding sensitivity bounds. **Change trigger:** if overlap diagnostics show large non-overlap regions, restrict recommendations to the overlap subpopulation and report narrowed scope.

## Caveats
- **Self-reported industrial numbers:** Both are Tencent ITE-team deployments — EFIN reports +10% ROI and +8% MAU in FiT credit-card marketing (arXiv:2306.00315); MTMT reports A/B gains in gaming-platform bonus allocation (arXiv:2408.12803) — neither independently audited. Treat as directional evidence of feasibility, not guaranteed lift.
- **Reaction-data identification risk:** Without explicit no-treatment/exposure records, unconfoundedness and positivity are partly untestable; all causal claims should be accompanied by sensitivity analysis. The recommended model reduces — but cannot eliminate — hidden-confounding bias.
- **Venue/maturity:** Several treatment-tower papers (MTMT, some short-video works) are arXiv preprints without confirmed peer-reviewed venues; weight accordingly.
- **Domain transfer:** Causal Transformer is validated in medicine; its temporal-confounding machinery is promising but unproven on financial marketing journeys.
- **Propensity scores as context:** The 10 monthly credit-card propensity scores are model outputs, not raw behavior; using them as confounders/context assumes they adequately summarize financial state — a modeling assumption to validate.

## Bibliography

**Causal foundations & meta-learners**
- Künzel, Sekhon, Bickel, Yu (2019). Metalearners for Estimating Heterogeneous Treatment Effects Using Machine Learning. *PNAS* 116(10):4156–4165. https://doi.org/10.1073/pnas.1804597116 · arXiv:1706.03461
- Nie, Wager (2021). Quasi-Oracle Estimation of Heterogeneous Treatment Effects (R-learner). *Biometrika* 108(2):299–319. https://doi.org/10.1093/biomet/asaa076 · arXiv:1712.04912
- Kennedy (2023). Towards Optimal Doubly Robust Estimation of Heterogeneous Causal Effects (DR-learner). *Electronic Journal of Statistics* 17(2):3008–3049. https://doi.org/10.1214/23-EJS2157 · arXiv:2004.14497
- Robinson (1988). Root-N-Consistent Semiparametric Regression. *Econometrica* 56(4):931–954. https://doi.org/10.2307/1912705
- Chernozhukov et al. (2018). Double/Debiased Machine Learning for Treatment and Causal Parameters. *The Econometrics Journal* / arXiv:1608.00060. https://arxiv.org/abs/1608.00060
- Wager, Athey (2018). Estimation and Inference of Heterogeneous Treatment Effects Using Random Forests. *JASA* 113(523):1228–1242. https://doi.org/10.1080/01621459.2017.1319839 · arXiv:1510.04342
- Athey, Tibshirani, Wager (2019). Generalized Random Forests. *Annals of Statistics* 47(2):1148–1178. https://doi.org/10.1214/18-AOS1709
- Gutierrez, Gérardy (2017). Causal Inference and Uplift Modeling: A Review of the Literature. *PMLR* 67:1–13. http://proceedings.mlr.press/v67/gutierrez17a.html
- Zhao, Harinen (2019). Uplift Modeling for Multiple Treatments with Cost Optimization. *IEEE DSAA*. arXiv:1908.05372

**HTE deep nets & treatment-as-input / two-tower causal**
- Shalit, Johansson, Sontag (2017). Estimating Individual Treatment Effect: Generalization Bounds and Algorithms (TARNet/CFR). *ICML*. arXiv:1606.03976
- Shi, Blei, Veitch (2019). Adapting Neural Networks for the Estimation of Treatment Effects (Dragonnet). *NeurIPS*. arXiv:1906.02120
- Zhong et al. (2022). DESCN: Deep Entire Space Cross Networks for Individual Treatment Effect Estimation. *KDD*. https://doi.org/10.1145/3534678.3539198 · arXiv:2207.09920
- Liu, Tang, Gao, Lyu, He (2023). Explicit Feature Interaction-aware Uplift Network for Online Marketing (EFIN). *KDD*. https://doi.org/10.1145/3580305.3599820 · arXiv:2306.00315
- Wei, Qiu, Li, Sun, Li (2024). Multi-Treatment Multi-Task Uplift Modeling for Enhancing User Growth (MTMT). arXiv:2408.12803
- Sun, Chen (2024). M³TN: Multi-gate Mixture-of-Experts based Multi-valued Treatment Network for Uplift Modeling. *ICASSP*. arXiv:2401.14426
- Melnychuk, Frauen, Feuerriegel (2022). Causal Transformer for Estimating Counterfactual Outcomes. *ICML*. arXiv:2204.07258
- Schwab et al. (2020). DRNet — Learning Counterfactual Representations for Estimating Individual Dose-Response Curves. *AAAI*. arXiv:1902.00981
- Nie et al. (2021). VCNet and Functional Targeted Regularization for Continuous Treatment Effects. *ICLR*. arXiv:2103.07861
- Bockel-Rickermann et al. (2024). Uplift Modeling with Continuous Treatments: A Predict-then-Optimize Approach. *EJOR*. arXiv:2412.09232

**Transformer sequential recommendation**
- Vaswani et al. (2017). Attention Is All You Need. *NeurIPS*. arXiv:1706.03762
- Kang, McAuley (2018). Self-Attentive Sequential Recommendation (SASRec). *IEEE ICDM*. arXiv:1808.09781
- Sun et al. (2019). BERT4Rec: Sequential Recommendation with Bidirectional Encoder Representations from Transformer. *CIKM*. arXiv:1904.06690
- Chen et al. (2019). Behavior Sequence Transformer for E-commerce Recommendation in Alibaba (BST). *DLP-KDD*. arXiv:1905.06874
- Xia et al. (2023). TransAct: Transformer-based Realtime User Action Model for Recommendation at Pinterest. *KDD*. arXiv:2306.00248
- Pancha et al. (2022). PinnerFormer: Sequence Modeling for User Representation at Pinterest. *KDD*. arXiv:2205.04507
- de Souza Pereira Moreira et al. (2021). Transformers4Rec. *RecSys*. https://doi.org/10.1145/3460231.3474255

**Heterogeneous tabular sequential modeling (finance)**
- Padhi et al. (2021). Tabular Transformers for Modeling Multivariate Time Series (TabBERT). *ICASSP*. arXiv:2011.01843
- Zhang et al. (2023). FATA-Trans: Field And Time-Aware Transformer for Sequential Tabular Data. *CIKM*. https://doi.org/10.1145/3583780.3614879 · arXiv:2310.13818
- Luetto et al. (2023). One Transformer for All Time Series (UniTTab). arXiv:2302.06375
- Katariya, Origgi, Wang, Caputo (2024). TIMeSynC: Temporal Intent Modelling with Synchronized Context Encodings for Financial Service Applications. *RecSys RecTemp Workshop*. arXiv:2410.12825
- Katariya et al. (2025). FinTRec: Transformer Based Unified Contextual Ads Targeting and Personalization for Financial Applications. *RecSys*. arXiv:2511.14865

**Off-policy evaluation & learning**
- Dudík, Langford, Li (2014). Doubly Robust Policy Evaluation and Optimization. *Statistical Science* / arXiv:1503.02834
- Swaminathan, Joachims (2015). Counterfactual Risk Minimization / Batch Learning from Logged Bandit Feedback (POEM). *ICML* / *JMLR* 16:1731–1755. https://proceedings.mlr.press/v37/swaminathan15.html · arXiv:1502.02362
- Swaminathan, Joachims (2015). The Self-Normalized Estimator for Counterfactual Learning (SNIPS). *NeurIPS*.
- Su et al. (2020). Doubly Robust Off-Policy Evaluation with Shrinkage. *ICML*. arXiv:1907.09623
- Saito, Joachims (2022). Off-Policy Evaluation for Large Action Spaces via Embeddings (MIPS). *ICML*. arXiv:2202.06317

**Positivity / overlap / identification**
- D'Amour et al. (2020). Overlap in Observational Studies with High-Dimensional Covariates. *Journal of Econometrics*. arXiv:1711.02582
- Matsouaka et al. (2024). Causal Inference in the Absence of Positivity: The Role of Overlap Weights. *Biometrical Journal*. https://doi.org/10.1002/bimj.202300156
- (2021). Addressing Positivity Violations in Causal Effect Estimation Using Gaussian Process Priors. arXiv:2110.10266

**Causal recommendation surveys & NBA**
- Gao et al. (2022). Causal Inference in Recommender Systems: A Survey and Future Directions. arXiv:2208.12397
- Zhu, Ma, Li (2023). Causal Inference in Recommender Systems: A Survey of Strategies for Bias Mitigation, Explanation, and Generalization. arXiv:2301.00910
- Wang et al. (2023). Causal Recommendation: Progresses and Future Directions. *SIGIR* tutorial.