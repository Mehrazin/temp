# MTA current-attribution audit — complete Copilot kit

This is the complete fresh-start package. Everything needed from the earlier draft kits is integrated here. Use this ZIP alone. It contains instructions for Copilot to generate code against the real VDI environment; it does not contain an already generated or executed notebook.

## What Copilot will build

- ONE staged analysis notebook: `incumbent_output_audit.ipynb`, plus a platform-compatible source export and run guide.
- A compact saved-results bundle from that notebook: `report_inputs.zip`.
- After the run, an offline HTML report and a small report-builder script using those saved results. This report step does not need a second cluster analysis notebook or another data scan.

The analysis covers actual table schemas and grain, implemented attribution rules, absent observed history versus rule exclusions, production reconciliation, attribution by conversion/interaction dimensions, timing, shared touchpoints, and whether restricting conversions to FY26 Q3 changes their attribution. Broader conversion context is included only as required for that controlled comparison, within stated operational bounds. No attribution model training or production changes are part of this task.

## Step 1 — transfer and start one Copilot chat

Bring `MTA_Copilot_Audit_FINAL.zip` to VDI and extract it. Give Copilot access to this extracted folder (or attach `01_BUILD_NOTEBOOK_PROMPT.md`) and the existing production attribution notebook/SQL and relevant source definitions you already have.

Copy this exact starter message:

> Read `01_BUILD_NOTEBOOK_PROMPT.md` from the attached/extracted kit and carry out the complete notebook-building task, including section G on broader conversion context and shared touchpoints. Use the actual attribution code and discover the real schemas. Generate one staged notebook and an exact run guide. Ask me only for source locations or definitions you cannot discover. Do not generate empirical findings before I run it.

If Copilot cannot access attachments/folders, open `01_BUILD_NOTEBOOK_PROMPT.md`, select all, and paste the complete contents into the chat. You do not need to retype the requirements. If source code is not accessible to the chat, give it an exported notebook/SQL or the specific location it requests; the prompt supplies discovery steps rather than guessed columns.

## Step 2 — run the notebook on the cluster

Follow the generated `RUN_GUIDE.md`. Run discovery/preflight first, resolve any genuinely missing source mapping, then run the ready audit stages. The notebook should save completed sections, status and a small `report_inputs.zip` in a new run directory. If resource limits prevent a complete run, keep the partial results and explicit coverage; partial does not mean zero impact.

If a stage fails, use `03_REPAIR_IF_NEEDED.md` in the SAME chat with the error and current artifact. Copilot should tell you precisely which corrected cells to rerun, preserving usable work.

## Step 3 — turn actual results into the report

Give the SAME Copilot chat the executed notebook with outputs, its `report_inputs.zip`, and `02_BUILD_REPORT_PROMPT.md`. Copy this exact message:

> Follow `02_BUILD_REPORT_PROMPT.md` using this executed notebook and saved-results bundle. Build the offline HTML report and its report-builder script. Include Q3-versus-broader-context impact and observed-history-versus-rule exclusions in the first 12 capture cards. Show missing or partial evidence explicitly. Tell me exactly how to generate and open the report inside VDI.

If a new chat is necessary, those files and the report prompt are self-contained. The report builder reads saved aggregate results; it must not rerun cluster analysis. Execute its provided command/cell if Copilot cannot execute it. Open `incumbent_output_audit.html` in VDI.

## Step 4 — bring photographs back to the interview

Use the generated `CAPTURE_GUIDE.md`. Photograph the initial core cards (at most 12), especially run status, conversion accounting, production reconciliation, AUD-10 (does restricting to Q3 change the answer?) and AUD-11 (observed history, rules and shared touches). Start with these; the assistant can request particular appendix pages later.

Photographs are sufficient. No transfer of raw data out of VDI is required. Examples use report-local aliases and relative times; diagnostic keys and candidate datasets remain inside the cluster.

## Files in this kit

- `00_START_HERE.md` — this guide and the exact two messages to send.
- `01_BUILD_NOTEBOOK_PROMPT.md` — the complete analysis specification, including all requested additions.
- `02_BUILD_REPORT_PROMPT.md` — reporting from executed results only.
- `03_REPAIR_IF_NEEDED.md` — optional continuation if notebook/report generation or execution fails.
- `MANIFEST.json` — package version and file-integrity hashes.

Use one chat and one analysis notebook. The numbered prompts represent successive stages, not separate parallel assignments. The notebook should discover fiscal dates, keys, rules and production lineage before making empirical claims. Its findings remain investigation evidence for our interview.
