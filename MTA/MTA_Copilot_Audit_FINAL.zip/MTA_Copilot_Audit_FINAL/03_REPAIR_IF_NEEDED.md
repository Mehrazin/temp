# Optional: repair the current audit stage

The current attribution audit notebook or report builder failed or returned a blocked/partial status. Use the attached error/output, current notebook/source, run manifest and original task prompt. Continue this same audit; do not create a competing implementation or silently change its population/definitions.

1. Identify the specific failing stage and whether this is a missing source/schema, fiscal/snapshot ambiguity, syntax/runtime issue, resource limit, failed data check, or report-layout issue. Explain the observed cause and what is still uncertain.
2. Inspect relevant actual code/schema/output. Never guess absent columns or paths. If necessary, give one small discovery cell and request its output.
3. Preserve completed outputs and run provenance. Make the smallest justified repair. If rules or metric definitions change, explicitly version the change and identify all dependent outputs that must be regenerated. Do not adjust rules to make the numbers agree.
4. Keep source/production data read-only and writes inside this audit's output area. Follow existing operational limits. For resource failures, propose a bounded partitioned continuation or smaller diagnostic; never silently call a sample the full cohort. Persist progress and report coverage exactly.
5. Provide the corrected artifact and precise cells/stages to rerun. Reuse unaffected saved results. For report-only issues, regenerate from the saved bundle without rerunning cluster queries.
6. Record generated, executed, verified and still-blocked states separately. A failing data-quality check is a finding to report, not necessarily a code error to suppress.

If a key decision requires my input, ask one focused question and complete independent repairs first. Do not broaden this into new modeling or production changes.
