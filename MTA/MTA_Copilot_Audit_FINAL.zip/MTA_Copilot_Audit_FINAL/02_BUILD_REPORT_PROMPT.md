# Task: turn executed attribution-audit results into a photograph-friendly HTML report

I am giving you the executed `incumbent_output_audit.ipynb` and its compact `report_inputs.zip` from a current incumbent attribution audit. Build a self-contained HTML report that I can open inside VDI and photograph to discuss with an assistant on my personal laptop. You may also have the original build prompt; this report prompt stands alone.

## Evidence and scope

Use only actual saved results and source definitions. Inspect the run manifest first: cohort dates/fiscal calendar, source/rule snapshot, run ID, sample/full coverage, section status and check ledger. Verify that notebook outputs and bundle belong to the same run. Separate notebook code, successfully executed output, reused evidence and unexecuted instructions. Do not fill missing metrics with zero, infer success from a finished notebook, merge different runs silently, or manufacture illustrative data. If the bundle and notebook conflict, expose that discrepancy.

The requested audit is an output-first investigation of the current attribution process for FY26 Q3 (exact dates must come from results), across observed conversion LOB/types. Previous short-period credit-card acquisition modeling is historical and is not validation of this cohort. No new model is being evaluated here. Deterministic attribution is rule-selected credit, not proof of causal effect. No project policy or production code changes are requested.

Read the bundle manifest and data dictionary rather than assuming fixed physical source schemas or result filenames. Metric captions must retain cohort, numerator/denominator, units, filters, version and full/sample/partial status where relevant. Approximate statistics must be labeled. Follow actual definitions for attributed, retained, excluded, eligible, same-LOB, Brand, cross-LOB and matching route.

## Deliverables

1. `incumbent_output_audit.html`: a standalone offline HTML file, with CSS and any JavaScript embedded, no CDN, external fonts, internet access, analytics or remote assets. Simple HTML/SVG/CSS charts are sufficient. All displayed values must trace to actual saved tables. Do not depend on opening local files through browser fetch.
2. `build_audit_report.py` (or an equivalent supported local script/notebook) that deterministically reads the result bundle/directory and regenerates the HTML without connecting to the cluster or reading raw production data. Use installed standard libraries where practical. If you cannot execute it yourself, give me the exact single command/cell to run and label the HTML as not yet generated/verified. Do not request new cluster analysis merely to change formatting.
3. `CAPTURE_GUIDE.md`: exact initial card IDs to photograph (at most 12), with a short explanation of optional appendix cards. The goal is minimum useful photographs, not an arbitrary page count. Include failed/partial status in the first capture set.
4. `REPORT_PROVENANCE.md`: run ID, input files, source sections, transformations used solely for display, and limitations. If metric definitions need correction, state it explicitly; do not quietly rewrite the underlying audit.

## Layout for photographs

Use one numbered card per screen, approximately 1280 × 800 CSS pixels as a design target, with a fit-to-window option and normal scrolling fallback. Preserve readable type (roughly 22 px body text, 18 px table text at design size), strong contrast and generous spacing. Split dense tables across additional numbered cards rather than shrinking text to fit. Avoid horizontal scrolling. Use at most 6–8 visible columns per card; repeat row keys where a wide schema is split.

Every card needs: stable ID such as AUD-01, clear title, short evidence-based takeaway, visible scope/denominator, and a small run/status footer. Add previous/next controls, a contents page and keyboard navigation if feasible, but core content must remain visible without JavaScript. No animation. Support printing without clipped content. Use consistent channel/LOB labels and accessible colors. Display counts with separators and sensible precision; do not obscure exact reconciliation counts by showing only rounded abbreviations. Empty/missing/unavailable sections must explain the reason.

Do not include direct customer, account, application or employee identifiers. Worked examples must use the report-local aliases already provided, with relative times. Do not put hidden original identifiers in HTML, tooltips, JSON, comments or filenames.

## Required evidence: conversion-context validity and pre-rule history

Check for the conversion-context comparison in the run manifest and bundle. Production reconciliation alone does not establish that this separate comparison ran. If missing, show NOT ESTABLISHED and identify the missing outputs; do not invent a zero effect or launch cluster work.

The controlled test is: A filters conversions to FY26 Q3 before attribution; B runs the same implementation on a verified dependency-complete broader conversion population and filters to the same Q3 targets afterward. Source snapshots, interaction history and rules must match. Include the filter location, broader-context definition and its sufficiency, lineage/version differences, sample/full status and comparison coverage. Production agreement alone is not this experiment if the production run's conversion context or lineage is unknown.

Use one core card for **Does restricting conversions to Q3 change the answer?** Show target Q3 count, comparable count, missing/ambiguous/not-evaluated count, changed assignment status, changed winning touch within the same channel, changed channel, and unchanged results. Keep primary mutually exclusive categories separate from overlapping flags; list n/N and percent with the denominator on each metric. Show overall and most affected observed LOB/type segments, with all segment details in the appendix. Full-Q3 impact is not established from partial comparisons or differing snapshots. Zero observed changes needs the denominator and coverage; it is not a general proof.

Use another core card for **Observed history, rules and shared touchpoints.** Distinguish no usable keys, no observed PRIOR linked interaction within documented history, history present but actual rules exclude candidates, other/unresolved reasons, and any verified cross-conversion suppression. Keep pre-rule history evidence separate from production-eligible candidates. Explain actual shared-touch policy and distinguish candidate sharing from a touch winning for multiple conversions. Reuse alone does not mean a Q3 assignment changes. Flags such as online, Brand, halo and WBANA-like source may overlap; use actual definitions and do not force a partition. Unknown or unaudited history must stay visible.

Place both cards in the first 12 captures. Use AUD-10 for conversion-context validity and AUD-11 for history/shared-touch behavior. Put detailed alternatives and worked examples in appendices. AUD-05 can give overall coverage while AUD-11 explains mechanisms. Keep at most 12 initial cards; do not cram tables or shrink fonts. Include appendix real traces comparing Q3 and outside-quarter conversions for a shared touch, with aliases, relative times, flags/ranks and first observed divergence stage. Do not manufacture cases.

## Initial cards: adapt to evidence, keep at most 12

- **AUD-01 — Run and evidence status.** Exact population/dates, full versus preflight/sample, executed/reused/blocked sections, and production validation status. What this report can and cannot establish.
- **AUD-02 — Actual process.** A readable input → matching → conditions → ranking → enrichment → final output diagram, with real code locators and any exceptions. Separate removal from ranking.
- **AUD-03 — Final table and its grain.** Compact real schema/example views showing conversion fields, attribution fields, winning touch and reporting fields. Explain whether unmatched conversions remain and whether enrichment duplicates rows. If not known, say so.
- **AUD-04 — Conversion accounting.** Starting, excluded, retained, attributed and unassigned distinct conversions with reconciliation and row-count checks. Do not show a sequential funnel for states that are not nested.
- **AUD-05 — Coverage and non-attribution.** Breakdown by conversion LOB/type and main primary reasons; primary reasons must sum to the stated universe. Keep overlapping flags separate. If many segments exist, show a clearly labeled summary plus linked appendix cards; do not hide exceptions or imply the displayed subset is complete.
- **AUD-06 — Production agreement.** Full-outer comparison categories, counts, denominators and mismatches; distinguish missing comparator or snapshot mismatch from agreement. Include separate dashboard bridge only if supported, on an extra appendix card if needed.
- **AUD-07 — Who receives credit?** Conversion LOB/type → winning channel/event, with counts and explicitly labeled shares of all conversions versus attributed conversions. Keep detailed interaction LOB in an appendix if needed.
- **AUD-08 — Same-LOB, Brand and cross-LOB.** Real categories, unknowns, and matching/ranking composition, with counts and denominators.
- **AUD-09 — Winning-touch timing.** Clear lag distribution, median and tail summaries; visibly show negative/missing lags and date precision. Define signed lag. Split detailed channel/event panels into appendix pages as needed.
- **AUD-10 — Does restricting conversions to Q3 change the answer?** Controlled A/B impact, denominator, coverage and sufficient-context status as specified above. Alternatives/selection and timing comparisons move to appendix cards.
- **AUD-11 — Observed history, rules and shared touchpoints.** Pre-rule history versus rule exclusions and verified reuse/exclusivity behavior as specified above. Real multi-conversion traces and other worked examples go to appendix cards.
- **AUD-12 — Checks and unresolved questions.** Material failures, unknowns and the smallest next evidence request, clearly distinguished from findings. Do not recommend a model as the conclusion of this audit.

Cards can be combined when sparse, or replaced by explicit status cards if results are missing. Appendices should preserve all produced LOB/type summaries, reason tables, dimensions, schema details, discrepancy categories, timing views and remaining example traces. Use stable IDs such as APP-01. Provide a manifest of aggregate tables not displayed and why. Never manufacture completion merely to populate all cards.

## Analytical integrity

Use conditional wording when production agreement is not verified. Do not interpret unattributed as organic, no linked touch as no exposure, channel share as incrementality, or timing patterns as causal delay. Sample results need their sample denominator and selection method on every relevant card. Reconciliation checks and numeric totals must use the same cohort and grain. Zero denominators yield not applicable, not 0%.

A dashboard may combine filters and adjusted measures, including MMM. Keep those measures separate from real conversion-level counts. Do not force a dashboard match by introducing unprovided adjustments.

## Verification and finish

Validate file references and numeric consistency against saved tables. Check that core totals and categories reconcile or visibly state why they do not; check no unsupported metric is presented as a result. If a browser/rendering tool exists, inspect a sample of dense cards, schema cards and example cards for overflow at the design size. Otherwise perform structural checks and explicitly state visual inspection is pending; do not claim to have seen screenshots.

Finish with exact artifact paths, how to open the report, the initial card IDs to photograph, and any result inputs still needed. Do not launch new cluster work or alter analysis code unless I explicitly ask for a repair.
