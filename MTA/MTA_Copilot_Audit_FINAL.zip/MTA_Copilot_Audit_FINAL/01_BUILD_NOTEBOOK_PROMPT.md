# Task: build a bounded FY26 Q3 incumbent attribution audit notebook

You are working inside my VDI. Generate an executable analysis notebook for my existing cluster, using the actual local attribution implementation and available data. I will run the notebook, then give you its executed outputs for a separate HTML reporting step. Complete discovery and code generation using the files available to you. If you cannot access cluster schemas, generate small schema-discovery cells first and tell me exactly which output you need. Never invent physical tables, paths, columns, join keys, dates or results.

## Purpose and boundaries

We are documenting the current attribution product before considering a new fractional approach. We need to understand the input and final table, reproduce the incumbent for one cohort, reconcile with production, and examine coverage, winners, alternatives and timing. We are not selecting or fitting an attribution model, proving causality, changing attribution policy, or updating production.

Historical modeling was only short-period credit-card acquisition. This audit concerns the current broader data and all conversion LOB/type segments present in the selected cohort. Do not reuse old pilot metrics as current results. Use existing saved analyses if their population, snapshot, implementation and definitions match; label their provenance and any mismatch. Do not rerun a prior model or evidence kit.

Read only task-relevant code and local documentation. No internet or image interpretation is needed. Use the installed cluster framework and libraries; prefer its existing distributed operations (e.g. PySpark where available). Read source/production data; write only new, isolated audit artifacts in a configured output directory. Do not execute production write cells from imported notebooks.

## Source discovery: clues, not verified schema

An earlier walkthrough referred to a notebook named `prod-04-attribution`, particularly original cells 52–53. It mentioned logical objects `conversions_final`, `chnl_interactions`, `eligibility`, `lookback_windows`, `interaction_rank`, and later metadata/account/SVA enrichment. Those may be temporary objects, stale names or inaccessible here. Discover actual mappings and code locations; do not assume they are registered physical tables.

That walkthrough described application-reference or DAB-reference matching, or customer matching with eligibility; different treatment of same-LOB, Brand and cross-LOB candidates; affiliate/nested/channel/event/recency ranking; and retention of unmatched conversions. It also described exceptions to ordinary time windows and an out-of-window fallback class. These are hypotheses to check against actual code, not instructions to reproduce them blindly. Fiscal dates, identifier normalization, rule versions, current ranking, output grain and dashboard measures remain to be established.

Find the actual current notebook/SQL and any saved production final output and reporting definitions. Prefer direct code, schemas, configuration and executed evidence over prose summaries. If a material source cannot be located, name the missing source and continue independent sections. Ask me one focused blocking question only if needed; do not make me manually describe discoverable schemas.

## Notebook organization

Generate ONE analysis notebook with separately rerunnable stages and shared functions/configuration. Keep both Q3-only and broader-context attribution in the same implementation, parameterized by conversion context; do not maintain two copies of the rules. Suggested execution order: source/schema/calendar discovery; dependency inspection from section G1; bounded preflight; Q3 reproduction/accounting; production reconciliation; broader-context comparison; composition/timing/examples; checks and result-bundle export. Section letters below describe requirements, not a mandatory execution order. Each stage must persist status and usable summaries so reporting can proceed from partial results when necessary.

Use the actual available runtime to make the notebook portable to my cluster. If context-window/output limits prevent generating everything in one response, continue the same artifact in numbered parts with a progress checklist; do not drop section G or other requirements. Audit scope must remain explicit.

## Deliverables

Create:
1. `incumbent_output_audit.ipynb`, with readable Markdown explanations and idempotent numbered cells. Also provide the platform-compatible source export (`.py` or SQL as appropriate).
2. `RUN_GUIDE.md`, with exact setup/run/export steps, required privileges or source mappings, and a list of any genuinely unresolved configuration. Centralize configuration near the top.
3. Notebook logic to save a small `report_inputs.zip` under a unique run directory. The bundle contains manifest/status JSON, data dictionary/source map, actual rule description with code locators, data-quality/reconciliation checks, aggregate tables, and redacted examples. Include a README describing filenames, columns and denominators. CSV plus JSON/Markdown is preferred; no external dependency for reading this bundle. It must stand alone if the executed notebook does not embed all outputs.
4. A concise completion message distinguishing code generated, code syntax-checked, executed, reconciled and not run. Do not claim an analysis ran merely because code was generated.

The following output names are NEW artifact contracts, not claims about source tables. The manifest should map logical report sections to actual files, dimensions, metric definitions, units, denominators, cohort, filter/snapshot/rule version, full-versus-sampled coverage, approximation, runtime and status. Represent a missing result with an explicit status/reason, never a fabricated zero.

## Configuration and bounded execution

- Discover authoritative FY26 Q3 conversion-date start and end, using a half-open interval if supported; record timezone and calendar source. Do not assume calendar Q3.
- Discover the canonical conversion key and grain, including repeated conversions per customer/account. Record uniqueness before any deduplication; never force uniqueness by arbitrarily dropping rows.
- Discover the interaction key/grain, production output, rule tables and snapshot information. Preserve raw production normalization semantics in the reproduction; put proposed fixes only in diagnostic notes.
- Keep the reporting target as FY26 Q3 conversions. Preserve interaction history required by REAL matching rules and include outside-quarter CONVERSIONS wherever the controlled context comparison in section G requires them. Do not truncate interaction history to Q3 or assume conversion processing is independent across quarters. The A/B comparison must hold interaction history fixed; its separate diagnostic search for prior recorded history can extend beyond attribution eligibility windows, with explicit bounds.
- Default to a deterministic 10,000-conversion preflight, stratified where feasible across LOB/type. Sample CONVERSIONS and preserve all relevant interactions for those sampled conversions. Label every sample diagnostic; do not extrapolate sample shares as full-cohort results.
- Operational defaults (configurable; not scientific thresholds): 15 minutes for discovery/preflight actions, 45 minutes for the full audit stage, and 100 million projected materialized conversion–interaction candidate pairs. Before full execution, estimate candidate volume using preflight segment fan-out plus high-fan-out diagnostics and available source statistics; estimates are not guaranteed upper bounds. If estimates exceed limits or cannot be made credibly, return preflight results and a specific bounded continuation proposal. Do not silently run an unbounded join.
- Use stage timing and platform job cancellation/timeouts where supported. State clearly if cancellation cannot be enforced; a timer checked only after an action is not a hard timeout. Do not install packages to implement limits.
- Prefer selective joins, partition pruning consistent with rules, reused intermediate results and distributed aggregation. Inspect plans for explosive joins. Never collect raw full cohorts or candidates to the driver. Cap each collected/exported aggregate chunk at 10,000 rows; partition larger aggregates or retain them in cluster storage with an explicit omitted-detail manifest. No silent truncation. Keep initial report bundle under approximately 20 MB, listing excluded details.
- Save completed stage summaries as execution proceeds. Give each section a complete/partial/skipped/blocked status. Use a new run ID, do not overwrite another run, and clean up only temporary objects created by this audit.

## Required analysis

### A. What are the actual tables and rules?

Produce a source map and data dictionary for inputs and final output: real field name, type, meaning, originating source, role, null behavior and verified versus inferred definition. Show the actual final schema and a few narrow, redacted example views that preserve field relationships. Record row grain and keys for each relevant stage, including final enrichment.

Explain the implemented sequence with source notebook/cell/function/SQL locators: base population filters; matching routes and placeholder/null handling; time and eligibility conditions; ranking order and ties; selected attribution status; enrichment; output/report filters. Distinguish matching, qualification, ranking and reporting. A low-ranked or out-of-window candidate may survive: only call it rejected if the code actually excludes it or makes it unassignable. Explain terms such as online or halo using actual definitions. Note incomplete or conflicting evidence.

### B. Conversion accounting and reasons

Report raw rows AND distinct conversions at each relevant stage, overall and by conversion LOB × conversion type (retain null/unknown groups). Reconcile the configured starting conversion universe to exclusions plus retained conversions, then retained conversions to attributed plus unattributed, under the actual status definition. Explain any additional legitimate state explicitly. Count both missing and duplicated conversions after joins/enrichment; never treat a row-count change automatically as conversion loss.

Build a mutually exclusive, exhaustive conversion-level disposition with documented precedence and counts that sum to the starting universe. Its labels must follow the real implementation. Separately provide overlapping diagnostic flags with their own denominators.

For missing attribution, distinguish what evidence permits: no usable matching identifiers; usable identifiers but no recorded match in searched sources/history; candidate matches rejected by actual eligibility/time/other filters; unresolved attribution despite surviving candidates; and unknown/untraceable. Report eligible nonwinning candidates separately from unassigned conversions. Where filters are embedded inside joins, recover prefilter diagnostics through bounded instrumented joins without changing the reproduction, or label the stage unobservable. State searched source/history bounds. No recorded match is not proof of no exposure. Do not infer exclusion reasons merely from final null fields.

### C. Reproduction versus production

Reproduce the actual incumbent semantics for the cohort. Reconcile with a saved production output at the same grain, snapshot and version when possible. Use a full outer comparison on the verified conversion key, inspecting duplicate keys before comparing. Report only-in-reproduction, only-in-production, duplicate/ambiguous records, assignment-status mismatches, winning-channel mismatches, winning-event/interaction-LOB mismatches and winning-interaction-key mismatches when available. Handle null equality explicitly. Preserve overlapping flags plus mutually exclusive primary comparison categories; give denominator and counts. Include a few redacted discrepancy traces.

Same aggregate totals do not prove agreement. If snapshots/rules differ, label comparisons accordingly; do not attribute all disagreements to implementation. If production data are unavailable, mark reconciliation NOT VERIFIED and continue the self-consistency audit. Do not use a dashboard total as a substitute for conversion-level production validation.

Provide a separate dashboard bridge only where actual definitions exist: base/attributed counts, dashboard scope filters and grouping, value measures, and any MMM or other adjusted rows. Keep adjusted measures and actual distinct conversions separate. Report unexplained differences; never force totals to agree.

### D. Attribution composition and alternatives

For attributed conversions, produce counts and shares by conversion LOB × conversion type × winning channel × winning event type × interaction LOB; provide smaller marginal views for readability. Define denominators: share of all conversions in that conversion segment, and share of attributed conversions in that segment. Show both numerators and denominators. Describe same-LOB, Brand and cross-LOB according to implemented taxonomy, with unknown explicit. Include campaign/interaction target or conversion objective only where a real field supports it; do not conflate interaction LOB, campaign target, and conversion type.

Summarize matching routes, ranking classes, effective lookback rules/defaults and winner selection. Track multiple matching routes without double-counting a conversion–interaction pair, following actual production duplicate semantics and separately diagnosing any duplication. Quantify exact ranking ties and any nondeterministic winner behavior; do not invent a tie-breaker to obtain agreement.

Describe number of candidate interactions and distinct candidate/eligible channels per conversion, with explicit definitions. For conversions with alternatives, identify the highest-ranked nonwinner and the first ranking field on which it loses, when reconstructable. Do not count this as a causal explanation. Summarize multi-channel opportunity and the common selection reasons; keep this diagnostic rather than a new fractional model.

### E. Touch-to-conversion timing

Define signed lag = conversion timestamp minus interaction timestamp. Report precision/timezone and any date-only limitation. For winners, show count, missing lag count, pre/same/post-conversion counts, median, p10/p25/p75/p90/p95 and readable lag bins by winning channel × event type, with useful conversion LOB/type splits. Document bin boundaries and denominators; distinguish exact from approximate quantiles. Do not silently drop negative lags or relabel them errors where rules permit them.

Provide comparable timing summaries for eligible nonwinning interactions if within limits. Those are touch-weighted unless explicitly summarized per conversion; label weighting and differing populations. Use a paired winner-versus-best-alternative comparison at conversion level where possible to reduce confusion from high-touch journeys. Differences reflect selection rules and observation windows; do not call them causal response-time estimates.

### F. Worked examples and checks

Create up to 12 compact real traces spanning available cases: no usable identifier, no observed match, actual rule exclusions, single-channel, multi-channel, same-LOB/Brand/cross-LOB, older winner versus newer loser, fallback/direct-reference exception, and production mismatch or tie. Cases absent from the data must be marked absent or not observed, not fabricated. State how cases were selected; illustrative examples are not prevalence estimates.

Each trace should use report-local conversion/touch aliases, relative times, conversion LOB/type, relevant candidate attributes, matching route(s), rule/eligibility status, rank tuple, winner and reason. Do not export customer/account/application identifiers or a re-identification crosswalk in the report bundle. Keep any diagnostic original keys inside the cluster. Mark candidate truncation if a trace has more candidates than shown.

Include a check ledger: conversion conservation, grain/key uniqueness, candidate multiplicity, winner cardinality, enrichment multiplication, disposition sums, segment sums, share denominators, timestamp nulls, coverage bounds, ties and production reconciliation. Checks must return pass/fail/not testable with observed values and tolerances, not just assertions that discard results on failure. A failed gate blocks claims that depend on it; unaffected summaries can still be exported as provisional.

## G. Quarter-filter validity, shared touches and observed history

## The question

Does restricting the CONVERSION population to FY26 Q3 BEFORE attribution change Q3 results relative to running the actual broader conversion population and filtering to Q3 AFTER attribution? Retaining enough interaction history is necessary but not sufficient to answer this.

For example, a recorded touch could be a candidate for both a Q1 conversion and a Q3 conversion. Does the implementation allow the touch to win for both, assign it to the nearest conversion, use another exclusivity rule, or do something else? Do not presume any of these behaviors. Quantify actual effects on Q3, not just the existence of shared candidates.

The user reports that conversion records have LOB and conversion type, and touch records have time, channel, event/action type, LOB and a conversion-type/target-like attribute. Verify actual schema names and meanings, especially the touch's conversion-type field; do not assume it has the same semantics as the conversion outcome. Flags/ranks include concepts such as same LOB, time window, Brand, halo, online and a Webana/WBANA-like flag. Locate actual fields and definitions in code. These may overlap or be hierarchical conditions; do not impose a single mutually exclusive 'marketing type' unless the implementation does so.

## G1. Inspect dependencies on other conversions

Trace actual code from source preparation through reporting, not only the final row_number operation. Record partition/group keys and sort criteria for conversion deduplication, interaction deduplication, reference matching, candidate creation, lookback/eligibility derivation, ranking, winner selection, suppression, interaction consumption/exclusivity, nearest-conversion logic, and final enrichment. Include derived identifiers or sequence numbers that could change when a quarter filter moves. Verify uniqueness/collisions for the stable conversion and touch keys before using them in comparisons.

Determine whether the outcome for one conversion is independent of the presence of others, with exact code locators and assumptions. Ranking within each conversion is evidence about that stage only. Upstream processing may still depend on other conversions. If all required inputs and rules are fixed and every relevant stage operates independently per conversion, explain why quarter restriction should commute with attribution; separately state whether execution confirms it. Inspect treatment of equal distances, timestamps and exact rank ties; do not add a new tie-breaker.

## G2. Make a controlled comparison

Define the common target universe Q as the verified distinct FY26 Q3 conversions from the same source snapshot BEFORE audit-specific attribution filtering. Hold source snapshots, interaction history, rules, normalization, timestamp/calendar definitions and code version constant.

- Run A: the actual planned Q3-restricted pipeline, with the conversion filter at its actual intended location. Record that location.
- Run B: the same implementation on the production-relevant broader conversion context, then filter its outputs to Q. Keep the other inputs equivalent to A so the intended difference is conversion context. Preserve and compare keys of Q even if an output row disappears.

Specify the broader universe from actual processing semantics, not an arbitrary 'Q1 plus Q3' or a presumed 90-day window. Other conversions can occur before or after Q3 and can have other LOBs/types. If production itself processes time partitions independently, document that scope; agreement with such a partition alone does not establish broader-context invariance.

Prefer a compatible saved broad-run intermediate/final output if its lineage, source snapshot, rule version and processing scope can be established. Distinguish ordinary production reconciliation from the controlled A/B experiment. Unknown lineage or different snapshots makes the comparison confounded; do not label all discrepancies as effects of the Q3 filter.

If new work is necessary, obey the existing total runtime/candidate-volume limits; do not grant each extra pass a fresh unlimited budget. Reuse intermediates. A minimal connected context may be used only if the real dependency structure proves it sufficient. Discover related conversions via ALL applicable identity/reference routes and include required history and boundary cases. If a rule allocates touches globally or iteratively, shared-touch chains may require recursive closure; a one-hop shared-customer extract is not automatically sufficient. Document closure/sufficiency and limits. If a dependency-complete context cannot be obtained within the bound, return a clearly labeled partial/sample diagnostic and a bounded continuation proposal. Do not substitute an arbitrary time slice and call it a full-context test.

Keep the stable touch and conversion identifiers inside the cluster. A generated row_number is not a valid cross-run identity if filtering changes it. If no reliable touch identity can be established, label touch-level comparisons ambiguous rather than deduplicating distinct events by timestamp/channel alone.

## G3. Quantify outcome changes and touch reuse separately

For Q overall and by conversion LOB × conversion type (and conversion month where useful), export exact counts and explicit denominators for:

1. The full Q target count, number comparable, number not evaluated/ambiguous, and comparison coverage.
2. Attributed in both, unassigned in both, assigned in A but unassigned in B, and unassigned in A but assigned in B. Distinguish excluded/missing output rows and duplicate/ambiguous keys from unassigned status.
3. Both attributed with the same winning touch; a different winning touch within the same channel; and a different winning channel. Add event/interaction LOB/target-field changes where verified. Report differences in downstream reporting fields separately from attribution changes.
4. Changes in candidate/eligible sets even when the winner is unchanged, if recoverable within budget. Do not equate changed alternatives with changed assignment.
5. Q3 conversions with candidates that are also candidates for other conversions; Q3 winners that also win for other conversions; and reuse counts restricted to within-Q3 versus involving outside-Q3 conversions. Distinguish candidate sharing, eligible sharing and actual winner reuse. Count distinct stable conversion–touch pairs; diagnose duplicate rows separately.
6. The number of distinct conversions per touch and the associated LOB/type/quarter combinations for relevant Q3-linked touches. This is a Q3-related touch population, not automatically all touches in the enterprise.

Use one mutually exclusive comparison-disposition table with documented precedence whose counts sum to |Q|, plus overlapping flags for the richer diagnostics. Specify both 'any attribution outcome changed' and 'channel changed'; touch-level changes within a channel matter. Report n/N and percent. Where full comparable coverage exists, answer directly what fraction of all Q3 conversions changes because conversion context changes. Where coverage is partial, report the observed fraction among comparable conversions and coverage; a whole-Q3 percentage is not established. Where snapshots/rules differ, report observed disagreement with confounding rather than a causal attribution to filtering. If zero changes are observed, state the evaluated denominator, precision and scope: zero in a sample is not proof of zero for all Q3.

A touch reused across two conversions does NOT by itself imply either result is wrong or that the quarter filter changes the result. Equally, a nearest-conversion rule is not a universal convention. Describe what this implementation actually does.

Provide up to four additional real redacted traces: a touch shared across quarters; an actual changed Q3 assignment if any; a reused winner with unchanged Q3 attribution if present; and a near-boundary or tie case if present. Show all relevant conversions and relative times, not only the Q3 conversion. Explain the first observed stage where A and B diverge and any verified rule mechanism. When the cause cannot be isolated, mark it unresolved. Never fabricate a case to match the user's hypothetical example.

## G4. Strengthen the no-attribution explanation

For each Q3 conversion, separate 'any observed prior interaction linked through available identifiers within the explicitly audited source/history bounds' from 'candidate admitted by production joins', 'qualifies under actual rules', and 'selected/assigned'. The diagnostic history search should not inherit the very lookback/LOB/eligibility restrictions it is intended to examine. Use bounded identity/reference-based retrieval over available history; document any source, identifier or date restriction. Do not turn this diagnostic linkage into a new attribution policy.

If production has removed history upstream or the broader pre-rule diagnostic is unaffordable/unavailable, mark that distinction not observable. Missing keys, unavailable history and no observed match are different states. Post-conversion-only interactions must be distinguished from prior interactions; timestamp precision and missing timestamps limit what 'prior' means.

Add cross-conversion competition/suppression as a non-attribution reason only if actual code and traces establish it. For conversions with some prior recorded interactions but no assignment, explain actual exclusion/qualification reasons with overlapping flags and a documented primary reason. Retain a bucket for unknown/unresolved. Never claim 'no interactions occurred' from no observed linked record.

Preserve conversion LOB/type and verified touch LOB, target/type, channel, event, relative time, matching route, flags and rank fields in diagnostic lineage. Export readable aggregates across meaningful dimensions, including rule-family breakdowns (time eligibility, same-LOB/Brand/halo, online/reference route, WBANA-like source flag, affiliate/channel/event ranks), with exact definitions and denominators. Avoid exploding every possible cross-product or treating overlapping flags as parts of a pie chart.

## G5. Saved outputs and HTML

Extend the manifest with A/B source/context/filter definitions, proof-of-sufficiency or limitations, comparison coverage, runtime status, and source code locators. Save aggregate comparison dispositions, overlapping change flags, touch-reuse summaries, pre-rule-history versus eligibility summaries, segmented impact and redacted traces in the existing report bundle. Logical section names are output contracts, not source table names. Preserve provenance for reused outputs and give modified runs new IDs.

The report must show in its INITIAL capture set a clear 'Does restricting conversions to Q3 change the answer?' card with A/B definitions, n/N, coverage, status and limitations. A second card should show observed prior-history versus actual-rule exclusions and shared-touch behavior; details go into appendix cards. Keep initial captures at most 12 by moving less urgent existing cards to appendices. Unsupported impact is 'not established', not 0%. Include any affected LOB/type segments and a real trace where available. Do not infer these values from previously saved production-agreement totals.


## Finish

The run should leave a compact summary of what ran, what was reused, what remains partial, and exact artifact paths. It must answer what the current output means without asserting that deterministic credit measures causal contribution. Provide the notebook and run guide now; wait for my executed outputs before drawing empirical conclusions or generating a populated results report.
