# Tables and files are different things

`lumen_mta` is the existing Hive database. “Shared” means reused tables, not a directory and not a new database. An experiment name identifies its output table prefix and its separate file folder. Nothing searches for those objects automatically.

```python
snapshots = spark.table("lumen_mta.cc_daily_feb_jul_snapshots")
predictions.write.option("overwriteSchema", True).mode("overwrite").saveAsTable(
    "lumen_mta.cc_q2_to_q3_predictions_q3"
)
```

The active save pattern matches the supplied VDI code. Use it directly in cells; no writer wrapper or output-existence check. Exact copied-source leaf names remain editable. Derived saves never target the source-copy tables.

## Reusable Hive tables

| Table in lumen_mta | Grain / purpose |
|---|---|
| `customer_history_v1_conversions` | Each selected source row, with conversion_row_id and original row_id retained |
| `customer_history_v1_interactions` | Each source touch row, persistent touch_row_id and original nullable interaction_id |
| `customer_history_v1_customer_references` | customer_id, reference_type, reference_value, originating conversion_row_id |
| `customer_history_v1_customer_index` | One selected customer; includes no-touch customers |
| `customer_history_v1_journey_index` | construction, journey_id, customer_id, nullable conversion_row_id; includes empty journeys |
| `customer_history_v1_journey_interactions` | One journey/touch pair; source attributes and matching routes/reference provenance |
| `cc_daily_feb_jul_snapshots` | One snapshot with journey/customer/outcome/start/end, label, construction and nullable conversion linkage |
| `cc_daily_feb_jul_journey_basic` | snapshot_id, feature_code, numeric nullable feature_value |
| `cc_daily_feb_jul_prism_lag1` | Same long layout, selected PRISM score and missingness features |
| `cc_daily_feb_jul_prism_lag1_used` | snapshot/head, intended/used vintage, available time if known, score, supported missing reason |
| `cc_daily_feb_jul_extra_decays` | Additional D60/D90/D180/D360 values when requested |
| `cc_q3_conversion_map` | Every Q3 CC source-conversion row, nullable snapshot link, ready/unscored status and reason |

Table names are illustrative descriptive choices. Rename them explicitly when their meaning changes. Generated row IDs are local to their saved source extract; save first, then use that saved table for downstream joins. Recomputing `monotonically_increasing_id()` in a different plan does not reproduce earlier keys. If using known unique source row_id directly, state that choice; no mandatory uniqueness-scanning framework. The default config instead assigns a generated conversion-row reference without consolidating any source row.

For A, journey_id refers to the customer history and journey conversion_row_id is NULL. For B, one journey per conversion row with populated linkage. Keep journey membership outside the interaction table, so zero touches do not delete a journey. A source touch linked by direct and reference routes appears once per journey, with all routes retained together. Multiple different journeys may share a touch.

## Tables belonging to the first experiment

All are in the same database; the name makes ownership visible.

| Table suffix after `cc_q2_to_q3_` | Contents |
|---|---|
| `split_membership` | Snapshot/outcome and independent fit_candidate/score_q2/score_q3 flags, or equivalent rows |
| `training_selection` | Candidate snapshot, label, N1/N2 eligibility, selected, probability, weight, reason |
| `predictions_q2`, `predictions_q3` | Snapshot/outcome/model reference, actual label, probability, actual fit_member, evaluation scope |
| `explanation_scores` | snapshot_id, method, level, player_code, signed_score |
| `explanation_endpoints` | snapshot_id, method, level, baseline, full probability, score_sum, output_scale |
| `removal_predictions` | snapshot_id, level, player_code, full_probability, removed_probability |
| `conversion_credits` | conversion_row_id, snapshot_id, method, level, rule, player/category, credit_fraction, report_status |

Method/level columns distinguish fine group, channel group, feature TreeSHAP, explicit-block Owen and removal. Rule distinguishes the three allocations. A small `explanation_settings.yaml` records model/prediction table, exact groups/blocks, off values, fixed context, background snapshot IDs, output scale, seed/permutations and numerical tolerance. These scientific settings are enough; no opaque run registry.

For one method at a time, a separate descriptive table such as `cc_q2_to_q3_fine_group_scores` is also fine. If using the consolidated names in YAML, combine the newly generated method tables visibly before the one overwrite cell. Do not overwrite all methods with one method accidentally or append duplicates on rerun. The same applies to credit rules. Show the choice in notebook 4.

## File directory

The user supplies one path already suitable for Python file operations in their Databricks setup. It is independent of Hive storage. Do not assume `pathlib` supports an object-store URI; if the supplied directory requires dbutils, write the few small files using that existing convention directly, without a general path adapter.

```text
/YOUR_EXISTING_DATABRICKS_DIRECTORY/mta/
  shared_definitions/
    customer_history_v1_notes.yaml
    cc_daily_feb_jul_group_dictionary.csv
    cc_daily_feb_jul_feature_dictionary.csv
    prism_heads.csv
  cc_q2_to_q3/
    config.yaml
    selected_features.csv
    sampling_summary.csv
    model/
      model.json
      feature_order.csv
      config_used.yaml
      feature_dictionary.csv
      prism_heads.csv
    evaluation/metrics.csv
    explanations/explanation_settings.yaml
    allocations/report_totals.csv
    plots/
    NOTES.md
  cc_q3_on_q3/
    config.yaml
    model/
    ...
```

Only create the few directories actually used, with ordinary `mkdir(..., exist_ok=True)` cells; no existence/readability probes or status files. CSV dictionaries are small documentation files, permitted by the user. Full analytic outputs remain Hive tables. A copy of dictionaries alongside the model preserves its feature meaning even if a working shared dictionary is edited later.

## Reuse without machinery

| Change | Reuse | Create / rewrite visibly |
|---|---|---|
| Q3 fitting instead of prior fitting | Journeys, shared snapshots/features and report map | New named experiment selection, model and downstream outputs |
| N2 buffers or random sample | Existing compatible snapshots/features | New selection; new fit/prediction/explanation/credit tables |
| Count/recency subset | Already computed feature values | New ordered column list and fit |
| Add D60/D90/D180/D360 | Existing count/recency/D7/D30/PRISM | Supplementary feature table, new column list and fit |
| PRISM lag2 | Journey features and snapshots | New `...prism_lag2` and provenance tables; new fit |
| New explanation or explicit group list | Saved model, features, report map | New scores/endpoints and credits |
| New allocation rule | Saved signed group scores | Credits and small totals CSV only |
| Positive-only attribution dataset | Existing model and sufficient journey coverage | Only missing report snapshots/features/predictions/map; no training negatives |

Working YAML stays unchanged while notebooks run. A comparison copies/edits the YAML, changes `name`, `artifact_dir` and the experiment output table names explicitly; shared table names remain the same where compatible. Save the selected config as `model/config_used.yaml` when fitting. Overwriting a shared table intentionally changes inputs for its dependents; keep the existing table when the purpose is a comparison. No automatic dependency tracking is required.
