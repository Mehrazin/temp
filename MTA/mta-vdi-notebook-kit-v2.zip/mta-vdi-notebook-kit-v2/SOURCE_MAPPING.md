# Existing source fields

The user has copied the original source tables into `lumen_mta`. The default config assumes the original leaf names were retained. If not, replace those two strings. Do not create another copy from `e2e_cross_channel_new` or use the old schema as a fallback.

| Meaning | Conversion copy | Interaction copy |
|---|---|---|
| Customer | acct_cust_id | cust_id |
| Original row reference | row_id | interaction_id (nullable; not a primary key) |
| Date/time | conversion_dt | event_ts |
| LOB | acct_lob | lob |
| Outcome type / interaction target | acct_conversion_type | target_conversion_type |
| Channel | — | mkt_channel |
| Event | — | event_type |
| Application reference | app_ref_num_left | application_ref_num |
| DAB reference | dab_ref_num_left | dab_confirmation_id |
| Account | acct_id | — |

These mappings come from supplied historical schema/code evidence. Use ordinary explicit select/cast/rename cells, not a schema-scanning or validation framework. If a field is different in the local copy, fix that field. `event_ts` was observed as a string; parse using its actual format. Identifiers stay identifiers; make join types compatible without stripping meaningful leading zeros. Display timestamps through seconds. Date-only conversion_dt shown at midnight is not a known intraday event time.

The user already treated `abc`, `no_dab_conv` and null references as missing. Do not join nulls to nulls or add a speculative repeated cleaning investigation. Save typed application/DAB relationships separately; the same text in different reference types is not the same key. Preserve originating conversion row IDs. Retain ambiguity instead of merging all people connected through an identifier.

Source copies inherit the original preparation. That process includes base status/LOB/target filters, synthetic Affiliate/Direct Mail, EDB Leads relabeling and a later Salesforce branch; uniform final filtering is not established. No requirement to replicate incumbent filters, eligibility, lookback rules, winner ranking or RESL-specific reporting changes. Model outcome CC NEW ACCOUNT does not mean CC-only source interaction histories or references. No new upstream integration.

Each selected conversion row is one conversion accounting unit **in this design**. This supersedes older event-consolidation proposals; it does not claim verified business-event uniqueness. Preserve original row_id and add a generated row reference if using the default configuration. Persist touch-row IDs once, retaining the nullable original interaction_id. A generated ID distinguishes stored input rows, not verified distinct real-world contacts.

## PRISM mapping, only when needed in notebook 2

Actual PRISM source names and physical fields are unknown here. Do not invent them from toy P001/P002. Provide a small explicit alias cell mapping customer, head, score, effective vintage and known publication/availability fields. If the source is wide, select/unpivot the chosen real head columns directly. If long, select them directly. Keep the head mapping as a small CSV, including family/version where known.

Reported approximately 66 heads at end-January 2026 and about 40 populated for an individual are **unverified**. Preserve all selected nulls. Distinguish head not yet released, customer not scored, unavailable monthly delivery and unknown cause only when actual evidence supports that distinction. A null alone does not identify its cause. A release timestamp is not the same as a score's vintage label or input-data cutoff. If availability is not recorded, a stated lag assumption is possible but must not be labelled verified as-of timing.

A head all-missing in training cannot simply become a meaningful new predictor at inference; keep the selected model's head list and missing policy. New releases do not silently extend a saved model. Head availability is not established product eligibility or no-marketing probability.

No package installation, broad table crawl, mandatory schema checks or automated runtime probes are required. A specific genuinely unknown source mapping can be resolved before generating that notebook; ordinary coding mistakes can be fixed after running it.
