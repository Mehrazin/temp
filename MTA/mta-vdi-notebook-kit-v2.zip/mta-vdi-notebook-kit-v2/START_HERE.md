# Simple MTA notebooks — VDI kit v2

Prepared 2026-10-05 · EXP-a7b4df03f703 · CC NEW ACCOUNT first.

**Start by pasting [prompts/00_START_WITH_COPILOT.md](prompts/00_START_WITH_COPILOT.md) into VDI Copilot.** Attach this folder's text files. Copilot generates a complete notebook 1, you run/review/change it, then request notebook 2. The kit supplies instructions, mathematical explanations, text examples and two optional helpers. It does not claim to contain completed or executed Databricks notebooks.

The motto: **if ten readable lines do the job, prefer them to a hundred.** Repeated code, literal table names and ordinary notebook edits are welcome. No schema/directory checking, try/except, run registry, status machinery, automatic budgets, orchestration or five-cell-at-a-time handoff.

## Your storage convention

All data tables are Hive tables in **`lumen_mta`**. The source copies already exist there. Their exact leaf names are editable in `config.yaml`; the supplied names assume the copies retained `_conversions_final_mat` and `_chnl_interactions_mat`. Do not recopy from or write to the original `e2e_cross_channel_new` tables.

```python
conversions = spark.table("lumen_mta._conversions_final_mat")
journey_interactions.write.option("overwriteSchema", True).mode("overwrite").saveAsTable(
    "lumen_mta.customer_history_v1_journey_interactions"
)
```

A separate, ordinary Databricks file directory holds YAML, model files, plots, small dictionaries/CSVs and optional notes. A Hive table name is never joined to that directory. The schema already exists; do not generate database creation or permission probes.

## Read these files

| File | Purpose |
|---|---|
| [COPILOT_RULES.md](COPILOT_RULES.md) | Current generation agreement; supersedes the old kit |
| [config.yaml](config.yaml) | Complete editable example: table names and file directory kept separate |
| [DATA_AND_STORAGE.md](DATA_AND_STORAGE.md) | Saved tables, row keys, file locations and reuse |
| [SOURCE_MAPPING.md](SOURCE_MAPPING.md) | Known source columns and the few genuinely unknown mappings |
| [NOTEBOOKS.md](NOTEBOOKS.md) | Complete responsibilities of notebooks 0–4 |
| [METHODOLOGY.md](METHODOLOGY.md) | Offline equations and experiment alternatives |
| [WORKED_EXAMPLE.md](WORKED_EXAMPLE.md) | Full numerical Q2→Q3 example, all relevant tables and alternatives |
| [examples/READABLE_CELLS.md](examples/READABLE_CELLS.md) | Direct Spark saves, explicit groups, actual TreeSHAP call and helper calls |
| [examples/PRISM_TIMING.md](examples/PRISM_TIMING.md) | Lag, publication timing and different missingness causes |
| [experiment_config.py](experiment_config.py) | Optional small YAML reader; no execution state |
| [attribution.py](attribution.py) | Direct group Shapley, explicit-block Owen, removal and allocation math |
| [SOURCES_AND_QUALIFICATIONS.md](SOURCES_AND_QUALIFICATIONS.md) | Source precedence and implementation notes, readable offline |

## Fixed requirements versus example settings

Fixed: binary CC NEW ACCOUNT first; **TD fiscal Q3 2026 = [2026-05-01 00:00:00, 2026-08-01 00:00:00)**; fit prior data then score/evaluate/explain Q3 and inspect the fitted period; separately allow Q3 fitting/Q3 explanation; customer overlap allowed. Preserve N2 before/after buffers independently of sampling, null historical PRISM scores, source traces, empty journeys, signed explanations and three allocation choices. Signed-net total ≤0 means full unattributed.

Example choices still editable: prior fit Q2 February–April, A/conversion-derived customers, UTC, daily horizon/spacing, 365-day history, N1/all, lag1, two fictional PRISM heads, learner parameters and explanation sample sizes. These are not silently selected by this kit. Count/recency/D7/D30 is the initial requested journey bundle; expanded D60/D90/D180/D360 is supported. An additional annual decay remains optional and is distinct from history length.

Set the file directory and any different source-copy names when notebook 1 is generated. Actual PRISM source/columns are only needed for notebook 2. Ordinary missing-field or package errors may stop a cell; fix them directly. No web access is required in VDI and no automatic installs are requested.
