# Complete notebooks, ordinary cells

Produce notebook source with normal markdown/code cells (Databricks `# COMMAND ----------` source export is fine). Deliver the **whole requested notebook**. Each notebook loads its named saved inputs, so it can run in a fresh session. Do not implement all experimental branches in one engine. Implement the selected branch completely and leave concise editable alternatives beside the relevant cells.

## Optional 0 — config

Copy/edit the supplied YAML, create the experiment's file directory and save config.yaml. The two source table names, reusable/experiment output tables and artifact directory are independent settings. Show them plainly. `experiment_config.py` is optional; direct `yaml.safe_load` is fine. No schema/directory probes or environment manager. If PyYAML is unavailable, leave settings as a plain notebook dict and retain the readable YAML recipe; resolve YAML loading directly when needed rather than inventing a fallback framework.

## 1 — source rows, references and linked journeys

Reads: the already copied conversion and interaction tables in `lumen_mta`.

1. Imports and explicit input/output names. Set chosen timezone. No compulsory date/LOB/status source filter. Source extracts and later fit/report windows are separate.
2. Read the required known fields directly. Save selected conversion rows with `conversion_row_id` and original `row_id`; save interaction rows with persistent `touch_row_id` and original `interaction_id`. The default can generate a reference for every physical row, so no preflight uniqueness scanner is needed. Use `monotonically_increasing_id()` once and **persist the resulting table before using its IDs in separate downstream plans**. Reloading that saved table for actual joins is necessary persistence, not a validation gate.
3. Build `customer_index` from the selected population (conversion customers is the illustration). Include customers without interactions. For U2 later, explicitly union identifiable interaction customers; U3 uses a supplied existing population. No source customer IDs are model features.
4. Build `customer_references`: typed application and DAB rows with customer and originating conversion_row_id. Save this table. Deduplicate customer/type/reference for the joining lookup only, retaining the source relationships in the saved reference table.
5. Build A `journey_index`: one explicit journey_id per customer, construction A, nullable conversion_row_id. Save even empty journeys.
6. Build direct-customer, application and DAB matches with separate readable joins. Combine route edges; aggregate to one journey/touch pair while retaining matching routes and matched source-conversion references. Do not collapse customers transitively through shared keys. Keep the full linked customer history independent of snapshot windows.
7. Save `journey_interactions` and display one customer's ordered history plus its reference map. The human can inspect the calculation. A small source note gives source-copy names, linkage timing and selected coverage; no logging system.

Six tables are saved: conversions, interactions, customer_references, customer_index, journey_index, journey_interactions. Their exact names are in YAML. The output remains CC-independent history even though notebook 2 first predicts CC NEW ACCOUNT. There are no PRISM joins, model labels, fitting or explanations here.

For requested B, journey_index instead has one journey per selected conversion row and populated conversion linkage; use that conversion's references plus direct customer matches. B-union attaches unified customer history to those same conversion journeys. Empty journeys remain in the index and require a selected active-start convention for training. Do not automatically generate all constructions together.

## 2 — snapshots, selection, features, report map

Independent sections let the user reuse earlier outputs and run only a selected new section. No path resolver decides what to run.

**Shared snapshots:** read customer/journey indexes and conversions. Build selected anchors/outcomes and labels under actual known observation coverage. For A, label 1 if at least one requested conversion row is in [start,end); otherwise 0 only with complete outcome observation. Save labels and readable source-conversion links (an array of conversion_row_id is fine). Keep construction, journey_id and customer_id. Multiple conversion rows on one customer/day/outcome yield one binary snapshot. Zero-touch customers survive.

**Experiment membership:** select fit and score periods from those snapshots. Save independent fit_candidate and scoring memberships; Q2 rows can be both fitted and diagnostic. Reporting customers may overlap fitting customers. An optional supplied customer holdout removes their labelled fit rows, not their feature histories.

**Negative eligibility then sampling:** preserve positives; N1/all is the illustration. N2 has independent b-before and a-after buffers, requested outcome, and known follow-up through its whole selection window. Restrict fitting-side selection to its outcome cutoff. Save negative eligibility separately from random selection, actual selected keys, probabilities/weights/reasons and small aggregate counts. Uniform or selected stratified sampling has explicit arithmetic; no hidden class balancing. Keep the full selected Q3 evaluation population separate from sampled training.

**Journey features:** write group tuples/short codes visibly in a cell. Compute count, recency, D7 and D30 for interactions in [t−H,t). No touches gives zero counts/decays and NULL recency. Save long snapshot/feature/value tables and the short-code dictionary. If calculating only selected training/evaluation/report rows, select their union first. Do not require a full customer×day×touch Cartesian expansion or all excluded-touch lists. An on-demand trace for one snapshot is enough. Add requested D60/D90/D180/D360 in a separate table later. No learned global imputer/scaler.

**PRISM:** use actual physical mapping, explicit selected heads and lag1/lag2 rule. Save long values and `prism_used` with intended/used vintage and known availability/missing cause. Nulls stay null; indicators are separate. A lag change changes the PRISM block only. Notebook cells, not a head registry, define the selected columns.

**Report map:** select every Q3 CC NEW ACCOUNT source row; map to its compatible positive snapshot, preserving unmatched/unscored rows and reasons. Score each distinct matching snapshot once later. Missing customer is not the same as known customer with no touches or no PRISM. Report-only preparation needs only those positive snapshots and features, no training negative sample.

Save ordered `selected_features.csv` and dictionaries as small files. Snapshot/feature/provenance/map and selection data are Hive tables. Show a chosen snapshot, feature vector, contributing/excluded touches and label-supporting conversions; timestamps through seconds. No repeated mandatory checks/read-backs.

## 3 — fit, predict, evaluate

Load the saved selection, snapshots and selected feature blocks with `spark.table`. Pivot/join the needed long values with visible DataFrame code. Keep snapshot keys next to predictors and preserve their row order when assembling prediction output. Select numeric feature columns in the saved ordered list; identifiers, outcome labels, dates and roles do not accidentally become predictors.

Fit mode:

- First fit a binary CC NEW ACCOUNT learner on selected prior-period rows. Use native missing handling or fit any needed preprocessing only on those training rows.
- Call XGBClassifier and `.fit` directly. The YAML parameters and no-tuning first pass are illustrative. Later tuning uses declared fitting-side validation; avoid a generic search system.
- Save `model.json`, exact feature order, feature/head definitions and `config_used.yaml`. A calibrated model must also save its calibration function and use it consistently when scoring/explaining; no calibration is silently added.
- Score the selected Q2 diagnostic and Q3 evaluation populations. Save actual labels, probabilities, model reference and actual fit membership. Q2 scores for unsampled rows are not all in-sample after downsampling.
- Calculate log loss, Brier, prevalence and useful PR-AUC/ROC-AUC/calibration displays on the declared full or correctly weighted evaluation population. A one-class set cannot yield every classification metric; choose meaningful metrics for the actual selected population rather than catching errors. Store small metrics/plots in the file directory.

Predict-only mode is a separate plain cell path: load the saved model/column order/definitions; read compatible new feature rows; call predict_proba; save the output. No refit, new imputer, new sample or automatic new-head inclusion. Positive-only reporting predictions do not provide general occurrence-model evaluation.

A Q3-on-Q3 comparison is a **new fit** with its own name/table names/file folder. Reuse shared features, select Q3 fit rows and label Q3 predictions as fitting diagnostics. Scoring the prior model on Q2 does not perform this comparison. Customer-fold experiments, when requested, use a short visible loop and one actual model per fold; explanations use the model that produced each row's prediction.

## 4 — explain, then allocate

Read the selected prediction table, exact saved model/feature definitions and report map. Select the desired unique snapshots explicitly. Training diagnostics, held-out rows and report positives are different permissible row sets. On a subset explanation run, retain all report conversions with not_explained status for those not yet explained; never turn them into zero scores or modeled unattributed.

Write **fine_groups**, **channel_groups**, **off_values**, PRISM columns and **owen_blocks** directly in cells, as in examples/READABLE_CELLS.md. These lists can be edited by the user. No hierarchy system or dictionary-driven discovery. Groups cover the journey features selected for that game, are disjoint, and exclude PRISM values/indicators. All outside columns stay fixed in the helper.

Use ordinary cells for each selected method:

- Feature TreeSHAP: installed SHAP package, explicit training background and supported output scale. Retain every input feature including PRISM in this diagnostic. Do not write a new TreeSHAP algorithm.
- Direct group Shapley: all columns of each listed group move together. Recompute at channel level for a channel game; summing finer values generally differs.
- Owen: explicit blocks, such as Email's two fine groups together; the helper averages block-respecting orders. No weighted-by-channel-score allocation.
- Removal: full probability minus each group-off probability, preserving removed predictions; its scores need not sum to full minus baseline.

`attribution.py` performs small numerical loops and returns wide pandas score/endpoints tables. Convert to long Hive tables visibly in the notebook. Persist method, grouping level, explained model/output/reference and the selected lists/settings. The helper does not load models, save files, choose data or call other notebooks.

Allocation is a separate cell using already saved signed scores. Apply positive_only, negative_residual and signed_net. Signed-net total ≤0 -> all group credit 0 and unattributed 1. Keep the explicit floating equality tolerance distinct from a threshold on real small positive scores. Baseline probability is outside the allocation denominator. Feature-based credits first sum the selected journey feature scores to the chosen group level as an explicit accounting convention; PRISM remains in the explanation and receives no marketing credit.

Join unique snapshot credits onto **all** report conversion rows with a left join. Rows sharing a snapshot each receive their own full accounting unit. Preserve missing-customer/unscored and not-yet-explained categories distinctly from modeled unattributed. Roll up credits without renormalizing at a coarser level; report cohort count and coverage. Save long credit rows in Hive and a small totals CSV. Show a complete source→snapshot→features→prediction→scores→credits trace.

A new credit rule reuses scores; a new game/grouping reuses model/features but recalculates scores; a new fit requires that fit's own scores. No hidden recomputation.
