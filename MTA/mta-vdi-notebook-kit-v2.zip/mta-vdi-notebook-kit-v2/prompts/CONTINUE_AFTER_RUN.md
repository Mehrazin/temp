Continue the current notebook using my code, current YAML and outputs below. Read COPILOT_RULES.md if needed. Keep my literal table names, chosen settings and simple coding style. Fix the specific error or requested change directly; do not introduce schema checks, try/except, an adapter layer or a framework. Do not regenerate other notebooks or shared data unless the changed calculation actually needs them. If I request a full revised notebook, provide it completely. If I ask for one cell, give that cell.

My current notebook/code:
[PASTE]

My result/error or requested change:
[PASTE]
