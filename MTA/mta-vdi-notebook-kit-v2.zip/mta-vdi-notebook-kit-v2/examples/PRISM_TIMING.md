# Historical head timing — entirely fictional

Month-end intended vintages, lag1, availability strictly before snapshot and missing rather than older fallback are illustrative. Logical aliases below are not asserted TD column names.

| Customer | Head | Vintage | Available at | Score |
|---|---|---|---|---:|
| C1 | P001 | 2026-01-31 00:00:00 | 2026-02-03 08:00:00 | .42 |
| C1 | P002 | 2026-01-31 00:00:00 | 2026-01-31 18:00:00 | .20 |
| C2 | P001 | 2026-01-31 00:00:00 | 2026-02-03 08:00:00 | .31 |

Suppose separate coverage evidence says P003 was not released at that vintage and C2 was not scored for P002.

| Snapshot/customer | P001 | P002 | P003 | Meaning |
|---|---:|---:|---:|---|
| February1 00:00:00 / C1 | NULL | .20 | NULL | P001 unavailable yet; P003 unreleased |
| February4 00:00:00 / C1 | .42 | .20 | NULL | Same intended January vintage now available for P001 |
| February4 00:00:00 / C2 | .31 | NULL | NULL | P002 customer not scored; P003 unreleased |

Without the separate coverage evidence, null causes remain unknown. A two-month lag selects December31 vintage, not January shifted or zero-filled. For May10, lag1 selects April30; lag2 selects March31. Save intended and used dates alongside snapshot/head. Keep null scores and optional missing indicators separate. Feature snapshots use their own time-specific vintage, not one current PRISM table for all history.
