# Runnable synthetic helper demonstration

Optional local numerical illustration, not a notebook-generation gate. Requires only NumPy/pandas and the supplied attribution.py. Run from a folder where that helper is importable. These are manually defined probabilities, not a trained model or TD evidence. Only the count features and P001 affect this toy function; unused recency/decay/P002 columns are omitted from this compact demonstration.

```python
import numpy as np
import pandas as pd
from attribution import group_shapley, owen_values, group_removal, allocate

X = pd.DataFrame({
    "G01_C": [2., 1., 2., 0.],
    "G02_C": [2., 0., 1., 0.],
    "G03_C": [1., 2., 0., 0.],
    "G04_C": [1., 2., 1., 0.],
    "P001": [.42, .25, .35, np.nan],
}, index=pd.Index(["S393", "S526", "S679", "S700"], name="snapshot_id"))

def toy_probability(frame):
    a = (frame["G01_C"] > 0).astype(float)
    b = (frame["G02_C"] > 0).astype(float)
    c = (frame["G03_C"] > 0).astype(float)
    d = (frame["G04_C"] > 0).astype(float)
    context = (frame["P001"] > .30).astype(float)
    return .10 + .10*context + .05*a + .02*b + .03*c - .08*d + .06*a*b + .12*a*b*c

groups = {"G01": ["G01_C"], "G02": ["G02_C"],
          "G03": ["G03_C"], "G04": ["G04_C"]}
off = {"G01_C": 0., "G02_C": 0., "G03_C": 0., "G04_C": 0.}
channels = {"Email": ["G01_C", "G02_C"], "SEO": ["G03_C"], "Leads": ["G04_C"]}
blocks = [["G01", "G02"], ["G03"], ["G04"]]

scores, endpoints = group_shapley(toy_probability, X, groups, off, n_permutations=None)
channel_scores, _ = group_shapley(toy_probability, X, channels, off, n_permutations=None)
owen_scores, _ = owen_values(toy_probability, X, groups, blocks, off, n_permutations=None)
removal_scores, _, removed = group_removal(toy_probability, X, groups, off)
print(scores.round(6))
print(channel_scores.round(6))
print(owen_scores.round(6))
print(removal_scores.round(6))
print(allocate(scores, "signed_net", zero_tolerance=1e-12).round(6))
```

Expected first row: fine (.12,.09,.07,−.08), channel (.19,.09,−.08), Owen (.11,.08,.09,−.08), removal (.23,.20,.15,−.08). Signed credit (.60,.45,.35,−.40), unattributed0. S526's nonzero scores cancel and receive full unattributed under signed-net. S700 is no-touch, all scores0 and full unattributed under all three rules. Unscored source row206 is handled in the report mapping, not passed as a fabricated zero-score input to this helper.
