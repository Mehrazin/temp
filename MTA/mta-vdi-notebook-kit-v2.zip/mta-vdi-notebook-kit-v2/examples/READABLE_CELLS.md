# Small ordinary cells to reuse

These are patterns for the complete notebooks Copilot will generate, not a partial notebook to run as-is. The four group names and two PRISM aliases are from the fictional example. Replace them with chosen real groups/heads in the visible cells. The helper contains math only; reads, row selection, groups and saves stay here.

## Config and explicit table storage

```python
from pathlib import Path
import yaml
from experiment_config import ExperimentConfig

cfg = ExperimentConfig.load("/YOUR_EXISTING_DATABRICKS_DIRECTORY/mta/cc_q2_to_q3/config.yaml")
settings = cfg.settings
artifact_dir = cfg.artifact_dir
```

A literal table name is fine even when YAML lists the same selected name. Keep edited settings aligned manually; no synchronizer.

```python
conversions = spark.table("lumen_mta._conversions_final_mat")
interactions = spark.table("lumen_mta._chnl_interactions_mat")

journey_interactions.write.option("overwriteSchema", True).mode("overwrite").saveAsTable(
    "lumen_mta.customer_history_v1_journey_interactions"
)
```

Generated touch-row references need a persisted source table before downstream use:

```python
from pyspark.sql import functions as F

interactions = interactions.withColumn("touch_row_id", F.monotonically_increasing_id())
interactions.write.option("overwriteSchema", True).mode("overwrite").saveAsTable(
    "lumen_mta.customer_history_v1_interactions"
)
interactions = spark.table("lumen_mta.customer_history_v1_interactions")
```

This reload uses the saved generated keys; it is not a schema/count/readability check. Preserve interaction_id beside touch_row_id. Use the corresponding explicit save for generated conversion_row_id if that option is selected; preserve original row_id. Do not rerun key generation separately in each join branch.

## Model and small files

The notebook assembles `X_train`, `y_train`, `weights_train`, `X_q3` and their matching row references from selected Spark rows. Columns in X are only the ordered numeric predictors, including their numeric nulls.

```python
from xgboost import XGBClassifier
import pandas as pd

model = XGBClassifier(**settings["model"]["params"])
model.fit(X_train, y_train, sample_weight=weights_train)
q3_probability = model.predict_proba(X_q3)[:, 1]

(artifact_dir / "model").mkdir(parents=True, exist_ok=True)
model.save_model(str(artifact_dir / "model/model.json"))
pd.DataFrame({"feature_code": X_train.columns}).to_csv(
    artifact_dir / "model/feature_order.csv", index=False
)
cfg.save(artifact_dir / "model/config_used.yaml")
```

Copy the small selected feature/head definitions beside those files. For prediction only:

```python
model = XGBClassifier()
model.load_model(str(artifact_dir / "model/model.json"))
feature_order = pd.read_csv(artifact_dir / "model/feature_order.csv")["feature_code"].tolist()
X_report = report_features.set_index("snapshot_id")[feature_order]
probability = model.predict_proba(X_report)[:, 1]
```

`report_features` here is the selected wide pandas feature frame built in the notebook, with a unique snapshot_id and the saved model's feature definitions. `X_report.index.name` is snapshot_id. The prediction table retains that key explicitly; no positional join across separately collected unordered Spark frames.

## Explicit fine groups and off values

```python
import numpy as np
from attribution import group_shapley, owen_values, group_removal, allocate

fine_groups = {
    "G01": ["G01_C", "G01_R", "G01_D7", "G01_D30"],
    "G02": ["G02_C", "G02_R", "G02_D7", "G02_D30"],
    "G03": ["G03_C", "G03_R", "G03_D7", "G03_D30"],
    "G04": ["G04_C", "G04_R", "G04_D7", "G04_D30"],
}
off_values = {
    "G01_C": 0., "G01_R": np.nan, "G01_D7": 0., "G01_D30": 0.,
    "G02_C": 0., "G02_R": np.nan, "G02_D7": 0., "G02_D30": 0.,
    "G03_C": 0., "G03_R": np.nan, "G03_D7": 0., "G03_D30": 0.,
    "G04_C": 0., "G04_R": np.nan, "G04_D7": 0., "G04_D30": 0.,
}
prism_columns = ["P001", "P002", "P001_M", "P002_M"]
predict = lambda frame: model.predict_proba(frame)[:, 1]
```

PRISM columns are outside `fine_groups`, so the helper leaves their observed values/indicators fixed. There is no automated group construction. Add extra decay columns to the actual selected lists and off_values when using an expanded model. If a saved model includes another context block, declare its role explicitly; columns outside the listed groups stay fixed. Cross-group engineered features would require coherent recomputation, which this compact helper does not implement.

```python
fine_scores, fine_endpoints = group_shapley(
    predict, X_report, fine_groups, off_values, n_permutations=128, seed=17
)
display(fine_scores)
```

128 is an editable illustration, not proven convergence. For the four-player synthetic game, use `n_permutations=None` for exact 16-coalition values. Select a manageable real explanation row set before calling these in-memory functions; explain additional batches with a visible notebook loop if needed. No hidden Spark collection or file writes occur in the helper.

## Direct channel game and explicit-block Owen

```python
channel_groups = {
    "Email": fine_groups["G01"] + fine_groups["G02"],
    "SEO": fine_groups["G03"],
    "Leads": fine_groups["G04"],
}
channel_scores, channel_endpoints = group_shapley(
    predict, X_report, channel_groups, off_values, n_permutations=128, seed=17
)

owen_blocks = [["G01", "G02"], ["G03"], ["G04"]]
owen_scores, owen_endpoints = owen_values(
    predict, X_report, fine_groups, owen_blocks, off_values,
    n_permutations=128, seed=17
)
display(owen_scores)
```

That literal list is the whole block specification. Each fine group occurs in one block. Exact toy Owen uses `None` and 12 block-respecting orders. Independently sampled channel and Owen runs need not give numerically identical block totals at a finite budget; equality holds for the exact games and in the Monte Carlo limit. No need to build a hierarchy object or read groups from a table.

```python
removal_scores, removal_endpoints, removed_predictions = group_removal(
    predict, X_report, fine_groups, off_values
)
display(removed_predictions)
```

## Actual TreeSHAP call

Use selected fitting-period background rows with the same ordered columns. Background IDs and selection belong in the explanation note. This example is for the installed compatible binary XGBoost/SHAP combination; an ordinary version/API error is fixed directly in this cell.

```python
import shap

explainer = shap.TreeExplainer(
    model, data=X_background,
    feature_perturbation="interventional", model_output="probability"
)
feature_explanation = explainer(X_report)
feature_scores = pd.DataFrame(
    feature_explanation.values, index=X_report.index, columns=X_report.columns
)
feature_endpoints = pd.DataFrame({
    "baseline": np.broadcast_to(feature_explanation.base_values, len(X_report)),
    "probability": predict(X_report),
    "score_sum": feature_scores.sum(axis=1),
}, index=X_report.index)
display(feature_scores)
```

This keeps all feature scores, including PRISM. Do not rename raw-margin output as probability if the local library/model cannot support this call. This pattern assumes the usual 2D single-output explanation for binary XGBoost; select the actual intended class/output explicitly if the local API returns another shape. No general adapter or silent fallback is needed.

If choosing feature-derived marketing credits, visibly sum only journey-feature scores by the selected groups. It remains an aggregation of that feature game.

```python
feature_group_scores = pd.DataFrame({
    g: feature_scores[columns].sum(axis=1) for g, columns in fine_groups.items()
})
```

## Scores to Hive tables

This shows one method. Combine selected methods using concat before the single overwrite, or give each a separate explicit destination.

```python
fine_long = fine_scores.reset_index().melt(
    id_vars="snapshot_id", var_name="player_code", value_name="signed_score"
).assign(method="group_shapley", level="fine_group")

spark.createDataFrame(fine_long).write.option("overwriteSchema", True).mode("overwrite").saveAsTable(
    "lumen_mta.cc_q2_to_q3_explanation_scores"
)
```

Save corresponding endpoint/removal tables using the same direct pattern. The tiny explanation_settings.yaml records the chosen lists, reference, model and game; it is not loaded to construct groups automatically.

## Allocation is separate

```python
positive_credits = allocate(fine_scores, "positive_only")
negative_credits = allocate(fine_scores, "negative_residual")
signed_credits = allocate(fine_scores, "signed_net", zero_tolerance=1e-12)
```

For a complete report, credits are keyed by snapshot and mapped to every source-conversion row with a left join. Below illustrates one rule, retaining unscored and not-explained separately. The notebook creates this per selected method/rule, then combines and saves the results.

```python
credit_long = signed_credits.reset_index().melt(
    id_vars="snapshot_id", var_name="category", value_name="credit_fraction"
)
credit_spark = spark.createDataFrame(credit_long)
conversion_map = spark.table("lumen_mta.cc_q3_conversion_map")

report = conversion_map.join(credit_spark, "snapshot_id", "left")
report = (report
    .withColumn("category", F.when(F.col("snapshot_id").isNull(), F.lit("unscored"))
        .when(F.col("category").isNull(), F.lit("not_explained"))
        .otherwise(F.col("category")))
    .withColumn("credit_fraction", F.coalesce(F.col("credit_fraction"), F.lit(1.0)))
    .withColumn("method", F.lit("group_shapley"))
    .withColumn("level", F.lit("fine_group"))
    .withColumn("rule", F.lit("signed_net")))
report.write.option("overwriteSchema", True).mode("overwrite").saveAsTable(
    "lumen_mta.cc_q2_to_q3_conversion_credits"
)
```

The shown toy has null snapshot only for missing-customer row206. In an actual run, use its explicit prediction/report status to distinguish a mapped-but-unscored snapshot from a scored-but-not-explained snapshot. Do not turn a failed/unscored prediction into modeled unattributed or zero SHAP. A complete selected run has no pending not_explained bucket. Keep the full cohort denominator in a totals table; training sample weights do not scale these credits.
