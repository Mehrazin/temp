# Offline mathematical guide

This is a candidate predictive-attribution workflow, not validated TD results or a causal method. Current requirements supersede old example choices. Begin with one binary CC NEW ACCOUNT model; other constructions, samples and features are explicit comparisons, not a required grid.

## 1. Source rows, linkage and prediction unit

Each selected conversion-source row is one conversion accounting unit q. Keep its original row_id and a persistent row reference. Nullable source interaction_id is not a primary key; touch_row_id identifies one saved input row. No generated key proves real-world uniqueness.

For customer c, let K_c be the union of qualified typed application/DAB references from that customer's conversion rows. Let I_c be direct-customer matches, I_k the touches matching typed reference k. A uses

    J_c = unique journey/touch-row pairs in (I_c ∪ union_{k in K_c} I_k).

Preserve routes and originating reference-conversion relationships. Do not recursively merge customers through shared references. Retrospective reference recovery can use links learned later; label it retrospective, not proven prospective as-of linkage. Interactions themselves are still strictly before each snapshot.

For selected outcome o, horizon h and anchor t:

    Y(c,t,o) = 1 if at least one selected outcome-o conversion row is in [t,t+h), else 0.
    p(c,t,o) = P(Y=1 | feature vector, selected eligible observable population).

Complete label observation is needed to say 0. Two same-day conversions may share one positive snapshot; each still gets one reporting accounting unit. Training predicts occurrence, not number of conversion rows.

A uses one unified customer history and customer/outcome snapshots. B uses one successful conversion journey q with that conversion's references plus direct customer history; while active/unfinished, its label is whether that particular q completes in the horizon. A completed B journey leaves the active set; it does not become a negative. B-union uses B's rows/labels with the unified customer history. Empty journeys remain in journey_index, with an explicitly selected B start convention if needed. The kit implements A first; it does not materialize all constructions together.

Population choices: conversion-derived customers; union with identifiable interaction customers; or a qualified existing customer/scoring population. Outcome-specific converter-only restriction is another cohort choice. A conversion-derived population is retrospective and does not establish full-bank coverage. Absence of touches, missing PRISM, unknown label follow-up and ineligible outcome are different states.

## 2. Independent time and selection settings

History H controls feature retrieval [t−H,t); horizon h controls labels [t,t+h); spacing Δ controls anchors. None is a decay half-life. A 365-day history, 360-day half-life and calendar year are different definitions. The daily example omits all same-day touches after midnight; displaying date-only conversions at midnight does not reveal within-day order.

N1 keeps all eligible observed positive/negative snapshots. N2 preserves positives and only retains a negative if there is no requested outcome in

    [t − b, t + h + a)

where b is before-anchor buffer and a is extra after-horizon buffer. b=a=0 gives N1. Buffers do not relabel excluded rows as positive or change h. Require outcome coverage for the whole negative-selection interval; unresolved boundaries are not no-event observations. At a temporal fit cutoff, a future buffer must not consult test-period outcomes to choose training negatives.

Sampling follows this selection. Uniformly choosing m of N eligible negatives without replacement gives inclusion probability π=m/N and weight 1/π. Keep positives with π=1 if all retained. The target loss is

    − sum_selected (1/π_i) [ y_i log(p_i) + (1−y_i) log(1−p_i) ].

For strata s, use m_s/N_s and retain actual counts/selected keys. Sampling within date, across the whole period, by declared strata, or via customer/time-block stages are separate options. Two-stage inclusion is the product of first-stage and conditional probabilities when those stages define the design. Do not sum overlapping selection-route probabilities. A deterministic every-kth-day grid or cap is not automatically a random sample. Save the realized sample for feature/hyperparameter comparisons.

N2 exclusions have π=0 relative to N1; finite inverse weights cannot restore them. Sampling weights correct the selected row population only. They do not recover excluded customers, missing exposure or unobserved labels. Extra class weighting or calibration is not automatically added on top. Evaluate variants on the same natural-prevalence Q3 population or a probability sample with its own evaluation weights.

## 3. Group features and historical PRISM

Define group g visibly by channel × interaction LOB × event type × interaction target (or another explicitly selected partition). All relevant interaction LOBs may predict CC. Do not treat interaction target as the future conversion label.

    age_j = seconds(t − event_ts_j) / 86400
    C_g = number of included touches
    R_g = min(age_j)
    D_g(τ) = sum_j 2^(−age_j/τ)

Empty group: counts/decays=0, recency=NULL. Initial requested basis: C,R,D7,D30. Expanded: add D60,D90,D180,D360. Optional D365 remains a separate explicit choice. Short codes G01_C etc have readable meanings. Store NULL recency explicitly; an absent feature row means uncomputed, not zero or empty. A wide model matrix is an ordinary selected/pivoted view with saved column order. Learned imputers/scalers belong to the training model, not shared feature tables.

PRISM timing for the illustrated calendar rule:

    intended_vintage(t, lag) = last day of the month lag calendar months before month(t).

For May 10, lag1 means April 30; lag2 means March 31. Use that intended vintage only if its actual publication/availability precedes t. The illustrated policy leaves an unavailable vintage missing; using an older score is a separately chosen fallback with actual used vintage and staleness recorded. This is not “subtract 30/60 elapsed days.” Head-specific dates may differ. Do not invent publication timestamps from month labels.

Keep score NULLs; missing indicators are separate model features. Unreleased head, unscored customer and missing delivery are different causes when supported by evidence. Unknown causes stay unknown. PRISM is fixed context during the journey-group explanation, including its missingness indicators. Its scores are not established no-marketing probabilities, treatment propensities, product eligibility or causal adjustment guarantees.

## 4. Fit, infer and evaluate

First target Q3 is fixed: [2026-05-01 00:00:00,2026-08-01 00:00:00). Prior Q2 [February 1,May 1) is an illustrative fitting period, not a finalized history choice. Fit once on selected prior rows, inspect fitted-period predictions and evaluate Q3. Reporting customers can recur from training. A Q3 model needs a separate Q3 fit; its Q3 scores are in-sample diagnostics.

Other supported comparisons: earlier-quarter, rolling or expanding fit; within-quarter or broader-era customer-held-out fits; fitted-row diagnostic. Customer-held-out folds retain a customer's legitimate feature history while excluding its labelled fit rows. Use the actual fold model for both prediction and explanation. Later dates of other customers in retrospective training do not simulate forward temporal transfer. Neither customer-disjointness nor both disjointness conditions are mandatory for every experiment.

Tune and fit learned preprocessing/calibration inside training partitions. Repeated selection on Q3 makes it an exploratory comparison period; retain a separate final benchmark if independent performance is later desired. Fixed settings and a short visible fit call are sufficient for the first pass. Model plus ordered columns plus feature/head definitions and config_used.yaml preserve inference meaning.

    log loss = −mean(y log p + (1−y) log(1−p))
    Brier = mean((y−p)^2)

Report prevalence, denominator and weighting; PR-AUC/ROC-AUC and calibration can complement these. A positive-only attribution set cannot evaluate general occurrence prediction. Attribution-only inference loads the existing model; it does not refit, create negatives or learn a new imputer.

## 5. Explanation games

For one row, hold its model/output and PRISM context Z fixed. Players are the disjoint journey groups written in the notebook. For coalition S:

    v(S) = predicted probability with groups in S observed, other groups set to no-touch values.
    baseline = v(empty), full = v(all).

Off means all count/decay columns of that group=0 and recencies=NULL, passed through the saved model's preprocessing. The small helper assumes self-contained group features. Cross-group totals/ratios/pairs would need coherent recomputation; do not hold contradictory totals fixed. Context and baseline have no organic/causal interpretation. Coherent masks can still be outside observed support.

Direct group Shapley with m players:

    φ_g = sum_{S subset G\{g}} [ |S|! (m−|S|−1)! / m! ] [v(S∪{g})−v(S)].
    sum_g φ_g = full − baseline.

Small games enumerate 2^m coalitions. Larger games average increments over a chosen number of uniformly sampled full permutations. Permutations restore recorded information in different orders; they never reorder historical events. Every complete permutation telescopes to the endpoint difference, so that equality alone does not establish per-group Monte Carlo convergence. Compare a few chosen seeds/counts when evaluating stability. No all-data exact enumeration default.

**Feature TreeSHAP:** use the installed tree explainer with an explicit background and supported output scale. Individual input columns are players; a standard diagnostic may include PRISM. Background baseline differs from the row-specific fixed-context no-journey baseline. Summing feature values to groups generally differs from recomputing the group game. Dropping PRISM scores afterwards does not change which game was explained. Do not sigmoid individual raw-margin SHAP scores to make them probability contributions. A final calibrated prediction must be explained as that final function; an explainer for an uncalibrated model is not automatically equivalent.

**Coarser direct game:** Email={G01,G02}, SEO={G03}, Leads={G04} moves whole channel blocks at once. Recompute using those players. Equal feature counts do not make summation equal regrouping.

**Owen with literal blocks:** `[[G01,G02],[G03],[G04]]`. Permute blocks uniformly, then permute groups within each block; keep a block's groups adjacent. Average the same marginal increments. At this two-level partition, children's scores sum to their block's direct Shapley in the collapsed game. No multiplication by a channel score, no prediction weighting, and no hierarchy automation. Other block lists are configurable. Exact toy orders: 3! × 2! = 12. Sample larger games with finite permutations.

**Group removal:** d_g = v(all)−v(all without g). Save both probabilities. Removal may count joint effects repeatedly, so its scores need not sum to full−baseline. Both whole-group on/off evaluation and full-input removal are inspectable in the notebook; no causal effect is inferred.

All scores stay signed and are saved before allocation. Save method, player partition, model/output scale, background/reference, off values, fixed context and sampling settings. These are mathematical definitions, not a software registry.

## 6. Signed scores to conversion credits

Let s_g be the chosen group's score; P=sum max(s_g,0), N=sum max(−s_g,0), T=sum s_g=P−N.

| Rule | Group credit | Modeled unattributed |
|---|---|---|
| positive_only | max(s_g,0)/P if P>0, otherwise 0 | 0 when P>0, otherwise 1 |
| negative_residual | max(s_g,0)/(P+N) if mass>0, otherwise 0 | N/(P+N), or 1 when mass=0 |
| signed_net | s_g/T only when T>0, otherwise 0 | 0 when T>0; **1 when T≤0** |

Signed-net may exceed 100% on positive groups and be negative on others. The user explicitly chose the nonpositive-total fallback. Negative-residual is different: positive groups can retain credit even when T≤0. Baseline probability is excluded from all denominators. Preserve scores/P/N/T so a small positive T and large signed fractions remain understandable.

An explicit numerical equality tolerance handles floating cancellation; it is not a selected business threshold. The helper exposes 1e−12 as an illustrative tolerance; set 0 for a literal floating sign comparison or select another explicitly. Do not quietly clamp real negative scores or invent a minimum positive-net rule.

Map each unique snapshot's credit vector to each corresponding source conversion row. Include unscored conversions separately, not as modeled unattributed. A selected explanation subset also needs not-explained coverage. On a complete report:

    signed group credits + modeled unattributed + unscored = number of report conversion rows.

If not all scoreable rows were explained, add that separate pending category to accounting. Training sampling weights do not multiply complete conversion credits. If conversions were randomly sampled for an aggregate estimate, use that separate sampling design explicitly.

Choose allocation granularity first; normalize once, then sum the allocated credits for channel/LOB reporting. Summing raw scores first and renormalizing is another accounting rule. Group scores cannot uniquely recover individual-touch credits; any within-group split would be a separate selected convention.

## 7. Broader comparisons stay optional

Separate binaries may extend to other outcomes. Pooled binary adds requested outcome as an input; multilabel has distinct eligible/observed labels per head; exclusive multiclass requires a truly exclusive target rule. Default binary relevance can just repackage separate binaries. Do not silently force exclusive labels or encode missing heads as negative. These are future explicit branches, not part of notebook 1 or a mandated grid.

MMM dashboard quantities are reported as spend/planning-CPA at channel×LOB×objective. Comparing aligned levels/shares can be descriptive; matching MMM does not validate causal attribution, and tuning to it consumes that benchmark. Predictive contribution, allocated credit, causal impact and future recommendation remain separate. Time-to-event and longitudinal DR are deferred.
