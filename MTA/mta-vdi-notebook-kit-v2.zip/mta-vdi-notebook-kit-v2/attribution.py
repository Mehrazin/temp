"""Small in-memory math helpers. No Spark, file writes or model fitting.

X: pandas numeric frame in saved model column order, unique snapshot index.
predict: callable taking that frame and returning one probability per row.
groups: explicit disjoint dict of player -> list of journey columns.
off_values: explicit dict of journey column -> no-touch value (0 or NaN).
All columns outside groups, including PRISM and its indicators, stay fixed.
Independent per-group features only; cross-group features require coherent
recalculation in the notebook before using a different coalition game.
"""
from itertools import combinations, permutations, product
from math import factorial
import numpy as np
import pandas as pd


def _game(predict, X, groups, off_values):
    empty = X.copy()
    for columns in groups.values():
        for column in columns:
            empty[column] = off_values[column]

    def value(present):
        masked = empty.copy()
        for group in present:
            columns = groups[group]
            masked.loc[:, columns] = X.loc[:, columns]
        return np.asarray(predict(masked), dtype=float).reshape(-1)

    return value


def _tables(X, groups, values, baseline, full):
    scores = pd.DataFrame(values, index=X.index, columns=list(groups))
    endpoints = pd.DataFrame({"baseline": baseline, "probability": full,
                              "score_sum": scores.sum(axis=1)}, index=X.index)
    return scores, endpoints


def group_shapley(predict, X, groups, off_values, n_permutations=128, seed=17):
    """None -> exact 2**m coalitions; integer -> sampled full permutations."""
    names = list(groups)
    value = _game(predict, X, groups, off_values)
    m = len(names)
    baseline, full = value([]), value(names)
    scores = np.zeros((len(X), m))
    if n_permutations is None:
        coalitions = [frozenset(s) for k in range(m + 1)
                      for s in combinations(names, k)]
        predictions = {s: value(s) for s in coalitions}
        for j, group in enumerate(names):
            for s in coalitions:
                if group not in s:
                    weight = factorial(len(s)) * factorial(m - len(s) - 1) / factorial(m)
                    scores[:, j] += weight * (predictions[s | {group}] - predictions[s])
    else:
        rng = np.random.default_rng(seed)
        for _ in range(n_permutations):
            present, previous = [], baseline
            for j in rng.permutation(m):
                present.append(names[j])
                current = value(present)
                scores[:, j] += current - previous
                previous = current
        scores /= n_permutations
    return _tables(X, groups, scores, baseline, full)


def owen_values(predict, X, groups, blocks, off_values, n_permutations=128, seed=17):
    """Literal blocks, e.g. [[G01,G02],[G03],[G04]]; no hierarchy builder.

    Blocks partition the group names, each once. None enumerates all block
    orders and internal orders (small games only). Integer samples those orders.
    """
    names = list(groups)
    value = _game(predict, X, groups, off_values)
    baseline, full = value([]), value(names)
    scores = np.zeros((len(X), len(names)))
    positions = {name: j for j, name in enumerate(names)}
    rng = np.random.default_rng(seed)

    def orders():
        if n_permutations is None:
            for block_order in permutations(range(len(blocks))):
                for inside in product(*(permutations(blocks[b]) for b in block_order)):
                    yield [g for block in inside for g in block]
        else:
            for _ in range(n_permutations):
                yield [g for b in rng.permutation(len(blocks))
                       for g in rng.permutation(blocks[b])]

    count = 0
    for order in orders():
        present, previous = [], baseline
        for group in order:
            present.append(group)
            current = value(present)
            scores[:, positions[group]] += current - previous
            previous = current
        count += 1
    return _tables(X, groups, scores / count, baseline, full)


def group_removal(predict, X, groups, off_values):
    """Full prediction minus one-group-off prediction; no efficiency claim."""
    names = list(groups)
    value = _game(predict, X, groups, off_values)
    full = value(names)
    removed = pd.DataFrame({g: value([h for h in names if h != g])
                            for g in names}, index=X.index)
    scores = pd.DataFrame(full[:, None] - removed.to_numpy(),
                          index=X.index, columns=names)
    endpoints = pd.DataFrame({"baseline": value([]), "probability": full,
                              "score_sum": scores.sum(axis=1)}, index=X.index)
    return scores, endpoints, removed


def allocate(scores, rule, zero_tolerance=1e-12):
    """Wide signed group scores -> wide credit fractions + unattributed.

    Unscored conversions are mapped separately in the notebook. Only signed-net
    uses zero_tolerance, to treat floating-point cancellation as numerical zero.
    Use 0.0 for a strict sign test; no threshold is imposed on positive mass.
    """
    positive = scores.clip(lower=0)
    P = positive.sum(axis=1)
    N = (-scores.clip(upper=0)).sum(axis=1)
    T = scores.sum(axis=1)
    if rule == "positive_only":
        denominator, numerator = P, positive
        active = P > 0
        residual = pd.Series(0.0, index=scores.index)
    elif rule == "negative_residual":
        denominator, numerator = P + N, positive
        active = denominator > 0
        residual = N / denominator.where(active)
    elif rule == "signed_net":
        denominator, numerator = T, scores
        active = T > zero_tolerance
        residual = pd.Series(0.0, index=scores.index)
    credits = numerator.div(denominator.where(active), axis=0).fillna(0.0)
    credits["unattributed"] = residual.where(active, 1.0)
    return credits
