# Worked example — same arithmetic, Hive table storage

Entirely synthetic. No TD model was fitted and no TreeSHAP library was executed for these numbers. Two manually specified probability functions make the calculations reproducible. The old worked_example_v1's custom tree ensemble was a different illustration; its exact feature Shapley was not the TreeSHAP algorithm.

This is the numerical companion to config.yaml and NOTEBOOKS.md. All analytic tables are named `lumen_mta.*` tables as listed in DATA_AND_STORAGE.md. Only YAML/models/small CSVs/plots use the experiment file directory. The old shared-directory storage layout is not used.

## 1. Selected versus illustrative

Fixed report period: TD Q3 [2026-05-01 00:00:00,2026-08-01 00:00:00). First fit prior data and inspect both prior and Q3 scores; separately fit Q3 and explain Q3. The example chooses prior Q2 [2026-02-01 00:00:00,2026-05-01 00:00:00), UTC, A, four conversion-derived customers, daily one-day snapshots, 365-day history, N1/all and lag1. These are illustrative parameter values.

Initial features are C/R/D7/D30 per group plus two fictional PRISM heads and their missing indicators. Optional annual decay is unresolved; D360 is not D365 or a calendar year. The complete editable recipe is config.yaml. No stage silently edits it.

## 2. Notebook 1 — source rows and journeys

Save the six `lumen_mta.customer_history_v1_*` tables. Generated source-row keys are persistent within this named extract. No CC-only source filter is imposed.

### Synthetic conversion source: 13 rows


All rows have conversion type NEW ACCOUNT; dates are date-only source values shown at midnight. Account IDs are omitted from the display only. Each row is one conversion accounting unit.

| row_id | acct_cust_id | conversion_dt | acct_lob | app_ref_num_left |
| --- | --- | --- | --- | --- |
| 90 | C1 | 2025-01-12 00:00:00 | EDB | A0 |
| 101 | C1 | 2026-02-10 00:00:00 | CC | A1 |
| 102 | C2 | 2026-03-15 00:00:00 | CC | B1 |
| 103 | C1 | 2026-04-20 00:00:00 | CC | A2 |
| 104 | C3 | 2026-04-25 00:00:00 | CC | C1 |
| 105 | C4 | 2026-03-20 00:00:00 | EDB | D0 |
| 201 | C1 | 2026-05-10 00:00:00 | CC | A3 |
| 202 | C1 | 2026-05-10 00:00:00 | CC | A4 |
| 203 | C2 | 2026-06-12 00:00:00 | CC | B2 |
| 204 | C3 | 2026-07-20 00:00:00 | CC | C2 |
| 205 | C4 | 2026-07-25 00:00:00 | CC | D1 |
| 206 | NULL | 2026-07-28 00:00:00 | CC | NULL |
| 207 | C2 | 2026-07-30 00:00:00 | EDB | B3 |

### Synthetic interaction source: 17 rows

All targets are NEW ACCOUNT. Channel/LOB/event spellings in this toy, especially `Leads/LEAD`, are illustrative values, not claimed TD schema values. `touch_row_id` is the reference added once to the saved source copy. The original nullable `interaction_id` remains alongside it.

| touch_row_id | interaction_id | cust_id | application_ref_num | event_ts | mkt_channel | lob | event_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| T01 | NULL | C1 | NULL | 2025-01-01 10:00:00 | Email | CC | OPEN |
| T02 | NULL | C1 | NULL | 2026-02-09 10:00:00 | Email | CC | OPEN |
| T03 | I03 | NULL | A2 | 2026-04-19 12:00:00 | Email | CC | CLICK |
| T04 | NULL | C1 | NULL | 2026-05-09 10:00:00 | Email | CC | OPEN |
| T05 | NULL | C1 | A3 | 2026-05-09 11:00:00 | Email | CC | CLICK |
| T06 | NULL | NULL | A4 | 2026-05-08 12:00:00 | SEO | EDB | CLICK |
| T07 | NULL | C1 | NULL | 2026-05-07 12:00:00 | Leads | CC | LEAD |
| T08 | NULL | C1 | NULL | 2026-05-10 09:00:00 | Email | CC | OPEN |
| T09 | I09 | C2 | NULL | 2026-03-14 10:00:00 | Email | CC | OPEN |
| T10 | NULL | NULL | B2 | 2026-06-11 12:00:00 | SEO | EDB | CLICK |
| T11 | NULL | C2 | NULL | 2026-06-10 12:00:00 | Leads | CC | LEAD |
| T12 | NULL | C3 | NULL | 2026-04-24 10:00:00 | Email | CC | OPEN |
| T13 | NULL | C3 | NULL | 2026-07-19 11:00:00 | Email | CC | CLICK |
| T14 | I14 | C3 | NULL | 2026-07-19 10:00:00 | Email | CC | OPEN |
| T15 | NULL | C3 | NULL | 2026-07-18 12:00:00 | Leads | CC | LEAD |
| T16 | NULL | NULL | B1 | 2026-03-13 12:00:00 | SEO | EDB | CLICK |
| T17 | NULL | C2 | NULL | 2026-03-12 12:00:00 | Leads | CC | LEAD |

### Group dictionary

| Group | Channel | Interaction LOB | Event | Target |
|---|---|---|---|---|
| G01 | Email | CC | OPEN | NEW ACCOUNT |
| G02 | Email | CC | CLICK | NEW ACCOUNT |
| G03 | SEO | EDB | CLICK | NEW ACCOUNT |
| G04 | Leads | CC | LEAD | NEW ACCOUNT |

G03 remains available when predicting CC. The actual conversion outcome and the interaction's LOB are separate.

### Saves these six tables

| Output | Toy rows | Meaning |
|---|---:|---|
| `conversions` | 13 | Saved conversion rows; source row_id is unique in the toy |
| `interactions` | 17 | Saved interaction rows with persistent touch references |
| `customer_references` | 12 | One customer/type/reference/source-conversion relationship per row here |
| `customer_index` | 4 | C1–C4, including C4 with no interactions |
| `journey_index` | 4 | One A journey per customer |
| `journey_interactions` | 17 | One journey/touch pair; multiple matching routes retained together |

**`customer_references`: representative rows**

| customer_id | reference_type | reference_value | conversion_row_id |
|---|---|---|---:|
| C1 | application | A1 | 101 |
| C1 | application | A2 | 103 |
| C1 | application | A3 | 201 |
| C1 | application | A4 | 202 |
| C2 | application | B2 | 203 |

DAB references would use separate typed rows. No DAB values are invented for this toy. This table preserves both customer-wide key lookup and conversion-specific reference lookup.

**Complete `journey_index`**

| construction | journey_id | customer_id | conversion_row_id |
|---|---|---|---|
| A | J_C1 | C1 | NULL |
| A | J_C2 | C2 | NULL |
| A | J_C3 | C3 | NULL |
| A | J_C4 | C4 | NULL |

**`journey_interactions`: representative rows**

| construction | journey_id | customer_id | conversion_row_id | touch_row_id | event_ts | group | matched_through |
|---|---|---|---|---|---|---|---|
| A | J_C1 | C1 | NULL | T03 | 2026-04-19 12:00:00 | G02 | application:A2 |
| A | J_C1 | C1 | NULL | T05 | 2026-05-09 11:00:00 | G02 | customer; application:A3 |
| A | J_C1 | C1 | NULL | T06 | 2026-05-08 12:00:00 | G03 | application:A4 |
| A | J_C2 | C2 | NULL | T10 | 2026-06-11 12:00:00 | G03 | application:B2 |

T05 appears once in J_C1, despite two matching routes. `journey_id + touch_row_id` is unique within this named journey dataset. A generated touch-row reference does not prove real-world interaction uniqueness.

For B later, `journey_index` would have a journey for each conversion row and a populated conversion_row_id; links use that row's reference set plus direct customer matches. B-union would attach the unified customer history to those conversion journeys. For B/B-union, notebook 2 must also use the active, unfinished conversion-journey population and its particular-conversion label; completed journeys leave that population. Neither is calculated for this A example. Population/window/label differences stay explicit rather than changing the meaning of A in place.


## 3. Notebook 2 — shared snapshots and labels

Saved table: `lumen_mta.cc_daily_feb_jul_snapshots`.


**Reads:** `journey_index`, `customer_index`, `conversions`. `journey_interactions` supplies features later.

For each customer and daily snapshot:

\[
Y_{c,t}=\mathbf1\{\text{at least one CC NEW ACCOUNT row occurs in }[t,t+1\text{ day})\}.
\]

Features use interactions in `[t − 365 days, t)`. The toy declares complete required interaction/outcome coverage. Real source coverage and eligibility must be stated, rather than treating an unobserved label as zero.

| Dataset portion | Days | Customers | Snapshots | Positive snapshots | Negative snapshots |
|---|---:|---:|---:|---:|---:|
| Q2 | 89 | 4 | 356 | 4 | 352 |
| Q3 | 92 | 4 | 368 | 4 | 364 |
| Shared February–July | 181 | 4 | 724 | 8 | 716 |

C1's two May 10 conversion rows create **one** positive snapshot, later reused for two accounting units. The missing-customer conversion is retained for reporting but does not create a fabricated customer snapshot.

**Snapshot table: representative rows**

| snapshot_id | journey_id | customer_id | snapshot_start | snapshot_end (exclusive) | outcome | label |
| --- | --- | --- | --- | --- | --- | --- |
| S037 | J_C1 | C1 | 2026-02-10 00:00:00 | 2026-02-11 00:00:00 | CC_NEW_ACCOUNT | 1 |
| S038 | J_C2 | C2 | 2026-02-10 00:00:00 | 2026-02-11 00:00:00 | CC_NEW_ACCOUNT | 0 |
| S041 | J_C1 | C1 | 2026-02-11 00:00:00 | 2026-02-12 00:00:00 | CC_NEW_ACCOUNT | 0 |
| S335 | J_C3 | C3 | 2026-04-25 00:00:00 | 2026-04-26 00:00:00 | CC_NEW_ACCOUNT | 1 |
| S393 | J_C1 | C1 | 2026-05-10 00:00:00 | 2026-05-11 00:00:00 | CC_NEW_ACCOUNT | 1 |
| S526 | J_C2 | C2 | 2026-06-12 00:00:00 | 2026-06-13 00:00:00 | CC_NEW_ACCOUNT | 1 |
| S679 | J_C3 | C3 | 2026-07-20 00:00:00 | 2026-07-21 00:00:00 | CC_NEW_ACCOUNT | 1 |
| S700 | J_C4 | C4 | 2026-07-25 00:00:00 | 2026-07-26 00:00:00 | CC_NEW_ACCOUNT | 1 |

The saved table carries construction and nullable journey conversion reference as well; construction is A and that conversion reference is NULL for all these rows. The `snapshot_id` links the dates/customer/outcome shown; it is not an input feature.


### Experiment membership

First fit: 356 Q2 candidates, 4 positives/352 negatives, all weight 1. Q2 diagnostic also scores those 356; Q3 evaluation scores all 368. A row can be both fit and diagnostic. Save split_membership and training_selection in the experiment's Hive tables, not inside the shared snapshot table.

### Reusable journey features

Saved table: `lumen_mta.cc_daily_feb_jul_journey_basic`.


Define, for included events in a group:

\[
a_j=\frac{\operatorname{seconds}(t-event\_ts_j)}{86400},\quad
C_g=|J_g|,\quad R_g=\min_j a_j,\quad D_{g,h}=\sum_j2^{-a_j/h}.
\]

No touches: C/D values 0, recency NULL. Codes are `G01_C`, `G01_R`, `G01_D7`, `G01_D30`, etc. The dictionary explains each code in plain language.

**Trace S393: C1 at 2026-05-10 00:00:00**

| Window element | Value |
|---|---|
| History start | 2025-05-10 00:00:00 |
| Included touch rows | T02, T03, T04, T05, T06, T07 |
| Too old | T01 |
| At/after snapshot start | T08 at 2026-05-10 09:00:00 |
| Label-supporting conversion rows | 201, 202 |

Even if T08 preceded an unknown intraday conversion time, a midnight snapshot excludes it. Date-only conversion data does not establish that order.

| Group | Count | Recency (days) | D7 | D30 |
| --- | --- | --- | --- | --- |
| G01 | 2 | 0.583333 | 0.944015 | 1.112822 |
| G02 | 2 | 0.541667 | 1.079121 | 1.610288 |
| G03 | 1 | 1.500000 | 0.861973 | 0.965936 |
| G04 | 1 | 2.500000 | 0.780709 | 0.943874 |

Store the basic features as a long table, not one copy per future model:

| snapshot_id | feature_code | feature_value |
|---|---|---:|
| S393 | G01_C | 2 |
| S393 | G01_R | 0.583333 |
| S393 | G02_C | 2 |
| S393 | G03_C | 1 |
| S393 | G04_C | 1 |

In this toy, compute all 724 rows once to make reuse easy to see: 724 × 16 = **11,584 journey feature values**. A real run may calculate only the snapshots it needs. A missing stored row means uncomputed; a stored NULL recency has an explicit empty-group meaning.


### Historical PRISM

Saved tables: `lumen_mta.cc_daily_feb_jul_prism_lag1` and `lumen_mta.cc_daily_feb_jul_prism_lag1_used`.


This toy shows two selected heads; actual money-in/out head names and availability come from the real source. These are logical aliases, not invented physical source fields.

| Code | Toy meaning | Family |
|---|---|---|
| P001 | CC acquisition propensity | money_out |
| P002 | Deposit acquisition propensity | money_in |

For every month January–June in the fixture, each customer's scores are held constant purely to simplify the arithmetic. Effective vintage is that month's last date, available at 18:00:00 that date. The next month's snapshots use it. Actual dates and values are preserved in `prism_used`; this fixture convention is not a claim about TD publication times.

| Customer | P001 | P002 | P001_M | P002_M |
| --- | --- | --- | --- | --- |
| C1 | 0.420000 | 0.200000 | 0 | 0 |
| C2 | 0.250000 | NULL | 0 | 1 |
| C3 | 0.350000 | 0.100000 | 0 | 0 |
| C4 | NULL | NULL | 1 | 1 |

P001_M/P002_M indicate missing scores. Source coverage metadata in the toy identifies these NULLs as customer not scored. In real data, absent rows may instead mean missing delivery, unreleased head or unknown reason; do not invent a diagnosis. No requirement that every head be populated for every customer.

For S393, the intended/used vintage is `2026-04-30 00:00:00`, available `2026-04-30 18:00:00`. Its two scores are .42 and .20. If that vintage had been published after the snapshot, the configured policy would leave it missing; an older-score fallback would be another explicit choice.

The fixture stores 724 × 4 = **2,896 PRISM feature values** (two scores and two indicators), plus 724 × 2 = **1,448 head-provenance rows**. Journey and PRISM values remain separate so another PRISM lag need not recalculate journey features.


First model input: 16 journey + 2 PRISM + 2 missingness = 20 ordered numeric columns. Save the selected list as a small CSV in the experiment file directory. No learned imputer/scaler is fitted in notebook 2.

### Report mapping

Saved table: `lumen_mta.cc_q3_conversion_map`.


**Reads:** conversion rows and the shared snapshots. **Selects:** Q3 CC NEW ACCOUNT conversion rows for the report.

| conversion_row_id | customer_id | conversion_dt | snapshot_id | status |
| --- | --- | --- | --- | --- |
| 201 | C1 | 2026-05-10 00:00:00 | S393 | ready |
| 202 | C1 | 2026-05-10 00:00:00 | S393 | ready |
| 203 | C2 | 2026-06-12 00:00:00 | S526 | ready |
| 204 | C3 | 2026-07-20 00:00:00 | S679 | ready |
| 205 | C4 | 2026-07-25 00:00:00 | S700 | ready |
| 206 | NULL | 2026-07-28 00:00:00 | NULL | unscored: missing customer |


Six report rows map to four unique scoreable snapshots: five conversions can be scored and one is unscored. C4 has no touches or PRISM but is still a known customer with a valid model row; conversion 206 has no customer link.

## 4. Notebook 3 — fit and evaluate

Read the shared tables and experiment selection, assemble the ordered matrices visibly, call the selected learner and save model.json plus feature order/definitions and config_used.yaml in the file directory. The numerical tables below instead use the manually specified functions at the end of this example.


The notebook pivots/selects the requested columns, joins labels and membership, and creates the matrices below. This can be ordinary visible DataFrame work; no configurable matrix-building framework is needed.

| Matrix | Rows | Feature columns | Use |
|---|---:|---:|---|
| `X_train` | 356 | 20 | Q2 selected training inputs |
| `y_train` | 356 | — | Four positives, 352 negatives |
| `weights_train` | 356 | — | All 1 in this first experiment |
| `X_q2` | 356 | 20 | Q2 diagnostic predictions |
| `X_q3` | 368 | 20 | Q3 temporal predictions/evaluation |

Customer/journey/snapshot identifiers, dates and labels remain beside the matrix for joins and displays. They do not enter the predictors. Native missing handling or any training-only learned preprocessing belongs to the saved model. The simple first illustration uses the learner's missing handling rather than adding an imputation pipeline.

| Snapshot | Customer | Snapshot start | Actual label | Q2 fixture probability | Q3 fixture probability (later) |
| --- | --- | --- | --- | --- | --- |
| S037 | C1 | 2026-02-10 00:00:00 | 1 | 0.250000 | — |
| S038 | C2 | 2026-02-10 00:00:00 | 0 | 0.100000 | — |
| S041 | C1 | 2026-02-11 00:00:00 | 0 | 0.250000 | — |
| S335 | C3 | 2026-04-25 00:00:00 | 1 | 0.250000 | — |
| S393 | C1 | 2026-05-10 00:00:00 | 1 | 0.400000 | 0.510000 |
| S526 | C2 | 2026-06-12 00:00:00 | 1 | 0.100000 | 0.270000 |
| S679 | C3 | 2026-07-20 00:00:00 | 1 | 0.250000 | 0.370000 |
| S700 | C4 | 2026-07-25 00:00:00 | 1 | 0.100000 | 0.150000 |

Only `Q2 model` is available at this stage. The `Q3 model` column is filled later by the separate Q3 fit in the separate Q3-fit comparison below; it is shown alongside to make comparison concrete.

### Evaluation output

\[
\operatorname{LogLoss}=-\frac1n\sum_i[y_i\log p_i+(1-y_i)\log(1-p_i)],\qquad
\operatorname{Brier}=\frac1n\sum_i(y_i-p_i)^2.
\]

The following values are calculated over **all declared synthetic snapshots**, not just the rows shown above. They evaluate the two manually supplied probability functions. They are not fitted-model results and establish no preferred learner, feature set or fitting period.

| Probability function | Intended evaluation scope | Snapshots | Positives | Log loss | Brier |
| --- | --- | --- | --- | --- | --- |
| q2 | Q2 fit-period diagnostic | 356 | 4 | 0.197270 | 0.037832 |
| q2 | Q3 temporal test | 368 | 4 | 0.265355 | 0.065547 |
| q3 | Q3 fit-period diagnostic | 368 | 4 | 0.410736 | 0.121617 |

In an actual fitted run, the corresponding output scopes would be: Q2 fit diagnostic; Q3 temporal test of the Q2 model; Q3 fit diagnostic of the Q3 model. A future sampled experiment's full-quarter Q2 scores include both selected and unselected rows, so retain actual `fit_member` rather than calling every Q2 row fitted. Natural-prevalence Q3 evaluation stays the same across negative-sampling variants.

With hyperparameter tuning later, use a declared fitting-side validation split. Save its membership in notebook 2; tune in notebook 3. A final all-Q2 refit remains a different fitted artifact from the validation fit, and its Q2 predictions are fitting diagnostics. No complicated tuning machinery is necessary for a few chosen candidates.


Save Q2 and Q3 predictions as `lumen_mta.cc_q2_to_q3_predictions_q2` and `lumen_mta.cc_q2_to_q3_predictions_q3`. Metrics/plots are small files. Working YAML is unchanged.

## 5. Notebook 4 — explicit players and alternative explanations

Select the four positive report snapshots from saved Q3 predictions. No new fit or training negative sample. Use the literal group/block lists and calls shown in examples/READABLE_CELLS.md.


| Explanation | Players | Context/reference |
|---|---|---|
| Fine group Shapley | G01, G02, G03, G04; all columns of each group together | All PRISM values/indicators fixed; removed group uses no-touch values |
| Channel Shapley | Email={G01,G02}; SEO={G03}; Leads={G04} | Same context and off convention; whole channel switches together |
| Feature TreeSHAP | The model's individual input columns | Declared training background; includes PRISM in this diagnostic |
| Owen | Channels are blocks; fine groups are children | Blocks kept contiguous; children reordered inside each block |
| Removal | Each selected fine group, or a whole channel if configured | Remove one from the full input; leave everything else present |

You may later choose a different hierarchy or attribution partition without rebuilding features or refitting the model. A channel game requires recalculating explanations: it is not generally obtained by summing fine-group Shapley.

### One conversion trace: row 201 → S393

The fixture's fixed-context coalition probabilities for this row are defined by:

\[
v(S)=.20+.05I_1+.02I_2+.03I_3-.08I_4+.06I_1I_2+.12I_1I_2I_3,
\]

where `I_g=1` when group g is retained. All four groups are observed for S393. Full prediction=.40; no-journey prediction=.20. The term involving three groups makes the choice of grouping matter. This formula is a supplied toy, not an estimated TD relationship.

For m players, exact Shapley is:

\[
\phi_g=\sum_{S\subseteq G\setminus\{g\}}
\frac{|S|!(m-|S|-1)!}{m!}\big[v(S\cup\{g\})-v(S)\big].
\]

For many groups, average these marginal increments over sampled full permutations. Permutations reveal groups in different orders; they do not move historical timestamps. A real fit can use a chosen seed/permutation count; the four-group toy uses all 16 coalitions.

**Fine group Shapley for the four reporting snapshots**

| Snapshot | Customer | Probability | Baseline | G01 | G02 | G03 | G04 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| S393 | C1 | 0.400000 | 0.200000 | 0.120000 | 0.090000 | 0.070000 | -0.080000 |
| S526 | C2 | 0.100000 | 0.100000 | 0.050000 | 0.000000 | 0.030000 | -0.080000 |
| S679 | C3 | 0.250000 | 0.200000 | 0.080000 | 0.050000 | 0.000000 | -0.080000 |
| S700 | C4 | 0.100000 | 0.100000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |

Each row's score sum equals probability minus baseline. C2's positive/negative scores cancel despite nonzero individual contributions. C4 has zero journey scores because all groups are absent in this fixed-context game.

**Same S393 prediction, alternative explanations**

| Method | G01 Email open | G02 Email click | G03 SEO | G04 Leads | Sum |
|---|---:|---:|---:|---:|---:|
| Fine group Shapley | .1200 | .0900 | .0700 | −.0800 | .2000 |
| Owen: channel → fine group | .1100 | .0800 | .0900 | −.0800 | .2000 |
| Fine group removal | .2300 | .2000 | .1500 | −.0800 | .5000 |

**Channel-level comparison**

| Method | Email | SEO | Leads | Sum |
|---|---:|---:|---:|---:|
| Sum already-computed fine group scores | .2100 | .0700 | −.0800 | .2000 |
| Compute channel Shapley directly | .1900 | .0900 | −.0800 | .2000 |
| Sum Owen child scores within channels | .1900 | .0900 | −.0800 | .2000 |

Owen here averages 3! channel orders × 2! Email-child orders = 12 orders. There is no extra weighting by prediction value. Its children sum to the corresponding collapsed channel-game allocation.

Removal calculates `p(full) − p(without group)`:

| Removed group | Full probability | Without group | Difference |
|---|---:|---:|---:|
| G01 | .40 | .17 | .23 |
| G02 | .40 | .20 | .20 |
| G03 | .40 | .25 | .15 |
| G04 | .40 | .48 | −.08 |

Removal need not sum to full minus baseline. The interaction terms can appear in more than one group's full-input removal difference. Turning a group off coherently sets its counts/decays to zero and recency to missing, then uses the saved model's preprocessing. PRISM remains fixed.

### Feature TreeSHAP output: what should its table mean?

In the toy, choose Q2 training row **S004: C4 at 2026-02-01 00:00:00** as a single background. It has zero journey counts and missing PRISM. Its probability is .10; S393's probability is .40.

The probability functions in the probability-function section below depend only on four count-presence terms and P001. The exact individual-feature **interventional Shapley target** for S393 is therefore:

| Feature | Score |
|---|---:|
| G01_C | .12 |
| G02_C | .09 |
| G03_C | .07 |
| G04_C | −.08 |
| P001 | .10 |
| Each of the other 15 features | .00 |
| **Total** | **.30 = .40 − .10** |

This is an analytic feature-Shapley result for the supplied probability function. **No TreeSHAP library has been executed.** In VDI, the actual supported TreeSHAP calculation supplies the feature table for the fitted model; its API/output scale must match what is being explained. Unsupported probability output must not be relabeled as probability.

Journey feature sums happen to match fine-group scores in this special toy because only one journey feature per group affects its prediction and context is additive. That equality is not a general property. A real model can use recency/decay interactions and yield different feature-summed versus direct-group explanations. Dropping PRISM scores afterward does not turn ordinary feature SHAP into the fixed-context journey game.

For the example's feature-based credit comparison, sum journey feature scores to the chosen fine groups and exclude PRISM from marketing credit, keeping its score in the explanation table. This is an explicit accounting convention for that feature game. PRISM is not silently erased from its explained prediction.


Save scores/endpoints in the experiment's Hive tables with method/level keys; keep removal predictions separately. Write the exact group/block lists and other explanation settings as a small YAML/text note. This is enough to identify the game without a registry.

## 6. Three credit rules


Define `P = sum(max(score,0))`, `N = sum(max(−score,0))`, `T=P−N`.

| Rule | Group credit | Unattributed |
|---|---|---|
| Positive-only | max(score,0)/P if P>0; otherwise 0 | 0 if P>0; otherwise 1 |
| Negative-magnitude residual | max(score,0)/(P+N) if nonzero; otherwise 0 | N/(P+N), or 1 at zero mass |
| Signed-net | score/T **only if T>0**; otherwise every group is 0 | 0 if T>0; **1 if T≤0** |

**The user explicitly chose the signed-net fallback: zero or negative signed total → 100% unattributed.** Negative-residual retains its different behavior: positive groups can still receive fractions when T≤0. Baseline probability is outside all three denominators. These are accounting conventions, not probabilities of causation.

### Row 201, using fine-group Shapley

Scores = (.12,.09,.07,−.08); P=.28, N=.08, T=.20.

| Rule | Email open | Email click | SEO | Leads | Unattributed | Net total |
|---|---:|---:|---:|---:|---:|---:|
| Positive-only | 42.8571% | 32.1429% | 25.0000% | 0% | 0% | 100% |
| Negative residual | 33.3333% | 25.0000% | 19.4444% | 0% | 22.2222% | 100% |
| Signed-net | 60% | 45% | 35% | −40% | 0% | 100% |

Signed-net has **140% positive credit and −40% negative credit**. Conversion row 202 shares S393's explanation and gets another complete unit under the same rule.

### Cancellation and zero-history cases

| Conversion | Scores | Positive-only | Negative residual | Signed-net |
|---|---|---|---|---|
| 203 / C2 | (.05,0,.03,−.08); T=0 | G01=62.5%, G03=37.5%, U=0 | G01=31.25%, G03=18.75%, U=50% | U=100%; all group credits 0 |
| 205 / C4 | All zero | U=100% | U=100% | U=100% |
| 206 / missing customer | No prediction/explanation | Unscored=100% | Unscored=100% | Unscored=100% |

For row 204, T=.05 but positive mass=.13: signed normalization gives 260% positive and −160% negative. Small positive totals can amplify credit magnitude; preserve/display raw scores and denominators. The illustration adds no unrequested threshold that changes the user's rule.

### Full six-conversion report: fine-group credits

These totals include both rows 201 and 202 separately. Units are conversion credits, not percentages or event counts inferred by the model.

| Rule | G01 | G02 | G03 | G04 | Unattributed | Unscored | Net total |
| --- | --- | --- | --- | --- | --- | --- | --- |
| positive_only | 2.097527 | 1.027473 | 0.875000 | 0.000000 | 1 | 1 | 6.000000 |
| negative_residual | 1.360119 | 0.738095 | 0.576389 | 0.000000 | 2.325397 | 1 | 6.000000 |
| signed_net | 2.800000 | 1.900000 | 0.700000 | -2.400000 | 2 | 1 | 6.000000 |

Every rule totals six after summing **signed** group credit + modeled unattributed + unscored. Negative totals are permitted only in the signed-net rule. For human reporting, roll G01/G02 allocated credits into Email after allocation. Re-normalizing raw scores after changing granularity would be a different accounting procedure.


Save all selected method/level/rule credit rows in `lumen_mta.cc_q2_to_q3_conversion_credits`; a small report_totals.csv is optional. Rows 201 and 202 reuse one explanation but receive separate accounting units. No score recomputation is needed to change a credit rule.

## 7. Other fits and feature choices

| Change | Notebook action | Reused | New outputs |
|---|---|---|---|
| cc_q3_on_q3 | Select Q3 fit rows in 2, fit in 3, explain/allocate in 4 | All shared inputs and same report map | 368-row Q3 selection; new model, diagnostic predictions and scores/credits |
| cc_q2_n2_before7 | Change only selection then fit/explain | Snapshots/features | 330 Q2 fit rows: 4 positives +326 negatives, 26 excluded |
| cc_q2_sample2to1 | Keep 4 positives, sample 8/352 negatives | Existing features | 12 selected fit rows, negative π=8/352, weight44; new fit |
| cc_q2_more_decays | Compute extra decays in 2, fit in 3 | Existing C/R/D7/D30/PRISM | 16 new columns, 11,584 new long values; 36 total model columns |
| count+recency only | Select those 8 journey columns plus chosen PRISM | Existing values | New ordered input list and fit |
| prism lag2 | Calculate only new PRISM block in 2 | Journeys/snapshots/basic features | New lag2 values/provenance, fit and downstream outputs |

For each comparison, copy config.yaml; change name, artifact_dir and experiment table names explicitly. Keep reusable table names unchanged. The Q3 fit uses Q3 training background if feature SHAP is requested (e.g. toy S360, C4 May1). The N2 and sample fits still evaluate on the same complete N1 Q3 population. No synthetic fitted results are invented for N2/sample/extra-decay variants.

N2 b7/a0 means no CC conversion in [t−7,t+1) for a negative. After C1's February10 positive, February11–17 negatives are excluded; labels are not changed. Before/after buffers are independent and need observed outcomes. A future buffer cannot use Q3 outcomes to select prior fit rows.

For random sampling, save actual selected keys and probabilities; changing hyperparameters reuses that selection. Uniform negative weight44 targets the chosen N1 row population. N2 exclusions cannot be restored by finite weights. No automatic extra class weight.

A customer-held-out option excludes that subset's supervised fitting rows, preserving their historical inputs. Excluding all Q3 customers in this toy would remove every Q2 fit row; use a genuine subset or larger population. The initial temporal experiment permits returning customers.

### Added decay values for S393


| Group | D60 | D90 | D180 | D360 |
| --- | --- | --- | --- | --- |
| G01 | 1.348543 | 1.497125 | 1.705998 | 1.840449 |
| G02 | 1.782891 | 1.849786 | 1.922010 | 1.960256 |
| G03 | 0.982821 | 0.988514 | 0.994240 | 0.997116 |
| G04 | 0.971532 | 0.980930 | 0.990419 | 0.995198 |


## 8. Attribution only with an existing model

If Q3 full predictions already exist, reuse them; notebook 4 selects the four report snapshots. If not, create four unique positive snapshots, 64 journey values, 16 PRISM values, eight PRISM provenance rows and the six-row conversion map in descriptive Hive tables. Load the saved model/ordered features and score only those four rows in notebook 3 predict-only. No negatives, fitting or new imputation. Probabilities are .40,.10,.25,.10 for the same fixture and inputs. No general occurrence metric can be inferred from those positive rows alone.

Local IDs from a separately built dataset may differ. Keep the dataset/table reference and match the declared journey/customer/outcome/start/end semantics; do not join unrelated IDs accidentally.

### Complete conversion trace


| Stage | Selected object | Result |
|---|---|---|
| Source | Conversion 201 | C1, CC NEW ACCOUNT, 2026-05-10 00:00:00, A3 |
| Reference mapping | C1 references | Includes A1/A2/A3/A4 and provenance |
| Journey | J_C1 / construction A | Unified direct/reference-linked history |
| Snapshot | S393 | [2026-05-10 00:00:00, 2026-05-11 00:00:00), y=1 |
| History | 365 days | T02–T07; exclude old T01 and same-day T08 |
| Features | Basic + historical PRISM | 20 ordered columns; P001=.42, P002=.20 |
| Prediction | Q2 model's Q3 output | .40 |
| Fine group explanation | .20 baseline | (.12,.09,.07,−.08) |
| Positive-only allocation | Same explanation | (42.8571%,32.1429%,25%,0%), U0 |
| Negative-residual allocation | Same explanation | (33.3333%,25%,19.4444%,0%), U22.2222% |
| Signed-net allocation | Same explanation | (60%,45%,35%,−40%), U0 |
| Second conversion 202 | Same S393 | Reuse probability/explanation, retain another full accounting unit |


## 9. Reproducible probability functions


This section makes the arithmetic reproducible without claiming model training. Let `z_g=1` if the snapshot's observed group count is positive, otherwise 0; `b=1` if P001>.30, otherwise 0, including missing P001. The toy probability functions are:

\[
f_{Q2}(X)=.10+.10b+.05z_1+.02z_2+.03z_3-.08z_4+.06z_1z_2+.12z_1z_2z_3,
\]

\[
f_{Q3}(X)=.15+.10b+.10z_1+.02z_2+.06z_3-.04z_4+.04z_1z_2+.08z_1z_2z_3.
\]

Their outputs stay within [0,1] for all binary group/context states. These deliberately small, tree-representable functions ignore the remaining feature columns. That makes group/channel/Owen/feature calculations transparent; real fits can learn different behavior from counts, recencies, decays and PRISM. No improvement from extra features or Q3 fitting is implied by these supplied numbers.

The feature-Shapley example uses S004 as its single interventional background, so context baseline=.10. The group game holds S393's actual context fixed, so baseline=.20. The PRISM score .10 in the feature table explains that difference; neither baseline is interpreted as organic conversion probability.

Group values were enumerated across the 16 coalitions, channel values across eight coalitions, and Owen across 12 block-respecting orders. Removal compares full to each omitted-group prediction. Feature-Shapley active-player values follow the additive/context/interaction expression; no TreeSHAP algorithm was run. The metrics sum over 356 Q2 and 368 Q3 synthetic rows using their generated labels and the above functions.

The signed allocation illustration uses the user's selected T≤0 fallback. The cancellation in C2's score vector is exactly zero mathematically; floating-point implementation details should not accidentally turn numerical residue into enormous shares. A numerical equality tolerance, if needed in actual code, should be visible and distinguished from a business threshold on small genuine positive totals.


## 10. Storage and rewrite summary

0 creates the working YAML/file folder. 1 creates the six shared history Hive tables. 2 creates shared snapshot/feature/PRISM/map tables and experiment selection tables. 3 creates model files, two prediction tables and small metrics. 4 creates explanation and credit tables. No stage changes YAML merely by executing. Reuse means a direct spark.table read; a new variant changes its explicit destination names. Ordinary overwrite cells are acceptable for the current unfinished result. No status files, schema checks, read-back gates, try/except or dependency manager are part of this workflow.
