# Provenance and offline implementation notes

The current user request controls this v2 kit: simple complete notebooks; copied source tables and all derived data in `lumen_mta`; separate file directory for artifacts; direct Spark reads/overwrite saves; optional config and attribution helpers; explicit group lists, no hierarchy automation. The request authorizes preparing this package, not a TD model run.

The preceding handoff checkpoint was EXP-a7b4df03f703 revision10. The latest CC_Q3_WORKED_WORKFLOW.md supplies the numerical example; its original 1095-line source remains unchanged in the local exploration. This kit reuses its synthetic numerical sections, adapts storage and replaces its unimplemented helper interface with the included callable helper. The original package/ZIP is historical and is not bundled here, so its generation instructions cannot override v2.

Governing project documents consulted selectively:

- P03-v2 EXPERIMENT_CONTEXT.md (2026-10-03): population, A/B/B-union, N1/N2, sampling, feature and fitting alternatives. Its older business-event consolidation and infrastructure suggestions do not override the latest one-source-row accounting and simplicity instructions.
- P03 CONVERSATION_EVIDENCE.md: reported counts/relationships remain unverified; source cleaning is parked.
- P02 METHOD_CONTEXT.md: fixed-context probability game, grouped Shapley, feature sums, Owen, removal and positive/negative-residual allocation. Signed-net with nonpositive fallback is a newer explicit user choice.
- P01 PROJECT_KNOWLEDGE.md: qualified source fields/preparation/linkage. Original interaction_id is not assumed unique; copies inherit earlier filters and special branches.
- P01 E003 VISIBLE_ACTIVE_CODE.txt line20 and E008 EXTRACTED_CELLS.txt lines228–229/350–351: supplied VDI write pattern `.write.option("overwriteSchema", True).mode("overwrite").saveAsTable(...)`. Only that relevant pattern was used; no original filtering or defensive missing-column loop was copied into this kit.

This package includes the source semantics, equations and examples needed offline. It does not require opening those local source files, external links or images in VDI. No production code or database query was executed here. No TD cohort, PRISM schema, count, calibration, causal effect or model accuracy is validated.

## Official API notes checked during packaging

These concise notes are included so VDI does not need to browse. Installed versions may differ; ordinary errors can be fixed locally without a version-discovery framework.

- Spark `saveAsTable` writes a named table; overwrite replaces existing contents. The exact overwriteSchema option pattern comes from the supplied VDI code. [Spark API](https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.DataFrameWriter.saveAsTable.html).
- TreeExplainer documents probability output with an explicit interventional background. Raw binary XGBoost output is log odds; do not relabel it. The notebook cell uses the installed library, not a custom TreeSHAP algorithm. [SHAP API](https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html).
- XGBoost model IO supports JSON via save_model/load_model. Store the notebook's selected feature definitions and configuration separately beside it. [XGBoost model IO](https://xgboost.readthedocs.io/en/stable/tutorials/saving_model.html).

No internet installation commands are included. Group Shapley/Owen/removal/allocations in attribution.py need NumPy and pandas; the optional YAML helper needs PyYAML. These are stated dependencies, not an installation workflow. Spark, XGBoost and SHAP execute later in the user's VDI environment, not in this packaging session.
