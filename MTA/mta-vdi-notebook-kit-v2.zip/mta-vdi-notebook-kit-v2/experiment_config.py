"""Optional YAML convenience. Tables remain ordinary schema.table strings."""
from pathlib import Path
import yaml


class ExperimentConfig:
    def __init__(self, settings):
        self.settings = settings
        self.artifact_dir = Path(settings["artifact_dir"])

    @classmethod
    def load(cls, filename):
        with open(filename) as stream:
            return cls(yaml.safe_load(stream))

    def save(self, filename):
        with open(filename, "w") as stream:
            yaml.safe_dump(self.settings, stream, sort_keys=False)
