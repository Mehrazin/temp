# Data, readable names and exact save locations

Use one user-selected `BASE_DIR` in approved Databricks storage. Notebook source files may live in the Databricks workspace; save a source export/copy under the experiment when convenient. Data, models, configurations, previews and summaries go below `BASE_DIR`. Do not assume the location where the ZIP was unzipped is a Spark-accessible data location.

## 1. Proposed layout

All names below are examples, not chosen dates/settings. Choose descriptive names once and print full paths in each notebook. `_v1` is a human-readable version; changing the meaning creates `_v2` or a descriptive new name. Names and full paths are the identities; no UUID registry is required.

```
BASE_DIR/
  data/
    journeys/history_v1/
      conversions/                    # typed selected conversion rows
      interactions/                   # selected source rows with persisted touch keys
      customer_index/                 # includes eligible no-touch customers
      journey_interactions/           # linked long rows
      metadata.json
    datasets/cc_daily_q2_v1/
      snapshots/
      metadata.json
    features/journey_365d_v1/
      feature_dictionary.csv
      group_dictionary.csv
      cc_daily_q2_v1/feature_values/
      metadata.json
    features/prism_lag1_v1/
      feature_dictionary.csv
      prism_head_dictionary.csv
      cc_daily_q2_v1/feature_values/
      cc_daily_q2_v1/prism_used/
      metadata.json
    feature_sets/cc_counts_prism_v1.csv
    reports/cc_q2_v1/
      conversion_map/
      metadata.json
  experiments/cc_new_account/prior_fit_v1/
    config.json
    NOTES.md
    selections/
      split_membership/
      training_selection/
      sampling_summary/
      metadata.json
    model/
      fitted_model.json                # example XGBoost-native artifact, if selected
      ordered_features.csv
      preprocessing.json              # or actual saved fitted transformer if required
      metadata.json
    tuning_results/
    predictions/q2/
      predictions/
      evaluation_summary/
      metadata.json
    explanations/group_q2/
      endpoints/
      scores/
      metadata.json
    allocations/positive_only_q2/
      conversion_credits/
      report_totals/
      metadata.json
    inspection/                       # small chosen traces/previews, not full copies
    logs/                             # step summaries and output locations
```

If using customer folds, `model/fold_1/`, `model/fold_2/` etc each contain the actual fitted artifact and metadata. Predictions retain their fold/model reference. A new experiment can reference the previous experiment's selection or model path without copying it. The exact selected paths are saved in `config.json`.

Notebook 2 can create features for several compatible datasets under the same definition folder. Journey features and PRISM features are separate reusable blocks so changing PRISM lag need not recalculate journey counts. A feature-set CSV selects/reorders columns from those blocks. Keep this as a small table and ordinary joins, not a new framework.

Example feature-set membership:

| position | feature_block | feature_code |
|---:|---|---|
| 1 | journey_365d_v1 | G01_C |
| 2 | journey_365d_v1 | G01_R |
| 3 | prism_lag1_v1 | P017 |
| 4 | prism_lag1_v1 | P017_M |

`P017_M` is an optional selected missingness indicator. The head dictionary explains P017. If two chosen blocks expose the same feature code, resolve the alias/definition explicitly before pivoting; do not silently choose one.

## 2. Small notebook config

Use a few direct variables rather than a universal config file with every future possibility:

- Common: base directory and experiment name.
- Notebook 1: actual source tables, extract scope, linkage policy, output history name.
- Notebook 2: selected history/dataset names; outcome; population and dates; H/h/spacing/timezone; selected feature definitions and PRISM policy; split/sample choices only if needed now.
- Notebook 3: explicit training/evaluation dataset and feature-set paths, selection path, model settings or existing model path, output prediction name.
- Notebook 4: prediction/model/feature paths, report map, selected explanation and credit settings.

Save the resolved values next to outputs. Metadata contains source versions/extract identity, input paths, feature definitions, selected settings, library versions, timestamps, counts and status. It need not repeat every code in every displayed row. Do not maintain two independently editable copies of the same setting; save a snapshot of the variables actually used.

## 3. Core tables and grains

These are **derived logical columns**, not claims about physical source schemas. Within a selected folder, the folder supplies the dataset/run identity. If tables from different folders are combined, add their descriptive source name to preserve scoped keys.

| Stored table | One row per / key | Important columns |
|---|---|---|
| conversions | selected source conversion row | conversion_row_id, original_row_id, customer_id, conversion_date, outcome, account/reference fields |
| interactions | source interaction row within fixed extract | touch_row_id, original interaction_id, customer/reference fields, event_ts, channel/LOB/event/target |
| customer_index | customer in the named history/population scope | customer_id, construction, membership/coverage information |
| journey_interactions | construction/journey/touch-row pair | customer_id, nullable conversion_row_id, touch_row_id, event_ts, group attributes, matching_routes |
| snapshots | snapshot key and requested outcome | snapshot_id, construction, customer_id, optional journey reference, snapshot_start/end, outcome, label, observation status |
| split_membership | snapshot/outcome per fit or fold assignment | snapshot_id, outcome, role, fold when used |
| training_selection | candidate snapshot/outcome per selected sample | negative_rule_eligible, selected, stratum, probability, weight, exclusion reason |
| sampling_summary | class/stratum and relevant date/outcome | eligible count, selected count, design probability, seed |
| feature_values | snapshot/feature code within dataset + definition block | feature_value (numeric nullable), value_status |
| prism_used | snapshot/head | intended vintage, used vintage, availability evidence, score, missing reason |
| conversion_map | selected reporting conversion row | customer_id, outcome, nullable dataset/snapshot reference, status/reason |
| predictions | snapshot/outcome/model within named prediction output | actual_label, probability, role, actual_fit_member, fold/model reference |
| evaluation_summary | model/scope/outcome/period | counts, prevalence, weighting, log loss, Brier and selected metrics |
| endpoints | prediction reference within explanation output | baseline, full prediction, explained scale, score_sum |
| scores | prediction/player within explanation output | player_kind, player_code, signed_score |
| conversion_credits | conversion row/category within allocation output | explanation reference, credit_fraction, group/unattributed/unscored category |

Dictionaries are small CSVs. Base analytic tables are typed Parquet directories in the proposed minimal implementation; if an established approved Delta workflow is simpler locally, use it explicitly. Both are database-friendly columnar structures. No elaborate SQL is necessary; temporary views can expose a chosen table for inspection without creating persistent catalog objects.

`feature_values` missing row means uncomputed/not provided; an explicit null value can mean no-touch recency or unavailable PRISM. An explicit zero count is observed empty under the declared coverage, not a null. Verify expected feature keys for every row claimed complete. A wide matrix is a pivot/view with saved model column order, not a second authoritative dataset.

## 4. Storage behavior, logs and reuse

Each stage has a short visible save section showing dataframe -> exact path. Use fail-if-exists writes for completed outputs. After writing, read back and check the key/count/schema or a bounded trace. Save a summary with `status=complete` last. No atomic-write framework is required; downstream loads require complete status and matching inputs/settings.

For a resumed interrupted build, either select a new output folder or explicitly handle the incomplete output. Do not silently overwrite a shared completed feature block or append duplicate keys. If calculating additional feature rows, write a clearly named supplementary part with disjoint keys and list it in metadata, or write a new complete version; show the choice. Do not build automatic merge machinery merely to support this possibility.

When a definition changes, existing folder names must not retain a new meaning. A small config/metadata comparison (sources, timing, feature codes/formulas and model column order) is enough for compatibility. No UUIDs or hash-based naming are needed; optional hashes belong in metadata only.

A simple output-location log can look like:

| object | path | rows | status |
|---|---|---:|---|
| snapshots | BASE_DIR/data/datasets/cc_daily_q2_v1/snapshots | measured count | complete |
| predictions | BASE_DIR/experiments/cc_new_account/prior_fit_v1/predictions/q2/predictions | measured count | complete |

Do not log full feature/customer rows by default. Bounded trace displays are intentional, chosen inspection data. Logs describe what was read/written, counts/exclusions and decisions; not a separate observability system.

## 5. What to rerun

| Change | Start here |
|---|---|
| Hyperparameters only | Notebook 3; same datasets/features/selection |
| Select another already computed feature subset | Notebook 3 with a different ordered feature-set list |
| Change negative sampling or N2 buffers | Notebook 2 selection cells, then 3; calculate newly needed feature rows only |
| Change training period/customer split inside prepared coverage | Notebook 2 membership cells, then 3 |
| Change PRISM lag/head policy | Notebook 2 PRISM cells, then 3; reuse journey features |
| Different report using an existing model | Notebook 2 missing report inputs, notebook 3 predict-only, notebook 4 |
| Different explanation method | Notebook 4 explanation and allocation cells |
| Different allocation rule | Notebook 4 allocation cells only |
| Another conversion outcome | Notebook 2 outcome labels/eligibility/selections; reuse compatible journey/PRISM features; 3 and 4 |
| New history construction or source version | Notebook 1 and affected downstream inputs |

## 6. Databricks path choice

Ask for an existing writable approved location. If a Unity Catalog volume is available, `/Volumes/<catalog>/<schema>/<volume>/<folder>` is a path that Spark and Python file operations can use on supported compute. This kit uses it only as an example, not a requirement to create a volume or register tables. Databricks also supports other existing storage conventions; confirm their actual access instead of pretending `pathlib` works with an `abfss://` URI. For a non-POSIX path, use the established Spark/dbutils file-write mechanism explicitly for metadata or a small driver temporary file plus a copy. Keep one visible base setting; do not scatter path conversions through hidden helpers.

The optional code snippets target an existing POSIX-accessible volume. They do not run until placeholders are filled. Source table reads use table names; they are separate from output file paths. Notebook 1 should display the selected convention before saving data.
