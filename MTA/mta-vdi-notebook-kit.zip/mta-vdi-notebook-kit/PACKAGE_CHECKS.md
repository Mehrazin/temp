# Package checks

Prepared 2026-10-04. These are packaging/synthetic arithmetic checks, not TD validation.

- 46 copied reference files match their original source hashes.
- Saved toy tables checked: 308 unique features, 176 unique predictions, explanation endpoint identity and 24 conversion/allocation unit totals.
- 24 local Markdown links resolve within the package.
- Python reference and all Python code snippets pass syntax parsing; reference math assertions also passed separately.
- No Databricks, Spark, XGBoost or SHAP execution/installation performed here. Notebook source mappings and runtime checks remain VDI work.
- The original synthetic generator, renderer and source artifacts were not modified or rerun.
