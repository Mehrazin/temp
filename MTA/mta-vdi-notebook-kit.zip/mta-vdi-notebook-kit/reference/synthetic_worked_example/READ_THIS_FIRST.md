# Reading the saved toy

Open `WORKED_EXAMPLE.md` for the full source → journey → snapshot → feature → model → explanation → credit trace. Each linked CSV is included and gives the complete table, even when the markdown shows only selected columns/rows. `models.json` preserves the tiny fitted synthetic model artifacts.

This is a saved illustration, not the VDI implementation. Use the main kit's current names, multihead PRISM policy and notebook prompts. Do not copy the custom tree engine into the CC experiment. The original build/render scripts and redundant all_tables.json are not needed and are not bundled. The earlier markdown's references to those original files describe its original provenance.

All people, source rows, dates and computed outputs in this folder are synthetic. No actual source data or TD validation is represented.
