# MTA — full worked notebook example

Synthetic data only. Numerical features, seven small fitted tree ensembles, predictions, validation/test metrics, exact Shapley scores and credits are calculated. This is a workflow illustration, not a TD result or a selected production learner. The numeric engine is a nine-tree random-subspace ensemble; fitted artifacts and its generator accompany the example.

All timestamps use UTC and seconds. Conversion dates are date-only source values displayed at midnight. All named customers are assumed observable and eligible for the toy target; source outcomes are complete through 2026-09-01 00:00:00. Source snapshot SV1 is fixed. One conversion source row is one accounting unit. All interaction targets are NEW ACCOUNT. Blank DAB fields are omitted.

## 0. Experiments, definitions and stored-versus-view design

| workflow | dataset | features | selection | result |
| --- | --- | --- | --- | --- |
| Feature comparison | D1 | F1/F2/F3/F4 | SAM1 | M01/M02/M03/M04 |
| Sampling comparison | D1 | F4 | SAM0/SAM1/SAM2/SAM3 | M07/M04/M05/M06 |
| August inference | D2 | F4 | positive conversion snapshots only | AUG_M04 and AUG_M05 |
| Explanation comparison | D2 | same saved inputs | same predictions | feature Shapley / group Shapley / removal |
| Allocation comparison | same report rows | same group scores | positive-only / negative-residual | four allocation runs |


**group_dictionary**

| dictionary_version | group_id | channel | interaction_lob | event_type | target |
| --- | --- | --- | --- | --- | --- |
| DICT1 | G01 | Email | CC | OPEN | NEW ACCOUNT |
| DICT1 | G02 | SEO | EDB | CLICK | NEW ACCOUNT |
| DICT1 | G03 | Display | CC | VIEW | NEW ACCOUNT |


O1 = CC × NEW ACCOUNT. P01 = a fictional selected CC PRISM head; P01_M = 1 when its score is unavailable, otherwise 0. Actual PRISM source fields/head mapping remain to be supplied for implementation.

\[a_j=\frac{\operatorname{seconds}(snapshot\_start-event\_ts_j)}{86400},\quad C_g=|J_g|,\quad R_g=\min_j a_j,\quad D30_g=\sum_j2^{-a_j/30}.\]

**feature_dictionary**

| dictionary_version | feature_code | kind | group_id | definition | no_interaction_value |
| --- | --- | --- | --- | --- | --- |
| DICT1 | G01_C | journey | G01 | count | 0 |
| DICT1 | G01_R | journey | G01 | recency_days | NULL |
| DICT1 | G01_D30 | journey | G01 | decayed_count_half_life_30_days | 0 |
| DICT1 | G02_C | journey | G02 | count | 0 |
| DICT1 | G02_R | journey | G02 | recency_days | NULL |
| DICT1 | G02_D30 | journey | G02 | decayed_count_half_life_30_days | 0 |
| DICT1 | G03_C | journey | G03 | count | 0 |
| DICT1 | G03_R | journey | G03 | recency_days | NULL |
| DICT1 | G03_D30 | journey | G03 | decayed_count_half_life_30_days | 0 |
| DICT1 | P01 | context | NULL | PRISM_CC_head | hold fixed |
| DICT1 | P01_M | context | NULL | PRISM_missing_indicator | hold fixed |


| feature_set_id | features | count |
| --- | --- | --- |
| F1 | G01_C, G02_C, G03_C | 3 |
| F2 | C and R for G01/G02/G03 | 6 |
| F3 | C, R and D30 for G01/G02/G03 | 9 |
| F4 | F3 + P01 + P01_M | 11 |


Shared primitive feature values are stored once. Feature-set membership selects/reorders columns; adding F4 does not duplicate F1 values.

**Stored lookup: feature_set_members — F4**

Displayed projection: 11 of 29 rows. [Complete CSV](feature_set_members.csv).

| feature_set_id | position | dictionary_version | feature_code |
| --- | --- | --- | --- |
| F4 | 1 | DICT1 | G01_C |
| F4 | 2 | DICT1 | G01_R |
| F4 | 3 | DICT1 | G01_D30 |
| F4 | 4 | DICT1 | G02_C |
| F4 | 5 | DICT1 | G02_R |
| F4 | 6 | DICT1 | G02_D30 |
| F4 | 7 | DICT1 | G03_C |
| F4 | 8 | DICT1 | G03_R |
| F4 | 9 | DICT1 | G03_D30 |
| F4 | 10 | DICT1 | P01 |
| F4 | 11 | DICT1 | P01_M |


| persisted | inspection_view |
| --- | --- |
| journey_interactions | one customer with an array of touch IDs |
| snapshots + split membership + training selection | snapshot intervals, labels, role and sample weights together |
| feature_values, long numeric values | wide feature matrix for one feature set |
| predictions | labels and predictions side by side across models |
| explanation endpoints + long player scores | feature/group columns; removal calculations |
| report_rows + long attribution_credits | one conversion per row with group percentages |


Compact definitions/configurations can live in one run register and the small dictionaries. CSVs labelled views/inspection are reproducible displays, not a requirement to create a permanent database table for each one. Full snapshot×all-touch expansions are not required in a real run.

## 1. Notebook 1 — source rows → linked journeys

Inputs: SV1 conversions, interactions and historical PRISM. Outputs: referenced source rows and JSET1 journeys. Linkage here is explicitly retrospective.

**conversions**

| row_id | acct_cust_id | acct_id | conversion_dt | acct_lob | acct_conversion_type | app_ref_num_left |
| --- | --- | --- | --- | --- | --- | --- |
| 101 | C1 | AC101 | 2025-02-10 00:00:00 | EDB | NEW ACCOUNT | A0 |
| 102 | C1 | AC102 | 2026-07-01 00:00:00 | CC | NEW ACCOUNT | A1 |
| 103 | C2 | AC103 | 2026-07-02 00:00:00 | CC | NEW ACCOUNT | B1 |
| 104 | C1 | AC104 | 2026-07-03 00:00:00 | CC | NEW ACCOUNT | A2 |
| 105 | C3 | AC105 | 2026-07-02 00:00:00 | EDB | NEW ACCOUNT | C0 |
| 106 | C3 | AC106 | 2026-07-04 00:00:00 | CC | NEW ACCOUNT | C1 |
| 107 | C2 | AC107 | 2026-07-05 00:00:00 | CC | NEW ACCOUNT | B2 |
| 108 | C4 | AC108 | 2026-07-06 00:00:00 | CC | NEW ACCOUNT | D1 |
| 109 | C2 | AC109 | 2026-07-07 00:00:00 | CC | NEW ACCOUNT | B3 |
| 201 | C1 | AC201 | 2026-08-02 00:00:00 | CC | NEW ACCOUNT | A3 |
| 202 | C1 | AC202 | 2026-08-15 00:00:00 | CC | NEW ACCOUNT | A4 |
| 203 | C1 | AC203 | 2026-08-15 00:00:00 | CC | NEW ACCOUNT | A5 |
| 204 | C2 | AC204 | 2026-08-20 00:00:00 | CC | NEW ACCOUNT | B4 |
| 205 | C5 | AC205 | 2026-08-22 00:00:00 | CC | NEW ACCOUNT | E1 |
| 206 | NULL | AC206 | 2026-08-25 00:00:00 | CC | NEW ACCOUNT | NULL |
| 207 | C3 | AC207 | 2026-08-28 00:00:00 | EDB | NEW ACCOUNT | C2 |


**interactions**

Displayed projection: 21 of 21 rows. [Complete CSV](interactions.csv).

| touch_row_id | interaction_id | cust_id | application_ref_num | event_ts | mkt_channel | lob | event_type |
| --- | --- | --- | --- | --- | --- | --- | --- |
| T01 | NULL | C1 | NULL | 2024-12-15 12:00:00 | Email | CC | OPEN |
| T02 | NULL | C1 | NULL | 2025-07-01 12:00:00 | SEO | EDB | CLICK |
| T03 | NULL | C1 | NULL | 2026-06-28 12:00:00 | Email | CC | OPEN |
| T04 | I04 | NULL | A1 | 2026-06-30 12:00:00 | SEO | EDB | CLICK |
| T05 | NULL | NULL | A2 | 2026-07-01 12:00:00 | Display | CC | VIEW |
| T06 | NULL | C1 | NULL | 2026-07-02 12:00:00 | Email | CC | OPEN |
| T07 | NULL | C1 | NULL | 2026-07-04 12:00:00 | Display | CC | VIEW |
| T08 | I08 | C1 | NULL | 2026-08-01 12:00:00 | Email | CC | OPEN |
| T09 | NULL | C1 | A4 | 2026-08-14 12:00:00 | SEO | EDB | CLICK |
| T10 | NULL | C1 | NULL | 2026-08-16 12:00:00 | Display | CC | VIEW |
| T11 | NULL | C2 | NULL | 2025-06-01 12:00:00 | Email | CC | OPEN |
| T12 | I12 | C2 | NULL | 2026-06-29 12:00:00 | Email | CC | OPEN |
| T13 | NULL | NULL | B1 | 2026-07-01 12:00:00 | SEO | EDB | CLICK |
| T14 | NULL | NULL | B2 | 2026-07-04 12:00:00 | Display | CC | VIEW |
| T15 | NULL | C2 | NULL | 2026-08-19 12:00:00 | Email | CC | OPEN |
| T16 | I16 | C2 | NULL | 2026-08-21 12:00:00 | SEO | EDB | CLICK |
| T17 | NULL | C3 | NULL | 2026-06-30 12:00:00 | Display | CC | VIEW |
| T18 | NULL | C3 | NULL | 2026-07-03 12:00:00 | Email | CC | OPEN |
| T19 | NULL | C3 | NULL | 2026-08-10 12:00:00 | Email | CC | OPEN |
| T20 | I20 | NULL | D1 | 2026-07-05 12:00:00 | SEO | EDB | CLICK |
| T21 | NULL | C5 | NULL | 2026-08-23 12:00:00 | Email | CC | OPEN |


**PRISM source — illustrative logical schema**

| customer_id | head_code | score_vintage | available_at | score |
| --- | --- | --- | --- | --- |
| C1 | P01 | 2026-06-01 00:00:00 | 2026-06-03 08:00:00 | 0.3500 |
| C1 | P01 | 2026-07-01 00:00:00 | 2026-07-03 08:00:00 | 0.4200 |
| C1 | P01 | 2026-08-01 00:00:00 | 2026-08-03 08:00:00 | 0.5500 |
| C2 | P01 | 2026-06-01 00:00:00 | 2026-06-03 08:00:00 | 0.2500 |
| C2 | P01 | 2026-07-01 00:00:00 | 2026-07-03 08:00:00 | 0.3200 |
| C2 | P01 | 2026-08-01 00:00:00 | 2026-08-03 08:00:00 | 0.4000 |
| C3 | P01 | 2026-06-01 00:00:00 | 2026-06-03 08:00:00 | 0.1500 |
| C3 | P01 | 2026-07-01 00:00:00 | 2026-07-03 08:00:00 | 0.2200 |
| C3 | P01 | 2026-08-01 00:00:00 | 2026-08-03 08:00:00 | 0.3000 |
| C4 | P01 | 2026-07-01 00:00:00 | 2026-07-03 08:00:00 | 0.1200 |
| C4 | P01 | 2026-08-01 00:00:00 | 2026-08-03 08:00:00 | 0.1800 |


**journey_interactions**

Displayed projection: 21 of 21 rows. [Complete CSV](journey_interactions.csv).

| construction | journey_id | customer_id | conversion_row_id | touch_row_id | event_ts | group_id | matched_through |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A | J1 | C1 | NULL | T01 | 2024-12-15 12:00:00 | G01 | [customer] |
| A | J1 | C1 | NULL | T02 | 2025-07-01 12:00:00 | G02 | [customer] |
| A | J1 | C1 | NULL | T03 | 2026-06-28 12:00:00 | G01 | [customer] |
| A | J1 | C1 | NULL | T04 | 2026-06-30 12:00:00 | G02 | [application:A1] |
| A | J1 | C1 | NULL | T05 | 2026-07-01 12:00:00 | G03 | [application:A2] |
| A | J1 | C1 | NULL | T06 | 2026-07-02 12:00:00 | G01 | [customer] |
| A | J1 | C1 | NULL | T07 | 2026-07-04 12:00:00 | G03 | [customer] |
| A | J1 | C1 | NULL | T08 | 2026-08-01 12:00:00 | G01 | [customer] |
| A | J1 | C1 | NULL | T09 | 2026-08-14 12:00:00 | G02 | [customer, application:A4] |
| A | J1 | C1 | NULL | T10 | 2026-08-16 12:00:00 | G03 | [customer] |
| A | J2 | C2 | NULL | T11 | 2025-06-01 12:00:00 | G01 | [customer] |
| A | J2 | C2 | NULL | T12 | 2026-06-29 12:00:00 | G01 | [customer] |
| A | J2 | C2 | NULL | T13 | 2026-07-01 12:00:00 | G02 | [application:B1] |
| A | J2 | C2 | NULL | T14 | 2026-07-04 12:00:00 | G03 | [application:B2] |
| A | J2 | C2 | NULL | T15 | 2026-08-19 12:00:00 | G01 | [customer] |
| A | J2 | C2 | NULL | T16 | 2026-08-21 12:00:00 | G02 | [customer] |
| A | J3 | C3 | NULL | T17 | 2026-06-30 12:00:00 | G03 | [customer] |
| A | J3 | C3 | NULL | T18 | 2026-07-03 12:00:00 | G01 | [customer] |
| A | J3 | C3 | NULL | T19 | 2026-08-10 12:00:00 | G01 | [customer] |
| A | J4 | C4 | NULL | T20 | 2026-07-05 12:00:00 | G02 | [application:D1] |
| A | J5 | C5 | NULL | T21 | 2026-08-23 12:00:00 | G01 | [customer] |


**Readable customer-journey view**

| journey_id | customer_id | construction | touches |
| --- | --- | --- | --- |
| J1 | C1 | A | [T01, T02, T03, T04, T05, T06, T07, T08, T09, T10] |
| J2 | C2 | A | [T11, T12, T13, T14, T15, T16] |
| J3 | C3 | A | [T17, T18, T19] |
| J4 | C4 | A | [T20] |
| J5 | C5 | A | [T21] |


T09 is stored once although customer and application routes both match it. C4 still belongs to the training cohort before its first touch. C5 has a later touch, but no touch before its reporting conversion.

## 2. Notebook 2 — datasets, splits, sampling and features

Inputs: JSET1 + conversions + PRISM + definitions. Outputs: snapshots, selection records and long feature values. Inspection arrays and wide matrices are views.

**dataset_register**

| dataset_id | purpose | construction | journey_set_id | population | start | end_exclusive | horizon_days | history_days | snapshot_count |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| D1 | training/evaluation | A | JSET1 | C1,C2,C3,C4 | 2026-07-01 00:00:00 | 2026-07-07 00:00:00 | 1 | 365 | 24 |
| D2 | conversion attribution | A | JSET1 | August CC conversion rows | 2026-08-01 00:00:00 | 2026-09-01 00:00:00 | 1 | 365 | 4 |


D1 has 24 snapshots: four customers × six days. D2 has four unique positive snapshots for six requested conversion rows; one requested conversion cannot be linked to a customer.

**snapshots**

Displayed projection: 28 of 28 rows. [Complete CSV](snapshots.csv).

| dataset_id | snapshot_id | construction | customer_id | snapshot_start | snapshot_end | outcome | label |
| --- | --- | --- | --- | --- | --- | --- | --- |
| D1 | S01 | A | C1 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | O1 | 1 |
| D1 | S02 | A | C2 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | O1 | 0 |
| D1 | S03 | A | C3 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | O1 | 0 |
| D1 | S04 | A | C4 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | O1 | 0 |
| D1 | S05 | A | C1 | 2026-07-02 00:00:00 | 2026-07-03 00:00:00 | O1 | 0 |
| D1 | S06 | A | C2 | 2026-07-02 00:00:00 | 2026-07-03 00:00:00 | O1 | 1 |
| D1 | S07 | A | C3 | 2026-07-02 00:00:00 | 2026-07-03 00:00:00 | O1 | 0 |
| D1 | S08 | A | C4 | 2026-07-02 00:00:00 | 2026-07-03 00:00:00 | O1 | 0 |
| D1 | S09 | A | C1 | 2026-07-03 00:00:00 | 2026-07-04 00:00:00 | O1 | 1 |
| D1 | S10 | A | C2 | 2026-07-03 00:00:00 | 2026-07-04 00:00:00 | O1 | 0 |
| D1 | S11 | A | C3 | 2026-07-03 00:00:00 | 2026-07-04 00:00:00 | O1 | 0 |
| D1 | S12 | A | C4 | 2026-07-03 00:00:00 | 2026-07-04 00:00:00 | O1 | 0 |
| D1 | S13 | A | C1 | 2026-07-04 00:00:00 | 2026-07-05 00:00:00 | O1 | 0 |
| D1 | S14 | A | C2 | 2026-07-04 00:00:00 | 2026-07-05 00:00:00 | O1 | 0 |
| D1 | S15 | A | C3 | 2026-07-04 00:00:00 | 2026-07-05 00:00:00 | O1 | 1 |
| D1 | S16 | A | C4 | 2026-07-04 00:00:00 | 2026-07-05 00:00:00 | O1 | 0 |
| D1 | S17 | A | C1 | 2026-07-05 00:00:00 | 2026-07-06 00:00:00 | O1 | 0 |
| D1 | S18 | A | C2 | 2026-07-05 00:00:00 | 2026-07-06 00:00:00 | O1 | 1 |
| D1 | S19 | A | C3 | 2026-07-05 00:00:00 | 2026-07-06 00:00:00 | O1 | 0 |
| D1 | S20 | A | C4 | 2026-07-05 00:00:00 | 2026-07-06 00:00:00 | O1 | 0 |
| D1 | S21 | A | C1 | 2026-07-06 00:00:00 | 2026-07-07 00:00:00 | O1 | 0 |
| D1 | S22 | A | C2 | 2026-07-06 00:00:00 | 2026-07-07 00:00:00 | O1 | 0 |
| D1 | S23 | A | C3 | 2026-07-06 00:00:00 | 2026-07-07 00:00:00 | O1 | 0 |
| D1 | S24 | A | C4 | 2026-07-06 00:00:00 | 2026-07-07 00:00:00 | O1 | 1 |
| D2 | A01 | A | C1 | 2026-08-02 00:00:00 | 2026-08-03 00:00:00 | O1 | 1 |
| D2 | A02 | A | C1 | 2026-08-15 00:00:00 | 2026-08-16 00:00:00 | O1 | 1 |
| D2 | A03 | A | C2 | 2026-08-20 00:00:00 | 2026-08-21 00:00:00 | O1 | 1 |
| D2 | A04 | A | C5 | 2026-08-22 00:00:00 | 2026-08-23 00:00:00 | O1 | 1 |


All snapshot_end values are exclusive. Labels use [snapshot_start, snapshot_end); features use [snapshot_start − 365 days, snapshot_start).

### 2.1 Split membership

**Stored split_membership — first eight rows**

Displayed projection: 8 of 24 rows. [Complete CSV](split_membership.csv).

| split_id | dataset_id | snapshot_id | role | construction |
| --- | --- | --- | --- | --- |
| SPLIT1 | D1 | S01 | train | A |
| SPLIT1 | D1 | S02 | train | A |
| SPLIT1 | D1 | S03 | train | A |
| SPLIT1 | D1 | S04 | train | A |
| SPLIT1 | D1 | S05 | train | A |
| SPLIT1 | D1 | S06 | train | A |
| SPLIT1 | D1 | S07 | train | A |
| SPLIT1 | D1 | S08 | train | A |


**Readable split/label view — each customer cell is snapshot ID / label**

| snapshot_start | snapshot_end | role | C1 | C2 | C3 | C4 |
| --- | --- | --- | --- | --- | --- | --- |
| 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | train | S01 / y=1 | S02 / y=0 | S03 / y=0 | S04 / y=0 |
| 2026-07-02 00:00:00 | 2026-07-03 00:00:00 | train | S05 / y=0 | S06 / y=1 | S07 / y=0 | S08 / y=0 |
| 2026-07-03 00:00:00 | 2026-07-04 00:00:00 | train | S09 / y=1 | S10 / y=0 | S11 / y=0 | S12 / y=0 |
| 2026-07-04 00:00:00 | 2026-07-05 00:00:00 | validation | S13 / y=0 | S14 / y=0 | S15 / y=1 | S16 / y=0 |
| 2026-07-05 00:00:00 | 2026-07-06 00:00:00 | test | S17 / y=0 | S18 / y=1 | S19 / y=0 | S20 / y=0 |
| 2026-07-06 00:00:00 | 2026-07-07 00:00:00 | test | S21 / y=0 | S22 / y=0 | S23 / y=0 | S24 / y=1 |


Customers intentionally overlap across calendar splits. No customer IDs enter the predictors. Depth is selected using validation only; reported test results are exploratory comparisons, not an independently selected winner.

### 2.2 Negative rules and sampling

**sampling_configs**

| sampling_id | split_id | negative_rule | before_days | after_days | design | seed |
| --- | --- | --- | --- | --- | --- | --- |
| SAM0 | SPLIT1 | N1 | 0 | 0 | all train rows | NULL |
| SAM1 | SPLIT1 | N1 | 0 | 0 | all positives; 3 of 9 negatives | 17 |
| SAM2 | SPLIT1 | N1 | 0 | 0 | all positives; 2 empty + 1 active negatives | 23/24 |
| SAM3 | SPLIT1 | N2 | 1 | 0 | all surviving train rows | NULL |


N2 here uses b=1 day and a=0: keep positives; exclude negatives with a requested conversion in the preceding day. It requires no future look beyond the ordinary label horizon. Validation/test remain the same unsampled N1 population.

| sampling_id | stratum | candidate_rows | selected_rows | inclusion_probability | weight |
| --- | --- | --- | --- | --- | --- |
| SAM1 | negative | 9 | 3 | 0.3333 | 3 |
| SAM2 | empty-history negative | 3 | 2 | 0.6667 | 1.5000 |
| SAM2 | active-history negative | 6 | 1 | 0.1667 | 6 |


**Stored training_selection — SAM2**

Displayed projection: 12 of 48 rows. [Complete CSV](training_selection.csv).

| sampling_id | snapshot_id | label | negative_rule_eligible | stratum | selected | sampling_probability | training_weight | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SAM2 | S01 | 1 | yes | positive | yes | 1.0000 | 1.0000 | selected |
| SAM2 | S02 | 0 | yes | active | no | 0.1667 | NULL | not_sampled |
| SAM2 | S03 | 0 | yes | active | no | 0.1667 | NULL | not_sampled |
| SAM2 | S04 | 0 | yes | empty | yes | 0.6667 | 1.5000 | selected |
| SAM2 | S05 | 0 | yes | active | no | 0.1667 | NULL | not_sampled |
| SAM2 | S06 | 1 | yes | positive | yes | 1.0000 | 1.0000 | selected |
| SAM2 | S07 | 0 | yes | active | no | 0.1667 | NULL | not_sampled |
| SAM2 | S08 | 0 | yes | empty | yes | 0.6667 | 1.5000 | selected |
| SAM2 | S09 | 1 | yes | positive | yes | 1.0000 | 1.0000 | selected |
| SAM2 | S10 | 0 | yes | active | no | 0.1667 | NULL | not_sampled |
| SAM2 | S11 | 0 | yes | active | yes | 0.1667 | 6.0000 | selected |
| SAM2 | S12 | 0 | yes | empty | no | 0.6667 | NULL | not_sampled |


**Readable comparison of all sampling selections**

| snapshot_id | customer_id | snapshot_start | label | SAM0 | SAM1 | SAM2 | SAM3 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| S01 | C1 | 2026-07-01 00:00:00 | 1 | selected; w=1 | selected; w=1 | selected; w=1 | selected; w=1 |
| S02 | C2 | 2026-07-01 00:00:00 | 0 | selected; w=1 | not_sampled | not_sampled | selected; w=1 |
| S03 | C3 | 2026-07-01 00:00:00 | 0 | selected; w=1 | not_sampled | not_sampled | selected; w=1 |
| S04 | C4 | 2026-07-01 00:00:00 | 0 | selected; w=1 | not_sampled | selected; w=1.5 | selected; w=1 |
| S05 | C1 | 2026-07-02 00:00:00 | 0 | selected; w=1 | not_sampled | not_sampled | buffer_excluded |
| S06 | C2 | 2026-07-02 00:00:00 | 1 | selected; w=1 | selected; w=1 | selected; w=1 | selected; w=1 |
| S07 | C3 | 2026-07-02 00:00:00 | 0 | selected; w=1 | not_sampled | not_sampled | selected; w=1 |
| S08 | C4 | 2026-07-02 00:00:00 | 0 | selected; w=1 | not_sampled | selected; w=1.5 | selected; w=1 |
| S09 | C1 | 2026-07-03 00:00:00 | 1 | selected; w=1 | selected; w=1 | selected; w=1 | selected; w=1 |
| S10 | C2 | 2026-07-03 00:00:00 | 0 | selected; w=1 | selected; w=3 | not_sampled | buffer_excluded |
| S11 | C3 | 2026-07-03 00:00:00 | 0 | selected; w=1 | selected; w=3 | selected; w=6 | selected; w=1 |
| S12 | C4 | 2026-07-03 00:00:00 | 0 | selected; w=1 | selected; w=3 | not_sampled | selected; w=1 |


Selected row counts: SAM0=12; SAM1=6; SAM2=6; SAM3=10. Weight sums: 12, 12, 12, 10. S05 and S10 are N2 exclusions, not relabeled positives. Population-correction weights do not recover them.

### 2.3 Window inspection

**window_inspection**

Displayed projection: 9 of 28 rows. [Complete CSV](window_inspection.csv).

| snapshot_id | history_start | included_touches | too_old | at_or_after_start |
| --- | --- | --- | --- | --- |
| S01 | 2025-07-01 00:00:00 | [T02, T03, T04] | [T01] | [T05, T06, T07, T08, T09, T10] |
| S04 | 2025-07-01 00:00:00 | [] | [] | [T20] |
| S05 | 2025-07-02 00:00:00 | [T03, T04, T05] | [T01, T02] | [T06, T07, T08, T09, T10] |
| S09 | 2025-07-03 00:00:00 | [T03, T04, T05, T06] | [T01, T02] | [T07, T08, T09, T10] |
| S13 | 2025-07-04 00:00:00 | [T03, T04, T05, T06] | [T01, T02] | [T07, T08, T09, T10] |
| A01 | 2025-08-02 00:00:00 | [T03, T04, T05, T06, T07, T08] | [T01, T02] | [T09, T10] |
| A02 | 2025-08-15 00:00:00 | [T03, T04, T05, T06, T07, T08, T09] | [T01, T02] | [T10] |
| A03 | 2025-08-20 00:00:00 | [T12, T13, T14, T15] | [T11] | [T16] |
| A04 | 2025-08-22 00:00:00 | [] | [] | [T21] |


Arrays are typed lists for inspection. Feature calculation can use range joins/aggregation directly; it does not need to parse concatenated strings.

### 2.4 PRISM timing

**prism_inspection**

Displayed projection: 9 of 28 rows. [Complete CSV](prism_inspection.csv).

| snapshot_id | customer_id | snapshot_start | score_vintage | available_at | value | missing |
| --- | --- | --- | --- | --- | --- | --- |
| S01 | C1 | 2026-07-01 00:00:00 | 2026-06-01 00:00:00 | 2026-06-03 08:00:00 | 0.3500 | 0 |
| S04 | C4 | 2026-07-01 00:00:00 | NULL | NULL | NULL | 1 |
| S09 | C1 | 2026-07-03 00:00:00 | 2026-06-01 00:00:00 | 2026-06-03 08:00:00 | 0.3500 | 0 |
| S13 | C1 | 2026-07-04 00:00:00 | 2026-07-01 00:00:00 | 2026-07-03 08:00:00 | 0.4200 | 0 |
| S16 | C4 | 2026-07-04 00:00:00 | 2026-07-01 00:00:00 | 2026-07-03 08:00:00 | 0.1200 | 0 |
| A01 | C1 | 2026-08-02 00:00:00 | 2026-07-01 00:00:00 | 2026-07-03 08:00:00 | 0.4200 | 0 |
| A02 | C1 | 2026-08-15 00:00:00 | 2026-08-01 00:00:00 | 2026-08-03 08:00:00 | 0.5500 | 0 |
| A03 | C2 | 2026-08-20 00:00:00 | 2026-08-01 00:00:00 | 2026-08-03 08:00:00 | 0.4000 | 0 |
| A04 | C5 | 2026-08-22 00:00:00 | NULL | NULL | NULL | 1 |


The July vintage is unavailable at 2026-07-03 00:00:00 because release is at 2026-07-03 08:00:00. The August-2 snapshot uses July PRISM. C5 has missing PRISM, not a score of zero.

### 2.5 Long feature storage → wide model views

**Stored feature_values — S01, all eleven values**

Displayed projection: 11 of 308 rows. [Complete CSV](feature_values.csv).

| dataset_id | snapshot_id | dictionary_version | feature_code | feature_value | value_status |
| --- | --- | --- | --- | --- | --- |
| D1 | S01 | DICT1 | G01_C | 1 | available |
| D1 | S01 | DICT1 | G01_R | 2.5000 | available |
| D1 | S01 | DICT1 | G01_D30 | 0.9439 | available |
| D1 | S01 | DICT1 | G02_C | 2 | available |
| D1 | S01 | DICT1 | G02_R | 0.5000 | available |
| D1 | S01 | DICT1 | G02_D30 | 0.9887 | available |
| D1 | S01 | DICT1 | G03_C | 0 | available |
| D1 | S01 | DICT1 | G03_R | NULL | no_touch |
| D1 | S01 | DICT1 | G03_D30 | 0 | available |
| D1 | S01 | DICT1 | P01 | 0.3500 | available |
| D1 | S01 | DICT1 | P01_M | 0 | available |


Stored key: dataset_id + snapshot_id + dictionary_version + feature_code. All feature sets reference these same values. There are 308 stored values: 28 snapshots × 11 features, rather than one duplicate copy per feature set.

**Readable F4 view — all 28 snapshots**

Displayed projection: 28 of 28 rows. [Complete CSV](feature_wide_view.csv).

| dataset_id | snapshot_id | G01_C | G01_R | G01_D30 | G02_C | G02_R | G02_D30 | G03_C | G03_R | G03_D30 | P01 | P01_M |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| D1 | S01 | 1 | 2.5000 | 0.9439 | 2 | 0.5000 | 0.9887 | 0 | NULL | 0 | 0.3500 | 0 |
| D1 | S02 | 1 | 1.5000 | 0.9659 | 0 | NULL | 0 | 0 | NULL | 0 | 0.2500 | 0 |
| D1 | S03 | 0 | NULL | 0 | 0 | NULL | 0 | 1 | 0.5000 | 0.9885 | 0.1500 | 0 |
| D1 | S04 | 0 | NULL | 0 | 0 | NULL | 0 | 0 | NULL | 0 | NULL | 1 |
| D1 | S05 | 1 | 3.5000 | 0.9223 | 1 | 1.5000 | 0.9659 | 1 | 0.5000 | 0.9885 | 0.3500 | 0 |
| D1 | S06 | 1 | 2.5000 | 0.9439 | 1 | 0.5000 | 0.9885 | 0 | NULL | 0 | 0.2500 | 0 |
| D1 | S07 | 0 | NULL | 0 | 0 | NULL | 0 | 1 | 1.5000 | 0.9659 | 0.1500 | 0 |
| D1 | S08 | 0 | NULL | 0 | 0 | NULL | 0 | 0 | NULL | 0 | NULL | 1 |
| D1 | S09 | 2 | 0.5000 | 1.8898 | 1 | 2.5000 | 0.9439 | 1 | 1.5000 | 0.9659 | 0.3500 | 0 |
| D1 | S10 | 1 | 3.5000 | 0.9223 | 1 | 1.5000 | 0.9659 | 0 | NULL | 0 | 0.2500 | 0 |
| D1 | S11 | 0 | NULL | 0 | 0 | NULL | 0 | 1 | 2.5000 | 0.9439 | 0.1500 | 0 |
| D1 | S12 | 0 | NULL | 0 | 0 | NULL | 0 | 0 | NULL | 0 | NULL | 1 |
| D1 | S13 | 2 | 1.5000 | 1.8466 | 1 | 3.5000 | 0.9223 | 1 | 2.5000 | 0.9439 | 0.4200 | 0 |
| D1 | S14 | 1 | 4.5000 | 0.9013 | 1 | 2.5000 | 0.9439 | 0 | NULL | 0 | 0.3200 | 0 |
| D1 | S15 | 1 | 0.5000 | 0.9885 | 0 | NULL | 0 | 1 | 3.5000 | 0.9223 | 0.2200 | 0 |
| D1 | S16 | 0 | NULL | 0 | 0 | NULL | 0 | 0 | NULL | 0 | 0.1200 | 0 |
| D1 | S17 | 2 | 2.5000 | 1.8044 | 1 | 4.5000 | 0.9013 | 2 | 0.5000 | 1.9108 | 0.4200 | 0 |
| D1 | S18 | 1 | 5.5000 | 0.8807 | 1 | 3.5000 | 0.9223 | 1 | 0.5000 | 0.9885 | 0.3200 | 0 |
| D1 | S19 | 1 | 1.5000 | 0.9659 | 0 | NULL | 0 | 1 | 4.5000 | 0.9013 | 0.2200 | 0 |
| D1 | S20 | 0 | NULL | 0 | 0 | NULL | 0 | 0 | NULL | 0 | 0.1200 | 0 |
| D1 | S21 | 2 | 3.5000 | 1.7632 | 1 | 5.5000 | 0.8807 | 2 | 1.5000 | 1.8672 | 0.4200 | 0 |
| D1 | S22 | 1 | 6.5000 | 0.8606 | 1 | 4.5000 | 0.9013 | 1 | 1.5000 | 0.9659 | 0.3200 | 0 |
| D1 | S23 | 1 | 2.5000 | 0.9439 | 0 | NULL | 0 | 1 | 5.5000 | 0.8807 | 0.2200 | 0 |
| D1 | S24 | 0 | NULL | 0 | 1 | 0.5000 | 0.9885 | 0 | NULL | 0 | 0.1200 | 0 |
| D2 | A01 | 3 | 0.5000 | 1.9334 | 1 | 32.5000 | 0.4719 | 2 | 28.5000 | 1.0006 | 0.4200 | 0 |
| D2 | A02 | 3 | 13.5000 | 1.4318 | 2 | 0.5000 | 1.3380 | 2 | 41.5000 | 0.7410 | 0.5500 | 0 |
| D2 | A03 | 2 | 0.5000 | 1.2928 | 1 | 49.5000 | 0.3186 | 1 | 46.5000 | 0.3415 | 0.4000 | 0 |
| D2 | A04 | 0 | NULL | 0 | 0 | NULL | 0 | 0 | NULL | 0 | NULL | 1 |


C/R/D30 in each group are numeric model features. IDs, outcome labels, timestamps and inspection lists are metadata. The union of the example runs requests all 24 D1 snapshots; a real sampled run can calculate only the rows it needs.

## 3. Notebook 3 — fit, validate, evaluate or predict

Inputs: dataset + feature set + split + sampling selection. Outputs: model artifact, predictions and evaluation summaries. Model input is a view; the model bundle stores its ordered feature list and fitted preprocessing.

**model_register**

| model_id | dataset_id | feature_set_id | split_id | sampling_id | selected_depth | fit_rows | fit_weight_sum | status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| M01 | D1 | F1 | SPLIT1 | SAM1 | 1 | 6 | 12.0000 | fitted_synthetic_example |
| M02 | D1 | F2 | SPLIT1 | SAM1 | 1 | 6 | 12.0000 | fitted_synthetic_example |
| M03 | D1 | F3 | SPLIT1 | SAM1 | 1 | 6 | 12.0000 | fitted_synthetic_example |
| M04 | D1 | F4 | SPLIT1 | SAM1 | 1 | 6 | 12.0000 | fitted_synthetic_example |
| M05 | D1 | F4 | SPLIT1 | SAM2 | 1 | 6 | 12.0000 | fitted_synthetic_example |
| M06 | D1 | F4 | SPLIT1 | SAM3 | 1 | 10 | 10.0000 | fitted_synthetic_example |
| M07 | D1 | F4 | SPLIT1 | SAM0 | 1 | 12 | 12.0000 | fitted_synthetic_example |


Numerical engine: nine weighted trees on deterministic random feature subsets; candidate max_depth ∈ {1,2}; train-only median imputation; probability in each leaf = (weighted positives + 1)/(total weight + 2); final probability = mean of nine trees. No calibration is applied. This miniature engine makes the example reproducible; it is not a proposed replacement for the planned learner.

**fit_candidates**

| model_id | feature_set_id | sampling_id | candidate_depth | validation_log_loss | selected |
| --- | --- | --- | --- | --- | --- |
| M01 | F1 | SAM1 | 1 | 0.6252 | yes |
| M01 | F1 | SAM1 | 2 | 0.6737 | no |
| M02 | F2 | SAM1 | 1 | 0.5536 | yes |
| M02 | F2 | SAM1 | 2 | 0.6043 | no |
| M03 | F3 | SAM1 | 1 | 0.4623 | yes |
| M03 | F3 | SAM1 | 2 | 0.6053 | no |
| M04 | F4 | SAM1 | 1 | 0.5281 | yes |
| M04 | F4 | SAM1 | 2 | 0.6183 | no |
| M05 | F4 | SAM2 | 1 | 0.8560 | yes |
| M05 | F4 | SAM2 | 2 | 0.8807 | no |
| M06 | F4 | SAM3 | 1 | 0.9483 | yes |
| M06 | F4 | SAM3 | 2 | 1.0047 | no |
| M07 | F4 | SAM0 | 1 | 0.4717 | yes |
| M07 | F4 | SAM0 | 2 | 0.5669 | no |


Depth 1 wins or ties for every example model. M04 and M05 are predetermined workflow comparisons for August, not winners chosen using test results. No train+validation refit occurs here.

### 3.1 Exact fitted inputs

**M04 actual numeric training matrix after its saved imputer**

| snapshot_id | label | weight | G01_C | G01_R | G01_D30 | G02_C | G02_R | G02_D30 | G03_C | G03_R | G03_D30 | P01 | P01_M |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S01 | 1 | 1.0000 | 1 | 2.5000 | 0.9439 | 2 | 0.5000 | 0.9887 | 0 | 2.0000 | 0 | 0.3500 | 0 |
| S06 | 1 | 1.0000 | 1 | 2.5000 | 0.9439 | 1 | 0.5000 | 0.9885 | 0 | 2.0000 | 0 | 0.2500 | 0 |
| S09 | 1 | 1.0000 | 2 | 0.5000 | 1.8898 | 1 | 2.5000 | 0.9439 | 1 | 1.5000 | 0.9659 | 0.3500 | 0 |
| S10 | 0 | 3.0000 | 1 | 3.5000 | 0.9223 | 1 | 1.5000 | 0.9659 | 0 | 2.0000 | 0 | 0.2500 | 0 |
| S11 | 0 | 3.0000 | 0 | 2.5000 | 0 | 0 | 1.0000 | 0 | 1 | 2.5000 | 0.9439 | 0.1500 | 0 |
| S12 | 0 | 3.0000 | 0 | 2.5000 | 0 | 0 | 1.0000 | 0 | 0 | 2.0000 | 0 | 0.2500 | 1 |


**Model-specific imputation values**

| feature_code | M04 | M05 |
| --- | --- | --- |
| G01_R | 2.5000 | 2.5000 |
| G02_R | 1.0000 | 0.5000 |
| G03_R | 2.0000 | 2.0000 |
| P01 | 0.2500 | 0.3000 |


These imputed numbers are model inputs, not rewritten source feature_values. The no-touch counts remain zero; P01_M remains one when PRISM was missing.

### 3.2 Predictions and evaluation

**Stored predictions — M04, full D1 population**

Displayed projection: 24 of 176 rows. [Complete CSV](predictions.csv).

| prediction_run_id | snapshot_id | outcome | model_id | data_role | fit_member | actual_label | probability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| P_M04 | S01 | O1 | M04 | train | yes | 1 | 0.7722 |
| P_M04 | S02 | O1 | M04 | train | no | 0 | 0.4481 |
| P_M04 | S03 | O1 | M04 | train | no | 0 | 0.1330 |
| P_M04 | S04 | O1 | M04 | train | no | 0 | 0.1330 |
| P_M04 | S05 | O1 | M04 | train | no | 0 | 0.2626 |
| P_M04 | S06 | O1 | M04 | train | yes | 1 | 0.6426 |
| P_M04 | S07 | O1 | M04 | train | no | 0 | 0.1330 |
| P_M04 | S08 | O1 | M04 | train | no | 0 | 0.1330 |
| P_M04 | S09 | O1 | M04 | train | yes | 1 | 0.5778 |
| P_M04 | S10 | O1 | M04 | train | yes | 0 | 0.1330 |
| P_M04 | S11 | O1 | M04 | train | yes | 0 | 0.1330 |
| P_M04 | S12 | O1 | M04 | train | yes | 0 | 0.1330 |
| P_M04 | S13 | O1 | M04 | validation | no | 0 | 0.5778 |
| P_M04 | S14 | O1 | M04 | validation | no | 0 | 0.2626 |
| P_M04 | S15 | O1 | M04 | validation | no | 1 | 0.4481 |
| P_M04 | S16 | O1 | M04 | validation | no | 0 | 0.1330 |
| P_M04 | S17 | O1 | M04 | test | no | 0 | 0.5778 |
| P_M04 | S18 | O1 | M04 | test | no | 1 | 0.2626 |
| P_M04 | S19 | O1 | M04 | test | no | 0 | 0.4481 |
| P_M04 | S20 | O1 | M04 | test | no | 0 | 0.1330 |
| P_M04 | S21 | O1 | M04 | test | no | 0 | 0.5778 |
| P_M04 | S22 | O1 | M04 | test | no | 0 | 0.2626 |
| P_M04 | S23 | O1 | M04 | test | no | 0 | 0.4481 |
| P_M04 | S24 | O1 | M04 | test | no | 1 | 0.3274 |


**Stored evaluation_summary — M04**

Displayed projection: 4 of 28 rows. [Complete CSV](evaluation_summary.csv).

| model_id | scope | weighting | n | positive_count | weight_sum | log_loss | brier |
| --- | --- | --- | --- | --- | --- | --- | --- |
| M04 | train_selected | inverse_sampling | 6 | 3 | 12.0000 | 0.2111 | 0.0431 |
| M04 | train_all | unit | 12 | 3 | 12 | 0.2623 | 0.0626 |
| M04 | validation | unit | 4 | 1 | 4 | 0.5281 | 0.1813 |
| M04 | test | unit | 8 | 2 | 8 | 0.7268 | 0.2690 |


**Readable feature/sampling experiment comparison**

| model_id | features | sample | depth | fit_rows | validation_log_loss | test_log_loss | test_brier |
| --- | --- | --- | --- | --- | --- | --- | --- |
| M01 | F1 | SAM1 | 1 | 6 | 0.6252 | 0.6541 | 0.2324 |
| M02 | F2 | SAM1 | 1 | 6 | 0.5536 | 0.4693 | 0.1468 |
| M03 | F3 | SAM1 | 1 | 6 | 0.4623 | 0.5737 | 0.1926 |
| M04 | F4 | SAM1 | 1 | 6 | 0.5281 | 0.7268 | 0.2690 |
| M05 | F4 | SAM2 | 1 | 6 | 0.8560 | 1.0902 | 0.4250 |
| M06 | F4 | SAM3 | 1 | 10 | 0.9483 | 0.7729 | 0.2875 |
| M07 | F4 | SAM0 | 1 | 12 | 0.4717 | 0.6565 | 0.2330 |


train_selected uses inverse-sampling weights; train_all evaluates all 12 candidate training rows with unit weights. Validation has 4 rows; test has 8. Test and validation use natural toy-cohort prevalence. Nothing is evaluated on a class-balanced test sample.

## 4. Existing-model workflow — August attribution

Notebook 1 reuses JSET1. Notebook 2 creates D2 positive snapshots and their feature values. Notebook 3 loads M04/M05 without fitting. Notebook 4 explains their predictions.

**report_rows**

Displayed projection: 6 of 6 rows. [Complete CSV](report_rows.csv).

| report_id | conversion_row_id | customer_id | conversion_dt | snapshot_id | status | reason |
| --- | --- | --- | --- | --- | --- | --- |
| REPORT_AUG | 201 | C1 | 2026-08-02 00:00:00 | A01 | ready | NULL |
| REPORT_AUG | 202 | C1 | 2026-08-15 00:00:00 | A02 | ready | NULL |
| REPORT_AUG | 203 | C1 | 2026-08-15 00:00:00 | A02 | ready | NULL |
| REPORT_AUG | 204 | C2 | 2026-08-20 00:00:00 | A03 | ready | NULL |
| REPORT_AUG | 205 | C5 | 2026-08-22 00:00:00 | A04 | ready | NULL |
| REPORT_AUG | 206 | NULL | 2026-08-25 00:00:00 | NULL | unscored | missing_customer_id |


Rows 202 and 203 remain two conversions but share A02. C1 and C2 are returning training customers; C5 is new. Row 206 is retained as unscored. No negative sampling or new train/test split is performed for D2.

**Stored D2 snapshots — all four**

Displayed projection: 4 of 28 rows. [Complete CSV](snapshots.csv).

| dataset_id | snapshot_id | construction | customer_id | snapshot_start | snapshot_end | outcome | label |
| --- | --- | --- | --- | --- | --- | --- | --- |
| D2 | A01 | A | C1 | 2026-08-02 00:00:00 | 2026-08-03 00:00:00 | O1 | 1 |
| D2 | A02 | A | C1 | 2026-08-15 00:00:00 | 2026-08-16 00:00:00 | O1 | 1 |
| D2 | A03 | A | C2 | 2026-08-20 00:00:00 | 2026-08-21 00:00:00 | O1 | 1 |
| D2 | A04 | A | C5 | 2026-08-22 00:00:00 | 2026-08-23 00:00:00 | O1 | 1 |


**Stored August predictions — both models, same feature rows**

Displayed projection: 8 of 176 rows. [Complete CSV](predictions.csv).

| prediction_run_id | dataset_id | snapshot_id | model_id | data_role | actual_label | probability |
| --- | --- | --- | --- | --- | --- | --- |
| AUG_M04 | D2 | A01 | M04 | report | 1 | 0.5778 |
| AUG_M04 | D2 | A02 | M04 | report | 1 | 0.7722 |
| AUG_M04 | D2 | A03 | M04 | report | 1 | 0.5778 |
| AUG_M04 | D2 | A04 | M04 | report | 1 | 0.1330 |
| AUG_M05 | D2 | A01 | M05 | report | 1 | 0.7944 |
| AUG_M05 | D2 | A02 | M05 | report | 1 | 0.7944 |
| AUG_M05 | D2 | A03 | M05 | report | 1 | 0.7944 |
| AUG_M05 | D2 | A04 | M05 | report | 1 | 0.0993 |


**Readable inference comparison**

| snapshot_id | customer_id | snapshot_start | seen_in_training | conversion_rows | M04 | M05 |
| --- | --- | --- | --- | --- | --- | --- |
| A01 | C1 | 2026-08-02 00:00:00 | yes | [201] | 0.5778 | 0.7944 |
| A02 | C1 | 2026-08-15 00:00:00 | yes | [202, 203] | 0.7722 | 0.7944 |
| A03 | C2 | 2026-08-20 00:00:00 | yes | [204] | 0.5778 | 0.7944 |
| A04 | C5 | 2026-08-22 00:00:00 | no | [205] | 0.1330 | 0.0993 |


No general occurrence-model evaluation metrics are produced from this positive-only attribution cohort.

## 5. Notebook 4 — explanations before percentages

| explanation_run_id | predictions | players | reference | scale |
| --- | --- | --- | --- | --- |
| EX_F_M04 | AUG_M04 | 11 individual features | single background S11, including PRISM | probability |
| EX_G_M04 | AUG_M04 | G01/G02/G03 | no journey; PRISM fixed | probability |
| EX_R_M04 | AUG_M04 | G01/G02/G03 | remove each group from full input | probability |
| EX_G_M05 | AUG_M05 | G01/G02/G03 | no journey; PRISM fixed | probability |
| EX_DIAG_M04 | P_M04: S09 and S18 | G01/G02/G03 | no journey; PRISM fixed | probability |


Exact feature Shapley is enumerated for this tiny example. The feature-score layout also accommodates TreeSHAP, but this calculation is not claimed to use the TreeSHAP algorithm. Group SHAP enumerates all eight group coalitions. Context-fixed group attribution is not obtained by merely dropping PRISM from ordinary feature SHAP.

**Stored explanation endpoints — A02**

Displayed projection: 3 of 14 rows. [Complete CSV](explanation_endpoints.csv).

| explanation_run_id | prediction_run_id | snapshot_id | method | scale | reference | baseline | prediction | score_sum |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EX_G_M04 | AUG_M04 | A02 | direct_group_shapley | probability | no_journey; PRISM fixed | 0.2626 | 0.7722 | 0.5096 |
| EX_F_M04 | AUG_M04 | A02 | exact_feature_shapley | probability | background S11; includes PRISM | 0.1330 | 0.7722 | 0.6392 |
| EX_G_M05 | AUG_M05 | A02 | direct_group_shapley | probability | no_journey; PRISM fixed | 0.1641 | 0.7944 | 0.6303 |


**Stored long scores — A02, feature and group games**

Displayed projection: 14 of 86 rows. [Complete CSV](explanation_scores.csv).

| explanation_run_id | snapshot_id | outcome | player_kind | player_id | score |
| --- | --- | --- | --- | --- | --- |
| EX_G_M04 | A02 | O1 | group | G01 | 0.3152 |
| EX_G_M04 | A02 | O1 | group | G02 | 0.1944 |
| EX_G_M04 | A02 | O1 | group | G03 | 0.0000 |
| EX_F_M04 | A02 | O1 | feature | G01_C | 0.0000 |
| EX_F_M04 | A02 | O1 | feature | G01_R | 0.0000 |
| EX_F_M04 | A02 | O1 | feature | G01_D30 | 0.3152 |
| EX_F_M04 | A02 | O1 | feature | G02_C | 0.0000 |
| EX_F_M04 | A02 | O1 | feature | G02_R | 0.1296 |
| EX_F_M04 | A02 | O1 | feature | G02_D30 | 0.0648 |
| EX_F_M04 | A02 | O1 | feature | G03_C | 0.0000 |
| EX_F_M04 | A02 | O1 | feature | G03_R | 0.0000 |
| EX_F_M04 | A02 | O1 | feature | G03_D30 | 0.0000 |
| EX_F_M04 | A02 | O1 | feature | P01 | 0.1296 |
| EX_F_M04 | A02 | O1 | feature | P01_M | 0.0000 |


**Readable feature-SHAP view — all August snapshots**

| snapshot_id | probability | baseline | G01_C | G01_R | G01_D30 | G02_C | G02_R | G02_D30 | G03_C | G03_R | G03_D30 | P01 | P01_M |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A01 | 0.5778 | 0.1330 | 0.0000 | 0.0000 | 0.3152 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.1296 | 0.0000 |
| A02 | 0.7722 | 0.1330 | 0.0000 | 0.0000 | 0.3152 | 0.0000 | 0.1296 | 0.0648 | 0.0000 | 0.0000 | 0.0000 | 0.1296 | 0.0000 |
| A03 | 0.5778 | 0.1330 | 0.0000 | 0.0000 | 0.3152 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.1296 | 0.0000 |
| A04 | 0.1330 | 0.1330 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |


**Readable group-SHAP view — two models**

Displayed projection: 8 of 10 rows. [Complete CSV](group_score_view.csv).

| explanation_run_id | snapshot_id | label | probability | baseline | G01 | G02 | G03 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| EX_G_M04 | A01 | 1 | 0.5778 | 0.2626 | 0.3152 | 0.0000 | 0.0000 |
| EX_G_M04 | A02 | 1 | 0.7722 | 0.2626 | 0.3152 | 0.1944 | 0.0000 |
| EX_G_M04 | A03 | 1 | 0.5778 | 0.2626 | 0.3152 | 0.0000 | 0.0000 |
| EX_G_M04 | A04 | 1 | 0.1330 | 0.1330 | 0.0000 | 0.0000 | 0.0000 |
| EX_G_M05 | A01 | 1 | 0.7944 | 0.1641 | 0.5515 | 0.0788 | 0.0000 |
| EX_G_M05 | A02 | 1 | 0.7944 | 0.1641 | 0.5515 | 0.0788 | 0.0000 |
| EX_G_M05 | A03 | 1 | 0.7944 | 0.1641 | 0.5515 | 0.0788 | 0.0000 |
| EX_G_M05 | A04 | 1 | 0.0993 | 0.0993 | 0.0000 | 0.0000 | 0.0000 |


**On-demand coalition inspection — M04/A02**

Displayed projection: 8 of 32 rows. [Complete CSV](coalition_inspection.csv).

| model_id | snapshot_id | retained_groups | probability |
| --- | --- | --- | --- |
| M04 | A02 | [] | 0.2626 |
| M04 | A02 | [G01] | 0.5778 |
| M04 | A02 | [G02] | 0.4571 |
| M04 | A02 | [G01, G02] | 0.7722 |
| M04 | A02 | [G03] | 0.2626 |
| M04 | A02 | [G01, G03] | 0.5778 |
| M04 | A02 | [G02, G03] | 0.4571 |
| M04 | A02 | [G01, G02, G03] | 0.7722 |


**Readable removal calculation — M04/A02**

Displayed projection: 3 of 12 rows. [Complete CSV](removal_inspection.csv).

| explanation_run_id | prediction_run_id | snapshot_id | group_id | full_prediction | without_group | difference | construction |
| --- | --- | --- | --- | --- | --- | --- | --- |
| EX_R_M04 | AUG_M04 | A02 | G01 | 0.7722 | 0.4571 | 0.3152 | A |
| EX_R_M04 | AUG_M04 | A02 | G02 | 0.7722 | 0.5778 | 0.1944 | A |
| EX_R_M04 | AUG_M04 | A02 | G03 | 0.7722 | 0.7722 | 0.0000 | A |


The selected models are sums of stumps, so direct group Shapley and group-removal values coincide here. The storage design does not assume this equality for general models.

**Same explanation workflow on a fitted training row and a test row**

| snapshot_id | data_role | actual_label | probability | baseline | G01 | G02 | G03 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| S09 | train | 1 | 0.5778 | 0.2626 | 0.3152 | 0.0000 | 0.0000 |
| S18 | test | 1 | 0.2626 | 0.2626 | 0.0000 | 0.0000 | 0.0000 |


## 6. Notebook 4 — allocation and reporting views

\[P_q=\sum_g\max(\phi_{qg},0),\quad N_q=\sum_g\max(-\phi_{qg},0).\]

| rule | group_credit | unattributed |
| --- | --- | --- |
| positive_only | max(score,0)/P | 0 if P>0; otherwise 1 |
| negative_residual | max(score,0)/(P+N) | N/(P+N); 1 at zero denominator |


No baseline probability is inserted into these denominators. Unscored records have a separate accounting bucket.

**Stored long credits — representative scored, zero-history and unscored conversions**

Displayed projection: 15 of 120 rows. [Complete CSV](attribution_credits.csv).

| allocation_run_id | explanation_run_id | report_id | conversion_row_id | snapshot_id | credit_category | credit_fraction |
| --- | --- | --- | --- | --- | --- | --- |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 202 | A02 | G01 | 0.6184 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 202 | A02 | G02 | 0.3816 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 202 | A02 | G03 | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 202 | A02 | unattributed | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 202 | A02 | unscored | 0 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 205 | A04 | G01 | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 205 | A04 | G02 | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 205 | A04 | G03 | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 205 | A04 | unattributed | 1 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 205 | A04 | unscored | 0 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 206 | NULL | G01 | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 206 | NULL | G02 | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 206 | NULL | G03 | 0.0000 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 206 | NULL | unattributed | 0 |
| ALLOC_M04_U | EX_G_M04 | REPORT_AUG | 206 | NULL | unscored | 1 |


**Readable conversion credit view — percentages, both models**

Displayed projection: 12 of 24 rows. [Complete CSV](credit_view.csv).

| model_id | conversion_row_id | snapshot_id | G01 | G02 | G03 | unattributed | unscored |
| --- | --- | --- | --- | --- | --- | --- | --- |
| M04 | 201 | A01 | 100.0000 | 0.0000 | 0.0000 | 0.0000 | 0 |
| M04 | 202 | A02 | 61.8434 | 38.1566 | 0.0000 | 0.0000 | 0 |
| M04 | 203 | A02 | 61.8434 | 38.1566 | 0.0000 | 0.0000 | 0 |
| M04 | 204 | A03 | 100.0000 | 0.0000 | 0.0000 | 0.0000 | 0 |
| M04 | 205 | A04 | 0.0000 | 0.0000 | 0.0000 | 100 | 0 |
| M04 | 206 | NULL | 0.0000 | 0.0000 | 0.0000 | 0 | 100 |
| M05 | 201 | A01 | 87.5000 | 12.5000 | 0.0000 | 0.0000 | 0 |
| M05 | 202 | A02 | 87.5000 | 12.5000 | 0.0000 | 0.0000 | 0 |
| M05 | 203 | A02 | 87.5000 | 12.5000 | 0.0000 | 0.0000 | 0 |
| M05 | 204 | A03 | 87.5000 | 12.5000 | 0.0000 | 0.0000 | 0 |
| M05 | 205 | A04 | 0.0000 | 0.0000 | 0.0000 | 100 | 0 |
| M05 | 206 | NULL | 0.0000 | 0.0000 | 0.0000 | 0 | 100 |


**Readable cohort rollup — conversion units, both allocation rules**

| model_id | rule | conversion_rows | G01 | G02 | G03 | unattributed | unscored |
| --- | --- | --- | --- | --- | --- | --- | --- |
| M04 | positive_only | 6 | 3.2369 | 0.7631 | 0.0000 | 1.0000 | 1.0000 |
| M04 | negative_residual | 6 | 3.2369 | 0.7631 | 0.0000 | 1.0000 | 1.0000 |
| M05 | positive_only | 6 | 3.5000 | 0.5000 | 0.0000 | 1.0000 | 1.0000 |
| M05 | negative_residual | 6 | 3.5000 | 0.5000 | 0.0000 | 1.0000 | 1.0000 |


All grouped scores in these fitted runs are nonnegative, so the two rules agree. Zero-touch C5 receives modeled unattributed credit; missing-customer row 206 remains unscored. Each model/rule totals six conversion units. The four scored snapshots support five scored conversion rows.

## 7. Same schema for another construction

This final construction check is not another fitted experiment. It uses the same sources and shows the two C1 conversion journeys at one snapshot.

**alternative_journey_rows**

Displayed projection: 19 of 19 rows. [Complete CSV](alternative_journey_rows.csv).

| construction | journey_id | customer_id | conversion_row_id | touch_row_id | event_ts | group_id |
| --- | --- | --- | --- | --- | --- | --- |
| B | B_102 | C1 | 102 | T01 | 2024-12-15 12:00:00 | G01 |
| B | B_102 | C1 | 102 | T02 | 2025-07-01 12:00:00 | G02 |
| B | B_102 | C1 | 102 | T03 | 2026-06-28 12:00:00 | G01 |
| B | B_102 | C1 | 102 | T04 | 2026-06-30 12:00:00 | G02 |
| B | B_104 | C1 | 104 | T01 | 2024-12-15 12:00:00 | G01 |
| B | B_104 | C1 | 104 | T02 | 2025-07-01 12:00:00 | G02 |
| B | B_104 | C1 | 104 | T03 | 2026-06-28 12:00:00 | G01 |
| B | B_104 | C1 | 104 | T05 | 2026-07-01 12:00:00 | G03 |
| B | B_104 | C1 | 104 | T06 | 2026-07-02 12:00:00 | G01 |
| B-union | B-union_102 | C1 | 102 | T01 | 2024-12-15 12:00:00 | G01 |
| B-union | B-union_102 | C1 | 102 | T02 | 2025-07-01 12:00:00 | G02 |
| B-union | B-union_102 | C1 | 102 | T03 | 2026-06-28 12:00:00 | G01 |
| B-union | B-union_102 | C1 | 102 | T04 | 2026-06-30 12:00:00 | G02 |
| B-union | B-union_104 | C1 | 104 | T01 | 2024-12-15 12:00:00 | G01 |
| B-union | B-union_104 | C1 | 104 | T02 | 2025-07-01 12:00:00 | G02 |
| B-union | B-union_104 | C1 | 104 | T03 | 2026-06-28 12:00:00 | G01 |
| B-union | B-union_104 | C1 | 104 | T04 | 2026-06-30 12:00:00 | G02 |
| B-union | B-union_104 | C1 | 104 | T05 | 2026-07-01 12:00:00 | G03 |
| B-union | B-union_104 | C1 | 104 | T06 | 2026-07-02 12:00:00 | G01 |


**alternative_snapshot_view**

| construction | conversion_row_id | snapshot_start | snapshot_end | label | included_touches |
| --- | --- | --- | --- | --- | --- |
| B | 102 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | 1 | [T02, T03, T04] |
| B | 104 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | 0 | [T02, T03] |
| B-union | 102 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | 1 | [T02, T03, T04] |
| B-union | 104 | 2026-07-01 00:00:00 | 2026-07-02 00:00:00 | 0 | [T02, T03, T04] |


A at this anchor has one C1 occurrence row. B/B-union have a row per active conversion journey. B-union uses the unified customer history; B uses the particular conversion reference set plus direct customer matches. A customer fold would keep all of C1 together; the worked temporal split intentionally allows returning customers.

## 8. What is reused and what is newly written

**Stored run register — selected rows**

Displayed projection: 10 of 21 rows. [Complete CSV](run_register.csv).

| run_id | stage | inputs | settings | outputs | status |
| --- | --- | --- | --- | --- | --- |
| PREP_J1 | 01 journeys | [SV1] | construction=A; retrospective qualified links | [JSET1] | complete |
| PREP_D1 | 02 dataset/features | [JSET1, SV1, DICT1] | named four-customer cohort; daily h=1; H=365; F1-F4; SPLIT1; SAM0-SAM3 | [D1] | complete |
| PREP_D2 | 02 report dataset/features | [JSET1, SV1, DICT1] | REPORT_AUG; positive snapshots only; F4 | [D2, REPORT_AUG] | complete |
| FIT_M04 | 03 fit/evaluate | [D1, F4, SPLIT1, SAM1] | depth candidates 1/2; select on validation; no refit | [M04, P_M04] | complete |
| FIT_M05 | 03 fit/evaluate | [D1, F4, SPLIT1, SAM2] | depth candidates 1/2; select on validation; no refit | [M05, P_M05] | complete |
| AUG_M04 | 03 predict | [D2, F4, M04] | predict only; no fit or sampling | [predictions:M04:D2] | complete |
| EX_G_M04 | 04 explain | [AUG_M04, M04, D2] | probability; groups; no journey; context fixed | [endpoints, group scores] | complete |
| ALLOC_M04_U | 04 allocate | [REPORT_AUG, EX_G_M04] | negative_residual | [attribution_credits] | complete |
| AUG_M05 | 03 predict | [D2, F4, M05] | predict only; no fit or sampling | [predictions:M05:D2] | complete |
| EX_F_M04 | 04 explain | [AUG_M04, M04, D2, D1:S11] | exact feature Shapley; probability; background S11; PRISM included | [endpoints, feature scores] | complete |


| action | reuse | new |
| --- | --- | --- |
| M01 → M04: add temporal features and PRISM | D1, JSET1, split, SAM1, existing primitive feature values | model, predictions, evaluation |
| M04 → M05: change sampling | D1, F4 definitions and values, split | SAM2 selection, model, predictions, evaluation |
| July → August reporting | JSET1, F4 definitions, saved M04/M05 | D2 snapshots/features, report map and predictions |
| M04 → M05 on August | D2 and its same F4 values | AUG_M05 predictions |
| Group SHAP → feature SHAP / removal | prediction + saved model + features | explanation outputs |
| Positive-only → negative residual | group scores + report mapping | allocation run only |


Run IDs identify executions; dataset/feature/model IDs identify reusable inputs. Views use explicit filters. Completed outputs are fixed: a repeated write must reject or explicitly replace the same run, not silently append duplicates.

**Trace conversion row 202**

| stage | record | values |
| --- | --- | --- |
| source | row 202 | C1; 2026-08-15 00:00:00; CC New Account; A4 |
| journey | JSET1 / J1 | unified C1 history; customer and qualified application routes |
| snapshot | D2 / A02 | [2026-08-15 00:00:00, 2026-08-16 00:00:00); label=1 |
| window | A02 | T03,T04,T05,T06,T07,T08,T09; T10 is future |
| features | D2 / F4 / A02 | G01_C=3; G02_C=2; G03_C=2; P01=.55; eleven features |
| prediction | AUG_M04 / A02 | M04 probability=.772222 |
| explanation | EX_G_M04 / A02 | baseline=.262626; G01=.315152; G02=.194444; G03=0 |
| allocation | ALLOC_M04_U / 202 | G01=61.8434%; G02=38.1566%; G03/U/unscored=0 |
| second conversion | ALLOC_M04_U / 203 | same A02 explanation, another full conversion accounting unit |


**verification**

| check | result |
| --- | --- |
| snapshot and feature keys unique | PASS |
| all included touches satisfy history bounds | PASS |
| PRISM availability precedes snapshot | PASS |
| Shapley sums equal prediction minus baseline | PASS |
| every conversion has one accounting unit per allocation | PASS |
| 6 report rows map to 4 scored snapshots + 1 unscored row | PASS |


All base rows and view outputs are available in the accompanying CSVs. `build.py` reproduces the numerical example; `models.json` contains the fitted synthetic artifacts. They are supporting calculations, not Databricks implementation notebooks.
