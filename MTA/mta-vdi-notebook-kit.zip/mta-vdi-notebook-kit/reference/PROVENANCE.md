# Provenance and precedence

## Current governing order

1. The user's current VDI instructions and confirmed experiment choices.
2. This kit's `COPILOT_RULES.md`, `NOTEBOOK_DESIGN.md`, `DATA_AND_FOLDERS.md`, `SOURCE_MAPPING.md` and `METHODOLOGY.md`, written for the current continuation.
3. P03-v2 for the broader experiment menu, P02 for additional attribution detail, P01 for qualified source semantics; preserved under `source_context/`.
4. The synthetic worked example as an illustration of rows, arithmetic and separation of stages.

This is continuation of exploration EXP-a7b4df03f703 in project context. The package incorporates the approved reusable-dataset/features and multihead PRISM refinements, then the user's latest request for descriptive names, one configurable Databricks base directory, explicit saved tables/logs and notebook-by-notebook Copilot collaboration. It is an exploration deliverable, not promotion of a validated project method.

## Important changes from older material

- Each selected conversion-source row is one conversion in this design. Older discussion of deduplicated business-event q and consolidation is not an instruction to merge rows here.
- `interaction_id` is nullable and is not a primary key. Generated touch-row references identify rows within a persisted source extract, not verified real-world events.
- Fiscal Q2 is a candidate interpretation until confirmed, not an automatically chosen period.
- Reporting customers may overlap training customers. Customer-held-out folds and prior-period exclusion are selectable experiments, not mandatory for every fit.
- Reporting attribution datasets contain selected positive snapshots; training negatives are not required there.
- Multihead PRISM replaces the toy's single-head example. Head counts, physical field mappings, effective dates, actual availability and per-customer missingness must be qualified locally.
- User-facing folder names and paths identify versions/runs. Old `D1/F4/M04/...` codes are for following the toy tables. Do not reproduce that whole code/register system as infrastructure.
- Notebook 2 owns deterministic feature construction; learned preprocessing belongs to each training model/fold. Metadata records compatibility without a generic asset manager.
- No mandatory full experiment grid, full snapshot×history materialization, new upstream source, quarterly production schedule or automatic all-notebook execution.

## Preserved local sources

`SOURCE_HASHES.json` records the exact copied local source files and SHA-256 values. The source-context text files are unchanged historical snapshots, including their original qualifications and links to material outside this package. Those legacy links are provenance, not dependencies; the main kit is self-contained. Do not try to fetch missing old interview files, archives or pilot code just to build these notebooks.

The historical schema JSON is a transcription, not proof of today's accessible schema. Source nullability is not observed null frequency. Current source `printSchema()` and qualified mappings govern implementation.

The source reports about earlier monthly negative SHAP, approximately 66 PRISM heads, incumbent audits, old CC results and model availability are not results of this kit. No TD data or model was run here.

## Synthetic reference inclusion

`synthetic_worked_example/` includes the full markdown, all its CSVs and fitted synthetic `models.json`. Source copies are unchanged. The older generator (`build.py`), renderer (`render.py`) and redundant `all_tables.json` are intentionally omitted: they are not the implementation template. The markdown mentions those original supporting files; the user does not need them to read the complete saved tables. No original generator has been rerun or modified for this handoff.

The fitted engine was a small custom nine-tree random-subspace ensemble, selected between depths 1 and 2 on the toy validation set. It is not XGBoost or an approved TD learner. Feature explanations enumerate individual-feature Shapley; they do not run TreeSHAP. The chosen stumps make removal/group Shapley coincide and the resulting nonnegative scores make the two allocation conventions coincide in that fixture. Neither equality is a general assumption.

## External implementation references checked during package preparation

These are optional citations, not required internet access in VDI. The practical points are included here and the mathematical specification is in the kit. No third-party documentation, paper or library package is redistributed.

**Databricks files.** Existing Unity Catalog volumes provide `/Volumes/<catalog>/<schema>/<volume>/...` paths usable by Spark and supported Python file operations. This motivates the illustrative common base path; actual access/compute and the user's existing convention still govern. This kit's explicit Parquet-file pattern is a small experiment choice, not a claim that volumes are registered database tables. [Databricks file documentation](https://docs.databricks.com/aws/en/volumes/volume-files).

**XGBoost.** Its scikit-learn interface accepts an explicitly supplied validation set and supports native model saving. The VDI author must check installed signatures for early stopping, prediction iteration behavior and evaluation weighting, and preserve the model actually used for scoring. This package does not assume the current online version is installed offline. [XGBoost estimator documentation](https://xgboost.readthedocs.io/en/stable/python/sklearn_estimator.html).

**SHAP.** TreeExplainer's reference/dependence and model-output options determine what is explained; probability-output support depends on supported model/settings, and interventional explanations use background data. Specify these settings and check the local implementation rather than relying on defaults. An unsupported probability/calibrated pipeline needs another explicitly chosen method or a clearly labeled raw-margin diagnostic. [TreeExplainer documentation](https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html).

## Methodological references retained in P03

The local P03 snapshot includes source titles/URLs and carefully scoped component connections: response-model-to-Shapley MTA (Dalessandro et al.; Du et al.), grouped players (Jullum et al.), removal frameworks (Covert et al.), time-response bases (Shender et al.), and held-out/model-selection principles (Cawley and Talbot). These support components, not the entire TD recipe or the residual credit convention. Their online papers are not required for the formulas implemented here.
