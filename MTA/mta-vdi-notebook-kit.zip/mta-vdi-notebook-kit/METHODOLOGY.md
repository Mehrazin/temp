# Offline methodology — from source rows to conversion credits

This is the mathematical specification for the notebook author. It is deliberately more detailed than the user's notebook prose. Build only the selected experiment branch. No internet is needed to interpret any formula here. P03-v2 governs the experiment menu; the latest user choices govern source-row accounting, readability and the initial CC scope. No method is validated merely by being documented.

## 1. Goal, objects and notation

The immediate model predicts **CC NEW ACCOUNT occurrence** in a chosen future interval. The report explains selected observed conversions using that model, then maps signed explanations to accounting fractions. Prediction quality, explanation stability, fractional accounting and causal identification are separate questions.

| Symbol | Meaning |
|---|---|
| c | Customer; identifier for linkage/splits, never a predictor |
| q | One selected conversion-source row, the agreed conversion accounting unit |
| o | Requested outcome = actual conversion LOB × conversion type |
| T_q | Conversion date/time; date-only inputs retain date precision |
| t | Snapshot start |
| H | History length |
| h | Outcome horizon |
| Δ | Snapshot spacing |
| R(c,t,o) | Eligible and sufficiently observable population membership |
| J_c | Unified linked customer interaction-row history |
| g | Journey feature group: channel × interaction LOB × event type × interaction target |
| Z | Available customer context, including selected historical PRISM heads |
| X | Model input summaries; not necessarily the entire event sequence |

Show timestamps as `YYYY-MM-DD HH:MM:SS`, retain typed timestamps for comparison, and declare timezone. A date-only conversion rendered at midnight does not acquire a real event time. Fixed 365 days and a calendar year differ; calendar month and 30 days differ. Specify the implementation. A timezone with daylight-saving transitions needs calendar-day anchors if the desired unit is a local day; `seconds / 86400` is elapsed-day age, not necessarily local-calendar-day difference.

## 2. Linkage and journeys, independent of snapshots

Let K_c be the union of qualified typed application/DAB references from the selected conversion-source scope for customer c. Let I_c be direct-customer interaction rows, and I_k interaction rows matching typed reference k.

    J_c = distinct touch-row/customer pairs in (I_c union all I_k for k in K_c)

Distinct here collapses **join-route duplication**, not unverified real-world duplicate interactions. Store every matching route in provenance. If customer and application both reach T09 for C1, the C1/T09 pair counts once. A touch may appear for multiple customers when source relationships support that; ambiguities stay visible. Do not transitively merge every person connected to a shared reference. Application and DAB are different key types.

Source `interaction_id` is nullable and not a primary key. Generate a row reference once within an identified extract and persist it. This does not establish a unique real-world interaction. Each selected conversion row remains a separate conversion; keep source row provenance even when two rows map to one model snapshot. This current accounting agreement supersedes older proposals to consolidate conversion events.

Retrospective linkage can use a reference learned from a later conversion to recover an earlier touch. It is allowed as an explicitly labeled retrospective construction, but is not proof the reference was available at the earlier anchor. Record the linkage evidence policy and outcome-dependent feature-recovery limitations. An as-of linkage variant needs actual availability evidence; do not invent it.

The full customer journey is independent of a particular training/report window. Snapshot features select only its relevant prefix/window. Population membership comes from the chosen cohort, not an inner join to nonempty interactions. A customer with zero touches can still have a valid snapshot.

## 3. Population, snapshots, labels and reporting maps

Population alternatives:

- U1: customers from a declared conversion-source period; an observed-converter cohort.
- U2: union of those customers and identifiable interaction customers from a declared scope.
- U3: an existing customer/scoring population if its eligibility/observation semantics are known. No new source is required.
- Optional outcome-specific observed-converter cohort: customers who have CC NEW ACCOUNT somewhere in a declared study period. This estimates timing within that cohort, not general bank-wide probability.

Record study-wide retrospective versus as-of membership. A future-converter cohort can have negative snapshots; it is still selected using future information. A person with no CC conversion in observed data is not proven never to convert. Holding a product, having PRISM, and being eligible for a particular conversion are different facts. If eligibility is not known, name the observable cohort rather than asserting eligibility.

For construction A (initial focus):

    Y(c,t,o) = 1 if any selected q has customer c, outcome o, and t <= T_q < t+h; else 0
    p(c,t,o) = P(Y=1 | X(c,t), R(c,t,o)=1)
    features use only t-H <= interaction_time < t

Assign zero only with complete enough outcome follow-up through t+h. Unknown follow-up is unknown, not negative. Two same-outcome conversion rows in one horizon still yield binary label 1. Preserve both rows separately for reporting; the model predicts occurrence, not event count.

For daily midnight snapshots, all touches on the conversion day are excluded. Increasing the outcome horizon does not include same-day touches. Do not move only positive anchors to just before conversion. For Δ<h, positive intervals overlap; for Δ>h, there are coverage gaps. An event can label multiple training rows but receives one reporting accounting unit. Select one reporting anchor per conversion by a declared rule (e.g. latest preceding grid anchor whose horizon contains its date); unmatched/gap records remain unscored or use an explicitly assessed added-anchor policy.

**Positive reporting dataset:** select the report conversion rows, map them to unique compatible customer/start/end/outcome snapshots, prepare their features and predict once per snapshot/model. Same-customer/date/outcome rows may share a prediction; different outcomes or incompatible constructions may not. No training negatives or new split are required for reporting. Keep every requested conversion row, including those without a score. Returning training customers are allowed.

## 4. N1, N2 and sampling are different choices

N1: in population R, every row with no requested outcome during [t,t+h) is negative. A CC converter yesterday or tomorrow can still be negative today. Converting to EDB does not make the CC label positive.

N2: preserve every eligible positive and retain a negative only if there is no requested outcome in the wider interval:

    [t-b, t+h+a)
    keep = (Y=1) OR (no requested conversion in that interval)

b is the preceding-day buffer; a is the extra future buffer beyond the horizon. a=b=0 reduces to N1. With t=October 10 midnight, h=1, a=b=7 days, a negative requires no requested conversion from October 3 through October 17 inclusive. A buffered-out row is excluded, not relabeled positive. Any-outcome buffering is a different explicit option.

N2 requires preceding outcome observation for b and future follow-up through t+h+a. Boundary rows with incomplete observation have unresolved selection. N2 estimates a contrast conditional on being selected. Inverse weights cannot recover deterministically excluded rows with zero selection probability. To ask whether N2 training improves ordinary occurrence prediction, evaluate N1- and N2-trained models on the same untouched N1 population. Also show native-population results if useful.

Sampling is applied **after** population, labels, split and negative rule. Store realized membership, candidate/selected counts, seed, per-row inclusion probability π_i and inverse weight w_i=1/π_i. A ratio alone is insufficient. Keep selected keys stable across feature/hyperparameter comparisons. Repeated seeds are a sampling sensitivity, not a search for a favorable sample.

| Design | Negative inclusion probability |
|---|---|
| Uniform over period | m/N |
| Within each date/outcome | m_(t,o)/N_(t,o) |
| Stratified | m_s/N_s for mutually exclusive exhaustive stratum s |
| Two-stage time block then row | ρ_t × η_i |
| Customer-first then negative row | ρ_c × η_i |
| Uniform per-customer cap | min(1, m_c/N_c) |

All-positive retention is a separate branch. Overlapping routes need probability of inclusion by any route, not a sum of route probabilities. A deterministic first/latest cap or every-seventh-day selection changes the target; it is not the uniform design above. Dates with zero positives can still contribute negatives; use a declared minimum budget if sampling per date. No silent zero-probability strata.

Useful candidate strata are calendar period/outcome, plus one of: historical PRISM band (with missing category), no-touch/activity recency, prior-conversion recency, or linkage coverage. Band thresholds are fixed or derived from fitting data, not held-out labels. Sparse cells and empty categories need explicit handling. Avoid the Cartesian product of every stratifier.

For Bernoulli sampling π is the design rate and actual selected count varies; m/N is for fixed-size uniform selection. Do not label a Spark `sample` draw as exact-size sampling and silently recalculate its probability from the realized count. Persist the chosen design and realized keys.

## 5. Journey features

For group g let event ages d_j = seconds(t-u_j)/86400 for events u_j in [t-H,t). Define:

    C_g = number of included events
    I_g = 1(C_g > 0)
    R_g = min_j d_j                    (missing for an empty group)
    D_g(τ) = sum_j 2^(-d_j/τ)          (τ > 0, a fixed half-life)

Empty group: counts/presence/decays are zero; recency is missing, not zero. At age τ an event contributes 1/2 to its decay, at 2τ it contributes 1/4. The learner fits the response to the feature; it does not learn the fixed half-life unless a separate search changes it.

Short codes: `G01_C`, `G01_R`, `G01_D30`, `G01_D90`. A dictionary maps G01 to the full source group and each feature code to its formula, units, parameters and missing/off value. Do not define codes from future outcome values. Retain all selected interaction LOBs for a CC outcome unless a named feature experiment narrows them.

Example: ages [2,3,5,7] and [2,60,120,180] both have count 4 and recency 2, but D30 is approximately 3.629 and 1.283. At age 360, D30 contributes about 0.000244; D180 contributes 0.25; annual count contributes 1. Old touches may remain represented without receiving credit.

Optional temporal extensions, only if selected:

| Feature | Definition | Empty value |
|---|---|---|
| First age | max d_j | missing |
| Span | max d_j - min d_j | missing; one touch gives 0 |
| Recent count | sum 1(d_j <= w), with strict pre-anchor input | 0 |
| Age bins | sum 1(b_(l-1) < d_j <= b_l), edges 0...H | 0 |
| Mean / dispersion | mean d; sqrt(mean((d-mean d)^2)) | missing |
| Active days | distinct declared local dates of events | 0 |
| Gaps | mean/std adjacent sorted event gaps | missing if fewer than 2 |
| Recent share | recent count / total count | missing |
| Triangular basis | sum max(1-d_j/w,0) | 0 |
| Spline summaries | sum of each declared spline basis at d_j | 0 |

Possible comparisons: count+recency; add D30; multiple half-lives such as 7/30/90/180; age bins; compact activity/spread statistics. These numerical settings are proposals. Truncate bins to the chosen history. Cross-group totals/pairs require coherent recomputation when explaining masked histories. Do not enumerate every pair automatically.

Changing history changes feature values even when codes look identical. A feature-definition version records history/timing contract, grouping, formulas and PRISM policy. A feature **set** can just select/order existing definitions. Counts need not be recalculated when adding a PRISM column. A changed sample may need features only for newly selected snapshots.

Prior-conversion features are optional: count before t, indicator of an observed prior event and age since last event, by requested outcome/window. A historical conversion is not a current holding; events before available source coverage are unknown. Calendar controls and context-only baselines are optional and explicit. IDs, label, future-event distance and join references are not predictors.

## 6. Multihead PRISM, vintage selection and nulls

PRISM is customer/product/event prediction context, not treatment-assignment propensity or established no-marketing probability. User reports money-in/out families and varying monthly head availability. Around 66 heads with around 40 populated for a customer is an example, not a schema. Historical releases/horizons and absence of marketing inputs remain unverified.

Choose a fixed ordered head dictionary for each fitted model. It can include CC-related and other heads if selected. Each head has a short code, physical mapping, product/event meaning, family and version. The model has the same expected columns at training and prediction; a newly released head does not silently appear in an old model's input.

**Lag policy has two separate components:**

1. Which *effective month/vintage* is intended? If scores are indexed by month-end, define m(t,L) = last day of the month L calendar months before the month containing t. For February snapshots, L=1 means January month-end and L=2 December month-end. This is a proposed precise interpretation to confirm against source semantics; it is not necessarily `t minus 30 days` or `t minus one month`.
2. Was that vintage actually available before the snapshot? Require verified availability_time < t under the selected strict policy, regardless of effective month.

For requested head r and customer c, choose the row for the intended vintage if it is unique and available. If unavailable, either retain missing or choose the latest older available vintage under an explicitly selected fallback/staleness rule. Store intended vintage, actual vintage, availability evidence and score age. Do not silently use the newest row in the extract. If effective dates are month-start or issue dates, define the equivalent source mapping before code.

Example: January-effective score published February 3 at 08:00 is not available for February 1 at 00:00. Depending on the selected fallback, that snapshot gets an older score or missing. Every positive/negative row uses the same anchor-based policy; never choose positives' scores relative to conversion date and negatives' scores relative to a different date.

Missing score is null, not zero. Supported reason fields may include head_not_released, customer_not_scored, missing_vintage, stale, and unknown_reason. Specific reasons require evidence. No row in a score table alone does not identify the reason or prove outcome ineligibility. A null does not exclude the customer by default; scored-only is a separate population experiment. A head with no observed values in the fit partition cannot teach a response to future values: explicitly omit it for that fitted model or freeze a documented training-only treatment; no automatic learning from report rows.

Use native missing handling if the chosen learner supports it, or fit imputation on fitting rows only. Save its learned values with each model/fold. Optional missingness/age indicators have their own definitions and remain context. In the fixed-context journey game, keep **all** PRISM scores, missingness indicators, score-age variables and other chosen context fixed. PRISM can follow earlier marketing while preceding t, which limits a causal interpretation of this game.

## 7. Response model, loss and sampling correction

Initial architecture: separate binary model for CC NEW ACCOUNT:

    p_i = f_θ(X_i) in (0,1)
    L(θ) = -sum_i w_i [y_i log p_i + (1-y_i) log(1-p_i)] + regularization(θ)

For population correction w_i=1/π_i. Additional class balancing, outcome weighting or equal-customer weighting changes the objective and must be named. Do not automatically add `scale_pos_weight` on top of inverse sampling weights. Mean-normalizing weights changes interactions with some regularization/child-weight settings; compare consistently.

With ideal label-only sampling rates s1 and s0:

    logit(p_population) = logit(p_sample) + log(s0/s1)

Keeping all positives and a fraction q of negatives gives +log(q), which lowers odds when q<1. This is an ideal identity, not a calibration guarantee for a finite learner. A global intercept adjustment is insufficient for feature/date-dependent inclusion. Do not apply both inverse weighting and the same prior correction as though they were independent corrections. Calibration, if selected, uses training-side representative/appropriately weighted validation and is saved in the final prediction pipeline.

XGBoost is available in the project context, but the VDI installation must be checked locally. Keep a small explicit parameter list and maximum fit/round budget. Hyperparameters are not selected by this package. Use direct library calls, ordinary loops over a small candidate list and a visible tuning-results table. Never use the final test/report labels to choose parameters while calling them untouched evaluation. A constant/context-only baseline is useful if selected; not every experiment needs every baseline.

Later separate models reuse compatible snapshots/features but require their own outcome labels, eligibility, sampling and fits. Do not label ineligible heads zero. Other optional architectures:

- Pooled binary: f(X, requested_outcome), one row per eligible customer-anchor-outcome.
- Multilabel: vector of binary probabilities with head-specific observation/eligibility masks. Default binary relevance can simply be separate models in one API; it is not necessarily shared learning.
- Exclusive multiclass: requires an explicitly exclusive label definition; concurrent outcomes cannot be silently prioritized.
- Conversion-only multiclass predicts type conditional on conversion, not occurrence.
- Count models predict expected count, not probability; deferred unless explicitly selected.

## 8. Fitting periods, customer overlap and evaluation

Fit-label period, evaluation period and conversion-report period are separate settings. Historical feature retrieval often starts H before the earliest anchor; N2 observation extends by b and a. Complete labels/buffers must not cross a temporal training boundary into held-out future data.

| Variant | Fitting | Q2 score/explanation interpretation |
|---|---|---|
| Q2 fitted rows | Selected Q2 snapshots | In-sample for actual fitted rows; allowed diagnostic |
| Earlier-period fit | Prior quarter(s)/expanding earlier anchors | Temporal transfer; same customers may return |
| Earlier fit excluding evaluated customers | Earlier rows of other customers | Temporal and customer holdout |
| Q2 customer folds | Other Q2 customers for each fold | Retrospective customer-held-out |
| Broader-era customer folds | Other customers over chosen available quarters | Retrospective broader-era generalization |

Exclude **all** labeled rows/outcomes of a held-out customer from that fold's supervised fitting, tuning and learned preprocessing. Their legitimate historical interactions, prior outcomes and PRISM remain available as inputs to their own held-out snapshots. Do not delete their history. Route each prediction and explanation to the actual fold model, not an all-customer refit mislabeled out-of-fold.

A fixed customer-fold map reused across feature candidates supports comparison. Retrospective folds may use later-calendar data from other customers but are not a real-time backtest. To isolate the effect of training-period reach, keep the same evaluation customers excluded in both prior-period and retrospective fits. Alternatively allow returning customers and name that different question. No universal customer-disjointness requirement.

Q2 in-sample explanations need no assertion of predictive validation. If hyperparameters are tuned within Q2 and a final model is refit on all Q2, score it as in-sample; retain earlier held-out scores separately. In-sample, validation-selected and held-out scores of the same snapshot must not overwrite each other.

For weights v_i appropriate to the evaluation population:

    log_loss = -sum v_i [y_i log p_i + (1-y_i) log(1-p_i)] / sum v_i
    Brier = sum v_i (y_i-p_i)^2 / sum v_i
    prevalence = sum v_i y_i / sum v_i

Use numerically bounded probabilities only for metric arithmetic and record the epsilon. Report counts/weights alongside metrics. Calibration bins compare mean predicted probability to observed rate on the same population. PR-AUC / average precision definitions are not interchangeable: record the actual metric implementation, prevalence and head. ROC-AUC supplements these; single-class cells make ranking metrics undefined, not zero. Positive-only conversion reports are not occurrence-model evaluation cohorts.

Validation/test use natural prevalence or their own known evaluation sampling weights, not training weights copied blindly. Repeated snapshots are dependent; customer bootstrap is a descriptive uncertainty option. Repeated model fits/seeds address another source of variation. Multiple candidates selected on one holdout consume that holdout; use untouched/nested assessment for an independent final-performance claim. Predictive accuracy does not validate masked histories or causal marketing effects.

## 9. Explanation games and their computation

Fix the actual fitted model (including preprocessing/calibration), row, requested outcome and output scale. Choose a disjoint partition G of journey information. For coalition S of groups:

    v(S) = predicted_probability(fixed_context, journey_features_with_groups_S_retained)
    baseline = v(empty)
    full = v(G)

For absent groups set counts/decays/presence/active days to zero and recency/gaps to the model's raw no-touch missing encoding, then apply the saved preprocessing. Recompute dependent totals/shares/pairs coherently. Do not overwrite a group's recency but keep its count, or remove a component while retaining a contradictory total. PRISM/context remain fixed. This baseline is a modeled no-journey reference, not organic conversion probability or a causal counterfactual.

Already-empty groups are dummy players and get zero in this deterministic game. They need not be zero in a population-background game. Coherent masking can still be outside observed support. Save no-touch support and inspect unusual combinations. More complicated off/background policies are different games, not implementation optimizations.

### Direct group Shapley

For m groups:

    φ_g = sum over S subset G\{g} of
          [ |S|! (m-|S|-1)! / m! ] [v(S union {g}) - v(S)]
    sum_g φ_g = full - baseline

For few groups evaluate 2^m coalitions once per row. For many groups sample complete uniform permutations: start empty, add one group at a time, allocate each marginal increment, and average per group. Every complete permutation telescopes; efficiency alone does not prove per-group convergence. Record seed, budget and variation across batches. Cache/batch predictions where simple. Do not expand every row into 2^m coalitions at TD scale. Explain a bounded selected set first and estimate cost as rows × permutations × (active groups+1), before expanding. Omitting empty dummy groups preserves this game.

### Individual-feature Shapley / TreeSHAP

Individual features are the players. For a reference dataset B, a common interventional replacement game is:

    v_B(S) = mean over b in B of f(x_S, b_notS)

Whether context is also a player or is held fixed is part of this definition. A conditional game instead uses a conditional distribution for missing features; it is a different question. Sum feature scores for a group if desired, but that is generally not equal to direct group Shapley. Independent feature replacement can create zero-count/observed-recency combinations.

TreeSHAP is a tree-specific algorithm, not a separate attribution principle. The bundled toy enumerates feature coalitions and is **not** TreeSHAP. The local SHAP implementation must support the requested model/game/scale. Ordinary TreeSHAP including PRISM does not become fixed-context group attribution after discarding PRISM scores.

For raw-margin binary outputs:

    margin = baseline_margin + sum feature_scores
    probability = sigmoid(margin)

Do not sigmoid each score separately and call them additive probability contributions. Explain the final probability/calibration function when that is the target. If a library only supports raw margin for the selected model, label that diagnostic accordingly; do not relabel it probability or silently normalize it as the selected game.

### Removal and Owen alternatives

Leave-one-group-out: d_g = v(G) - v(G\{g}). Usually sum d_g != full-baseline. Keep full/removed predictions in the table. Retraining without the group (LOCO) is a different experiment.

Owen/hierarchy: choose blocks, permute blocks uniformly and members uniformly within each block while keeping block members contiguous. Average marginal increments over these restricted orders. Children sum to the block's Shapley in the collapsed block game; a deeper tree imposes more restrictions. State the hierarchy. The user's earlier term “OVA” was not confirmed as Owen; do not assume it is a selected method.

Permuting groups changes the order information is revealed, not the chronology of recorded touches.

### Fully worked probability game

For Email E, SEO S, Display D:

    v(A) = .10 + .20*1(E in A) + .30*1(S in A)
                 - .10*1(D in A) + .12*1(E and S in A)

| A | empty | E | S | D | ES | ED | SD | ESD |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| v(A) | .10 | .30 | .40 | .00 | .72 | .20 | .30 | .62 |

Direct Shapley = (.26,.36,-.10), sum=.52=.62-.10. Removal = (.32,.42,-.10), sum=.64. The .12 interaction is shared under Shapley and counted in both E/S removals. The optional Python math example reproduces these numbers.

Equal numbers of columns do not fix grouping differences. With Email features a,b and SEO c,d all observed 1, masked 0, let v=.10+.40abc+.20d. Feature Shapley summed to groups is (.266667,.333333); direct channel Shapley is (.20,.40). Owen with the two channel blocks gives a=b=.10 and c=d=.20. Different allowed coalitions explain the difference.

## 10. Signed scores to conversion accounting

For each conversion q and chosen signed group scores z_qg:

    P_q = sum_g max(z_qg,0)
    N_q = sum_g max(-z_qg,0)

| Rule | Group credit | Modeled unattributed credit |
|---|---|---|
| Positive-only | max(z,0)/P when P>0; otherwise 0 | 0 when P>0; otherwise 1 |
| Negative-magnitude residual | max(z,0)/(P+N) when denominator>0; otherwise 0 | N/(P+N) when denominator>0; otherwise 1 |

Neither is a probability of marketing causation. Baseline probability is not included in these denominators. No positive-net gate is imposed: scores (.10,-.30) yield .25 positive credit and .75 unattributed under negative-residual. Negative score is not causal harm.

For (.26,.36,-.10), P=.62,N=.10. Positive-only gives Email 41.935%, SEO 58.065%, Display/U=0. Negative-residual gives Email 36.111%, SEO 50%, Display=0, U=13.889%. Zero score mass gives U=1. Tiny positive mass can produce extreme shares; keep magnitudes and inspect stability rather than silently choosing a threshold.

Choose normalization granularity before allocation. With fine scores Email(.20,-.10) and SEO(.10), negative-residual gives Email .50, SEO .25, U .25. Summing signed scores to channels first instead gives Email .50, SEO .50, U0. Roll up already allocated fractions; do not renormalize at each level.

A score for a group does not uniquely determine credit for its individual touches. Event-level attribution needs an event game or an explicitly chosen secondary allocation convention. Do not silently divide among touches and claim it is recovered model evidence.

For a report Q:

    channel_credit_k = sum over q,g assigned to k of credit_qg
    total channel credit + modeled unattributed + unscored count = number of requested conversion rows

Unscored records have their own accounting bucket/reason. Scored no-touch customers can have modeled U=1, which is different from missing-customer unscored. Multiple conversion rows sharing a snapshot reuse its explanation but each has one unit. No inverse negative-sampling weight enters a conversion's unit credit. Show full-cohort share and assigned-credit share with their different denominators.

Keep actual conversion LOB/type separate from interaction LOB/target in rollups. CC reporting can include EDB interaction credit. Predicted occurrence is not conversion count or an individual cause.

## 11. Comparisons, known evidence and optional extensions

Compare model/sampling variants on a fixed Q2 report cohort, and predictive metrics on a fixed eligible evaluation cohort where support allows. Show common-intersection and native coverage when populations differ. Report signed-score magnitude/stability as well as normalized shares. Explainer changes reuse predictions; allocation changes reuse scores. Changing both model and explainer simultaneously prevents attributing the difference to one choice.

The historical monthly run reported mostly negative TreeSHAP, including without PRISM. Its exact settings were not supplied. Possible explanations include below-background values, nonconverter-heavy explanation sets, margin scale, background selection, cancellation and model error. No one cause is established. Direct grouping/Owen does not guarantee nonnegative scores. A constant logit prior correction shifts the raw-margin baseline in an ideal unchanged model; it alone does not change its raw-margin Shapley contributions.

MMM is optional later comparison, not initial notebook scope. The reported dashboard benchmark is monthly spend / vendor-MMM-informed planning CPA by channel × LOB × objective. Map outcomes/objectives, dates, units and coverage before comparing it with credits. For comparable cells, compare levels and shares, not assumed equal totals. Zero/missing CPA is undefined. Agreement is descriptive; choosing a model to match the same MMM period consumes that benchmark. Spend/allocated conversions is allocated CPA, not causal ROI.

B construction is optional: one row per active eventually-converting journey q at t, with T0q<=t<=Tq and label 1(Tq in [t,t+h)). Completed journeys leave the population. Features use that conversion's qualified references plus direct history. B-union uses the same B rows/labels with unified customer history. B versus B-union isolates history reach; A versus B-union also changes labels/multiplicity/population. Two unfinished journeys can produce identical features with different labels. Empty-journey start policy must be chosen. Do not implement B now unless requested.

Time-to-event, longitudinal DR and causal treatment estimators remain deferred. Removal, SHAP and an S-learner all involve prediction differences but causal interpretation requires defined interventions, timing, confounding adjustment and support. PRISM is not treatment propensity; low-propensity weighting does not repair missing linkage. The old Apr–Jul 2025 CC pilot, recalled PRISM AUC and supplied incumbent audits do not validate this proposed workflow.
