# Instructions for the VDI Copilot

The user wants to understand every part of the experiment. Optimize for readable researcher-written notebooks. Rich methodology in this kit must not become a complex software framework.

## Working agreement

- Generate one requested notebook at a time. Do not generate or execute all four, scaffold a package, or launch later stages automatically.
- Before writing each notebook, inspect the previous outputs/config and ask one focused question only for a decision that materially blocks that notebook. Defer later-stage choices.
- Provide short markdown explanations, formulas where useful, ordinary code cells, and representative displayed tables. Number the main steps. Let the user edit a line directly.
- Start every notebook with paths/settings in plain assignments or a small flat dictionary; show the resolved input/output paths. Read existing data directly from its path.
- Prefer standard PySpark DataFrame operations for large data and pandas for bounded local model matrices. No giant SQL query, dynamic SQL generator, custom configuration classes, factories, plugin registry, CLI, scheduler, automatic workflow runner, MLflow dependency or dependency injection.
- Start with no helper file. Extract genuinely repeated substantial logic into at most one or two small Python files only when it improves readability. Do not wrap one-line reads/writes or hide source joins in helpers.
- Use familiar names such as `conversions`, `journey_interactions`, `snapshots`, `training_rows`, `feature_values`, `X_train`, `predictions`. Avoid invented abbreviations and UUIDs in the user-facing flow.
- Persistent row references and separate prediction/explanation/allocation identities are necessary. Implement their identity through clear folder names plus small metadata, not layers of codes the user must track.
- Implement the selected branch, not every theoretical option. Keep alternative choices documented and inexpensive to add. Do not build a universal engine to support the whole menu on day one.
- The user has good Copilot models but no internet. Do not require web browsing, pip downloads or new upstream datasets. Inspect installed package versions and signatures locally. If a required package is absent, discuss the smallest available alternative; never install silently or substitute a learner without saying so.
- Do not read another experiment or broad source collection by default. Use only selected paths and known inputs.

## Readability and persistence

Each notebook ends with: (1) output location table, (2) counts/coverage and a few readable rows, (3) direct read-back of its important saved output, (4) short checks, (5) next unresolved decision. Stop there and wait for the user's review.

Keep source rows and derived canonical tables separate from inspection views. Large tables are typed Parquet files at explicit paths in the simple default layout (or the user's already approved Delta-table convention). A Spark output is a directory of part files, not one CSV. Small dictionaries/config/summary files can be CSV or JSON. Do not collect a large table merely to write one CSV. Human-readable preview tables are views; save only bounded samples when helpful.

Write new meaningful folder names for changed settings. Default writes fail if the destination exists; do not append duplicate rows or silently overwrite completed results. For an interrupted attempt, clearly show which incomplete output would be replaced or select a new folder. A `metadata.json` with `status: writing/complete/failed` is sufficient; this is not a transaction framework. Mark complete only after checks and read-back pass.

For tuning, reuse the chosen feature and selection paths. For an allocation-rule change, reuse the explanation path. A notebook should not import/run earlier notebooks as hidden setup. Independent notebook sessions should load their saved inputs.

## Scientific boundaries

Preserve distinctions among prediction, explanation, accounting credit and causal effects. In-sample explanations are allowed and labeled. Reporting customers may overlap training customers. Positive-only reporting data need no negatives and cannot provide general occurrence-model evaluation. Missing history/labels/PRISM are not silently zero. A source row is one conversion for this design; do not silently consolidate the user's conversion rows.

Honor current directions in this kit over older reference proposals. The synthetic fixture is not a chosen TD cohort, hyperparameter search, PRISM schema or performance benchmark.

## Compute agreement

Before expanding data or collecting to pandas, display the estimated rows/columns/bytes and obtain a concrete user-selected cap/budget if none is set. Reuse saved membership and sample keys. No automatic full population grid, exhaustive parameter search or per-row enumeration over dozens of groups. Start with a bounded chosen scope, inspect, then expand when requested. Exact limits are settings, not arbitrary constants hidden in helpers.

Return bounded aggregate diagnostics to the user: population flow, missingness/PRISM coverage by head/vintage, split/sample counts, model metrics and grouped credit totals. Raw row inspection stays in Databricks. Do not send messages to anyone.

Before an expensive action, its relevant budget must be a concrete value in the current notebook: maximum candidate snapshots/materialized feature rows in notebook 2; maximum local matrix bytes and candidate fits/rounds in notebook 3; maximum explanation rows and coalition/permutation evaluations in notebook 4. If unset, stop before that action and agree the bound. Do not make the user fill every future budget in notebook 1. A small readable estimate and conditional check is sufficient.
