# MTA offline notebook kit

Prepared 2026-10-04 for Mehrazin. First target: **CC × NEW ACCOUNT**. Purpose: understand, build and compare retrospective predictive-attribution experiments in Databricks, one readable notebook at a time.

## Start in VDI

1. Unzip this folder where Copilot can read its text files. No internet is needed to read the kit or run the small mathematical example.
2. Open `prompts/00_START_WITH_COPILOT.md` and paste it into Copilot, attaching/referencing the files named there.
3. Build **notebook 1 only**. Review it, run it in Databricks, inspect the saved tables, and revise it with Copilot.
4. When ready, use the prompt for notebook 2, then 3, then 4. Each prompt starts from the files and decisions actually produced by the previous notebook.
5. Keep a short `NOTES.md` in your experiment folder with decisions and the next step. The included `prompts/CONTINUE_AFTER_A_RUN.md` helps with follow-ups.

If Copilot cannot read a file, paste its relevant text. This package relies on text, CSV tables and formulas, not images or external links. The final notebooks are intentionally to be generated with you in VDI, after actual source mappings are known; this ZIP is a detailed specification and examples, not an already executed TD pipeline.

## Read only what you need

| File | Purpose |
|---|---|
| `COPILOT_RULES.md` | How to keep the code simple and proceed one notebook at a time |
| `NOTEBOOK_DESIGN.md` | Each notebook's cells, inputs, saved outputs and stopping point |
| `DATA_AND_FOLDERS.md` | Descriptive folder names, exact save locations, schemas and reuse |
| `METHODOLOGY.md` | Full offline mathematical specification and experiment choices |
| `SOURCE_MAPPING.md` | Known source field names; bounded discovery for what is unknown |
| `examples/READABLE_CELLS.md` | Small code-cell patterns, not a framework |
| `examples/math_reference.py` | Standard-library worked math; no Spark, fitted TD model or package downloads |
| `reference/synthetic_worked_example/WORKED_EXAMPLE.md` | Complete earlier synthetic workflow with all its CSV tables |
| `reference/PROVENANCE.md` | Source precedence, original context files and implementation-documentation notes |

## What's selected and what is still open

Selected direction: readable four-notebook workflow; CC new-account binary model first; Q2 2026 focus; independently reusable datasets/features; multiple historical PRISM heads; different populations, negative buffers, samples and fits; separate prediction, explanation and credit outputs.

Open choices are resolved when their notebook needs them: actual source tables and base path; fiscal/calendar Q2; timezone and cutoff; source/linkage/population definitions; history/horizon/spacing; exact PRISM lag/vintage/missingness policy; fit/evaluation arrangement; sampling; model parameters; explanation and credit convention. No example number silently selects a real setting. The working starting candidate is customer snapshots, daily horizon/spacing, annual history; these are not mandatory.

Fiscal Q2 FY2026 is February–April; calendar Q2 2026 is April–June. Until confirmed, neither is an executable default.

## Latest simplicity requirement

Use descriptive folder names and ordinary Python variables. A folder name already identifies a saved dataset or model run. Do not ask the user to manage opaque run IDs, feature-build IDs or a registry. Keep a small metadata JSON with paths/settings and retain essential row keys for joins. Short **feature codes** such as `G01_C` and `P017` still have a readable dictionary.

Each chosen conversion-source row is one conversion for this design. Source `interaction_id` is nullable and is not a primary key. Those current choices override older event-consolidation proposals in the reference context.

All example customers, fitted values and allocations are synthetic. The historical worked example uses a tiny custom tree ensemble, not XGBoost, production methodology or TD validation. Its enumerated individual-feature Shapley is not TreeSHAP. Use it to see tables, not as the learner to copy.
