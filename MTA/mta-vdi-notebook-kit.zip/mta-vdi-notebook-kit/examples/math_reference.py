"""Synthetic arithmetic only. Run: python math_reference.py

No external packages, model training, database access or file writes.
This is optional reading material, not a required notebook helper.
"""
from itertools import combinations
from math import factorial, fsum, isclose
from random import Random


def journey_features(ages_days, half_life_days):
    """Ages must already satisfy the selected history window."""
    if half_life_days <= 0 or any(age <= 0 for age in ages_days):
        raise ValueError('Use a positive half-life and strictly pre-anchor ages.')
    return {
        'count': len(ages_days),
        'recency': min(ages_days) if ages_days else None,
        'decay': fsum(2 ** (-age / half_life_days) for age in ages_days),
    }


def exact_group_shapley(value, groups):
    """value(frozenset(groups)) returns the chosen model game's probability.

    Deliberately limited to tiny examples: at most 10 groups / 1024 coalitions.
    This enumerates group Shapley; it is not the TreeSHAP algorithm.
    """
    if len(groups) != len(set(groups)):
        raise ValueError('Groups must be unique.')
    if len(groups) > 10:
        raise ValueError('This toy enumerator is limited to 10 groups.')
    m = len(groups)
    coalition_values = {}
    for size in range(m + 1):
        for members in combinations(groups, size):
            coalition = frozenset(members)
            coalition_values[coalition] = value(coalition)
    scores = {}
    for group in groups:
        others = [name for name in groups if name != group]
        increments = []
        for size in range(m):
            weight = factorial(size) * factorial(m - size - 1) / factorial(m)
            for members in combinations(others, size):
                before = frozenset(members)
                after = before | {group}
                increments.append(weight * (coalition_values[after] - coalition_values[before]))
        scores[group] = fsum(increments)
    return scores


def permutation_group_shapley(value, groups, permutation_count, seed):
    """Small reference implementation; TD code should batch model predictions."""
    if permutation_count < 1 or len(groups) != len(set(groups)):
        raise ValueError('Use a positive count and unique groups.')
    rng = Random(seed)
    totals = {group: 0.0 for group in groups}
    for _ in range(permutation_count):
        order = list(groups)
        rng.shuffle(order)
        retained = frozenset()
        before = value(retained)
        for group in order:
            retained = retained | {group}
            after = value(retained)
            totals[group] += after - before
            before = after
    return {group: score / permutation_count for group, score in totals.items()}


def group_removal(value, groups):
    full_groups = frozenset(groups)
    full_probability = value(full_groups)
    return {group: full_probability - value(full_groups - {group}) for group in groups}


def allocate(scores, rule):
    """Convert signed scores to accounting fractions; baseline is excluded."""
    if rule not in ('positive_only', 'negative_residual'):
        raise ValueError('Choose a documented allocation rule.')
    positive = fsum(max(score, 0) for score in scores.values())
    negative = fsum(max(-score, 0) for score in scores.values())
    denominator = positive if rule == 'positive_only' else positive + negative
    if denominator == 0:
        return {group: 0.0 for group in scores}, 1.0
    credits = {group: max(score, 0) / denominator for group, score in scores.items()}
    unattributed = 0.0 if rule == 'positive_only' else negative / denominator
    return credits, unattributed


def example_probability(retained):
    return (0.10 + 0.20 * ('Email' in retained)
            + 0.30 * ('SEO' in retained) - 0.10 * ('Display' in retained)
            + 0.12 * ({'Email', 'SEO'} <= retained))


if __name__ == '__main__':
    groups = ['Email', 'SEO', 'Display']
    shapley = exact_group_shapley(example_probability, groups)
    removal = group_removal(example_probability, groups)
    assert all(isclose(shapley[g], expected, abs_tol=1e-12)
               for g, expected in zip(groups, [0.26, 0.36, -0.10]))
    assert all(isclose(removal[g], expected, abs_tol=1e-12)
               for g, expected in zip(groups, [0.32, 0.42, -0.10]))
    assert isclose(sum(shapley.values()), 0.62 - 0.10, abs_tol=1e-12)
    assert not isclose(sum(removal.values()), 0.62 - 0.10)
    credits, residual = allocate(shapley, 'negative_residual')
    assert isclose(credits['Email'], 0.26 / 0.72, abs_tol=1e-12)
    assert isclose(residual, 0.10 / 0.72, abs_tol=1e-12)
    assert isclose(sum(credits.values()) + residual, 1.0, abs_tol=1e-12)
    credits, residual = allocate({'positive': 0.10, 'negative': -0.30}, 'negative_residual')
    assert isclose(credits['positive'], 0.25) and isclose(residual, 0.75)
    for rule in ['positive_only', 'negative_residual']:
        assert allocate({'empty': 0.0}, rule) == ({'empty': 0.0}, 1.0)
        credits, residual = allocate({'negative': -0.30}, rule)
        assert credits == {'negative': 0.0} and residual == 1.0
    empty = journey_features([], 30)
    assert empty == {'count': 0, 'recency': None, 'decay': 0.0}
    assert isclose(journey_features([30, 60], 30)['decay'], 0.75)
    approximate = permutation_group_shapley(example_probability, groups, 2000, 7)
    assert isclose(sum(approximate.values()), 0.52, abs_tol=1e-12)
    assert max(abs(approximate[g] - shapley[g]) for g in groups) < 0.01
    # An absent/dummy group stays zero in the same deterministic game.
    with_dummy = exact_group_shapley(example_probability, groups + ['Empty'])
    assert isclose(with_dummy['Empty'], 0.0, abs_tol=1e-12)
    print('Synthetic math checks passed: features, Shapley, removal, allocation and permutations.')
    print('Exact group scores:', {g: round(x, 6) for g, x in shapley.items()})
    print('Removal scores:', {g: round(x, 6) for g, x in removal.items()})
