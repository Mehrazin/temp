# Multihead timing example — entirely fictional

Illustrative UTC dates. Assume month-end effective vintages, one-calendar-month lag, strict availability before snapshot, and **missing rather than fallback**. These are example choices, not selected TD settings. Three heads represent a changing multihead source; real head mappings must be supplied locally.

| Code | Fictional meaning | Family |
|---|---|---|
| P001 | CC new-account propensity | money_out |
| P002 | Deposit account propensity | money_in |
| P003 | Another product propensity | money_out |

| Customer | Head | Effective vintage | Available at | Score |
|---|---|---|---|---:|
| C1 | P001 | 2026-01-31 00:00:00 | 2026-02-03 08:00:00 | .42 |
| C1 | P002 | 2026-01-31 00:00:00 | 2026-01-31 18:00:00 | .20 |
| C2 | P001 | 2026-01-31 00:00:00 | 2026-02-03 08:00:00 | .31 |

Suppose independent coverage metadata confirms C2 was not scored for P002; it also confirms P003 was not released for this vintage. Without that metadata, the corresponding cause would be `unknown_reason`.

| Snapshot/customer | P001 | P002 | P003 | Explanation |
|---|---:|---:|---:|---|
| 2026-02-01 00:00:00 / C1 | NULL | .20 | NULL | P001 not yet available; P003 not released |
| 2026-02-04 00:00:00 / C1 | .42 | .20 | NULL | P001 now available; same intended January vintage |
| 2026-02-04 00:00:00 / C2 | .31 | NULL | NULL | P002 customer not scored; P003 not released |

Changing to two-month lag selects December-effective vintages instead; these rows cannot simply be shifted or zero-filled. An older-vintage fallback would be a different policy, with the actual used vintage shown. A head wholly absent in the fitting partition needs an explicit fitted-model policy before later non-null values appear. This table does not establish any actual PRISM horizon, release time or eligibility rule.
