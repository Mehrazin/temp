# Source mapping and bounded discovery

Known names below come from supplied historical schema transcriptions. They are starting mappings, not a guarantee of the currently accessible schema. Select base versus prepared inputs explicitly. Do not invent a PRISM table or column list.

## Candidate core tables

| Meaning | Observed source name |
|---|---|
| Base conversions | `e2e_cross_channel_new.conversions_final` |
| Prepared conversions | `e2e_cross_channel_new._conversions_final_mat` |
| Base interactions | `e2e_cross_channel_new.chnl_interactions` |
| Prepared interactions | `e2e_cross_channel_new._chnl_interactions_mat` |

## Relevant observed fields

| Logical field | Conversion source | Interaction source |
|---|---|---|
| Customer | `acct_cust_id` | `cust_id` |
| Source row reference | `row_id` (uniqueness needs checking in selected extract) | `interaction_id` (nullable, not a row key) |
| Date/time | `conversion_dt` (date) | `event_ts` (observed string; parse format explicitly) |
| LOB | `acct_lob` | `lob` |
| Conversion type / interaction target | `acct_conversion_type` | `target_conversion_type` |
| Channel | — | `mkt_channel` |
| Interaction event | — | `event_type` |
| Application reference | `app_ref_num_left` in prepared input | `application_ref_num` |
| DAB reference | `dab_ref_num_left` in prepared input | `dab_confirmation_id` |
| Account | `acct_id` | — |

Historical base interaction `cust_id` was long; prepared `cust_id` string. Preserve identifiers as identifiers, with explicit compatible types; do not remove significant leading zeros. Dates displayed at midnight have no recovered intraday precision. Keep parsed timestamps, parsing-failure counts and the declared timezone. User has already treated `abc`, `no_dab_conv` and null references as missing; inspect the selected source's actual handling without assuming those sentinels explain every multiplicity.

Source extracts can include wider outcomes/dates than the initial CC training label. Customer history linkage through reference unions across conversions must not accidentally become CC-only because the report is CC. Qualify direct/reference ambiguity and any use of future-discovered links. No new Contact History or other upstream integration is requested.

Prepared interactions inherit filters and special branches: base status/LOB/target filtering, synthetic Affiliate/Direct Mail, later Salesforce union, and EDB Leads relabeling. These are not uniformly observed marketing exposure. Do not automatically replicate incumbent eligibility, lookback or winner ranking. Source choice is a declared experiment setting. Missing contact records do not prove no contact.

## Notebook 1 discovery: small and explicit

1. User selects accessible source table names and base storage path. Inspect schemas and a bounded preview of selected columns; no recursive table crawl.
2. Confirm date ranges available for the desired extract, timestamp parsing, identifier nulls/types and source snapshot/version. Query aggregates, not full table downloads.
3. Check whether `row_id` is unique/nonmissing within selected conversion rows. If yes, keep it. Otherwise add an extract-specific conversion-row reference, preserving every selected row and the original `row_id`. Do not merge account/date matches.
4. Create and **persist once** an extract-specific touch-row reference. A Spark partition-generated value is not stable on recomputation; don't rebuild IDs separately in downstream notebooks. Persist the source extract and mapping, and load them thereafter. A hash of row contents alone cannot distinguish identical physical rows.
5. Fix bounded source windows sufficient for history, labels and buffers. Keep a counts table for excluded/missing/ambiguous records.

Do not turn these checks into a full production data-cleaning project. If a material ambiguity changes the experiment, state it and ask one focused question.

## PRISM discovery when notebook 2 needs it

The user reports monthly money-in/out head families, with about 66 heads around end-January 2026 and perhaps 40 non-null for a customer. These are unverified examples, not a fixed schema or count.

Ask for the accessible existing PRISM source(s), then inspect locally:

- Wide score columns versus long customer/head/value rows; actual customer key and score names.
- Head-to-product/event mapping, money-in/out family, model/head version and release history if present.
- Effective month/date versus scoring-data cutoff versus publication/availability timestamp. One must not be substituted for another without a declared assumption.
- Whether missing rows distinguish a head not released, a customer not scored, a missing monthly delivery, and an unknown cause.
- Head/value coverage by month and customer, uniqueness at the intended customer/head/vintage grain, ties/revisions, score scale and parsing.

Build a small readable mapping `P001 -> actual head -> description -> money_in/out`. The source field names must come from inspection. `available_at`, `head_name`, `score_vintage` and `score` in this kit are **logical aliases**, not asserted physical columns. If release information is unavailable, record the chosen conservative policy as an assumption; do not fabricate release timestamps or claim verified as-of availability.

## Runtime discovery

Print local Python, Spark, XGBoost, scikit-learn and SHAP versions if present, using `importlib.metadata`; inspect function signatures/help only as needed. Do not assume current web-documentation APIs equal installed VDI APIs. No online installation commands are required by this kit. Discover the existing approved storage path and whether Python file writes and Spark writes both work there before choosing the tiny logging pattern.
