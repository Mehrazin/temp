Notebook 1 is ready for the next step. Build **02_datasets_and_features** only, using the actual saved inputs and choices in my experiment notes. Read `COPILOT_RULES.md`, the notebook-2 design, `DATA_AND_FOLDERS.md`, `SOURCE_MAPPING.md`, and methodology sections 3–6/8.

First inspect my saved history metadata/schema. Resolve only the next required choice: Q2 fiscal versus calendar if not already confirmed, timezone, population/timing and actual PRISM mapping. Do not silently choose all remaining settings. Show a small cell outline and paths.

Make sections independently runnable by loading saved inputs:
- Candidate customer/outcome snapshots and labels; complete outcome follow-up; no-touch membership.
- Split/customer-fold membership, separate from snapshots.
- N1/N2 with explicit preceding b and extra future a; then the selected negative sampling and inclusion probabilities. Outcome-specific observed-converter versus broader population is a separate choice. Show candidate/selected/excluded counts.
- Bounded requested feature rows. Estimate rows/columns/compute before expanding; sample candidate keys before expensive aggregation where possible.
- Reusable long journey features plus readable dictionary and wide view. Show one snapshot's exact included touches and calculation. Counts/decays zero, empty recency missing.
- Historical multihead PRISM: actual money-in/out head mapping to short codes; one/two-month effective-vintage rule as chosen; actual release availability, fallback/staleness and null reasons. Same policy for both labels. No hard-coded 66-column assumption and no zero fill for absent scores. No learned preprocessing here.
- If requested now, positive-only report snapshots and conversion map; every source conversion row retained, including unscored, with shared snapshots reused.

Store journey and PRISM feature blocks separately so a changed PRISM lag does not require recomputing counts. A small feature-set CSV selects their ordered columns. Use descriptive saved paths and small metadata; no universal registry. At larger scale do not materialize all snapshot×all-touch inspection rows.

End with output paths/counts, a wide feature/label/selection view, one customer's multihead PRISM provenance, and direct saved-output checks. Stop before model code. Wait for me to run and revise this notebook.
