I brought an offline MTA methodology kit into this environment. Please help me build a simple Databricks experiment **one notebook at a time**. My first outcome is CC NEW ACCOUNT and my prediction/explanation focus is Q2 2026. I want to understand and edit every line. This is researcher-style code, not production infrastructure.

Read `COPILOT_RULES.md`, `SOURCE_MAPPING.md`, `DATA_AND_FOLDERS.md`, and the notebook-1 section of `NOTEBOOK_DESIGN.md`. Read methodology sections 1–3 in `METHODOLOGY.md`; use the rest only when needed. If these files are not available to you, tell me exactly which to attach/paste. Do not browse or install packages.

Start with **notebook 1 only**, using `prompts/01_JOURNEYS.md`. First establish my base output directory and actual source tables/scope through a few readable discovery cells. Ask one focused question at a time only for missing choices needed now. Do not ask me to decide model hyperparameters, Shapley settings or final allocation before preparing journeys.

Show me a short cell outline and explicit input/output locations, then create the notebook incrementally. After notebook 1, stop so I can run it, inspect the output and request changes. Do not generate notebook 2 until I ask.

My priorities: readable tables tracing conversions/snapshots; descriptive folders; reusable datasets/features; all multihead PRISM nulls preserved; flexible population/N1/N2/sampling/fitting; plain config variables at the top. Keep essential row keys for joins, but don't make me manage opaque run IDs or a registry. No more than one or two small helper files, and begin with none.

Each selected conversion-source row is one conversion. Source interaction_id is nullable and not a primary key. Existing source fields are listed in the kit; PRISM schema and release meaning must be discovered locally. No new upstream integration is requested. The synthetic worked example is only an illustration, not a production learner or validated result.
