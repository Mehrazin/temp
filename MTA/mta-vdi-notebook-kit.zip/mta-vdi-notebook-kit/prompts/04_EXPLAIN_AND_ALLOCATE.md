Build **04_explain_and_allocate** only. Read the local rules, notebook-4 design, data/folder contract and methodology sections 9–10. Use the actual saved predictions and corresponding model/fold, preprocessing, feature order and report conversion map.

Confirm the explanation row set and method/reference/output scale before code if unresolved. I may inspect training, held-out or positive reporting rows; label their roles correctly. Explain one or a few chosen rows first, display the math and cost, then expand only to the selected budget.

Use separate readable sections and separately named output folders for:
1. Signed explanations: selected direct-group Shapley, feature TreeSHAP diagnostic, removal, or explicitly chosen hierarchy. For the journey-group game hold all PRISM/context values and indicators fixed, turn whole groups off coherently, and apply the saved final prediction pipeline at every coalition. Exact enumeration only for small group count; bounded sampled permutations otherwise. Record seed/budget and inspect per-group convergence. Ordinary feature SHAP including PRISM is a different game; the bundled feature enumeration is not TreeSHAP.
2. Inspection: full prediction agrees with stored prediction; baseline and score sum; wide score table; one coalition/removal example. Removal need not satisfy Shapley efficiency. Do not claim efficiency proves Monte Carlo convergence.
3. Conversion allocation: load signed scores, apply the chosen positive-only or negative-magnitude-residual rule at a fixed granularity, then map to every reporting conversion row. No baseline in the denominator; no positive-net gate for negative-residual; no training sampling weights. Zero score mass gets modeled unattributed=1. Unscored rows retain their separate category/reason.
4. Reporting: conversion-level readable percentages, channel/actual-outcome rollups with explicit denominators and one full source-to-credit trace. Shared snapshot explanations can serve multiple conversion rows, each with one unit.

Save endpoints, scores, credits and rollups at explicit paths with small metadata. If I change only the credit rule, reload existing scores and run only allocation cells. Do not silently choose a touch-level credit rule or call predictive credit causal impact.

End with saved locations, checks, a conversion trace and aggregate credits including modeled unattributed/unscored. Wait for my review.
