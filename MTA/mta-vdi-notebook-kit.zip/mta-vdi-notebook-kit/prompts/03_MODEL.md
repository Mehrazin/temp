Build **03_fit_evaluate_or_predict** only from my saved datasets/features/selections. Read the local rules, notebook-3 design, data/folder contract and methodology sections 7–8. My first model is binary CC NEW ACCOUNT. Separate binaries for other outcomes should be easy to add later; do not implement all architectures now.

Ask which fit question I want if it isn't already chosen: Q2 in-sample explanation; previous-period training with returning customers; previous-period training excluding a declared Q2 evaluation customer set; or retrospective customer-held-out folds. Do not assume customer disjointness for every experiment. Use my chosen fit/evaluation/report dates and keep them distinct.

Start with a short plain settings cell that selects explicit existing dataset, feature-set, selection and output paths. Inspect locally installed learner/API versions; no internet/downloads. Show feature columns, labels/weights, row counts and memory estimate before local collection. If too large, discuss a bounded scope or existing scalable tool rather than collecting everything.

Fit mode: train-only preprocessing (or selected native missing support), one direct model fit or a small explicit candidate loop, and a saved tuning table. Record weights and selection meaning; do not automatically add another class correction. Choose parameters/rounds only on fitting-side validation. Each fold saves its own learned preprocessing and model. Preserve final refit versus validation-fit identities if both are used.

Predict mode: load the selected existing model and its saved feature order/preprocessing; do not refit or resample. Verify compatible source construction/timing/features and handle missing heads under the saved policy.

Save model artifacts and predictions with actual labels, role, actual fit membership and model/fold reference. Evaluate on the selected fully labeled population or an explicitly weighted evaluation sample. Report log loss, Brier, prevalence/counts and selected calibration/ranking metrics; positive-only reporting snapshots do not provide ordinary model evaluation. Show probabilities and labels side by side, and check reloaded-model predictions on a small example.

End with the paths, model inputs/settings, metrics and a few readable prediction rows. No explanation notebook until I ask. If I change only hyperparameters later, reuse these saved features and selection.
