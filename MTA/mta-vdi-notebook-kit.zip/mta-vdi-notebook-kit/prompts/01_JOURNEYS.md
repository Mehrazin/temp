Build or continue **01_prepare_journeys** only.

Use `COPILOT_RULES.md`, `SOURCE_MAPPING.md`, `DATA_AND_FOLDERS.md`, notebook 1 in `NOTEBOOK_DESIGN.md`, and methodology sections 1–3. Follow my latest choices from this chat and my experiment's NOTES.md. No code-generation framework and no automatic next notebook.

First resolve the actual source tables, source scope and existing writable Databricks base path. Use bounded schema/preview/aggregate discovery, not a full data collection. If source dates depend on an unresolved study choice, ask that choice now; source coverage must cover the selected history, fit/report intervals and labels/buffers, not just Q2.

Write plain cells to:
1. Define readable settings and show every output path.
2. Read selected source columns with explicit mappings; inspect timestamps, nulls and selected row keys.
3. Preserve every selected conversion row as one conversion. Use source row_id if unique/nonmissing here, otherwise persist a distinct row reference. Add/persist extract-specific touch-row references once; nullable interaction_id is not the key.
4. Build customer index and qualified direct/application/DAB linkage with clear separate joins. Preserve route provenance, avoid duplicate touch-row/customer pairs and show ambiguous relationships rather than merging customers transitively.
5. Store sources/mappings and unified customer `journey_interactions` independently of snapshot windows. Keep no-touch customers visible. Label retrospective versus as-of linkage.
6. Show a selected customer trace, date/route/coverage counts, and explicit saves plus read-back.

Use at most small direct DataFrame expressions and ordinary variables. Save under the agreed named history folder. Do not copy incumbent winner ranking or assume all prepared-source branches share filters. No PRISM joins, labels/features, training or explanations yet unless a tiny discovery is necessary to choose source scope.

At the end give me the saved-path/count table, one readable customer trace, any unresolved source limitation, and the next question. Then wait for my run/review.
