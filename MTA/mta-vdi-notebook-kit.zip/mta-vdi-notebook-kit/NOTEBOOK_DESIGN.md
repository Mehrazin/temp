# Four notebooks, built and reviewed one at a time

This is a cell-level outline, not a requirement to implement all options immediately. Core tables and exact proposed paths are in `DATA_AND_FOLDERS.md`. The user should be able to run each completed notebook in a fresh session from saved inputs.

## Notebook 1 — sources to linked journeys

**Inputs:** actual selected conversion and interaction tables, source scope, output base directory and linkage settings. PRISM scores themselves are not needed to complete this notebook.

**Readable cell sequence:**

1. Imports and plain settings: base directory, actual source names, selected extract bounds, history folder name and timezone.
2. Inspect source schemas and selected-column previews. Keep mappings explicit in ordinary select/rename statements.
3. Read selected source columns and bounded source scope. Show source row counts, date bounds, parsing/null/key issues. Confirm the one-source-conversion-row accounting grain.
4. Preserve conversion row keys or add extract-specific row references when needed. Generate/persist interaction touch-row references once. Save these source slices/mappings so repeated evaluation does not regenerate keys.
5. Build customer index/reference maps, then direct-customer/application/DAB links with readable separate joins. Combine routes, deduplicate touch-row/customer pairs, and collect route provenance. Resolve selected ambiguity handling explicitly.
6. Build `journey_interactions`. Keep full selected history independent of snapshot feature windows. Preserve construction, customer, touch row, timestamp and group attributes. No model fitting.
7. Show one customer's ordered touch table and compact touch-list view. Show no-touch membership and route overlap counts.
8. Save named tables, source/version/settings metadata and a short location/count log; read back. Stop for user review.

**Saved:** `data/journeys/<history_name>/{conversions,interactions,customer_index,journey_interactions}/`, plus `metadata.json`.

**Illustrative journey row:** `A | customer=C1 | touch=T04 | 2026-01-30 12:00:00 | SEO/EDB/CLICK/NEW ACCOUNT | application:A1`.

**Checks:** no duplicated selected source row references; no duplicated journey/touch pair; counts before/after joins reconcile by stated grain; no silent conversion consolidation; missing-customer/source parsing/ambiguous rows have visible coverage. Do not claim generated keys validate real-world uniqueness.

**End response:** output paths and counts, one readable trace, open source limitation and the next decision for notebook 2. No notebook 2 code yet.

## Notebook 2 — datasets, selections and features

**Inputs:** named history, source conversions, selected population/timing/outcome definitions and actual PRISM sources. Select only the feature/sampling branches needed now.

**Independent sections (rerunnable without rerunning all sections):**

1. Plain input/output settings and confirmed source mappings. CC NEW ACCOUNT initially; fiscal/calendar Q2 explicitly selected. Separate fit/evaluation/report dates from history source coverage.
2. Customer/outcome population and observation limits; candidate snapshot keys with start/end, binary labels and known/unknown follow-up. Retain zero-touch customers.
3. Split membership: temporal and/or fixed customer folds as selected. Save it separately from snapshots. Fit membership is not an intrinsic snapshot property.
4. Negative selection: N1 or N2 with chosen b/a and required outcome observation. Then sampling: counts, strata, probabilities/weights, seed and actual keys. Save the exclusion reason, not just selected rows, when practical; at large scale keep aggregate counts plus explicit selected keys and reproducible rules.
5. Row/feature budget. Select needed train/evaluation/report keys before expensive aggregation; estimate sizes. The whole daily customer×all-feature universe is not required.
6. Group dictionary and deterministic journey features. Use clear time-bound joins/aggregations; don't materialize every snapshot paired with the entire customer history. Show included/too-old/future touches for one chosen snapshot on demand.
7. PRISM head mapping and vintage logic: inspect actual schema, select ordered heads and lag policy, retain nulls/reasons/vintage, calculate only requested values. Show one customer's multihead scores and coverage summaries by head/month, including money-in/out.
8. Save reusable long features and small dictionaries. Build the selected wide feature view; no globally fitted imputer or scaler here. Save ordered feature-set membership.
9. If preparing attribution: select reporting conversion rows, map each to one compatible positive snapshot, retain unscored rows, reuse shared snapshots. No report negatives required.
10. Show output locations, selected rows/labels/weights, a wide feature sample, PRISM provenance and read-back. Stop.

**Saved:** dataset `snapshots`; experiment `selections`; named journey/PRISM feature blocks and dictionaries; ordered feature-set CSV; optional report `conversion_map`.

**Illustrative rows:** `S01 | C1 | [2026-02-01 00:00:00, 2026-02-02 00:00:00) | CC_NEW_ACCOUNT | y=1`; `S01 | P017 | value=NULL | reason=unknown_reason` (reason only as supported).

**Checks:** label/window boundaries; positive preservation under N2; unknown labels not negatives; π>0 for probability-sampled target strata; expected feature keys complete; no-touch/null/zero/uncomputed distinguished; PRISM intended/used vintage and as-of evidence; no learned preprocessing from held-out rows. If source follow-up needed for a changed buffer is absent, selection is unresolved.

## Notebook 3 — fitting, tuning, evaluation or existing-model prediction

**Inputs:** selected saved dataset(s), ordered feature list/blocks, split/sample records and explicit model settings; or a saved model and inference inputs.

**Readable cell sequence:**

1. Plain settings: `mode='fit'` or `'predict'`; explicit data/features/selection paths; output experiment/prediction path. Display settings and local library versions.
2. Load complete saved inputs and verify compatibility: source construction/timing, outcome, feature definitions/dtypes/order and missing policy. Build selected wide matrices and labels/weights without including IDs as predictors.
3. Display matrix counts/estimated memory. Only collect to pandas if inside the agreed budget. Otherwise reduce the selected experiment or use an explicitly chosen installed scalable learner; do not silently collect the full bank or invent a distributed framework.
4. Fit mode: train-only preprocessing if needed; one transparent model call or a small visible loop over candidates. Validation selects parameters/rounds; final test remains separate. Customer-fold mode is a visible outer loop with its own fitted artifacts/preprocessing. Exact fold/fit budgets are settings.
5. Predict mode: load model and its saved preprocessing, feature order and outcome; predict without refitting, resampling or fitting a new imputer. Missing heads use the saved policy.
6. Save model artifact(s), ordered features, preprocessing and model metadata. Predict selected train/validation/evaluation/report rows, recording actual model/fold and fit-member status.
7. Compute appropriate evaluation metrics on the full selected observed population or its properly weighted sample. Keep positive-only report probabilities without calling them general predictive validation. Show actual labels beside probabilities.
8. Save predictions, metrics/tuning table and run summary; reload the saved model on a small chosen input and verify prediction agreement. Stop for review.

**Saved:** experiment `model/`, `tuning_results/`, `predictions/<prediction_name>/{predictions,evaluation_summary}/` and metadata.

**Illustrative prediction row:** `snapshot=S01 | outcome=CC_NEW_ACCOUNT | model=prior_fit_v1 | label=1 | probability=.37 | role=temporal_test | fit_member=false`.

**Checks:** disjoint held-out membership when selected; label/buffer temporal bounds; train-only preprocessing/tuning; feature order; loaded-model prediction identity; metric denominators/prevalence. An all-Q2 refit is in-sample on Q2, even if a preceding validation fit was held out.

## Notebook 4 — explanations, conversion allocation and reporting

**Inputs:** named predictions, exact saved model(s)/features, explicit explanation choice and reporting conversion map. The explanation row set is configurable: report positives, diagnostic training rows, held-out rows, etc.

**Independent sections:**

1. Plain settings and resolved paths: prediction input, requested output/scale, players/reference, row selection, explanation budget/seed, allocation convention and output names.
2. Choose a bounded inspectable row set. Verify stored probability equals the explained model pipeline's full prediction. Estimate explanation cost before scaling.
3. Generate selected signed explanations: direct group Shapley, feature SHAP diagnostic, removal, or an explicitly selected hierarchy. Keep all PRISM/context fixed for the journey-group game. Use exact enumeration only for small group count; otherwise selected permutation budget with convergence inspection. Do not write a new TreeSHAP implementation.
4. Save endpoints and signed scores. Show a wide feature/group score view and, for one row, coalition or full-versus-removed predictions. Training explanations retain their in-sample label.
5. Load an existing explanation output when only the credit rule changes. Apply the selected positive-only or negative-residual formula; keep baseline out of the denominator. At zero mass use modeled unattributed=1.
6. Map snapshot explanations back to every requested conversion row. Reuse one explanation for shared matching snapshots; no sampling weights in conversion credits. Preserve unscored separately from modeled unattributed.
7. Save long credits and rollups; show one conversion trace and a cohort totals table, both actual conversion and interaction dimensions. Check conservation against all requested conversion rows. Stop.

**Saved:** `explanations/<name>/{endpoints,scores}/` (and removal detail if selected), `allocations/<name>/{conversion_credits,report_totals}/`, metadata and bounded traces.

**Illustrative credit row:** `conversion_row=202 | explanation=group_q2 | group=G01 | credit=.60`. Scores, credit formula and trace establish what .60 means; it is not an estimated causal probability.

**Checks:** full prediction identity; Shapley efficiency (not required for removal); absent-group zero in deterministic game; all expected players or an explicit sparse-zero convention; one unit per conversion including unscored; no double counting from overlapping horizons/shared snapshots. Permutation telescoping does not establish per-group convergence.

## Keep the user in control of the sequence

The end of a notebook is a review point, not a request to generate the rest. The user may modify the current notebook after inspecting results. Update its saved config/notes and changed output version before moving on. If a later discovery changes an earlier definition, identify the smallest affected cells/data, not “rerun everything.”
