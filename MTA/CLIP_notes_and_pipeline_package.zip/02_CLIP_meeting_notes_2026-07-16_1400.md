# CLIP – Meeting Notes
**Date:** July 16, 2026  
**Time:** 2:00 PM  
**Participants:** Mehrazin, Nazanin, Rahul

## Purpose
- Walk through the **current CLIP campaign process** in detail before defining the future-state model/orchestration flow.
- Understand where the customer universe comes from, how scrubs / control / eligibility work, and how channels are currently assigned and executed.

## Current campaign setup
- CLIP is a **monthly wave campaign** with a one-month offer period.
- Risk creates the initial population of credit-card customers who are eligible for a CLIP offer.
- Risk applies its own waterfall / scrubs before the file is passed downstream.
- File then moves through the current data / Salesforce process.
- DAS converts / prepares the data for Salesforce CDC.
- Marketing Delivery then applies additional scrubs and creates the campaign segmentation / TMD logic.
- Campaign execution has moved to Salesforce:
  - execution moved in March
  - backend scrubbing / TMD generation moved in April

## Offer / control population
- DAS splits the population into offer and control.
- Control group is relatively small, roughly **5–10%**.
- Rahul’s understanding:
  - a universal control group is set early in the year
  - Marketing Delivery can modify it for tactical tests
  - some customers can be moved from offer to control depending on the specific test

## Marketing Delivery / channel eligibility
- Marketing Delivery applies campaign scrubs in Salesforce / CDC and then moves the audience forward to MCE.
- Salesforce contains the channel-eligibility criteria and automatically slots customers into the appropriate DMD cell.
- A customer is assigned to **one DMD cell only**.
- If a customer qualifies for multiple special segments, there is a prioritization hierarchy.
- Example discussed: inactivity can take priority over DNS.
- Main digitally active group:
  - receives digital placements
  - is generally eligible for inbound phone acceptance
  - may additionally receive email and/or DM depending on eligibility and resting rules

## Current channel logic
- Channel assignment today is primarily rules / eligibility driven.
- Email / DM eligibility can depend on:
  - channel eligibility / consent
  - DNS / opt-out type flags
  - prior campaign participation
  - customer activity / inactivity
  - utilization
  - existing resting rules
- Example: customers with **credit utilization below 20%** may be scrubbed from email / DM.
- Current email / DM resting logic is approximately **60 days**, so a customer generally does not receive them again for the next two waves.

## Channel list
- EasyWeb
- Mobile
- Email
- Direct Mail
- Inbound / phone acceptance
- Other advice-prompt / digital placements
- OBTM is being de-scoped.
- Leads have not been part of CLIP.
- Depending on how EasyWeb/mobile tactics are counted, Rahul described the current setup as around 7 channel/tactic categories.

## Direct Mail timing problem
- DM list must be prepared **in the previous month**.
- Example: July DM list needs to be sent around **June 23**.
- Reason: agency needs lead time to ingest, print and mail.
- This creates an orchestration issue:
  - final DM population is fixed before the previous wave has fully completed
  - therefore customers who were in the previous DM wave may be suppressed from the next wave because their final response / fulfilment is not yet known
- Current rule discussed: if a customer received DM in June, they can be suppressed from all tactics in July.
- This is different from email / digital, where lists can be refreshed much closer to deployment.

## Email / digital timing
- Email list can be generated / refreshed close to deployment, even the day before.
- Advice prompts / digital placements can also be updated at the beginning of the new month.
- Current monthly execution timing:
  - week 1 is generally not used for deployment because prior-month fulfilment needs to complete and flow into Salesforce
  - go/no-go around week 2
  - digital assets are activated first
  - email and DM then follow
- Email can be scrubbed for customers who accepted before email deployment.
- DM cannot be updated after the file is sent for printing.

## DM placement within the journey
- DM has to be deployed early enough to arrive before the offer expires.
- Need to assume up to ~2 weeks of delivery time.
- Therefore DM cannot be tactic 3 or 4 late in a one-month journey.
- If DM is recommended, it likely needs to be **first or second**.

## Example population / waterfall
- An older May 2025 waterfall was shown as an example.
- Initial population: about **2.8M**.
- After scrubs: roughly **2.3M**.
- After control: roughly **2.1M targeted**.
- Example final DM-eligible population was around **138K**.
- Large exclusions were driven by overlapping reasons such as:
  - DNS
  - previous campaign
  - low utilization
  - other campaign / eligibility rules
- These exclusion categories overlap, so counts should not be added directly.

## Future-state business ask
- Current fixed 60-day resting rules for email / DM are not necessarily optimal for every customer.
- Business wants customer-level, wave-over-wave decisions such as:
  - one customer may be ready again after 30 days
  - another may need 90 / 120 days
- Goal is for the model / orchestration to help decide **when a channel should be used for that customer**, rather than relying only on a fixed global resting period.
- Need to handle:
  - customers present in many consecutive waves
  - customers who leave the universe and return later
  - timing restrictions such as DM
  - channel eligibility / opt-outs
  - business constraints

## Attribution
- Current campaign reporting does **not have clean channel attribution**.
- We know the DMD cell / set of tactics a responder belonged to, but not necessarily which specific tactic caused the response.
- Rahul is interested in attribution as a secondary capability:
  - which channel likely drove the response
  - which channel should be recommended for similar customers
- Prediction / orchestration is the higher priority; attribution can follow.

## Follow-ups
- Rahul to share the older CLIP waterfall.
- Reach out to Marketing Delivery to understand the underlying source tables / eligibility logic.
- Continue recurring touchpoints after Rahul returns.
- Use this current-state process as the baseline for the future-state design.