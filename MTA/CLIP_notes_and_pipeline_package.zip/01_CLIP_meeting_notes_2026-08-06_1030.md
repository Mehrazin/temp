# CLIP – Meeting Notes
**Date:** August 6, 2026  
**Time:** 10:30 AM  
**Participants:** Mehrazin, Rahul, Paul, Vanda (joined later)

## Purpose / context
- Set up regular touchpoints over the next ~2 months while the CLIP model / orchestration approach is being developed.
- Rahul is preparing the Q2 F27–Q4 strategy recommendation and wants clarity on what the model/orchestration solution can and cannot support.
- Goal is to have the CLIP use case sufficiently defined before the strategy recommendation is finalized.

## Campaign timing / operating model
- CLIP will still operate on a **1-month offer period** for the initial use of the model.
- Extension to a 2-month offer period was being considered but is not expected to be prioritized for Q2.
- The solution therefore needs to work **wave over wave / month over month**.
- For a February campaign:
  - Marketing Delivery is expected to perform eligibility / scrubbing work around mid-January.
  - The DM list needs to be known and sent roughly by **Jan 22–23**.
  - Therefore the first model/orchestration run needs to happen in the **2nd–3rd week of January** at the latest for DM.
- DM is the limiting channel for timing.
- Other channels can be finalized later, which is preferable because a later decision point gives us more feedback from the previous wave.

## What business wants from the model / orchestration
- Replace as much of the current fixed 60-day email/DM resting logic as possible with more customer-specific decisions.
- Run the solution each wave and provide a refreshed recommendation for each eligible customer.
- Recommendation should reflect:
  - customer/channel propensity
  - recent journey / recent contacts
  - previous non-response / response patterns
  - business constraints
- Rahul does **not** want a fixed library of predefined journeys.
- Preferred setup:
  - give the system the eligible channels + constraints
  - let it determine the best customer journey within those constraints
- Example: if a customer is eligible for email, mobile, EasyWeb and DM, the system should be able to select the best **3 out of 4** rather than sending all four.
- **Maximum 3 tactics per wave** was suggested.
- If the customer does not accept in one wave, the next wave should use the newest available information and adjust the recommendation.

## Business constraints discussed
- **DM cannot be the final tactic** in a one-month journey because of delivery timing.
- DM needs to be decided early enough that it can be produced / mailed and still arrive before offer expiry.
- Mobile intercept has a **mandatory 90-day resting period**.
- Mobile intercept also has a **monthly volume cap of ~200K**.
- Other mobile / web tactics do not have the same hard constraints as mobile intercept.
- Business wants the orchestration to respect channel eligibility, resting, timing and volume constraints.

## Channels in scope
- Email
- Direct Mail (DM)
- EasyWeb
- Mobile / mobile tactics, including mobile intercept
- ATM and ACO are currently more “always-on” and do not necessarily need to be coordinated the same way.
- OBTM is not in scope.
- Leads are not in scope.
- Public-site web intercept was discussed as a separate tactic and is not part of the current CLIP setup.

## Mobile intercept data issue
- Current historical data does not yet have enough granularity to identify mobile intercept cleanly; currently there is mainly an indicator that a mobile touchpoint was available.
- Salesforce is expected to provide more granular information going forward.
- Problem: new granularity helps future scoring, but model development needs **historical data**.
- Need to confirm whether the approved model can be retrained later using the newly accumulated data.
- If retraining is not practical / allowed at that point, an interim approach may be required.
- Target business expectation is to have enough mobile-intercept granularity by Q2 / February.

## ATM
- ATM marketing is being tested now on approximately **207 ATMs**.
- Broader rollout was expected around September / October.
- Data will therefore be limited initially and more useful around October / November.
- CLIP may be one of the first campaigns using this channel in this way.
- Likely better to treat ATM as always-on initially and consider adding it into the model later, once enough history exists.
- Training data for the model is intended to use data from **all campaigns**, not only CLIP.

## Quebec
- Digital CLIP tactics are expected to expand to Quebec in February.
- Current Quebec experience is mainly email / DM with phone acceptance.
- EasyWeb / mobile digital acceptance will be new for this population.
- This may create a different response pattern from BAU because customers will be seeing these tactics for the first time.
- Need to monitor / analyze Quebec separately when evaluating recommendations and impact.

## Month-over-month population
- Rough estimate mentioned: about **70% of the eligible universe carries over month to month**.
- About 30% changes as customers move in / out of eligibility.
- Important for the use case because the solution needs to handle both:
  - customers appearing repeatedly in consecutive waves
  - customers dropping out and later returning

## Follow-ups
- Build a concrete end-to-end use case showing how the solution would be used operationally.
- Have an initial version ready for the next weekly meeting and refine with business.
- Target a fuller version by end of August / before the early-September strategy recommendation.
- Paul to provide SQL queries / logic for the channels.
- Need data showing how the CLIP universe changes month over month.
- Need to confirm retraining / model-governance options once mobile-intercept history becomes available.