# CLIP – Meeting Notes
**Date:** July 15, 2026  
**Time:** 11:30 AM  
**Participants:** Mehrazin, Rahul, Akber

## Main question
- Can the customer-journey model be adapted to the **one-month CLIP offer period**, rather than assuming a two-month future journey?
- Business wants the solution to operate **wave over wave** and produce updated recommendations each month.

## Desired monthly behavior
- Run the model for the eligible universe every wave.
- For each customer, use:
  - recent journey / recent channel contacts
  - customer/channel propensity
  - past non-response / response patterns
- Produce a refreshed customer-level journey / channel recommendation for the next wave.
- Business does not want the exact same journey repeated indefinitely.
- Example:
  - one month may recommend email + mobile
  - if there is no response, next month should be able to recommend a different combination such as digital + DM

## Resting rules
- Current example: email has a fixed **60-day** resting period.
- Business would prefer a more customer-specific approach where the effective rest period could vary by customer.
- Important distinction discussed:
  - **model** learns customer/channel response patterns and produces scores / propensities
  - **optimizer / orchestration layer** can enforce business rules on top of those scores
- Resting-rule logic can therefore be handled as an optimization constraint even when the underlying model is fixed.
- Possible optimizer logic can also prevent the same journey from repeating wave after wave.

## Model lookback / learning
- Current experimentation uses about a **2-month lookback** on the customer journey.
- That lookback can potentially be extended to 3–4 months or longer because the design is still being developed.
- The model learns from historical patterns among similar customers and their journeys.
- If customers who repeatedly receive a tactic without responding tend to have lower take-up later, the score can reflect that pattern.
- However, the model itself does **not retrain every month**.
- New outcomes are not automatically incorporated into the learned parameters until retraining.
- Model monitoring would determine when a formal retraining is required.

## Important distinction: scoring vs. retraining
- A fixed trained model can still score customers differently wave over wave because the **input features / recent journey** change.
- That is different from the model learning new parameters from the most recent wave.
- Monthly retraining is not expected / practical.
- Wave-over-wave adaptation should therefore come from:
  - refreshed customer inputs
  - current journey / recent touchpoints
  - the orchestration / optimization constraints
  - eventual retraining when required by model monitoring

## Data refresh dependency
- For the model to react to a recent contact, that contact needs to be available in the scoring data.
- Need to confirm the data refresh / latency.
- Example discussed:
  - if scoring at the end of July, historical data through June is known
  - need to confirm how quickly July activity becomes available
- The closer the model can run to the campaign launch, the more recent information it can use.

## Direct Mail constraints
- DM list must be prepared in the **previous month** because it is sent to an external agency for printing / mailing.
- Example: July DM list around **June 23**.
- DM cannot be deployed too late in the offer period because it may arrive after the offer expires.
- Need to assume approximately two weeks for delivery.
- Therefore the optimizer must support a **timing constraint** such as:
  - DM cannot be the last tactic
  - DM must be first / early enough in the journey

## Customer journey history
- Model is not intended to model a customer’s entire lifetime journey.
- It mainly uses the information available inside the selected historical input window.
- Older journeys outside that lookback are not directly available to the prediction unless summarized through other features.
- Business was comfortable with a finite recent-history window as long as the system can make useful refreshed recommendations.

## Avoiding repeated journeys
- Concern from business: a customer should not simply get DM every month because DM has the highest static propensity.
- Desired behavior:
  - repeated non-response should eventually reduce the attractiveness / rank of that tactic
  - customers can fall below a cutoff / be rested
  - other tactics can be selected
- Optimizer can add diversity / resting constraints on top of model scores.

## Agreed direction
- One-month future recommendation is feasible to explore.
- Keep developing the model with a recent customer-journey lookback.
- Separate:
  1. model scores / predicted customer-channel response
  2. optimizer constraints / business rules
- Need the next meeting to walk through the real campaign process and DMD so the technical design reflects the actual operating constraints.

## Follow-ups
- Rahul to walk through the CLIP campaign process in the next meeting.
- Rahul to share the DMD with the resting-rule examples.
- Team to understand:
  - current process
  - desired future process
  - exact business constraints that need to sit in the optimizer
- Confirm data-refresh timing, especially for month-over-month use.