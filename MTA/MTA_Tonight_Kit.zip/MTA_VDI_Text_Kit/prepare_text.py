"""Offline, non-executing source extraction. Python 3.9+; standard library only."""
import argparse
import csv
import hashlib
import json
import os
import re
import sys
import zipfile
from collections import Counter
from datetime import datetime, timezone
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from shutil import copyfile
from xml.etree import ElementTree as ET

KIT = Path(__file__).resolve().parent
OUTPUT_NAME = 'mta_text_workspace'
TEXT_SUFFIXES = {'.py', '.sql', '.scala', '.r', '.md', '.txt', '.csv', '.tsv', '.yaml', '.yml', '.json', '.toml', '.html', '.htm'}
EXCLUDE_NAMES = {'.git', '.venv', 'venv', 'node_modules', '__pycache__', '.ipynb_checkpoints', '90_review', 'mta_review', OUTPUT_NAME}


def as_text(value):
    return ''.join(str(x) for x in value) if isinstance(value, list) else str(value or '')


def clean(text, notices):
    """Remove image markup and common inline/bare binary representations."""
    patterns = [
        (r'<svg\b[^>]*>.*?</svg\s*>', '[SVG OMITTED]'),
        (r'<(?:img|image)\b[^>]*>', '[IMAGE ELEMENT OMITTED]'),
        (r'!\[([^\]]*)\]\([^\n]*?\)', '[MARKDOWN IMAGE OMITTED]'),
        (r'!\[([^\]]*)\]\[[^\]]*\]', '[MARKDOWN IMAGE REFERENCE OMITTED]'),
        (r'!\[[^\]]*\]', '[MARKDOWN IMAGE OMITTED]'),
        (r'data:[^\s\"\'<>)]*', '[DATA URI OMITTED]'),
        (r'attachment:[^\s\"\'<>)]*', '[ATTACHMENT REFERENCE OMITTED]'),
        (r'(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{512,}={0,2}', '[LONG ENCODED TOKEN OMITTED]'),
        (r'\\x[0-9a-fA-F]{2}(?:\\x[0-9a-fA-F]{2}){127,}', '[ESCAPED BINARY OMITTED]'),
    ]
    for pattern, replacement in patterns:
        text, count = re.subn(pattern, replacement, text, flags=re.I | re.S)
        if count:
            notices.append(f'{replacement}: {count}')
    text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text)
    text = ''.join(ch for ch in text if ch in '\n\t\r' or ord(ch) >= 32)
    return text


class HTMLText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.suppressed = []

    def handle_starttag(self, tag, attrs):
        if self.suppressed:
            if tag == self.suppressed[-1]:
                self.suppressed.append(tag)
            return
        if tag in {'script', 'style', 'svg', 'canvas', 'object', 'iframe', 'video', 'audio'}:
            self.suppressed.append(tag)
            self.parts.append(f'\n[{tag.upper()} CONTENT OMITTED]\n')
        elif tag in {'img', 'image', 'embed'}:
            self.parts.append('[IMAGE/EMBED OMITTED]')
        elif tag in {'br', 'p', 'div', 'tr', 'li', 'h1', 'h2', 'h3', 'section'}:
            self.parts.append('\n')
        elif tag in {'td', 'th'}:
            self.parts.append('\t')

    def handle_endtag(self, tag):
        if self.suppressed:
            if tag == self.suppressed[-1]:
                self.suppressed.pop()
            return
        if tag in {'p', 'div', 'tr', 'li', 'h1', 'h2', 'h3', 'section'}:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.suppressed:
            self.parts.append(data)


def html_text(value, notices):
    parser = HTMLText()
    parser.feed(as_text(value))
    parser.close()
    notices.append('HTML converted to plain text; layout and visual content unavailable')
    return clean(unescape(''.join(parser.parts)), notices)


def extract_notebook(raw, notices):
    nb = json.loads(raw.decode('utf-8-sig'))
    if not isinstance(nb, dict) or not isinstance(nb.get('cells'), list):
        raise ValueError('not_a_supported_notebook')
    ordered_code = []
    sections = ['NOTEBOOK TEXT EXTRACT. No cells executed. Cell positions are 1-based.\n']
    for index, cell in enumerate(nb['cells'], 1):
        kind = cell.get('cell_type', 'unknown')
        source = as_text(cell.get('source', ''))
        if kind == 'code':
            ordered_code.append(source)
        cell_id = clean(str(cell.get('id', 'absent')), notices)
        sections.append(f'\n=== CELL {index} | type={kind} | id={cell_id} | execution_count={cell.get("execution_count")} ===\n')
        sections.append(clean(source, notices))
        if cell.get('attachments'):
            notices.append(f'Cell {index}: attachments omitted')
            sections.append('\n[NOTEBOOK ATTACHMENTS OMITTED; no image interpretation]\n')
        for oi, output in enumerate(cell.get('outputs', []), 1):
            otype = output.get('output_type', 'unknown')
            sections.append(f'\n--- CELL {index} OUTPUT {oi} | {otype} ---\n')
            if otype == 'stream':
                sections.append(clean(as_text(output.get('text')), notices))
            elif otype == 'error':
                sections.append(clean(str(output.get('ename', '')) + ': ' + str(output.get('evalue', '')), notices))
                sections.append(clean('\n'.join(output.get('traceback', [])), notices))
            else:
                data = output.get('data', {})
                if not isinstance(data, dict):
                    notices.append(f'Cell {index} output {oi}: malformed MIME bundle omitted')
                    continue
                # Prefer a textual table representation; retain plain text as a
                # separately labeled alternative, never raw rich-media JSON.
                kept = False
                if 'text/html' in data:
                    sections.append('[HTML TEXT REPRESENTATION]\n' + html_text(data['text/html'], notices))
                    kept = True
                if 'text/plain' in data:
                    sections.append('\n[PLAIN TEXT REPRESENTATION]\n' + clean(as_text(data['text/plain']), notices))
                    kept = True
                if 'application/json' in data:
                    sections.append('\n[JSON TEXT REPRESENTATION]\n' + clean(json.dumps(data['application/json'], ensure_ascii=False), notices))
                    kept = True
                for mime in data:
                    if mime not in {'text/plain', 'text/html', 'application/json'}:
                        notices.append(f'Cell {index} output {oi}: omitted MIME {mime}')
                        sections.append(f'\n[OMITTED MIME {clean(str(mime), notices)}; original cell {index}, output {oi}; content not interpreted]\n')
                if not kept:
                    sections.append('[NO SUPPORTED TEXT REPRESENTATION; do not infer plotted results]\n')
    fingerprint = hashlib.sha256(json.dumps(ordered_code, ensure_ascii=False).encode()).hexdigest()
    return '\n'.join(sections), fingerprint


def extract_pptx(path, notices):
    ns = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}
    parts = ['PPTX text only. Figures, chart graphics and slide layout are not interpreted.']
    with zipfile.ZipFile(path) as z:
        names = sorted((n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)), key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
        total = 0
        for name in names:
            info = z.getinfo(name)
            total += info.file_size
            if info.file_size > 20_000_000 or total > 100_000_000:
                raise ValueError('pptx_xml_size_limit')
            element = ET.fromstring(z.read(name))
            parts.append('\n=== ' + name + ' ===')
            for paragraph in element.findall('.//a:p', ns):
                parts.append(''.join(t.text or '' for t in paragraph.findall('.//a:t', ns)))
            parts.append('[Figures/charts/notes not extracted for this slide]')
    notices.append('PPTX text only; no figures/charts/speaker notes; table reading order may need checking')
    return clean('\n'.join(parts), notices), ''


def extract(path, raw, notices):
    suffix = path.suffix.lower()
    if suffix == '.ipynb':
        return extract_notebook(raw, notices)
    if suffix == '.pptx':
        return extract_pptx(path, notices)
    text = raw.decode('utf-8-sig', errors='replace')
    if '\ufffd' in text:
        notices.append('UTF-8 replacement characters present; encoding may need investigation')
    if suffix in {'.html', '.htm'}:
        return html_text(text, notices), ''
    # Do not propagate embedded HTML script/visual blocks in Markdown or code.
    for tag in ['script', 'style', 'canvas', 'iframe', 'object']:
        text, n = re.subn(fr'<{tag}\b[^>]*>.*?</{tag}\s*>', f'[{tag.upper()} BLOCK OMITTED]', text, flags=re.S | re.I)
        if n:
            notices.append(f'{tag} block omitted: {n}')
    return clean(text, notices), ''


def source_paths(root):
    for folder, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE_NAMES and not d.startswith('.') and not (Path(folder) / d).is_symlink() and (Path(folder) / d).resolve() != KIT)
        for name in sorted(files):
            path = Path(folder) / name
            if path.is_symlink() or name.startswith('.'):
                continue
            yield path


def prepare(root, max_file_mb=256):
    root = root.resolve()
    if root == KIT or root == Path(root.anchor):
        raise ValueError('Choose the investigation folder, not the kit or a broad filesystem root.')
    if not root.is_dir():
        raise ValueError('Source root is not a directory.')
    out = root / OUTPUT_NAME
    if out.is_symlink():
        raise ValueError('Output folder must not be a symbolic link.')
    out.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    snapshot = out / 'snapshots' / stamp
    extracts = snapshot / 'extracted'
    extracts.mkdir(parents=True)
    records = []
    for path in source_paths(root):
        rel = path.relative_to(root).as_posix()
        sid = 'SRC-' + hashlib.sha256(rel.encode()).hexdigest()[:16]
        row = {'source_id': sid, 'original_relative_path': rel, 'size_bytes': 0, 'sha256': '', 'ordered_code_sha256': '', 'status': '', 'text_files': [], 'notices': []}
        try:
            size = path.stat().st_size
            row['size_bytes'] = size
            if path.suffix.lower() not in TEXT_SUFFIXES | {'.ipynb', '.pptx'}:
                row['status'] = 'not_extracted_unsupported'
                row['notices'] = ['Binary/image/PDF/unsupported file: listed only; do not open with Copilot.']
            elif size > max_file_mb * 1024 * 1024:
                row['status'] = 'not_extracted_size_limit'
                row['notices'] = [f'Exceeds configured {max_file_mb} MB file limit; no contents read.']
            else:
                raw = path.read_bytes()
                row['sha256'] = hashlib.sha256(raw).hexdigest()
                body, fingerprint = extract(path, raw, row['notices'])
                row['ordered_code_sha256'] = fingerprint
                header = f'SOURCE ID: {sid}\nORIGINAL PATH (locator only; do not open): {rel}\nSHA256: {row["sha256"]}\nORDERED CODE SHA256: {fingerprint or "not applicable"}\n'
                header += '\nEXTRACTION NOTICES:\n' + '\n'.join('- ' + s for s in row['notices']) + '\n\n'
                text = clean(header + body, row['notices'])
                # Fixed chunks avoid a single huge tool response. No text is
                # deliberately truncated; all parts remain indexed.
                chunks = []
                start = 0
                while start < len(text):
                    end = min(start + 60000, len(text))
                    if end < len(text):
                        boundary = text.rfind('\n', start, end)
                        if boundary >= start:
                            end = boundary + 1
                    chunks.append(text[start:end])
                    start = end
                chunks = chunks or ['']
                for index, chunk in enumerate(chunks, 1):
                    target = extracts / f'{sid}__part{index:03}.txt'
                    target.write_text(f'PART {index}/{len(chunks)}; boundaries may split a line.\n' + chunk, encoding='utf-8')
                    row['text_files'].append(target.relative_to(out).as_posix())
                row['status'] = 'extracted_with_omissions' if row['notices'] else 'extracted_text'
        except Exception as exc:
            # Do not echo potentially sensitive parser input or raw error values.
            row['status'] = 'extraction_error'
            row['notices'].append('Exception type: ' + type(exc).__name__ + '; original preserved; no automatic execution attempted.')
        records.append(row)
    manifest = snapshot / 'SOURCE_MANIFEST.json'
    manifest.write_text(json.dumps({'snapshot': stamp, 'records': records}, indent=2, ensure_ascii=False), encoding='utf-8')
    with (snapshot / 'SOURCE_MANIFEST.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['source_id','original_relative_path','size_bytes','sha256','ordered_code_sha256','status','text_files','notices'])
        writer.writeheader()
        for row in records:
            writer.writerow({**row, 'text_files': '; '.join(row['text_files']), 'notices': '; '.join(row['notices'])})
    counts = dict(Counter(r['status'] for r in records))
    summary = f'# Current extraction\n\nSnapshot: {stamp}\n\nManifest: snapshots/{stamp}/SOURCE_MANIFEST.json\n\nSources: {len(records)}\n\n' + '\n'.join(f'- {k}: {v}' for k,v in counts.items())
    summary += '\n\nOriginals unchanged. No notebooks executed, no image interpretation, no API/network calls.\nAll snapshots are text-only representations, not proof of clean execution.\nReview all unavailable/omitted material before calling the audit complete.\n'
    (out / 'CURRENT_SNAPSHOT.md').write_text(summary, encoding='utf-8')
    (snapshot / 'PREPARATION_SUMMARY.md').write_text(summary, encoding='utf-8')
    for template in (KIT / 'templates').glob('*'):
        if template.is_file():
            copyfile(template, out / template.name)
    print('TEXT PREPARATION COMPLETE')
    print('Open this folder in a NEW VS Code window: ' + str(out))
    print('Sources: ' + str(len(records)) + '; status counts: ' + json.dumps(counts))
    print('Read CURRENT_SNAPSHOT.md and the manifest for omissions/errors. No original files changed.')
    return out, records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=KIT.parent, help='Investigation folder. Default: parent of this kit.')
    parser.add_argument('--max-file-mb', type=int, default=256)
    args = parser.parse_args()
    if sys.version_info < (3, 9):
        parser.error('Python 3.9 or later is required.')
    if args.max_file_mb < 1:
        parser.error('--max-file-mb must be positive.')
    prepare(args.root, args.max_file_mb)


if __name__ == '__main__':
    main()
