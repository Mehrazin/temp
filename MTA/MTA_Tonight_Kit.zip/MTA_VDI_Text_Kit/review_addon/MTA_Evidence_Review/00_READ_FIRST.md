# Complete-package entry point

For this bundled run follow MTA_VDI_Text_Kit/START_HERE.md and 00_START_PROMPT.txt. Preparation installs this folder automatically. The numbered review prompts below remain the same. Tonight use Sol Medium for data/results, Sol High for model review and synthesis. Follow 09_TONIGHT_MODE.txt for the existing-artifacts-only review and twelve-card HTML report. The older general setup notes below are retained for reference.

# Review the existing work for the AVP presentation

This is an addition to the existing **MTA_VDI_Text_Kit**, not a new agent platform. The notebook extractor and previous reports stay unchanged. The supplied presentation evidence is preserved verbatim under `reference/`; the review distinguishes its transcriptions from its interpretations.

**Updated September 9:** `08_PROJECT_HISTORY_UPDATE.txt` records your clarified project history, TMIA/list-generation semantics, PRISM timing, Salesforce migration and current MTA-first delivery priority. All review roles now read it. Earlier presentation roadmaps remain historical evidence.

If you already transferred the previous package, you can bring just this one update file and paste its full contents into each active review chat, including the coordinator. No new extraction or review restart is needed. If starting fresh, use the updated ZIP and follow the steps below.

## Exactly what to do

1. If you have not prepared the notebooks yet, use the existing kit's `01_PREPARE_PROMPT.txt` first. It creates `mta_text_workspace`. No new extraction is needed just for this addition.
2. Unzip this package and put its **MTA_Evidence_Review** folder directly inside `mta_text_workspace`, beside `CURRENT_SNAPSHOT.md`. Open **only `mta_text_workspace`** in the VS Code review window. Close original notebook/image tabs.
3. Start one Copilot Agent chat, using your available **Sol** model. Paste all of `01_COORDINATOR_START.txt`. It indexes the existing text snapshot, creates the shared review context, and tells you when setup is complete.
4. After setup completes, open **three new chats in the same VS Code window**. Paste one complete prompt into each, as listed below. They can run simultaneously. They write separate files; you do not copy answers between them.
5. When all three finish, return to the coordinator chat and paste **`05_COORDINATOR_SYNTHESIS.txt`**. It reads their files, reconciles evidence and writes one presentation brief plus a technical appendix.

| Chat | Prompt | Suggested assignment |
|---|---|---|
| Coordinator | `01_COORDINATOR_START.txt`, then `05_COORDINATOR_SYNTHESIS.txt` | Sol |
| Data and incumbent attribution | `02_DATA_REVIEW.txt` | Sol |
| Model and fractional attribution | `03_MODEL_REVIEW.txt` | Sol |
| Results and recommendation evaluation | `04_RESULTS_REVIEW.txt` | Opus, for a separate perspective |

These assignments use the models you said are available; they are not speed or quality benchmark claims. Use the strongest effort setting you are comfortable waiting for. Distinct review scopes matter more than asking every model to reread everything at maximum effort. There is one review pass and one consolidation, with no automatic critique loop or API calls.

## What comes back

The coordinator creates a numbered folder under `90_review/presentation_evidence/` and reports its exact location. It contains:

- `AVP_BRIEF.md` and `REVIEW_CARDS.html`: ten compact cards covering the story, current implementation, evidence, outputs, uses and roadmap. Start by bringing those cards back to the presentation chat; the detailed appendix can stay in VDI.
- `CLAIM_LEDGER.csv`: each claim's source, model population, units, implementation/run evidence and usable wording.
- `TECHNICAL_APPENDIX.md`: exact formulas, code locators, contradictions and limitations.
- `NEXT_CHECKS.md`: only the remaining questions that affect the presentation or September scope, with a short batch of proposed checks if existing outputs cannot answer them.

No original notebooks, images or presentations are opened by the review chats. The existing text extracts contain notebook code and saved textual outputs; unavailable figures remain marked as gaps. Review does not run the TD pipelines or retrain a model. Small calculations on explicitly transcribed aggregate numbers are allowed and labeled as arithmetic checks.

## If a chat becomes too long

Send `06_CHECKPOINT.txt` in that chat. Open a fresh chat in the same window and send `07_RESUME.txt`. Each role has its own checkpoint. If several roles are unfinished, the new chat asks you which one to resume; replying `data`, `model`, `results` or `coordinator` is enough.

## Additional evidence

Read `EVIDENCE_REVIEW.md` for the findings and the small number of useful additional views. You can start the Copilot review immediately; those views are not prerequisites. Do not spend tonight transcribing the unused appendices or the older 2021 presentations unless a selected presentation claim needs them.

The original source document's model names, dates, results and interpretations remain evidence to verify. This package does not choose a new modeling architecture, certify a causal result, or change your delivery commitments.
