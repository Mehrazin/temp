# Evidence-directed checks

These are starting claims/questions, not accepted findings or requirements to change the model. Source IDs refer to the verbatim document at `MTA_Evidence_Review/reference/PRESENTATION_EVIDENCE.md`. Search for the relevant heading and read its surrounding text; do not assume all commentary under it is correct. Use code/output provenance to reconcile the claims.

**Owner clarification:** first read `08_PROJECT_HISTORY_UPDATE.txt` (OWNER-20260909). The broad history is now explained: TMIA campaign exploration -> measurement-data snapshot -> diagnostic/predictive development -> current full-data MTA delivery. Do not spend the review rediscovering that rationale or treating those scope changes as contradictory implementations. Exact result lineage, source parity, allocation formulas and metric discrepancies remain to verify. Current MTA-first priority supersedes D02's older prediction-first scheduling assumption.

Additional owner-directed checks, assigned without expanding the whole audit:

- DATA-01/08: verify batch assignment/list-generation semantics and Unicab/Salesforce source transition, supplemental feeds, duplicates, gaps and metadata coverage using existing results.
- MODEL-03/11: verify PRISM effective-date vs feature-availability vs target-horizon alignment; distinguish the original core TMIA study from later TMIA augmentation of measurement data.
- RESULTS-07: distinguish demonstrated snapshot results from full-data execution and September readiness; preserve the current MTA-first priority and later predictive stream.

## DATA — owned by the data reviewer

| ID | Evidence anchor and presented information | Required resolution |
|---|---|---|
| DATA-01 | R01 and D01-S003: application-reference OR DAB-reference OR customer-plus-eligibility matching; this differs from an earlier verbal description of sequential fallback. | Exact join predicate, deduplication, precedence if any, key-quality handling, and eligibility semantics. |
| DATA-02 | R01: online = app/DAB identity equality; `in_window` may be true for an online match without ordinary time filtering; default lookback seven days; RESL has special upper bounds. | Exact time predicates, post-anchor exceptions and whether as-of timing is suitable for each downstream use. |
| DATA-03 | R01: one winner, null/unattributed outputs retained; path = distinct in-window same-LOB channels. Winner and path need not coincide. | Grain, row retention, ties, path/winner definitions; do not describe all unmatched IDs as removed conversions. |
| DATA-04 | D01-S005/S006/S013: 10,538,441 primary audit entities; 10,536,464 supplementary entities; 10,123,225 production IDs. Primary 484.98M prepared rows includes July 1, 2026; supplement 986.02M all-history rows ends June 30. | Separate dates and denominator definitions; align comparable subsets only. |
| DATA-05 | D01: 8,679,415 technical matches (82.37%); 7,542,921 pre-conversion (71.59%); 5,954,297 within 90 days (56.51%), based on supplementary audit. Production-attributed 3,459,646 (34.18%) uses a different denominator. | Verify exact saved outputs and relation to production; no single mixed-denominator funnel. |
| DATA-06 | D01-S002: Display 9.21% usable customer/app/DAB keys; 4.71% of distinct Display events linked. Key route matches overlap; app/DAB customer agreement varies around 79–96%. | Distinguish any usable key vs customer key, raw rows vs distinct events, and linkage vs credit/causation. |
| DATA-07 | D01-S005/S006: earlier history adds 286,928 technical matches, 637,552 pre-conversion matches, only 5,357 within 90 days. | Same cohort? Date boundaries? Scope of recommendation; do not require one universal 90-day window. |
| DATA-08 | D01-S010/S013: excluded raw rows add 602,408 pre-conversion journeys and 1,524,400 within 90 days, mostly bank channels. RESL/Display short-window recovery is tiny. | What categories were restored, at which grain, and which can be contextual evidence versus credit-eligible? Existing results first. |

## MODEL — owned by the model reviewer

| ID | Evidence anchor and presented information | Required resolution |
|---|---|---|
| MODEL-01 | D09-S016/S017: eight channels, TMIA/campaign history, legacy scores (e.g. 1524/1536/1572), snapshot March 31, 2025, a `contrl_cell_in` field. D08: five-channel DR. D04: nine channels/24 event features/10 PRISM heads plus CC_ind. D10: twelve-channel summary. | Variant lineage and row/population definitions; do not merge these into one model or infer they share training artifacts. |
| MODEL-02 | D09-S018: 2,592,528 customers, 42,399 positives; train 77,527 with 5,999 positives; test 155,748 with 2,513 positives. D04-S002: 2,604,922 and 35,453. D10-S008 totals 1,652,021 and 30,990. | Reconcile preprocessing, cohort, sampling and label definitions per variant. |
| MODEL-03 | D04-S008/S020/S027: inconsistent-looking Apr–July diagnostic inputs vs Apr–May profile / June–July treatment. D09-S020: 12-month legacy-model observation Apr 2024–Mar 2025. Earlier recollection used conversion-truncated journeys and later scores. | Exact as-of feature dates and comparable observation opportunity; distinguish score-training history from journey window. |
| MODEL-04 | D08-S016 claims OOF response/propensity estimation and calibration. D09-S032 specifies isotonic on all data except test; S019 shows 0.2 for both downsample settings. | Actual fold boundaries and calibration population per variant, outcome-sampling correction and propensity target; no cross-deck inference of identical implementation. |
| MODEL-05 | D04-S020 displays per-row DR score with observed Y then average ATE; S027 labels a corrected score as customer CATE. D08-S006 examples 0.86 and 9.26 use converted treated customers. | Raw pseudo-outcome vs ATE vs fitted CATE, final-stage learner and future scoring. Values outside probability bounds can be valid pseudo-outcomes, not individual probability effects. |
| MODEL-06 | D06-S004/S005 and D07-S014: campaign selection by cell, scores/ranks, PA, zone, invitation type, manual Leads selection and other variables. | Are relevant pre-treatment confounders measured/used, what does control mean, and is randomization documented within any eligible stratum? A cell flag is not proof of a randomized global holdout. |
| MODEL-07 | D09-S030 explicitly distinguishes coalition Shapley from model-explanation SHAP. D09-S005 has 127/256 unobserved combinations. D10-S007 labels both plots mean absolute SHAP, one under “Doubly Robust Method.” | What function is explained, what coalitions/backgrounds are evaluated, on what scale and support? SHAP of a CATE predictor is not automatically attribution of a conversion. |
| MODEL-08 | D08-S007/S013: signed ATEs Email −0.0052; Leads +0.0429; Direct Mail +0.0058; EasyLine −0.0040; eBank +0.0109. Pie is explicitly absolute ATE shares. | Normalization formula, signs, aggregate vs per-conversion allocation, exposure masking and zero/no-journey handling. |
| MODEL-09 | D04-S023 channel mean Branch −0.0037 vs S024 four positive Branch event values (0.0851, 0.0003, 0.0003, 0.0002); Leads, Email and Mobile group/event values also differ. | Separate models/runs/aggregation weights/transcription? A simple mean of these Branch values is +0.021475, not −0.0037. Do not assume group effect equals sum or mean of event effects. |
| MODEL-10 | D08 per-channel overlap plots show ranges and different occupied bins; report comments overinterpret these. Historical TMIA control count around 504k. | Inspect treated/control support, near-zero/one mass, counts, weight tails, ESS and binning/trimming rules, only if already computed or cheaply specified. Low max e or two displayed bins alone does not decide identification. |
| MODEL-11 | Some model notebooks allegedly add sends/TMIA then abandon that branch; newer claims separate diagnostic from predictive work. | Trace actual read→join→feature→model→output consumption. Record features/decay selection and allocation implemented versus proposed. Don't discard a historical branch just because it isn't production. |

## RESULTS — owned by the results reviewer

| ID | Evidence anchor and presented information | Required resolution |
|---|---|---|
| RESULTS-01 | D03-S012/S013: historical BAU 1.31%, unconstrained 2.08%, constrained 1.45%; approximately +13% text partly readable. | Exact generating output, comparable population, method, denominator and caption. (1.45/1.31−1)×100 = 10.687%; ordinary rounding alone doesn't reach 13%. |
| RESULTS-02 | D03-S008/S009/S018: alternative ATE tiles, star footnote missing; e.g. Display 0.55% vs 0.65%, SEO 0.24% vs 0.43%. | Current figure, cohort, scale, unit, iteration and star meaning; don't pick the most favorable or the latest-uploaded view. |
| RESULTS-03 | D04-S011: AUC 0.7017 vs 0.7510, annotation +4.93%. Decile rates in S013 total implied mean ≈6% if equally sized, whereas general cohort header is 1.36%. | AUC gain is +0.0493 absolute (≈7.03% relative); reconcile targeted evaluation set, timestamp and decile construction. Better AUC/top-decile concentration does not guarantee better policy. |
| RESULTS-04 | D04-S031: “Average Next Best Channel Effect / Treatment Effect %” donut 62/21/8/7/2 for Leads/Display/Paid/SEO/Email. | Share of assignments, sum of effects, normalized means or another metric? Locate numerator/denominator and evaluated customers. |
| RESULTS-05 | D04-S027 illustrative ORCA actions include Display/Paid Search/SEO; D03-S010/S011 specify Email/Direct Mail/Leads and no action. | Implemented feasible actions, constraints, costs, scoring target and whether multiple-action additivity is assumed. |
| RESULTS-06 | D03-S019: opt-out rate by lift/PRISM decile; says signal not yet incorporated but might improve assignment. | Association vs demonstrated reduction; source plot values, horizon, sample, role in existing decisioning objective. |
| RESULTS-07 | D05 diagram says Transformer Engine; D06-S012 lists simulation and basic transformer development; D02 says XGB+DR delivered Aug 2026, MTA Sep 30, 2026, later MMM/transformer stages. | Separately establish code/run/evaluation/acceptance/deployment. A diagram is not delivery proof; code may exist beyond supplied inventory. Historical targets need owner confirmation to become current commitments. |
| RESULTS-08 | D07 describes LiDDA/NNN, MMM calibration, experiment comparison and simulation. Some results source is unstated; comments about method superiority are not citations. | TD experiment vs synthetic vs external literature vs illustrative diagram. Inspect local evidence; leave new literature research out of this presentation review. |
| RESULTS-09 | D09-S029/S032 calibration test-decile table; S008/S028 different eight-channel shares; D08 five-channel and D09 eight-channel charts compared side by side. | Identify which results are comparable, which are alternative methods/runs, and which can be showcased as earlier-stage evidence without asserting current-model validation. |

## Interpretation corrections applying to all roles

- D09 already defines RD/RW/LD/EM/EL/RM/ET/DM and legacy score IDs. Earlier “undefined” questions are not still missing slide evidence; code equivalence may remain open.
- Low maximum propensity is not itself overlap failure. Wide minimum-to-maximum range is not proof of good overlap either. Two bins may reflect ties or binning code. Do not label a channel unidentified from these plots alone.
- D08-S021's commentary says every Direct Mail decile bar is at or above 0.0058, but its own approximate values include 0.0047 and 0.0040. Retract that specific premise; still check whether pooled and subgroup estimates use the same population.
- A prospective roadmap can legitimately contain future dates. D10's Feb 2025 cover is not disproved merely by future 2026 milestones. The Jan/Feb 2025 entries placed after Nov 2025 are sequencing ambiguities, but do not silently correct the years. Reused content does not prove chronological direction.
- Different signs of estimation error in three experiments do not establish that one method is less accurate; absolute errors, uncertainty and comparability matter. Do not inherit D07's “different error directions” critique as a decisive finding.
- Shapley contributions can allocate interactions present in a value function. Additive output shares do not imply that the underlying response has no interactions. Missing coalition support is a distinct concern.
- Do not infer a twelve-month observed marketing journey from the legacy propensity model's twelve-month input history.
- The presence of a slide showing OOF/calibration metrics is useful presented evidence. It is not an independently reproduced run, and cannot establish that another variant used the same procedure.
