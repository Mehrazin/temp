# Presentation Evidence — Historical MTA and Workspace Inventory

## Scope and evidence standard

- This file records faithful extracts from screenshots of historical MTA presentations and the visible VDI project/file structure used to organize related work.
- Deck IDs are assigned in first-seen upload order: `D01`, `D02`, and so on.
- Slide IDs are assigned in visible slide order within each deck: `D01-S001`, `D01-S002`, and so on. If original slide numbers or sequence are not visible, the ID reflects screenshot upload order and that uncertainty is noted.
- Non-slide evidence uses its own prefixes: `R01`… for rendered reports, `L01`… for file-library listings. Views within one listing are numbered in upload order (`L01-S001`, `L01-S002`).
- Slides are treated as evidence of what was presented, not proof that a method was implemented, deployed, validated, or produced the claimed outcome.
- Unreadable content is marked `[UNREADABLE]`; partially readable content is marked `[PARTIALLY READABLE: ...]`. Exact values are not inferred from plots.
- Interpretation is kept separate from transcription.

## VDI directory and notebook inventory

### Evidence boundary

- Source: 10 Windows File Explorer screenshots supplied on 2026-09-09.
- These screenshots show directory names and file metadata only. They do **not** establish what the notebooks contain, whether they ran successfully, or whether any apparent workflow was implemented or validated.
- Names, dates, file types, and sizes below are transcribed as displayed. Windows reports all notebooks as `Jupyter Source File`.
- The screenshots do not show the absolute drive path. The visible root begins at `Documents/Investigate_mta`.

### Consolidated visible directory tree

```text
Documents/
└── Investigate_mta/
    ├── Measurement team/
    │   ├── Generated notebooks/
    │   ├── Original notebooks/
    │   ├── reports/
    │   └── Results of generated notebooks/
    └── Our team/
        ├── Mehrazin/
        ├── Nazanin/
        └── Vandad/
```

### Root-level folders

Path: `Documents/Investigate_mta`

| Name | Date modified | Type |
| --- | --- | --- |
| `Measurement team` | 9/9/2026 1:16 AM | File folder |
| `Our team` | 9/9/2026 1:16 AM | File folder |

### `Our team` folders

Path: `Documents/Investigate_mta/Our team`

| Name | Date modified | Type |
| --- | --- | --- |
| `Mehrazin` | 9/9/2026 1:11 AM | File folder |
| `Nazanin` | 9/9/2026 1:13 AM | File folder |
| `Vandad` | 9/9/2026 1:15 AM | File folder |

#### `Our team/Mehrazin`

| Name | Date modified | Type | Size |
| --- | --- | --- | ---: |
| `(Nazanin) MTA_EDA.ipynb` | 9/9/2026 1:07 AM | Jupyter Source File | 13,109 KB |
| `(Vandad) model_exploration.ipynb` | 9/9/2026 1:07 AM | Jupyter Source File | 20,393 KB |
| `EDA.ipynb` | 9/9/2026 1:11 AM | Jupyter Source File | 17,349 KB |
| `EDA_2.ipynb` | 9/9/2026 1:10 AM | Jupyter Source File | 18,598 KB |
| `EDA_3.ipynb` | 9/9/2026 1:10 AM | Jupyter Source File | 17,041 KB |
| `lumen_ai_bau_optimizer_eval_databricks.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 7,907 KB |
| `lumen_ai_bau_optimizer_eval_databricks_out_only.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 7,840 KB |
| `lumen_ai_diagnostic_channel_contribution_databricks.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 35 KB |
| `lumen_ai_optimizer_plots_databricks.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 128 KB |
| `lumen_ai_predictive_policy_eval_v3_databricks_s1.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 648 KB |
| `lumen_ai_predictive_policy_eval_v3_databricks_s2.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 534 KB |
| `mta_demo_analysis_databricks.ipynb` | 9/9/2026 1:07 AM | Jupyter Source File | 2,162 KB |
| `Oraca + Lumen.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 7,131 KB |
| `TMIA-EDA.ipynb` | 9/9/2026 1:06 AM | Jupyter Source File | 7,847 KB |

#### `Our team/Nazanin`

| Name | Date modified | Type | Size |
| --- | --- | --- | ---: |
| `Add TMIA.ipynb` | 9/9/2026 1:11 AM | Jupyter Source File | 62,265 KB |
| `conversion_interaction_join_aggregate.ipynb` | 9/9/2026 1:12 AM | Jupyter Source File | 96,975 KB |
| `mta_preprocess.ipynb` | 9/9/2026 1:12 AM | Jupyter Source File | 42,107 KB |

#### `Our team/Vandad`

| Name | Date modified | Type | Size |
| --- | --- | --- | ---: |
| `eda.ipynb` | 9/9/2026 1:14 AM | Jupyter Source File | 4,241 KB |
| `model_exploration.ipynb` | 9/9/2026 1:14 AM | Jupyter Source File | 11,605 KB |
| `model_exploration_tmia_final_predictive_only_no_interactions.ipynb` | 9/9/2026 1:14 AM | Jupyter Source File | 824 KB |
| `step_1_extract_channels_waves.ipynb` | 9/9/2026 1:15 AM | Jupyter Source File | 3,865 KB |
| `step_2_join_model_scores.ipynb` | 9/9/2026 1:15 AM | Jupyter Source File | 13,183 KB |

### `Measurement team` folders

Path: `Documents/Investigate_mta/Measurement team`

| Name | Date modified | Type |
| --- | --- | --- |
| `Generated notebooks` | 9/9/2026 12:44 AM | File folder |
| `Original notebooks` | 9/9/2026 12:43 AM | File folder |
| `reports` | 9/9/2026 12:46 AM | File folder |
| `Results of generated notebooks` | 9/9/2026 12:45 AM | File folder |

#### `Measurement team/Original notebooks`

| Name | Date modified | Type | Size |
| --- | --- | --- | ---: |
| `00-temp-wbana-interactions.ipynb` | 9/6/2026 2:27 PM | Jupyter Source File | 79 KB |
| `001-onetd_sf_ap_v1.ipynb` | 9/6/2026 2:29 PM | Jupyter Source File | 6,299 KB |
| `001-onetd_sf_email_v1.ipynb` | 9/6/2026 2:30 PM | Jupyter Source File | 12,853 KB |
| `001-onetd_sf_email_v1_loan_cell_code_mapping.ipynb` | 9/6/2026 2:29 PM | Jupyter Source File | 12,672 KB |
| `001-onetd_sf_leads_v1.ipynb` | 9/6/2026 2:30 PM | Jupyter Source File | 5,950 KB |
| `001-onetd_sf_merge_v1.ipynb` | 9/6/2026 2:29 PM | Jupyter Source File | 8,440 KB |
| `001-onetd_sf_obtm_v1.ipynb` | 9/6/2026 2:30 PM | Jupyter Source File | 5,984 KB |
| `accts_daily.ipynb` | 9/6/2026 2:27 PM | Jupyter Source File | 6,508 KB |
| `easyapply.ipynb` | 9/6/2026 2:29 PM | Jupyter Source File | 7,198 KB |
| `historical-pivot.ipynb` | 9/6/2026 2:26 PM | Jupyter Source File | 122 KB |
| `p2c_secondary_conversions.ipynb` | 9/6/2026 2:27 PM | Jupyter Source File | 4,618 KB |
| `prod-00-helpers.ipynb` | 9/6/2026 2:27 PM | Jupyter Source File | 39 KB |
| `prod-00-validation.ipynb` | 9/6/2026 2:26 PM | Jupyter Source File | 1,356 KB |
| `prod-01-tables-to-adls.ipynb` | 9/6/2026 2:27 PM | Jupyter Source File | 497 KB |
| `prod-02-channel-metadata.ipynb` | 9/6/2026 2:26 PM | Jupyter Source File | 10,413 KB |
| `prod-03-logs.ipynb` | 9/6/2026 2:26 PM | Jupyter Source File | 16,619 KB |
| `prod-04-attribution.ipynb` | 9/6/2026 2:26 PM | Jupyter Source File | 3,199 KB |

#### `Measurement team/Generated notebooks`

| Name | Date modified | Type | Size |
| --- | --- | --- | ---: |
| `prod-04-attribution-eda.ipynb` | 9/9/2026 12:12 AM | Jupyter Source File | 63 KB |
| `prod-04-history-window-sensitivity.ipynb` | 9/9/2026 12:12 AM | Jupyter Source File | 38 KB |
| `prod-04-journey-observability-audit.ipynb` | 9/9/2026 12:12 AM | Jupyter Source File | 60 KB |
| `prod-04-journey-segment-visuals.ipynb` | 9/9/2026 12:39 AM | Jupyter Source File | 59 KB |
| `prod-04-raw-exclusion-journey-recovery.ipynb` | 9/9/2026 12:12 AM | Jupyter Source File | 25 KB |

#### `Measurement team/Results of generated notebooks`

| Name | Date modified | Type | Size |
| --- | --- | --- | ---: |
| `prod-04-attribution-eda-w-data.ipynb` | 9/7/2026 10:18 PM | Jupyter Source File | 7,758 KB |
| `prod-04-history-window-sensitivity_w_data.ipynb` | 9/8/2026 9:45 PM | Jupyter Source File | 2,690 KB |
| `prod-04-journey-observability-audit-no-plots.ipynb` | 9/8/2026 2:21 PM | Jupyter Source File | 944 KB |
| `prod-04-raw-exclusion-journey-recovery_w_data.ipynb` | 9/8/2026 9:44 PM | Jupyter Source File | 857 KB |

#### `Measurement team/reports`

| Name | Date modified | Type | Size |
| --- | --- | --- | ---: |
| `attribution-logic-walkthrough.html` | 9/9/2026 12:12 AM | Chrome HTML Document | 13 KB |
| `journey-observability-full-research-handoff.md` | 9/9/2026 12:23 AM | Markdown Source File | 77 KB |
| `journey-observability-research-report.html` | 9/9/2026 12:23 AM | Chrome HTML Document | 28 KB |

### Filename-based relationships and cautions

The following are navigation aids for an LLM, not confirmed implementation facts:

- The `Our team` branch appears to contain individual working copies and explorations. Mehrazin's folder also contains notebooks attributed in filenames to Nazanin and Vandad.
- Vandad's filenames explicitly distinguish a `predictive_only_no_interactions` exploration from other model exploration work. This is evidence of a named notebook variant, not evidence that its modeling assumptions or results were accepted.
- Nazanin's filenames suggest a preprocessing sequence involving TMIA, a conversion/interaction join and aggregation, and MTA preprocessing. The execution order is not established by the screenshots.
- The Measurement team's `Original notebooks` include source/channel preparation (`onetd_sf_*`), account/conversion data, validation, ADLS tables, channel metadata, logs, and `prod-04-attribution.ipynb`.
- The `Generated notebooks` appear to be analysis/audit companions around the `prod-04` attribution stage: attribution EDA, history-window sensitivity, journey observability, journey-segment visuals, and recovery of journeys excluded from raw data.
- Four generated-notebook topics have apparent counterparts in `Results of generated notebooks`, typically with `w-data`, `_w_data`, or `no-plots` suffixes. No result counterpart for `prod-04-journey-segment-visuals.ipynb` is visible in the supplied screenshot.
- The result-notebook timestamps precede the generated-notebook timestamps shown in another folder. This may reflect copying, regeneration, or unrelated filesystem modification times; it should not be interpreted as workflow chronology without checking file contents or version history.
- Report filenames indicate an attribution-logic walkthrough and a journey-observability research handoff/report, but the screenshots do not expose their contents.

### Unreadable or uncertain details

- `00-temp-wbana-interactions.ipynb` refers to the Webana web-analytics table, per user clarification. The report displays this concept as `WBANA` in its candidate classes.
- No listed file size is unreadable in the supplied images.
- The screenshots do not expose files that may exist below the visible fold or in folders not opened.

## SharePoint presentations library inventory

### L01 — `presentations` library, TECE AIML Practice site

**Evidence boundary.** Two photographs of a monitor supplied 2026-09-09, both showing the same SharePoint document library at two scroll positions. These establish **filenames, created/modified dates, last modifier and file size as displayed**. They do not establish deck contents, authorship of the content, when a deck was presented, or whether it was presented at all. Per the user: the **Created** date is the more meaningful signal, because **Modified** can be updated by merely opening or re-saving a file, and several of these files have been opened recently.

- Site header: `TECE AIML Practice`, `Private group | Internal`, `Not following`, `27 members`.
- Breadcrumb: `Documents > Innovatio… > Channel A… > presentations` (middle crumbs truncated by the UI).
- View: `All Documents`. Columns: `Name`, `Modified`, `Modified By`, `Created`, `File Size`, `+ Add column`. The sort arrow sits on **`Created`, descending**.
- Taskbar clock reads `3:19 A[M]`, `9/9/20…` — one minute after the D10 editor screenshots (3:18 AM, 9/9/2026), so this is the same session.
- **Year handling.** Most `Created`/`Modified` values print no year. SharePoint conventionally omits the year for the current year, which would make the bare dates 2026, but the screenshots do not prove this. Values that do carry a year are truncated by the column width and are recorded as printed with `[TRUNCATED]`.
- Left edge of both images shows a sliver of a collapsed navigation pane (`…ons`, `…ts`, `SharePoint`, `…Point`); not legible enough to transcribe.

#### L01-S001 — Library listing, lower scroll position (upload 1 of 2)

Twelve rows visible, all PowerPoint icons except one `.url` shortcut. Transcribed as printed, in displayed order:

| # | Name | Modified | Modified By | Created | File Size |
|---:|---|---|---|---|---:|
| 1 | `DR_Shap_executive.pptx` | May 11 | `Davoodnia, Vanda…` | May 5 | 14.5 MB |
| 2 | `executive_review.pptx` | April 15 | `Davoodnia, Vanda…` | March 25 | 11.7 MB |
| 3 | `mta_biases.pptx` | March 10 | `Davoodnia, Vanda…` | March 10 | 6.21 MB |
| 4 | `literature_review.pptx` | March 10 | `Davoodnia, Vanda…` | March 10 | 6.73 MB |
| 5 | `Channel_Attribution_plan_one_slide.pptx` | June 20 | `Davoodnia, Vanda…` | February 17 | 5.57 MB |
| 6 | `Channel_Attribution_Doubly_Robust_demo.pptx` | March 17 | `Mehregan, Nazani…` | January 9 | 968 KB |
| 7 | `Channel_Attribution_Shapley_value_demo.pptx` | May 5 | `Mehregan, Nazani…` | `December 1, 20…` `[TRUNCATED]` | 7.61 MB |
| 8 | `MTA_proposal.pptx` | March 10 | `Davoodnia, Vanda…` | `November 19, 2…` `[TRUNCATED]` | 5.91 MB |
| 9 | `Channel Effect Estimation For ULOC Camaigns V8.pptx.url` | `November 19, 2…` `[TRUNCATED]` | `Qiu, Jessie` | `November 19, 2…` `[TRUNCATED]` | 285 bytes |
| 10 | `Channel_Attribution_plan.pptx` | April 29 | `Wang, Lili` | `November 19, 2…` `[TRUNCATED]` | 6.65 MB |
| 11 | `Channel_Attribution_Presentation_Snapshot_2021-11-19_Revised5 1.pptx` | June 20 | `Davoodnia, Vanda…` | `November 13, 2…` `[TRUNCATED]` | 1.13 MB |
| 12 | `Channel_Attribution_Presentation_ART_2021-07-30.pptx` | June 20 | `Davoodnia, Vanda…` | `November 13, 2…` `[TRUNCATED]` | 2.35 MB |

- Row 9: the filename appears to read `Camaigns`, an apparent misspelling of "Campaigns", and is transcribed as printed. In L01-S002 the same row renders as `Camaiqns` due to image blur; the two are the same file. `[PARTIALLY READABLE: the g/q is not sharp in either image]`
- Row 9 is a `.url` shortcut of 285 bytes, i.e. a pointer to a file held elsewhere, not a deck stored in this library.
- Row 11's name contains an internal space before `1.pptx`, consistent with a copy-suffix. Transcribed as printed.
- All `Modified By` names are clipped by the column width. They are consistent with `Davoodnia, Vandad`, `Mehregan, Nazanin`, `Wang, Lili` and `Qiu, Jessie`, but the surnames' endings are not visible except for the two short ones. `[PARTIALLY READABLE]`

#### L01-S002 — Library listing, top of list (upload 2 of 2)

Same library scrolled to the top. Twelve rows visible; the last nine repeat L01-S001 rows 1–9 and are not re-transcribed as separate claims. New rows only:

| # | Name | Modified | Modified By | Created | File Size |
|---:|---|---|---|---|---:|
| 1 | `Results` *(folder)* | June 5 | `Alizadeh, Mehrazi…` | June 5 | 1 item |
| 2 | `MTA_MMM_two_stream_timeline.pptx` | August 19 | `Alizadeh, Mehrazi…` | August 19 | 31.0 KB |
| 3 | `LumenAI_VP_Deck.pptx` | July 22 | `Alizadeh, Mehrazi…` | May 25 | 3.52 MB |

- Row 1 is the only folder in the library and reports `1 item`. Its contents are not visible.
- Cross-link: rows 4–12 of this view correspond to L01-S001 rows 1–9 with identical values, confirming the transcription above.
- This view establishes that L01-S001 was **not** the top of the list, and that the library contains **15 entries** in total across both views (14 files + 1 folder), assuming nothing sits below L01-S001's last visible row. The scrollbar in L01-S001 suggests the list ends there, but this is not certain. `[UNCERTAIN]`

#### Mapping to processed decks

Filename matches only. A filename match does not confirm that the screenshotted deck is the current version of that file.

| Library file | Deck ID | Cover date recorded in this file | Created (as printed) | Modified (as printed) |
|---|---|---|---|---|
| `MTA_MMM_two_stream_timeline.pptx` | **probably `D02`** | none visible on D02 slides | August 19 | August 19 |
| `LumenAI_VP_Deck.pptx` | `D03` | July 22, 2026 | May 25 | July 22 |
| `DR_Shap_executive.pptx` | `D04` | April 1st 2026 | May 5 | May 11 |
| `executive_review.pptx` | `D05` | April 1st 2026 | March 25 | April 15 |
| `mta_biases.pptx` | `D06` | Dec 5 2025 | March 10 | March 10 |
| `literature_review.pptx` | `D07` | Dec 5 2025 | March 10 | March 10 |
| `Channel_Attribution_Doubly_Robust_demo.pptx` | `D08` | Dec 5 2025 | January 9 | March 17 |
| `Channel_Attribution_Shapley_value_demo.pptx` | `D09` | Dec 5 2025 | `December 1, 20…` | May 5 |
| `Channel_Attribution_plan.pptx` | `D10` | Feb 17, 2025 | `November 19, 2…` | April 29 |
| `Channel_Attribution_plan_one_slide.pptx` | *not processed* | — | February 17 | June 20 |
| `MTA_proposal.pptx` | *not processed* | — | `November 19, 2…` | March 10 |
| `Channel Effect Estimation For ULOC Camaigns V8.pptx.url` | *not processed* | — | `November 19, 2…` | `November 19, 2…` |
| `Channel_Attribution_Presentation_Snapshot_2021-11-19_Revised5 1.pptx` | *not processed* | — | `November 13, 2…` | June 20 |
| `Channel_Attribution_Presentation_ART_2021-07-30.pptx` | *not processed* | — | `November 13, 2…` | June 20 |
| `Results` *(folder, 1 item)* | *not processed* | — | June 5 | June 5 |

- **`D01` and `R01` are absent from this library**, as expected: they are HTML/Markdown reports in the VDI `Measurement team/reports` folder, a different location.
- `D02` was recorded from slide content only, with no filename visible. `MTA_MMM_two_stream_timeline.pptx` is the only library file matching its subject (a two-stream MTA/MMM timeline) and its 31.0 KB size is consistent with a one- or two-slide file, which matches the two slides recorded as `D02-S001`–`D02-S002`. Treated as a **probable** match, not a confirmed one.

#### Observations and tensions arising from L01

- **Cover dates do not match creation dates.** The four decks whose covers all read **Dec 5 2025** (`D06`, `D07`, `D08`, `D09`) were created on four different dates: March 10, March 10, January 9 and `December 1, 20…`. Only D09's creation date is plausibly near its cover date. The shared `Dec 5 2025` cover therefore looks like a **template or event date reused across decks**, not a per-deck authoring date. This is an inference from metadata, not established.
- **Two covers post-date nothing consistently.** `D04` (`DR_Shap_executive.pptx`) prints cover date **April 1st 2026** but was created **May 5** and modified **May 11** — creation after the printed cover date, if the bare dates are 2026. `D05` (`executive_review.pptx`) prints the same **April 1st 2026** cover but was created **March 25** and modified **April 15**, which is consistent. The D04/D05 pair shares a cover date and tagline but not a creation window.
- **`D03` corroborates.** `LumenAI_VP_Deck.pptx` prints cover date **July 22, 2026** and carries `Modified: July 22`. This is the one case where a printed cover date coincides exactly with a metadata date, and it is the *modified* date, not the created date.
- **`D10`'s Feb 17 anomaly gains a new candidate explanation.** `Channel_Attribution_plan.pptx` was **created `November 19, 2…`** and last modified **April 29** by `Wang, Lili` — while a *separate* file, `Channel_Attribution_plan_one_slide.pptx`, was **created February 17**. D10's cover prints **Feb 17, 2025**. The coincidence of the day and month is noted; it does **not** resolve the D10 cover-date anomaly, and the two files are not shown to be related beyond their names. Flagged for checking, not concluded.
- **`D10` is the oldest deck in the library by creation date among processed decks** (`November 19, 2…`), tied with `MTA_proposal.pptx` and the ULOC `.url` shortcut. This is consistent with the D10 tensions section's conclusion that D10 is the earlier plan and the Dec-2025-branded decks reflect a later reassignment of phases.
- **`D08` is by far the smallest processed deck at 968 KB**, against 7.61 MB for its Shapley counterpart `D09`. Both are dated Dec 5 2025 on their covers and both were last modified by `Mehregan, Nazani…`. The size gap is not explained by slide count (20 vs 25).
- **Two 2021-dated filenames exist** (`…Snapshot_2021-11-19_Revised5 1.pptx`, `…ART_2021-07-30.pptx`), both created `November 13, 2…` and both 1–2 MB. Their names embed 2021 dates while their creation dates are much later, which is what one would expect of **archived or re-uploaded legacy material** predating the current effort. Contents unknown.
- **Ownership splits along visible lines.** `Alizadeh, Mehrazi…` last modified the three newest entries (`Results`, `MTA_MMM_two_stream_timeline.pptx`, `LumenAI_VP_Deck.pptx`); `Davoodnia, Vanda…` last modified most of the rest; `Mehregan, Nazani…` the two demo decks; `Wang, Lili` and `Qiu, Jessie` one each. `Modified By` records only the **last** modifier and is not evidence of authorship.
- **Several `Modified` dates cluster on June 20 and March 10**, across files with unrelated creation dates. Consistent with bulk operations (opening, re-saving, migration) rather than editing, which is precisely the caution the user raised.

#### Questions to verify from L01

- What year applies to each bare date? Confirm whether the library is displaying 2026 for year-less values.
- Is `MTA_MMM_two_stream_timeline.pptx` in fact the deck recorded as `D02`?
- What is in `Channel_Attribution_plan_one_slide.pptx`, and does its February 17 creation date relate to D10's `Feb 17, 2025` cover?
- What is `MTA_proposal.pptx` (created `November 19, 2…`, 5.91 MB), and does it predate or supersede the D10 plan?
- What does the ULOC `.url` shortcut point to, and is `Channel Effect Estimation For ULOC Camaigns V8` an earlier internal channel-effect estimation effort by a different group (`Qiu, Jessie`)?
- Do the two 2021 files represent prior channel-attribution work at TD, and does any of it contain experimental or incrementality evidence — the standing open question across this file?
- What is the single item inside the `Results` folder?
- Why does `D04`'s file appear to have been created after the date printed on its own cover?

## Report extracts

### R01 — `attribution-logic-walkthrough.html`

- Visible workspace path: `Documents/Investigate_mta/Measurement team/reports/attribution-logic-walkthrough.html`.
- Evidence source: seven screenshots supplied on 2026-09-09. They show the report from section 1 through section 9, although the screenshots were uploaded in reverse/nonsequential page order.
- Scope statement in report: a visual guide to `prod-04-attribution`, especially original cells 52–53.
- Evidence status: this records what the HTML report presented. It does not independently verify the query, the source notebook, data availability, execution, or results.

#### Title and stated core idea

**How the attribution query works**

> **Core idea:** start with every conversion, generate all plausible interaction candidates, classify and rank those candidates, retain one row per conversion, then enrich that winner for reporting.

#### 1. Inputs and their jobs

| Input | Reported role |
| --- | --- |
| `conversions_final` | `N` conversion rows. Left side of the join. Supplies account, customer, conversion date, account LOB/type, application reference and DAB reference. |
| `chnl_interactions` | `M` interaction rows. Possible touches. Supplies customer, event time/type, channel, interaction LOB, application reference, DAB reference and source flags. |
| `eligibility` | Allowed account ↔ interaction combinations. Used only for customer-ID matching. Direct application and DAB matches do not require it. |
| `lookback_windows` | Days by LOB × channel × event × halo type. Defines temporal validity. Missing matches default to seven days. |
| `interaction_rank` | Event type → priority. Breaks ties after affiliate, nested attribution class and channel priority. |
| `metadata, accounts and SVA` | Winner enrichment. Joined after ranking. They describe or value the selected result; they do not normally create the winner. |

#### 2. End-to-end shape

```text
Conversions (N rows) ─┐
                     ├─> Candidate join ─> Classify candidates ─> Rank within conversion ─> Enrich winner
Interactions (M rows)┘      App ref OR          time window;          attr_rank = 1            SVA, account,
                            DAB ref OR          same / Brand / halo;  ≈ one row per conversion campaign, path
                            customer +          online / WBANA /
                            eligibility          channel
                            K rows; K can be huge
```

#### 3. Candidate generation

Formula as displayed:

```text
Candidate(v, i) = AppRefMatch(v,i) OR DabRefMatch(v,i) OR [CustomerMatch(v,i) AND Eligible(v,i)]
```

| Route | Condition | Important consequence |
| --- | --- | --- |
| Application | Conversion application reference = interaction application reference | Can match even when `cust_id` is missing. |
| DAB | Conversion DAB reference = interaction DAB confirmation | Can match even when `cust_id` is missing. |
| Customer | Customer IDs match and concatenated LOB/conversion combination is eligible | Uses the eligibility map; normally creates the largest candidate population. |

The report states: “The SQL is a left join from conversions, so a conversion with no interaction still survives as an unattributed row.”

#### 4. Time window and candidate labels

Formula as displayed (line breaks normalized only):

```text
lower = conversion_date − configured_lookback_days or conversion_date − 7 when no rule matches
upper = conversion_date or conversion_date + lookback_days for RESL leads
[PARTIALLY READABLE: a visible `claim_sale` token follows “RESL leads”; its punctuation/operator relative to `in_window` is unclear.]
in_window = online_match OR lower ≤ event_time ≤ upper
```

- **Online attribution:** In this query, “online” means application-reference or DAB-reference equality. It does not simply mean that the channel is digital.
- **Halo rank:** 1 = same account and interaction LOB; 2 = interaction LOB is BRAND; 3 = all other eligible cross-LOB matches.

#### 5. Nested attribution priority

| Nested rank | Candidate class |
| ---: | --- |
| 1 | Non-WBANA, online, same LOB |
| 2 | Non-WBANA, in-window, same LOB |
| 3 | Non-WBANA, online, Brand |
| 4 | Non-WBANA, in-window, Brand |
| 5 | WBANA, online, same LOB |
| 6 | WBANA, in-window, same LOB |
| 7 | Non-WBANA, online, halo |
| 8 | Non-WBANA, in-window, halo |
| 9 | WBANA, online, halo |
| 10 | WBANA, in-window, halo |
| 11 | Everything else, including out-of-window candidates |

`WBANA` refers to the Webana web-analytics table, per user clarification.

#### 6. Final winner ordering

The report says the query assigns `ROW_NUMBER()` inside each conversion and that the lexicographically smallest tuple wins:

```text
winner = min( -is_affiliate, nested_rank, channel_rank, interaction_type_rank, -event_timestamp )
```

| Ordering position | Reported rule |
| --- | --- |
| First | Affiliate flag descending. This overrides every later criterion. |
| Second | Nested attribution rank: online/same-LOB/Brand/halo/WBANA hierarchy. |
| Third | Channel rank, with separate RESL, online and offline rules. |
| Fourth | Interaction event-type rank. |
| Last | Most recent interaction timestamp. |

#### 7. Worked example

**Conversion 42:** CC new account on 2026-06-15, customer C100, application A777.

| Candidate | Why joined | Classification | Nested rank | Result |
| --- | --- | --- | ---: | --- |
| Email OPEN, CC, 2026-06-10 | Customer + eligibility | In-window, same LOB | 2 | Runner-up |
| Paid Search CLICK, CC, 2026-06-01, app A777 | Application reference | Online, same LOB | 1 | Winner |
| Email OPEN, BRAND, 2026-06-12 | Customer + eligibility | In-window, Brand | 4 | Loses |
| Web CLICK, DI, 2026-06-14 | Customer + eligibility | In-window, halo | 8 | Loses despite recency |

> **Lesson:** recency is only the final tie-breaker. A newer interaction can lose to an older interaction with a better nested or channel rank.

#### 8. Paths, assists and enrichment

- **Path:** distinct channels from in-window candidates with `halo_rank = 1`. Brand and halo candidates are excluded.
- **Assist:** a path channel other than the winning channel.
- **SVA:** joined using product detail, conversion type, effective dates and cash account type.
- **Metadata:** campaign, trigger, paid-digital, Salesforce and account details are attached after ranking.
- **Final filter:** only `attr_rank = 1` is returned. Unattributed conversions remain, but their channel fields are mostly null.

#### 9. Questions worth checking in the EDA

| Topic | Reported question |
| --- | --- |
| Candidate explosion | How many interactions are created per conversion, especially through customer matching? |
| Default lookback | How often is seven days used because no explicit rule matches? |
| Exact ties | Can two candidates tie on every ordering field, making the selected row unstable? |
| Join multiplication | Are lookback, SVA or metadata keys nonunique and therefore able to duplicate results? |

#### Interpretation and task classification

The report’s explicit interpretation is: “this is a deterministic business-rule attribution model. It selects the preferred recorded touch; it does not prove that the interaction caused the conversion.”

| Task type | Classification supported by the report |
| --- | --- |
| Response prediction | Not supported. |
| Causal/uplift estimation | Explicitly not supported as a causal claim. |
| Retrospective attribution | Supported: selects a preferred recorded touch for a completed conversion. |
| Prospective channel recommendation | Not supported. |

The report footer states: “Generated as a read-only companion. No tables are read or written by this HTML file.”

## Deck registry

| Deck ID | Source / visible title | Evidence processed | Notes |
|---|---|---:|---|
| `D01` | *journey-observability-research-report.html* — “Journey observability is the binding constraint—not attribution mathematics” | `D01-S001`–`D01-S014` | Browser-rendered research handoff / “production attribution forensic audit,” rather than a conventional slide deck. IDs follow screenshot upload order. Several screenshots are scroll-position continuations or overlaps. |
| `D02` | “Channel Attribution & Prediction — Committed Timeline” | `D02-S001`–`D02-S002` | User described it as possibly “Timeline of Two Streams”; the visible slide title is used as the evidence name. |
| `D03` | *LumenAI_VP_Deck.pptx* — “LUMEN AI” | `D03-S001`–`D03-S010` | Filename is visible in the PowerPoint web editor. The visible cover is dated July 22, 2026. Several screenshots show speaker notes and alternative/iterative views of the same slide rather than distinct original slides. |
| `D04` | *DR_Shap_executive.pptx* — “MTA LUMEN AI”, April 1st 2026, 61 slides | `D04-S001`–`D04-S034` | Visible slides 1–18 and 30, with repeated views and close-ups. IDs follow upload order, not slide order. |
| `D05` | *executive_review.pptx* — “PRISM LUMEN AI”, April 1st 2026, 35 slides | `D05-S001`–`D05-S004` | Same tagline and date as D04 but a different title, filename and slide count. Visible slides 1–4 only; slides 5–35 sit under an `Appendix` section. |
| `D06` | *mta_biases.pptx* — “Multi-Touch Attribution Project – Introduction to Bias”, Dec 5 2025, 26 slides | `D06-S001`–`D06-S012` | Earliest-dated deck in this file. A bias/methods briefing: selection-bias examples, campaign selection mechanism, adversarial and causal-inference options, and one progress slide on simulated data. Visible slides 1–12; IDs follow upload order. |
| `D07` | *literature_review.pptx* — “Multi-Touch Attribution Project – Literature Review”, Dec 5 2025, 24 slides | `D07-S001`–`D07-S027` | Companion in date and branding to D06. Literature review of MTA/MMM methods plus the team's evaluation plan. Visible slides 1–6, 11, 13–24, five slides with illegible numbers, and one `Strategy Overview` slide with a conflicting number. IDs follow upload order. |
| `D08` | *Channel_Attribution_Doubly_Robust_demo.pptx* — “MTA – Doubly Robust Estimate”, Dec 5 2025, 20 slides | `D08-S001`–`D08-S021` | Third Dec 5 2025 deck. Contains the actual DR run: five channels, out-of-fold calibrated nuisance models with ROC-AUC, per-channel ATE, Shapley comparison and per-channel propensity-overlap diagnostics. Visible slides 1–12 plus nine with illegible numbers. |
| `D09` | *Channel_Attribution_Shapley_value_demo.pptx* — “Multi-Touch Attribution Project Demo – Phase 1”, Dec 5 2025, 25 slides | `D09-S001`–`D09-S033` | Fourth Dec 5 2025 deck and the Shapley counterpart to D08. Eight channels, full data lineage (schema, legacy score IDs, population/splits, hyperparameters, time windows), coalition-coverage diagnostic. Defines the two-letter channel codes and feature IDs left open in D08, and names isotonic regression as the calibration method. Visible slides 1–11, 13, 14, 16, 18–25 plus three with illegible numbers. |
| `D10` | *Channel_Attribution_plan.pptx* — “Multi-Touch Attribution Project Plan”, cover dated Feb 17 2025, 14 slides | `D10-S001`–`D10-S014` (first batch) | The phased project plan (Shapley → DR → Transformer). Cover date conflicts with an internal roadmap running Nov 2025–Sep 2026. Contains a twelve-channel raw conversion/lift summary and a response-model vs DR SHAP comparison. Resolves the D07-S025 stray-slide flag. |

**Source-file provenance.** Nine of these ten decks match files in the SharePoint `presentations` library recorded at `L01`, which supplies each file's created/modified dates, size and last modifier. See the mapping table in that section. `D01` is not in the library (it is a VDI report). `D02` has no visible filename and is only *probably* `MTA_MMM_two_stream_timeline.pptx`. Library dates repeatedly disagree with printed cover dates; the `Modified` column is unreliable as a timing signal because opening a file updates it.

## Slide-by-slide extracts

### D01 — Journey observability research report

#### D01-S001 — Executive-summary header and headline metrics

- Eyebrow: “RESEARCH HANDOFF · PRODUCTION ATTRIBUTION FORENSIC AUDIT”.
- Title: “Journey observability is the binding constraint—not attribution mathematics”.
- Standfirst: “The production path is a deliberately narrow, policy-filtered projection of recorded activity. It is useful as a deterministic attribution output, but it is not a complete customer journey and should not be treated as one when building fractional attribution.”
- Visible tags: “Read-only analysis”; “Full-population Spark audit”; “2024-11-01 to 2026-06-30 cohort”; “Graph expansion deferred”.
- Headline metric cards:
  - `10.54M` conversion entities examined.
  - `82.37%` technically matched with all prepared history.
  - `71.59%` with at least one pre-conversion event.
  - `56.51%` with an event in the previous 90 days.
- The beginning of “Executive findings” is visible but continues in `D01-S002`.
- Classification: **Retrospective attribution** (audit of a production attribution path). The slide explicitly rejects interpreting technical linkage as causal effect.

#### D01-S002 — Executive findings

1. “The recorded path is not the recorded journey.” It is the end of a narrowing sequence: “real-world behavior → recorded events → technically linkable events → policy-eligible/in-window events → reported path → one winner.”
2. “Identity is channel-dependent.” Prepared Display has `177.1M` rows, but only `9.21%` carry a usable customer/application/DAB key; only `4.71%` of distinct Display events link to any conversion in the cohort.
3. “Customer ID is the practical backbone.” At full population, `8.23M` conversions matched through customer ID, versus `688k` through application reference and `33.5k` through DAB. Direct application/DAB-linked events agreed with customer identity about `79%–96%` by channel—“strong but not perfect.”
4. “The old September 2024 history cutoff distorted long journeys but barely affected 90-day journeys.” Restoring older prepared history added `286,928` technical matches and `637,552` pre-conversion journeys, but only `5,357` conversions inside 90 days.
5. “Raw excluded rows contain substantial journey evidence, but mostly from intentionally excluded Mobile, Branch, Web, Phone and Email categories.” Their recovery is “operationally large and causally ambiguous.” Display recovery from excluded rows is “tiny inside 90 days.”
6. “Display is under-observed, not proven ineffective.” For RESL, `18.33%` had any technically linked Display event, `14.47%` a pre-conversion Display event, `8.32%` one within 90 days, `5.36%` same-LOB Display within 90 days, `2.38%` appeared in the reported path, and `1.40%` won.
- Interpretation boundary: “none of these links estimate causal lift. A technically linked event means ‘recorded under a usable identity,’ not ‘caused the conversion.’”
- Privacy note: no actual customer, account, application, credit-reference, DAB-reference, interaction, row, or conversion identifier values; only aggregate results and schema-level identifier descriptions.
- Classification: **Retrospective attribution**; causal/uplift estimation is explicitly **not** claimed.

#### D01-S003 — “What the production pipeline actually does”

- Step 1, “Prepare interactions”: Start from channel interactions; append/supplement sources such as Salesforce and WBANA; map metadata; normalize channels/events; apply supported LOB, conversion-type, event and Affiliate rules.
- Step 2, “Prepare conversions”: Start from conversion facts; enrich product and customer attributes; reconstruct RESL application/funding identity; preserve the relevant business anchor; materialize conversion records.
- Step 3, “Match, classify, rank”: Generate candidates through application reference, DAB reference, or customer ID plus eligibility; classify lookback/LOB/brand/halo state; rank candidates and select one winner.
- Candidate routes:
  - Application-reference equality between conversion and interaction.
  - DAB-reference equality between conversion and interaction.
  - Customer-ID equality, constrained by the interaction-to-conversion LOB eligibility matrix.
- Winner ordering formula: `Affiliate priority → nested business rank → channel rank → event rank → recency`.
- Claim: “The SQL is therefore not plain last-touch. It is a deterministic business-policy classifier with recency as the final tie-breaker after several higher-priority rules.”
- A “Path definition” callout begins below the visible area: `[PARTIALLY READABLE: text is cut off]`.
- Classification: **Retrospective attribution**. No response-prediction, uplift, or prospective-recommendation model is described.

#### D01-S004 — Candidate volume and beginning of RESL × Display case study

- “Candidate volume and route evidence”:
  - Median candidate events per conversion: `15`; `p90: 74`; `p99: 187`; maximum: `5,127`.
  - Conversions matched through customer ID: `8,225,338`.
  - Conversions matched through application reference: `688,328`.
  - Conversions matched through DAB: `33,514`.
  - Exact duplicate burden is material for Social CT (`4.59%`), Paid Search (`4.10%`) and Display (`2.49%`).
- Next section title: “RESL × Display: absence in the path is mostly a narrowing story”.
- Selection caveat: RESL × Display was proposed as an illustrative example before data examination; “It was not selected as a statistically representative LOB-channel pair.” The case study demonstrates the observability funnel, but its rates should not be generalized without all-LOB/all-channel results.
- Visible metric cards: `18.33%` any technical Display; `14.47%` pre-conversion Display; `8.32%` Display within 90 days; `2.38%` Display in reported path.
- The stage table is only partially visible; its full visible version is captured in `D01-S007`.
- Classification: **Retrospective attribution**. The selection caveat limits generalization.

#### D01-S005 — Full-population results and channel observability table

- Continuation of the “Full-population matching results” table:

| Stage | Conversions | Rate | Meaning |
|---|---:|---:|---|
| Technically matched, old cutoff | 8,392,487 | 79.65% | At least one prepared event on/after `2024-09-01`. |
| Technically matched, all history | 8,679,415 | 82.37% | At least one prepared event across available history. |
| Pre-conversion event, all history | 7,542,921 | 71.59% | At least one matched event before the business anchor. |
| Event within 90 days, all history | 5,954,297 | 56.51% | At least one matched event in the principal recent-journey horizon. |
| Production attributed rows | 3,459,646 | 34.18%* | Winner populated in the production output; denominator is `10,123,225` production conversion IDs. |

  `*` The displayed percentage is marked with an asterisk, but no associated footnote is visible in this screenshot.

- “Identity and event observability by channel”:

| Channel | Prepared rows | Rows with usable key | Key-bearing rate | Distinct events matching a conversion | Event match rate |
|---|---:|---:|---:|---:|---:|
| Display | 177,114,147 | 16,317,515 | 9.21% | 8,137,823 | 4.71% |
| Social CT | 3,970,902 | 928,304 | 23.38% | 404,787 | 10.68% |
| Paid Search | 67,341,805 | 31,275,493 | 46.44% | 18,647,700 | 28.87% |
| SEO | 34,223,547 | 28,907,551 | 84.47% | 18,461,827 | 54.52% |
| Email | 158,889,040 | 158,776,226 | 99.93% | 77,099,019 | 48.52% |
| Mobile | 32,035,740 | 32,035,740 | 100.00% | 18,096,192 | 56.56% |
| Web | 6,272,671 | 6,269,867 | 99.96% | 3,707,155 | 59.15% |
| Phone | 378,656 | 378,656 | 100.00% | 295,731 | 78.16% |

- Placeholder lesson: non-null is not usable. Values such as `XYZ`, `NO_DAB`, `ABC` and `NO_DAB_CONV` dominate several reference columns and must be normalized to missing before identity analysis.
- Classification: **Retrospective attribution / observability audit**; not causal inference.

#### D01-S006 — “The journey-completeness hierarchy”

- Hierarchy, from broadest to narrowest:
  1. “Real-world journey · unknowable upper bound”
  2. “Recorded interactions”
  3. “Technically linkable interactions”
  4. “Pre-conversion / in-window interactions”
  5. “Same-LOB reported path”
  6. “Single attributed winner”
- Set relation: `Reported path ⊂ in-window matched interactions ⊂ technically linkable interactions ⊂ recorded interactions ⊆ real-world journey`.
- “Full-population matching results” table is visible in part. Header: Stage | Conversions | Rate of `10,536,464` | Meaning. Visible rows repeat the figures in `D01-S005` for old-cutoff technical match, all-history technical match, and all-history pre-conversion event. Remaining rows extend below the screenshot.
- Classification: **Retrospective attribution**. The diagram represents data/path completeness, not causal contribution.

#### D01-S007 — RESL × Display funnel table and conclusion

- Same title and selection caveat as `D01-S004`.
- Funnel table:

| RESL Display stage | Rate | Drop from previous stage |
|---|---:|---:|
| Technically linked at any time | 18.33% | — |
| Before business conversion anchor | 14.47% | −3.86 pp |
| Within 90 days | 8.32% | −6.15 pp |
| Within 90 days and same LOB | 5.36% | −2.96 pp |
| Included in reported path | 2.38% | −2.98 pp |
| Selected winner | 1.40% | −0.98 pp |

- Claim: Technical Display reach varies by RESL subtype, “roughly `12.7%–26.5%` in the cutoff audit.” A large share of apparent loss is due to missing identity, temporal position, cross-LOB classification, or path policy, “not a measured lack of incremental impact.”
- Strongest conclusion: data can support “Display is often unobservable or filtered from the reported path.” It cannot support “Display is ineffective.”
- Classification: **Retrospective attribution / observability audit**; explicitly not causal/uplift estimation.

#### D01-S008 — History-window sensitivity (overview)

- “The independent sensitivity notebook held conversions fixed and compared prepared interactions available from `2024-09-01` onward with all available prepared history before `2026-07-01`.”
- Headline cards:
  - `501.41M` prepared rows before the old cutoff.
  - `+637,552` conversions gaining a pre-conversion journey.
  - `+5,357` conversions gaining a `≤90-day` journey.
- Table:

| Metric | From 2024-09-01 | All history | Increment | Percentage-point gain |
|---|---:|---:|---:|---:|
| Technical match | 8,392,487 | 8,679,415 | 286,928 | +2.72 pp |
| Any pre-conversion event | 6,905,369 | 7,542,921 | 637,552 | +6.05 pp |
| Event within 90 days | 5,948,940 | 5,954,297 | 5,357 | +0.05 pp |

- “What changed—and what did not” continues in `D01-S009`.
- Classification: **Retrospective attribution / data-sensitivity analysis**; no causal claim stated.

#### D01-S009 — History-window sensitivity (findings and decision)

- Repeats the `D01-S008` headline metrics and table.
- Findings:
  - Older recovery overwhelmingly arrived through **customer ID**; application reference added only small increments.
  - Most channels have material history from `2020`. Display becomes materially available around **March 2023**; LLM Chat begins in late `2024`.
  - For RESL × Display, all-history technical reach rose by about `3.1–6.2 pp` depending on subtype, but 90-day rates were effectively unchanged.
  - The only visible monthly RESL × Display 90-day gain was approximately `+0.27 pp` in **November 2024**; subsequent months were zero.
  - When both scenarios were restricted to fully observable horizons, 90-day estimates were essentially identical; differences primarily emerge at 180 and 365 days.
- Decision: use all available history for lineage and long-horizon research, but a September 2024 cutoff does not explain missing recent 90-day Display journeys after the first conversion month.
- Next section heading “Raw-exclusion recovery” is visible only.
- Classification: **Retrospective attribution / data-sensitivity analysis**; no causal effect claimed.

#### D01-S010 — Raw-exclusion recovery

- Question stated: if raw rows rejected by production base filters are retained as journey evidence, what technical observability returns? The analysis “did not propose that those rows should receive attribution credit.”
- Headline cards:
  - `3.873B` raw interaction rows.
  - `2.907B` rows excluded by base filters.
  - `97.0%` excluded rows carrying a usable key.
  - `+14.47 pp` global `≤90-day` technical coverage gain.
- Table:

| Metric | Prepared only | Prepared + excluded raw | Gain |
|---|---:|---:|---:|
| Conversions with any pre-event | 7,542,921 (71.59%) | 8,145,329 (77.31%) | 602,408 / +5.72 pp |
| Conversions with event ≤90 days | 5,954,297 (56.51%) | 7,478,697 (70.98%) | 1,524,400 / +14.47 pp |
| Conversions gaining at least one channel | — | 6,811,597 | 64.65% of conversions* |
| Conversions getting a closer event | — | 5,537,146 | 52.55% of conversions* |

  Footnote: “*A conversion can gain multiple channels/reasons. These are technical recovery measures, not unique causal effects by filter.”

- “Where the recovery comes from” table (only the first three visible rows):

| First exclusion reason | Channel | Segment-summed channel gains | Segment-summed gains within 90d |
|---|---|---:|---:|
| Unsupported conversion type | Mobile | 2,593,111 | 1,686,654 |
| Excluded event type | Mobile | 2,224,199 | 1,176,555 |
| Excluded event type | Branch | 2,558,121 | 512,570 |

- Further rows below the screenshot are `[UNREADABLE / NOT VISIBLE]`.
- Classification: **Retrospective attribution / technical observability recovery**. The slide explicitly says recovered rows are not proposed for attribution credit and do not identify causal effects.

#### D01-S011 — Raw-exclusion recovery: sources and Display exception

- Continuation, “Where the recovery comes from”:

| First exclusion reason | Channel | Segment-summed channel gains | Segment-summed gains within 90d |
|---|---|---:|---:|
| Unsupported conversion type | Mobile | 2,593,111 | 1,686,654 |
| Excluded event type | Mobile | 2,224,199 | 1,176,555 |
| Excluded event type | Branch | 2,558,121 | 512,570 |
| Unsupported LOB | Email | 863,110 | 383,446 |
| Unsupported LOB | Branch | 2,411,449 | 362,440 |
| Unsupported conversion type | Branch | 2,448,735 | 300,532 |
| Excluded event type | Web | 1,222,799 | 264,402 |
| Unsupported LOB | Display | 55,051 | 3,375 |

- “Display behaves very differently”: For RESL × Display, excluded raw rows add only about `0.39%–0.80%` of conversions as newly technically reachable by subtype. Within 90 days, gain is only `0.00–0.05 percentage points`; 365-day gain is roughly `0.09–0.23 pp`. All RESL × Display recovery in this audit came from rows classified as **unsupported LOB**.
- Warning: “Do not restore all excluded rows into attribution.” The large global recovery is concentrated in event types and product/LOB combinations that production intentionally rejects. Keep them in a separate observability layer, preserve exclusion reason, and validate semantic meaning before any modeling use.
- Classification: **Retrospective attribution / technical observability recovery**. The slide recommends data-layer separation, not retrospective credit assignment.

#### D01-S012 — “Implications for fractional attribution” and safeguards (part 1)

- Premise: A fractional model trained directly on production paths “would learn the production filter and identity architecture at least as strongly as it learns customer behavior.”
- Recommended two-layer architecture:
  - **Observability layer:** All deduplicated, as-of technically linkable events; raw exclusion reason, source, key route, key quality, channel availability, event semantics, LOB relation and temporal position retained.
  - **Attribution-eligible layer:** A governed subset of events allowed to receive credit after business eligibility, event semantics, horizon and leakage checks. “Policy changes become explicit rather than silently changing the journey.”
- Minimum safeguards visibly listed:
  1. **Use a fixed recent horizon.** 90 days is empirically robust to the old history cutoff; separately report 180/365-day sensitivity.
  2. **Use as-of identity only.** Do not allow keys learned after the conversion anchor to connect prior events without an explicit future-assisted diagnostic flag.
  3. **Preserve route confidence.** Customer, application and DAB matches should not be treated as identical; direct-key/customer disagreement must be measurable.
  4. **Deduplicate events before path construction.** Retain a stable event fingerprint and source-specific duplicate diagnostics.
  5. **Represent missingness.** Channel identity coverage, source start date and key-bearing rate must enter either sample eligibility, weighting, calibration or uncertainty reporting.
  6. **Do not force 100% credit onto observed channels.** Retain an unattributed/residual component so incomplete paths do not manufacture certainty.
  7. **Separate cross-LOB evidence from same-LOB credit.** Cross-LOB interactions may describe the customer but should not automatically inherit conversion credit.
  8. **Use negative controls and future-event checks.** High future-event rates show how easily customer affinity can be mistaken for pre-conversion influence.
- Safeguards 9 onward are outside this screenshot; `D01-S013` shows only the visible end of safeguard 10.
- Classification: **Ambiguous or mixed.** This is a prospective design recommendation for fractional attribution, but does not demonstrate a trained or validated model, channel recommendation policy, response prediction, or causal estimator.

#### D01-S013 — Fractional-attribution readiness and scope limitations

- Visible continuation of safeguard 10: “**Require causal validation.** Fractional credit is descriptive until checked against experiments, quasi-experiments or defensible incrementality designs.” Safeguard 9 is `[UNREADABLE / NOT VISIBLE]` in the supplied screenshots.
- “Readiness assessment”:

| Use case | Status | Reason |
|---|---|---|
| Reproduce deterministic production winner | Ready | Rules, candidates and ranking are understood. |
| Descriptive multi-touch journey summaries | Conditional | Feasible with 90-day horizon, deduplication and explicit observability flags. |
| Fractional allocation over production paths | High bias risk | Would inherit missing identity and policy-filter selection. |
| Causal channel effectiveness | Not established | Technical linkage and ranking do not identify incrementality. |

- “Scope, limitations and next questions”:
  - Primary audit snapshot contained `484.98M` prepared interaction rows and included `2026-07-01`; two independent supplements rebuilt `986.02M` prepared all-history rows and stop at `2026-06-30`. The one-day cohort difference is called negligible, but absolute counts should not be naively merged.
  - Conversion entity counts differ slightly across notebooks (`10,538,441` versus `10,536,464`) because of cutoff and independent entity construction.
  - Raw-exclusion “first reason” is a diagnostic classification. A conversion can be affected by multiple events, channels and reasons; reason totals are not mutually exclusive conversion effects.
  - A customer-ID match can join behavior from a broad customer history. It is technically valid linkage, but not proof that the event belongs to the decision process for the focal conversion.
  - RESL business anchor uses funded date where available, otherwise application date. Median funded-minus-application difference is zero; upper quartile is 31 days; maximum observed difference is 617 days.
  - Graph-based identity expansion was deliberately deferred after proving computationally expensive. If revisited, it must be typed, bounded, as-of, ambiguity-scored, and separately report future-assisted recovery.
- “Highest-value next research” begins below the screenshot and continues in `D01-S014`.
- Classification: **Retrospective attribution / readiness assessment**, with explicit statement that causal channel effectiveness is not established.

#### D01-S014 — Next research and evidence base

- “Highest-value next research”:
  1. Define a governed event taxonomy for “journey evidence” versus “credit eligible,” particularly for excluded Mobile, Branch, Web, Phone and Email categories.
  2. Build an as-of event-level modeling table with key-route confidence, source availability and deduplication.
  3. Quantify path-length and channel-mix changes under 30/90/180-day windows using only fully observable cohorts.
  4. Assess whether unattributed residual varies systematically by channel exposure, LOB and conversion type.
  5. Validate any fractional output against experiments or external incrementality evidence before business interpretation.
- “Evidence base” notebooks:
  - **Production logic:** `Original/prod-04-attribution.ipynb`
  - **Forensic EDA:** `Original/prod-04-attribution-eda.ipynb`
  - **Journey audit:** `prod-04-journey-observability-audit-no-plots.ipynb`
  - **History sensitivity:** `prod-04-history-window-sensitivity_w_data.ipynb`
  - **Raw exclusion recovery:** `prod-04-raw-exclusion-journey-recovery_w_data.ipynb`
- Note: “All analyses were read-only. No production source tables were modified.”
- Footer: “Journey observability & attribution research handoff · generated from persisted Databricks notebook outputs”.
- Classification: **Ambiguous or mixed.** This presents research/design priorities, including prospective work on fractional attribution, but does not evidence a deployed model or a prospective channel-recommendation system.

### D02 — Channel Attribution & Prediction committed timeline

#### D02-S001 — “Channel Attribution & Prediction — Committed Timeline”

- Top status strip, “DONE TO DATE”: “XGBoost + DR model built (uplift + attribution code)”; “Measurement-team AZ access secured”; “GPU + experiment infra in place”; and “Transformer research done — build underway”.
- Timeline axis labels: Sep ’26, Nov, Jan ’27, Mar, May, Jul, Sep, Nov.
- **Channel prediction:** `[PARTIALLY READABLE: “Next best journey - usage: CLIP campaign” and “Built on our existing GPU” are visible.]` “Delivered Aug ’26”: `V1 — XGB + DR uplift`; “baseline, codebase reused for attribution V1”. “MDR / Model Validation: Dec-Feb”. “Nov 30, 2026 (target Oct 31)”: `V2 — Transformer next-best-journey`. “Mar 2027”: “Production”; “campaign use is from Apr 2027”.
- **Channel attribution:** `[PARTIALLY READABLE: “MTA / MMM - usage: content from”; “V1 V2 can be developed in MKT AZ”; final line unclear.]` “Sep 30, 2026”: `V1 — Fractional attribution`; `XGB + DR code exists (~2 wk)`. `V2 — MMM-informed attribution`; visible subordinate text: “starts Nov, integrate MDR ROI extracts + incr. results”. Milestones: `SIMPLE` “Calibration Jan 29, 2027”; `BAYESIAN` “Priors Mar 31, 2027”. `TBD V3 — Transformer attribution`; “reuses the predictive data pipeline + infra”. `TBD Deployment`; “Model Validation - TBD” is displayed above the latter part of the stream.
- Footnote: “Internal. Dates are based on 2 FTEs across both streams — the prediction transformer holds priority through Oct 2026, then attribution takes the freed capacity while predictive is with compliance review.”
- Classification: **Ambiguous or mixed.** The slide presents a committed-plan timeline for prediction and attribution, but does not show model specifications, outcomes, implementation proof, or causal validation.

#### D02-S002 — “Basis of Estimates — Where Built, Who Uses It, What’s Reused”

| Milestone | Built where | Committed date | Who uses it · notes & reuse |
|---|---|---|---|
| `V1 — XGB + DR uplift (done)` | AI2 AZ | Delivered Aug 2026 | Team-internal baseline (XGB + DR, uplift training). Codebase is reused for attribution and prediction. |
| `V2 — transformer next-best-journey` | AI2 AZ & CC (GPU) | Nov 30, 2026 (target Oct 31) | CLIP campaign, after approval. It holds team priority through Oct. |
| Deployment (prediction) | Model Validation → prod (DaaS) | Mar 2027 · campaign use Apr | MDR opens once the model is finalized. |
| `V1 — Fractional Attribution` | MKT - AZ | Sep 30, 2026 | Reusing Measurement team’s data pipeline; built directly on MKT - AZ. |
| `V2 — MMM-informed attribution` | MKT - AZ | Simple: Jan 29, 2027; Bayesian: Mar 31, 2027 | Starts Nov. Needs MMM ROI extracts + incrementality test results. Calibration logic later reusable as priors/regularizer for the transformer. |
| `V3 — transformer attribution` | AI2 AZ & CC (GPU) | TBD | Reuses the predictive model’s data pipeline + GPU infra. Add ~8 wk if the MMM must be built in-house first. |
| Deployment (MTA) | Model Validation → prod (DaaS) | TBD | Measurement team + downstream reporting. Lands later because prediction is prioritized and V3 must pass validation (new architecture = new approval path). |

- Sequencing rationale: “V1-V2 are built on MKT AZ to reuse the data pipeline. The prediction transformer holds priority through October; attribution work interleaves (V1) and then absorbs the freed capacity while the MDR runs.”
- Footer: “Internal”.
- Classification: **Ambiguous or mixed.** This resourcing/estimate table supports only that milestones and dependencies were presented, not that they were implemented, approved, deployed, or validated.

### D03 — Lumen AI VP Deck (first batch)

#### D03-S001 — Cover

- Visible file name: `LumenAI_VP_Deck.pptx`.
- Cover text: “LUMEN AI”; tagline “Make it clear. Make it human.”
- Branding: “AI2 Analytics, Insights & Artificial Intelligence”.
- Date: “July 22nd, 2026”.
- PowerPoint editor status displays “Slide 1 of 22”.
- No method, result, or metric is presented on the cover.

#### D03-S002 — Speaker notes for cover

- Visible note: “Hi everyone, Today we are going to present Prism Lumen AI, a brand-new tool that helps with marketing channel attribution and decisioning.”
- This is presenter-note text, not a validation or implementation result.

#### D03-S003 — “Lumen AI: From Attribution to Channel Decisioning” (Overview)

- Slide subtitle: “Overview”; footer: “Slide 1 of 6”; “Internal”.
- **Current state (BAU):** “Have PRISM, providing what product to offer”; “Channel assignment is rule-based”.
- **Lumen AI — Two connected lenses:**
  - `LEARN` — “Diagnostic Attribution”; “Understand historical touchpoints and channel contribution”.
  - `GUIDE` — “Decision Optimization”; “Recommend controllable channels under constraints”.
- **Future state:** “Have LUMEN, providing which channel to reach the customer”; “Personalized channel recommendations, while respecting business constraints”.
- Four numbered inputs/quantities:
  1. “Data – Journey (observed data) & Propensity (provided by PRISM)”.
  2. “Gross Response – determined based on Data”.
  3. “Channel likelihood – determined based Data”.
  4. “Channel Lift – determined by 2 & 3”.
- Bottom message: “PRISM helps decide what to offer. Lumen AI helps decide how to reach the customer.”
- Classification: **Ambiguous or mixed.** It describes both historical attribution and future channel recommendation; the formula/definitions of gross response, channel likelihood, and channel lift are not shown.

#### D03-S004 — Speaker notes for overview

- Visible note: “We wanted to share our progress related to channel attribution project the team has been working on. We are hoping that by the end of today’s call, you have a clear understanding of what our current customer engagement strategy is and how the new solution helps improve and enhance our targeting, and marketing outreach.”
- Next note begins: “[slide]-on the slide from left, what we currently have is PRISM…”. Remaining text is not visible.
- Interpretation boundary: this explains intended presentation framing; it does not demonstrate results.

#### D03-S005 — “Diagnostic Lens: Understanding Historical Channel Impact”

- Subtitle: “Learning from the full customer journey”; footer: “Slide 2 of 6”; “Internal”.
- **Why this matters:**
  - “Raw channel performance can be misleading”.
  - “Customers are not randomly assigned to channels”.
  - “High-propensity customers often receive more expensive treatment”.
  - “Diagnostic modeling separates customer selection from channel contribution”.
- **Historical learning flow:**
  1. Observed touchpoints — “Email, Direct Mail, Leads, Paid Search, SEO, Display, Web, Mobile, Branch”.
  2. Customer context — “PRISM scores, existing product, journey history”.
  3. Adjusted attribution — “More credible channel impact view”.
- Important distinction: “Diagnostic modeling can use the full observed journey — including Paid Search, SEO, Display and Web — even when those channels are not customer-level actions we directly assign.”
- Bottom message: “Diagnostic modeling explains what we learned from historical journeys before we decide where TD can act.”
- The slide contains a color treemap labelled “Diagnostic Signal Results”; exact values are not legible in this screenshot and are captured/flagged in later views.
- Classification: **Retrospective attribution / causal-uplift intent ambiguous.** The slide describes adjustment for non-random assignment, but does not state an estimator, identification assumptions, comparison design, or validation.

#### D03-S006 — Speaker notes for diagnostic lens

- Owner: “Nazanin”.
- Suggested talk track says the first Lumen AI lens is diagnostic and seeks historical attribution of each channel; “we cannot simply compare raw conversion rates across channels and conclude that one channel is better than another.”
- It states customers are not randomly assigned and that higher-propensity customers are more likely to receive expensive or targeted treatments, “such as Leads”; a channel can appear strong partly because it was assigned to stronger customers.
- Three stated input classes: (1) observed touchpoints across the customer journey, including outbound/inbound channels such as email, Leads, paid search, mobile and other historical interactions; (2) customer context such as PRISM scores / baseline propensity; and (3) the outcome signal, “new credit card acquisition.”
- Stated question: “After accounting for customer context and selection effects, which channels appear to contribute more to conversion?”
- Notes say the full observed journey may include outbound email/Leads and inbound paid search, SEO, display and web behavior; these are valuable historical signals even if not channels TD can directly assign in a future campaign.
- Transition: “Once we have that historical learning, the next question is how to turn it into a practical recommendation. Vandad will walk through that decisioning lens.”
- Core message: diagnostic modeling helps explain historical outcomes because raw performance is misleading under non-random channel assignment.
- Classification: **Causal/uplift estimation intent, not established.** The talk track uses selection-effects/debiasing language, but gives no estimator, assumptions, experimental comparison, or result validation.

#### D03-S007 — Diagnostic results draft / iteration view

- Title/subtitle: “Diagnostic Lens: Understanding Historical Channel Impact” / “Learning from the full customer journey”.
- Main heading: “Diagnostic Signal Results”; separate panels labelled “Channel Level” and “Channel x Interaction Level”; color legend “positive impact” to “negative impact”.
- A small label above the interaction panel reads “Adjusted by iteration”.
- Most value labels are too blurred for faithful transcription: `[UNREADABLE: exact channel/interaction labels and ATE values]`.
- This appears to be an alternate/draft view of the results slide rather than a different analytical method.

#### D03-S008 — Diagnostic Signal Results, result view A

- Same title/subtitle and results layout as `D03-S007`; footer: “Slide 3 of 6”; “Internal”.
- Visible **channel-level** labels: Paid `ATE: 0.26%*`; Leads `ATE: 0.20%*`; Email `ATE: -0.16%*`. Additional channel labels/values are partially obscured or unreadable.
- Visible **channel × interaction-level** labels: Email CLICK `ATE: 0.51%`; Leads contacted `ATE: 0.31%`; Display VIEW `ATE: 0.30%`; Paid Search CLICK `ATE: 0.46%`; SEO CLICK `ATE: 0.29%`; Mobile NoResponse `ATE: -0.19%`. Other small tiles are `[UNREADABLE]`.
- Asterisk footnote text is not visible in the screenshot; the `*` must not be interpreted.
- Color legend maps green toward “positive impact” and red toward “negative impact”; no exact values are inferred from color/area.
- Classification: **Ambiguous.** “ATE” is shown but its treatment/outcome, population, uncertainty, estimator, and identification basis are not stated in the visible slide.

#### D03-S009 — Diagnostic Signal Results, result view B

- Same title/subtitle, panels, legend, footer and slide number as `D03-S008`; appears to be another iterative/alternative result display.
- Interaction-level readable labels repeat: Email CLICK `ATE: 0.51%`; Leads contacted `ATE: 0.31%`; Display VIEW `ATE: 0.30%`; Paid Search CLICK `ATE: 0.46%`; SEO CLICK `ATE: 0.29%`; Mobile NoResponse `ATE: -0.19%`.
- Channel-level labels include Display `ATE: 0.55%*` and SEO `ATE: 0.24%*`; other channel labels/values are `[PARTIALLY READABLE / UNREADABLE]` and are not reconstructed.
- The exact reason result view B differs from `D03-S008` is not explained in the screenshots. Treat it as a potential iteration/draft, not a contradiction or a confirmed rerun.
- Classification: **Ambiguous.** Same limitation as `D03-S008`; an “ATE” label alone does not establish causal effect.

#### D03-S010 — “Predictive Lens: Recommend Channels We Can Control”

- Subtitle: “Turning historical learning into practical channel decisions”; footer: “Slide 4 of 6”; “Internal”.
- “Signals we observe” includes Paid Search, SEO, Phone, Email, Direct Mail, Branch, Leads, Web, Display, Mobile, and “Action” `[PARTIALLY READABLE: the diagram’s linkage/roles are visual rather than fully textual]`.
- “Actions we can take”: Email, Direct Mail, Leads.
- Central distinction: “Predictive optimization focuses on controllable customer-level actions — not every diagnostic touchpoint.”
- Flow:
  1. “Score each option” — “For each customer, estimate the value of each candidate channel.”
  2. “Optimize allocation” — “Select the best channel while respecting operational constraints”; example: “Leads cap $C$K” `[PARTIALLY READABLE: exact cap notation may be “$C$K”]`.
  3. “Recommend channel” — “Output customer-level recommendation, constrained plan, and impact vs BAU.”
- Bottom message: “The optimizer recommends only channels TD can practically assign; diagnostic signals still inform the learning.”
- Classification: **Prospective channel recommendation.** The slide specifies an intended recommendation/optimization workflow, but does not show the objective function, evaluation, deployment, or evidence that recommendations improve outcomes.

#### D03-S011 — Speaker notes for predictive lens

- Owner: “Vandad”.
- The notes distinguish signals observed from actions the bank can control: TD can add budget to Paid Search but “cannot cause a customer to search for a product on Google”; TD can control whether customers receive an email, direct mail, or a phone call.
- Signals include positive/negative experience: started-but-incomplete applications and offers later expired are described as indicators of customer interest/intent.
- Three stated steps: estimate incremental benefit of each potential action for each customer; optimize across estimates under cost, capacity, population limits and business exclusion rules; recommend the best eligible action “—or no action where appropriate—” and validate expected impact against historical BAU.
- Example: if a customer received three emails in one month without response, another email recommendation may be suppressed for the next three months.
- Key point: the model uses everything learned from the customer journey, but recommends only actions “executable, appropriate, and expected to generate incremental value.”
- Notes introduce “early results” by Mehrazin.
- Classification: **Prospective channel recommendation**, with stated incremental-benefit intent. No causal evaluation or implementation result is supplied by the note.

#### D03-S012 — “What Changes Under Lumen AI”

- Subtitle: “Historical simulation: BAU vs optimized controllable channel mix”; footer: “Slide 5 of 6”; “Internal”.
- “Channel mix changes” compares BAU, “Optimizer – constrained,” and “Optimizer – unconstrained,” using Leads, Email and Direct Mail. Exact percentage labels are partially legible; `[UNREADABLE: do not infer all segment values from bar widths]`.
- “Expected conversion impact” bars display: BAU `1.31%`; Unconstrained `2.08%`; Constrained `1.45%`.
- Cards:
  - “Observed shift”: “The model reallocated channel mix from today’s rules toward capacity-aware …” `[PARTIALLY READABLE: final wording unclear]`.
  - “Operationally usable”: “The constrained optimizer can reflect real channel capacity limits.”
  - “Expected impact”: `[PARTIALLY READABLE: a +13% expected-conversions statement vs BAU is visible; associated parenthetical is not readable]`.
- Bottom caution: “Expected uplift is model-estimated from historical data and should be validated in live deployment.”
- Classification: **Prospective channel recommendation / simulation**. Conversion impact is explicitly model-estimated; it is not presented as experimental or deployed lift.

#### D03-S013 — Speaker notes for “What Changes Under Lumen AI”

- Owner: “Mehrazin”.
- Notes say this slide shows historical simulation versus BAU and optimizer-recommended channel mix; the key point is customer-level decisions based on estimated channel value, not broad rules.
- Unconstrained scenario: allocation “the model would choose if there were no operational capacity limits”; it shows “full model-preferred allocation.”
- Constrained scenario applies business constraints such as a Leads capacity cap and is closer to what the business could use.
- Right-side bars are described as observed historical baseline (BAU) and model-estimated expected conversion under recommended allocation.
- Explicit conclusion: “historical simulation suggests expected uplift, and the next step would be a live validation through deployment.” The core message calls results model-estimated and subject to live validation.
- Close recommendation: continue validation with business partners, focus predictive decisioning on controllable channels, and use the diagnostic lens to continue learning from the full customer journey.

#### D03-S014 — “Roadmap”

- Footer: “Slide 6 of 6”; “Internal”.
- “Industry Positioning” timeline as presented: Rules Based; Logistic Regression (`2011`); Bayesian (`2014`); Survival Theory (`2014`); Shapley Value (`2018`); Uplift models (`2019`); Causal Models (`2020`); Transformer Models (`2025`). No citations are displayed.
- Roadmap quarters:
  - `Q1` Shapley Value: “Fair and explainable credit allocation”; “Game-theory framework”.
  - `Q2` Doubly Robust: “True incremental impact measurement”; “Bias correction - Confounding”.
  - `Q3` Predictive Modeling: “Predictive model for channel recommendation”; “Uplift modeling - Meta learners”.
  - `Q4` Transformer Model: “Sequence-aware AI decision engine”; “Cross-channel interaction learning”.
- Classification: **Ambiguous or mixed / roadmap.** This presents sequencing and methodological claims, not evidence the techniques were implemented or validated.

#### D03-S015 — Speaker notes for Roadmap

- Notes state: “Logistic regression has always been the gold standard”; “We started from 2018.”
- “DR is the causal model, this methodology is mature but 5,6 years behind.”
- “Transformers are becoming to the industry standard due to its success in other domains (like GenAI).”
- Goal: “By the end of Q4, we are aiming to have the transformer model ready.”
- These are uncited speaker-note assertions and an objective, not established literature facts or delivery evidence.

#### D03-S016 — Closing slide and speaker note

- Closing slide: “Thanks for your attention”; AI2 Analytics, Insights & Artificial Intelligence branding.
- Visible note: “I hope you all enjoyed it and thanks for your attention.”
- No additional technical claim or result.

#### D03-S017 — “Marketing’s Last Touch” versus “Doubly Robust Diagnostic”

- Side-by-side visual comparison, with both panels using “Channel x Interaction Level”; the right also contains a “Channel Level” panel.
- Left title: “Marketing’s Last Touch”; subtitle: “Attributed by Interaction”.
- Right title: “Doubly Robust Diagnostic”; interaction tiles visibly include Email CLICK, Paid Search CLICK, SEO CLICK, Leads contacted, Display VIEW and Mobile NoResponse; a color legend spans positive to negative impact.
- Exact counts and ATE values in most tiles are `[UNREADABLE]`; no values are inferred from area or color.
- Classification: **Retrospective attribution / causal-uplift intent ambiguous.** The title “Doubly Robust” identifies a method label but the estimand, estimator details, treatment specification and validation are not shown.

#### D03-S018 — Detail view of Marketing’s Last Touch vs doubly robust diagnostic

- Closer view of `D03-S017`.
- Marketing’s Last Touch interaction labels visibly include Email OPEN, Email CLICK, SEO CLICK, Leads form sent, Leads contacted, Paid Search CLICK, Display VIEW, Mobile NoResponse and Mobile Brandless. Exact associated counts are not reliably readable.
- Right-panel readable method-result labels include Email CLICK `ATE: 0.51%*`, Paid Search CLICK `ATE: 0.46%*`, Display `ATE: 0.65%*`, SEO `ATE: 0.43%*`; other values/tiles are `[UNREADABLE]`.
- Asterisk footnote content is not visible. Do not treat it as a significance marker without source confirmation.
- Classification: **Ambiguous.** It illustrates a contrast in attribution framing, but cannot by itself establish that the shown ATEs are validated causal effects.

#### D03-S019 — “Decile Analysis: Opt-Out Rate - Predictive”

- Left chart title: “Email Lift Score vs Opt-Out Rate by Decile”; x-axis: “Email Lift Deciles (1 = highest CFX, Email)” `[PARTIALLY READABLE: exact parenthetical unclear]`.
- Right chart title: “Average PRISM Score vs Opt-Out Rate by Decile”; x-axis: “PRISM Score Deciles (1 = highest Avg TC; 10 = lowest)” `[PARTIALLY READABLE: exact middle acronym unclear]`.
- Both charts show opt-out rate by decile and horizontal average lines; exact bar labels/average-line values are `[UNREADABLE]`.
- Visible conclusion: “Our email lift scores decile customers more effectively than the Prism scores. Even though we have not yet incorporated the opt-out signal into the model, it should still improve email assignment and likely reduce opt-outs.”
- Classification: **Response prediction / prospective channel recommendation support, not causal validation.** This is a decile-association analysis; the slide itself says opt-out has not yet been incorporated and only claims it “should” help.

## Index of important claims

| ID | Source | Claim presented | Evidence caveat |
| --- | --- | --- | --- |
| R01-C01 | `attribution-logic-walkthrough.html` | Candidate generation starts from every conversion and permits application-reference, DAB-reference, or eligible customer matching. | Report claim; query logic not independently verified. |
| R01-C02 | `attribution-logic-walkthrough.html` | Candidate generation can create a large number of rows (`K can be huge`); customer matching normally creates the largest candidate population. | Report claim; no observed counts supplied. |
| R01-C03 | `attribution-logic-walkthrough.html` | `online` means application- or DAB-reference equality, not simply a digital channel. | Definition presented in the report. |
| R01-C04 | `attribution-logic-walkthrough.html` | The rule selects one `attr_rank = 1` touch per conversion and retains unattributed conversions. | Report claim; cardinality should be checked in results. |
| R01-C05 | `attribution-logic-walkthrough.html` | The model is deterministic business-rule retrospective attribution and does not prove that a touch caused a conversion. | Explicitly stated by the report. |
| D01-C01 | `journey-observability-research-report.html` | The production output is a policy-filtered projection, not a complete customer journey. | Audit finding; does not itself validate an alternative attribution method. |
| D01-C02 | `journey-observability-research-report.html` | Production attribution selects one winner with deterministic business-policy rules, not plain last-touch. | “Recency” is presented as the final tie-breaker; implementation should be checked in SQL/code. |
| D01-C03 | `journey-observability-research-report.html` | Customer ID is the main practical match route; identity quality is channel-dependent. | Counts and agreement rates are aggregates in this cohort/audit. |
| D01-C04 | `journey-observability-research-report.html` | Display can be missing from the reported path because of observability and filtering; its absence does not establish ineffectiveness. | RESL × Display is explicitly illustrative, not statistically representative. |
| D01-C05 | `journey-observability-research-report.html` | Restoring pre-September-2024 history materially changes long-horizon linkage but almost not 90-day linkage. | Verify cohort definitions and notebook code. |
| D01-C06 | `journey-observability-research-report.html` | Retaining raw excluded rows would increase technical coverage, but does not justify their attribution credit. | The report labels recovery technically large and causally ambiguous. |
| D01-C07 | `journey-observability-research-report.html` | A fractional-attribution model trained directly on production paths is high bias risk. | Recommendation/readiness assessment; not validation of a replacement model. |
| D01-C08 | `journey-observability-research-report.html` | Fractional credit is descriptive until validated against experimental, quasi-experimental, or defensible incrementality designs. | No such validation result is shown in this report. |
| D02-C01 | “Channel Attribution & Prediction — Committed Timeline” | XGBoost + DR uplift / attribution code, Azure access, GPU infrastructure, and transformer research/build status are presented as complete or underway. | Timeline/status claim only; not independently verified. |
| D02-C02 | “Channel Attribution & Prediction — Committed Timeline” | Prediction V2 is planned for Nov. 30, 2026 (target Oct. 31), with production in Mar. 2027 and campaign use from Apr. | Planned/committed dates, not delivery evidence. |
| D02-C03 | “Channel Attribution & Prediction — Committed Timeline” | Attribution V1 is planned as fractional attribution, V2 as MMM-informed attribution, and V3 as transformer attribution. | No methodology/results are shown beyond labels and dependencies. |
| D02-C04 | “Basis of Estimates” | V2 MMM-informed attribution requires MMM ROI extracts and incrementality test results; MTA V3/deployment are TBD and subject to model validation. | Stated dependency/estimate; does not show that inputs or validation exist. |
| D03-C01 | `LumenAI_VP_Deck.pptx` | Lumen AI pairs diagnostic attribution from the observed journey with decision optimization over controllable channels. | Architecture/vision presented; no model or deployment proof shown. |
| D03-C02 | `LumenAI_VP_Deck.pptx` | Raw channel performance is misleading because customers are not randomly assigned, and customer context plus observed touchpoints should inform adjusted attribution. | Causal/debiasing rationale only; estimator and validation are not visible. |
| D03-C03 | `LumenAI_VP_Deck.pptx` | Diagnostic modeling may use channels not directly assignable in a future campaign, while the optimizer recommends only controllable actions. | Presented as an intended design boundary. |
| D03-C04 | `LumenAI_VP_Deck.pptx` | The diagnostic result views label several effects as ATEs, including positive and negative values. | Footnote / significance notation, treatment definition, outcome, model, and uncertainty are absent or unreadable. |
| D03-C05 | `LumenAI_VP_Deck.pptx` | The predictive process scores candidate channels, optimizes under operational constraints, then returns a customer-level recommendation and impact vs BAU. | Intended workflow; no objective, experiment, or achieved impact is shown. |
| D03-C06 | `LumenAI_VP_Deck.pptx` | Historical simulation reports BAU conversion at 1.31%, unconstrained at 2.08%, and constrained at 1.45%. | Slide explicitly calls uplift model-estimated from historical data and requiring live validation. |
| D03-C07 | `LumenAI_VP_Deck.pptx` | The roadmap positions Shapley, doubly robust, predictive modeling and transformers as Q1–Q4 steps. | Roadmap and uncited industry-positioning claims, not implementation evidence. |
| D03-C08 | `LumenAI_VP_Deck.pptx` | Email lift scores are said to decile opt-out rates more effectively than PRISM scores. | Chart values/definitions are partly unreadable; opt-out was not yet incorporated, and future improvement is conjectural. |

## Method/task classification index

Classifications are added only when supported by slide content. Allowed labels:

- Response prediction
- Causal/uplift estimation
- Retrospective attribution
- Prospective channel recommendation
- Ambiguous or mixed

| Source | Classification | Rationale |
| --- | --- | --- |
| R01 | Retrospective attribution | Explicit selection and ranking of a recorded touch for each conversion. |
| R01 | Not causal/uplift estimation | The report explicitly says it does not prove causation. |
| R01 | Not response prediction / not prospective channel recommendation | No predictive target, counterfactual effect, or future action-selection procedure is shown. |
| D01-S001–D01-S011, D01-S013 | Retrospective attribution / observability audit | Audits matching, eligibility, path construction and a selected winner after conversion. |
| D01-S002, D01-S007, D01-S010, D01-S011, D01-S013 | Not causal/uplift estimation | Technical links/recovery do not estimate causal lift or unique causal effects; causal channel effectiveness is “Not established.” |
| D01-S003 | Not response prediction / not prospective channel recommendation | Describes deterministic matching/ranking, not a predictive outcome model or counterfactual channel policy. |
| D01-S012, D01-S014 | Ambiguous or mixed / prospective research direction | Recommend a potential fractional-attribution architecture and research agenda; no algorithm, output, or implementation result is shown. |
| D02-S001, D02-S002 | Ambiguous or mixed | The two streams combine prospective channel prediction, retrospective/fractional attribution plans and tentative causal/measurement inputs, without enough detail to classify any delivered model or causal estimator. |
| D03-S003 | Ambiguous or mixed | Explicitly combines diagnostic attribution and prospective channel decisioning. |
| D03-S005, D03-S006, D03-S007–D03-S009 | Retrospective attribution with causal/uplift intent not established | Uses selection-bias and ATE language, but the visible evidence lacks estimator, estimand specification, assumptions, uncertainty or validation. |
| D03-S010 | Prospective channel recommendation | Specifies controllable actions, constrained optimization and customer-level recommendations, but no deployed/recommended results. |
| D03-S011–D03-S013 | Prospective channel recommendation / simulation | Describes incremental-benefit optimization and a historical simulation; notes explicitly say live validation is next. |
| D03-S017–D03-S018 | Retrospective attribution with causal/uplift intent not established | The “Doubly Robust” label and ATE tiles lack required method, estimand, inference and validation evidence. |
| D03-S019 | Response prediction / recommendation support | Decile analysis of opt-out rates supports a predictive association claim, not causal effect. |

## Contradictions and tensions across slides/decks

1. **Denominator / cohort scope varies across views.** `D01-S001` reports `10.54M` conversion entities examined; `D01-S006` labels a full-population rate denominator of `10,536,464`; `D01-S005` states `10,123,225` *production conversion IDs* for the production-attributed-row rate. This may reflect intentionally different scopes, but they are not interchangeable without verification.
2. **“Old cutoff” versus cohort dates.** `D01-S002` calls it a September 2024 cutoff; `D01-S005`/`D01-S006` define old-cutoff technical match as events on/after `2024-09-01`; `D01-S001` displays a cohort from `2024-11-01` to `2026-06-30`. Verify that cohort start and event-history cutoff are intentionally distinct.
3. **Across-notebook counts and end dates are explicitly non-mergeable.** `D01-S013` says the primary audit used `484.98M` prepared rows and included `2026-07-01`, while supplements rebuilt `986.02M` all-history rows stopping at `2026-06-30`; entity counts are `10,538,441` versus `10,536,464`. The report itself says not to naively merge absolute counts.
4. **D02 is a planned timeline, while D01 is an audit/research handoff.** D02 presents committed targets through 2027, whereas D01 gives no proof that those commitments were met. Do not use one as implementation confirmation for the other without dated code/results.
5. **D03 result displays vary without an explanation.** `D03-S008` and `D03-S009` show alternative channel-level labels/values for the same “Slide 3 of 6” layout. The screenshots do not establish whether this represents data refresh, a different segment, a changed specification, or a draft revision.
6. **Slide-count metadata differs within D03.** The editor screenshot says “Slide 1 of 22,” while content-slide footers show “Slide 1 of 6” through “Slide 4 of 6.” This may denote a six-slide section within a larger 22-slide deck; confirm against the source presentation.
7. **Model-estimated simulation is not observed conversion lift.** `D03-S012`/`D03-S013` explicitly call the uplift historical/model-estimated and require live validation; do not report the 1.31%, 2.08% and 1.45% values as experimental results.
8. **Printed cover dates conflict with file metadata (`L01`).** Four decks print the same `Dec 5 2025` cover (`D06`–`D09`) but were created on four different dates spanning `December 1, 20…` to March 10. `D04` prints `April 1st 2026` yet its file shows created May 5. Cover dates in this corpus should be treated as **branding or event labels**, not authoring dates, and no deck's presentation date is established by any evidence in this file.
9. **Deck chronology cannot be ordered reliably.** Neither cover dates (item 8), nor `Modified` dates (updated by mere opening, per the user), nor `Created` dates (which do not survive copy/re-upload, as the two 2021-named files show) give a trustworthy sequence. Ordering claims about which deck superseded which — including the D10-versus-Dec-2025 phase-reassignment reading — rest on **content evidence**, with library metadata only weakly consistent with it.

## Questions to verify against code or results

### From R01 itself

- Is the report’s description of `prod-04-attribution`, especially original cells 52–53, faithful to the actual code currently used?
- How many candidate interactions are created per conversion, particularly from the customer-plus-eligibility route?
- How often does the seven-day default lookback apply because there is no explicit rule?
- Can candidates tie on every ranking field? If so, what stable final tie-breaker, if any, is in the implementation?
- Are lookback-window, SVA, or metadata keys unique at their intended join grain? If not, where are duplicates removed?
- Does `attr_rank = 1` yield exactly one row per conversion, and what are the counts and characteristics of unattributed conversions?
- Are the naming and semantics of `online_match`, `claim_sale`, `halo_rank`, `is_affiliate`, `channel_rank`, and `interaction_type_rank` aligned with the report’s wording?
- What is the complete order of the separate RESL, online, and offline channel-ranking rules mentioned in the report?

### From D01

- Which exact conversion population produces each denominator: `10.54M`, `10,536,464`, and `10,123,225`?
- Does implemented production SQL exactly use the candidate routes, eligibility logic, and ordering shown in `D01-S003`?
- What do “Affiliate priority,” “nested business rank,” “channel rank,” “event rank,” and lookback/LOB/brand/halo classifications mean operationally, and where are policy tables maintained?
- How are placeholder identifiers (`XYZ`, `NO_DAB`, `ABC`, `NO_DAB_CONV`) normalized, and are there more?
- Can the RESL × Display funnel be reproduced by subtype and all LOB/channel pairs? The report says this pair is not representative.
- What criteria define rows excluded by base filters, and which exclusions are policy requirements versus data-quality issues?
- What is safeguard 9 in the “Minimum safeguards” list? It is not visible in the supplied screenshots.
- Can each readiness status be linked to the named notebook, run/version, data snapshot and reproducible output?
- What experiment, quasi-experiment, or external incrementality evidence would be accepted to validate fractional output, and does any already exist?

### From D02

- What are the exact scopes and success metrics for `V1 — XGB + DR uplift`, V2 next-best-journey, and V1 fractional attribution?
- Is “XGBoost + DR model built (uplift + attribution code)” a shared codebase, two distinct implementations, or a planning shorthand?
- What are “MDR,” “DaaS,” “MKT - AZ,” “AI2 AZ,” and “CC (GPU)” in the operational delivery process?
- Did the MMM ROI extracts and incrementality test results become available, and what design/quality thresholds were required before their use?
- Were the target/committed dates, 2-FTE capacity assumption, and estimated additional ~8 weeks actually approved and later met?

### From D03

- What do the ATE labels measure exactly: treatment contrast, outcome, cohort, time window, unit and scale? What does the `*` footnote denote?
- Which estimator produces the ATE values, and how are PRISM propensity/context, treatment assignment, overlap, leakage, clustering and uncertainty handled?
- Why do `D03-S008` and `D03-S009` show different channel-level result views? Are they alternate designs, data snapshots, or segments?
- What are the formulas for “gross response,” “channel likelihood,” and “channel lift” in `D03-S003`?
- Which observed channels are eligible actions, which are diagnostic-only signals, and under what business rules are Email, Direct Mail and Leads selected?
- What optimization objective, constraints, capacity/cost data, BAU comparator and offline/online evaluation determine the recommendation in `D03-S010`?
- Is “Prism Lumen AI” a product name for the full system, or does it refer to a PRISM–Lumen integration? The cover itself only displays “LUMEN AI.”
- What exact controls, outcome horizon, counterfactual baseline, leakage checks and uncertainty method produced the `D03-S012` simulated conversion values?
- What is the footnote represented by `*` in the ATE results, and why do values differ between the iterative views?
- What data and citations support the D03 industry-positioning dates and the claims in the Roadmap notes?
- In D03-S019, what is the sample, opt-out definition/horizon, decile ordering direction, and quantitative comparison metric used to say email lift deciles better than PRISM?

## Processing log

- 2026-09-09: Evidence file initialized; no screenshots processed.
- 2026-09-09: Processed 10 File Explorer screenshots as a VDI directory/file inventory. No presentation deck or slide IDs assigned for this batch.
- 2026-09-09: Processed 7 screenshots of `attribution-logic-walkthrough.html` as report R01. Extracted visible sections 1–9, including formulas, candidate hierarchy, winner ordering, example, caveats, and EDA checks. No standalone HTML was recreated.
- 2026-09-09: Appended 14 screenshots from `journey-observability-research-report.html` as `D01-S001`–`D01-S014`. The batch covers production-path observability, matching, RESL × Display, history sensitivity, raw exclusions, fractional-attribution safeguards/readiness, and the cited notebook evidence base. Safeguard 9 was not visible and is explicitly flagged.
- 2026-09-09: Processed 2 screenshots from a separate presentation as `D02-S001`–`D02-S002`. The visible title is “Channel Attribution & Prediction — Committed Timeline”; user’s remembered “Timeline of Two Streams” label is not used as the title. Minor introductory text in `D02-S001` is marked partially readable.
- 2026-09-09: Processed the first batch of 10 screenshots from `LumenAI_VP_Deck.pptx` as `D03-S001`–`D03-S010`. This includes cover/notes, slides visibly numbered 1–4 of 6, diagnostic-result iterations and speaker notes. Unreadable values, the ATE asterisk footnote, and unexplained differences between result views are explicitly flagged.
- 2026-09-09: Processed the final 9 screenshots from `LumenAI_VP_Deck.pptx` as `D03-S011`–`D03-S019`, completing the supplied D03 batch. Includes predictive notes, historical simulation, roadmap/notes, closing, last-touch vs doubly-robust visual, and opt-out decile analysis. Exact unreadable values and footnotes remain flagged.

## D04 — `DR_Shap_executive.pptx` (inferred filename; partial views)

**Deck-level evidence.** Cover identifies **MTA LUMEN AI**, AI2 branding, tagline “Make it clear. Make it human.” and date **April 1st, 2026**. The editor view shows **Slide 1 of 61**. The supplied screenshots show visible slides **1–14, 15, 16, 17, 18 and 30**, with several close-ups/repeated views. Slides 15–18 and 30 arrived in a later batch than slides 1–14, so the evidence IDs are in upload order, not slide order; the printed slide numbers are recorded per entry. In that final batch the supplied filenames did not sort in the same sequence as the displayed upload order; IDs follow the displayed order. These are records of presented material, not independent proof of implementation, validity, or causal effect.

### D04-S001 — Cover

- Visible filename: `DR_Shap_executive.pptx`; title: **MTA LUMEN AI**; date: **April 1st, 2026**.
- Tagline: “Make it clear. Make it human.” Editor metadata: **Slide 1 of 61**.

### D04-S002 — Project Scope & Data Overview (visible slide 2)

- Summary table: **2,604,922** total customers; **35,453 (1.36%)** converters; analysis period **April–July 2025**; **4 inbound** and **5 outbound** channels.
- `Conversion rate and customer share by number of touchpoints`: touchpoints 1/2/3/4/5+ have conversion rates **1.20% / 1.03% / 0.75% / 1.24% / 2.92%** and customer shares **25.61% / 20.55% / 25.43% / 10.57% / 17.84%**.
- `Exposure rate and conversion rate (among exposed) by channel` is transcribed in D04-S004.
- Review comments from Nafeh Akber are visible (including requests to simplify totals/rates, write conclusion titles, enlarge a view, and remove a duplicate). They indicate a draft/review state, not final evidence.

### D04-S003 — Close-up: touchpoint chart

- Repeats the D04-S002 chart. Exact values: 1 touchpoint **1.20% / 25.61%**; 2 **1.03% / 20.55%**; 3 **0.75% / 25.43%**; 4 **1.24% / 10.57%**; 5+ **2.92% / 17.84%** (conversion rate / customer share).

### D04-S004 — Close-up: exposure and conversion by channel

| Channel | Exposure rate | Conversion rate among exposed |
|---|---:|---:|
| Mobile | 57.46% | 0.91% |
| Email | 38.30% | 1.76% |
| SEO | 5.87% | 3.10% |
| Paid | 5.79% | 3.67% |
| Display | 2.15% | 4.27% |
| Web | 1.87% | 1.67% |
| Branch | 1.70% | 2.10% |
| Leads | 0.90% | 10.27% |
| Phone | 0.10% | 1.25% |

These are descriptive exposed-population rates, not causal channel effects.

### D04-S005 — Project Scope & Data Overview (visible slide 3)

`Top 10 Channel Journeys by Conversion Rate` (conversion rate; number of customers shown by line):

| Journey | Conversion | Customers |
|---|---:|---:|
| Leads+Paid_Search | 23.68% | 114 |
| Leads+Paid_Search+Mobile | 22.86% | 35 |
| Leads+SEO | 19.33% | 119 |
| Email+Display+SEO+Paid_Search+Web | 17.65% | 34 |
| SEO+Paid_Search+Web | 17.14% | 105 |
| Leads+SEO+Mobile | 16.67% | 42 |
| Email+Display+Paid_Search+Mobile | 15.20% | 204 |
| Display+SEO+Paid_Search+Web | 14.55% | 55 |
| Email+SEO+Paid_Search+Mobile | 14.45% | 256 |
| Email+Display+SEO+Mobile | 14.06% | 128 |

`Top 10 Channel Journeys by Number of Customers`:

| Journey | Customers | Conversion |
|---|---:|---:|
| Mobile | 1,260,457 | 0.57% |
| Email | 761,798 | 1.36% |
| Email+Mobile | 177,098 | 2.57% |
| SEO | 91,539 | 2.36% |
| Paid_Search | 84,984 | 2.89% |
| Branch | 21,956 | 1.72% |
| Web | 19,980 | 1.13% |
| Leads | 16,702 | 10.30% |
| SEO+Paid_Search | 16,225 | 3.99% |
| Email+Web | 14,419 | 1.03% |

### D04-S006 — Close-up: journeys by conversion

- Repeats the left table/chart in D04-S005; exact transcription is retained there.

### D04-S007 — Close-up: journeys by customers

- Repeats the right table/chart in D04-S005; exact transcription is retained there.

### D04-S008 — Time Window Selection (visible slide 4)

- Timeline: **April, May, June, July**.
- `Prism scores on April data` → `Latency: scores` → `Prism prediction window`.
- `Feature window`: “All channels, all events (what has the customer [PARTIALLY READABLE]).”
- `Treatment window`: “Outbound channels only (what WE choose to do).”
- `Conversion window`: “CC new account openings.”
- This is temporal-design framing for prediction/treatment/outcome; it does not itself show an estimator run or validated causal result.

### D04-S009 — System Overview (visible slide 5)

- Central **LUMEN AI** takes inputs labelled `Customer Data (Prism)` and `Customer Journeys`.
- Predictive side: score table → **ORCA Optimization Engine** → `Personalized Marketing`.
- Diagnostic side: diagnostic visualisation / channel composition. Arrows portray a conceptual system linkage.

### D04-S010 — Diagnostic approach: SHAP + doubly robust (visible slide 6)

- **Method 1: SHAP**: a response model predicts conversion; channel SHAP shows how much a channel pushed the prediction toward conversion. Listed strength: non-linear effects/interactions. Listed limits: correlation not causation, no correction for selection bias, cannot answer “what if…”. Explicit statement: **“High SHAP ≠ channel caused conversion.”**
- **Method 2: DR**: response model for conversion plus nine outcome models per channel; slide says it estimates ATE and separates incremental lift from “would have converted anyway.” Listed assumptions/limits: overlap required; cannot correct unobserved effects; complexity of interpretation.
- This is a methodological claim and conceptual distinction, not validation that its causal assumptions or estimators hold in this data.

### D04-S011 — Response Model — PRISM vs Lumen AI Performance (visible slide 7)

- Slide says PRISM is general-purpose; Lumen is task-specific and trained on a targeted population, leading to “better predictive performance (higher AUC)” and more accurate channel recommendations for future campaigns.
- ROC legend: **PRISM AUC = 0.7017**; **Lumen AI AUC = 0.7510**; chart annotation **+4.93%** (the slide does not define the calculation).
- It says comparison of the causal model with PRISM uses off-policy evaluation on a single treatment group. Treatment definition, policy, evaluation design, uncertainty and validation details are not visible.

### D04-S012 — Decile performance (visible slide 8)

- Plots: `Conversion rate by decile — PRISM vs Lumen` and `Decile-by-decile Conversion Lift (Lumen - PRISM)`; decile 1 is highest score and 10 lowest. Exact values are transcribed in D04-S013–S014.

### D04-S013 — Close-up: PRISM vs Lumen deciles

| Decile | PRISM | Lumen |
|---|---:|---:|
| 1 | 17.37% | 22.90% |
| 2 | 8.59% | 9.73% |
| 3 | 7.46% | 5.74% |
| 4 | 7.06% | 5.15% |
| 5 | 5.35% | 5.16% |
| 6 | 4.93% | 3.63% |
| 7 | 3.44% | 3.06% |
| 8 | 2.67% | 2.10% |
| 9 | 2.68% | 2.10% |
| 10 | 1.15% | 0.57% |

### D04-S014 — Close-up: decile-by-decile conversion lift

- Lumen minus PRISM, calculated from the displayed rates: **+5.53, +1.14, −1.72, −1.91, −0.19, −1.30, −0.38, −0.57, −0.58, −0.58 percentage points** for deciles 1–10 respectively.

### D04-S015 — Per-channel Lumen score by PRISM decile (visible slide 9)

- Series: **Email, Leads, Display**; x-axis `PRISM decile (1 = highest)`; y-axis `Lumen score (percent or unit of score)`.
- Bar labels are not visible with enough clarity for faithful numeric transcription.

### D04-S016 — Selection Bias heatmap (visible slide 10)

- `Cells = exposure rate ÷ channel average • numbers = conversion rate among exposed (%)`; colour scale is `Exposure ratio (1.0 = no bias)`.
- Rows by baseline propensity decile 1–10 (1 highest):

| Channel | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Leads | 15.1 | 8.4 | 6.6 | 6.9 | 6.1 | 6.8 | 5.3 | 5.3 | 4.8 | 5.8 |
| Branch | 6.3 | 2.6 | 1.8 | 1.4 | 0.9 | 1.1 | 0.8 | 1.1 | 1.0 | 0.0 |
| Phone | 3.0 | 2.9 | 0.8 | 0.5 | 1.1 | 0.8 | 0.0 | 0.6 | 0.0 | 0.0 |
| Web | 6.6 | 2.8 | 1.5 | 1.1 | 0.9 | 0.8 | 0.5 | 0.7 | 0.5 | 0.0 |
| Email | 6.3 | 2.6 | 1.6 | 1.2 | 0.9 | 0.7 | 0.6 | 0.5 | 0.4 | 0.3 |
| Display | 13.0 | 6.9 | 5.1 | 3.9 | 3.1 | 2.2 | 2.0 | 1.7 | 1.1 | 0.4 |
| Paid | 14.7 | 6.6 | 4.4 | 3.1 | 2.5 | 2.0 | 1.3 | 1.2 | 0.9 | 0.5 |
| Mobile | 4.8 | 1.7 | 1.0 | 0.6 | 0.4 | 0.2 | 0.1 | 0.1 | 0.0 | 0.0 |
| SEO | 13.5 | 5.9 | 4.1 | 2.7 | 2.2 | 1.7 | 1.2 | 1.0 | 0.7 | 0.4 |

### D04-S017 — Selection Bias (visible slide 11)

`Conversion rate by channel: exposed vs unexposed`:

| Channel | Exposed | Unexposed |
|---|---:|---:|
| Leads | 10.27% | 1.28% |
| Display | 4.27% | 1.30% |
| Paid | 3.67% | 1.22% |
| SEO | 3.10% | 1.25% |
| Branch | 2.10% | 1.35% |
| Email | 1.76% | 1.11% |
| Web | 1.67% | 1.36% |
| Phone | 1.25% | 1.36% |
| Mobile | 0.91% | 1.97% |

- Lower chart title: `Per-channel raw lift vs baseline-propensity gap (if both bars and dots move together → lift is largely selection bias)`.
- Readable raw-lift labels: Leads **+9.0 pp**, Display **+3.0 pp**, Paid **+2.5 pp**, SEO **+1.9 pp**, Web **+0.3 pp**, Phone **−0.1 pp**, Mobile **−1.1 pp**. Branch and Email labels are not fully reliable in the supplied view.

### D04-S018 — Close-up: exposed vs unexposed / raw-lift chart

- Repeats D04-S017; confirms the upper values and readable raw-lift labels. The dot series is labelled `Avg baseline propensity gap`; exact point values are not printed clearly enough to transcribe.

### D04-S019 — Close-up: raw-lift chart

- Repeats D04-S017 lower chart. It visibly supports Email at approximately **+0.6 pp**, but the close-up is not clear enough to treat the Branch value as exact. Retain D04-S017’s unreadable qualification.

### D04-S020 — Diagnostic Approach: Doubly Robust (visible slide 12)

- Text: doubly robust “combine two models to estimate true channel impact”; a response/outcome model asks what would happen with vs without a channel, and a channel-propensity model asks who gets which channel.
- Key benefit as presented: consistent estimates if either propensity or response model is correctly specified. Limits: overlap assumption and inability to fully correct unobserved confounding.
- Diagram: one response model uses PRISM score, April–July channel interactions, nine channel binary flags and conversion; illustrative outputs **μ₁(X)=4.1%** and **μ₀(X)=2.8%**. Nine propensity models (one per channel) use PRISM score and features excluding the focal channel; an illustrative Leads propensity is **18.4%**.
- Displayed score formula: `DR(i, C) = (μ₁ − μ₀) + ((T − e) / (e(1 − e))) × (Y − μ_T)`; bottom formula: `ATE(C) = (1/N) Σ DR(i, C)`, described as average causal lift in percentage points per channel across customers.
- This is an explanatory model/diagram with illustrative values, not independently verified fitted-model output or causal validation.

### D04-S021 — Duplicate full view: Diagnostic Approach: Doubly Robust

- Repeated view of D04-S020 in the next upload batch. It confirms the same assumptions, limitations and diagram; no new distinct slide content.

### D04-S022 — Close-up: doubly robust diagram

- Confirms inputs/outputs and formulas in D04-S020. Additional legible detail: the propensity model says `T = Leads exposure` (**0 = not exposed, 1 = exposed**) and repeats its architecture for **Display, Paid Search, SEO, Email, Branch, Mobile, Web, Phone**.

### D04-S023 — Diagnostic Results (visible slide 13)

`Channel-group attribution: DR vs SHAP (n = number of interaction types within the channel)`. Green = Mean DR; orange = Mean SHAP. Values displayed:

| Channel group | n | Mean DR | Mean SHAP |
|---|---:|---:|---:|
| Leads | 2 | +0.0183 | −0.0061 |
| Display | 2 | +0.0048 | +0.0014 |
| Paid | 1 | +0.0031 | −0.0070 |
| SEO | 1 | +0.0026 | −0.0280 |
| Web | 5 | +0.0002 | +0.0000 |
| Phone | 3 | +0.0002 | +0.0000 |
| Email | 2 | −0.0015 | +0.0018 |
| Branch | 4 | −0.0037 | +0.0000 |
| Mobile | 4 | −0.0070 | −0.0032 |

The slide calls these attributions; its scale, estimand, uncertainty and validation are not shown.

### D04-S024 — Diagnostic Results — Channel and Interaction (visible slide 14)

`Channel × interaction attribution summary (sorted by DR)`:

| Channel × interaction | Mean DR | Mean SHAP | DR − SHAP |
|---|---:|---:|---:|
| branch followuplater | +0.0851 | +0.0000 | +0.0851 |
| leads claim sale | +0.0152 | +0.0007 | +0.0145 |
| email click | +0.0038 | +0.0005 | +0.0032 |
| display view | +0.0029 | +0.0002 | +0.0028 |
| seo click | +0.0029 | −0.0289 | +0.0318 |
| paid search click | +0.0027 | −0.0077 | +0.0104 |
| leads contacted | +0.0023 | −0.0055 | +0.0078 |
| web interested | +0.0018 | +0.0002 | +0.0017 |
| mobile interested | +0.0011 | −0.0010 | +0.0021 |
| mobile followuplater | +0.0006 | +0.0000 | +0.0006 |
| display click | +0.0004 | −0.0001 | +0.0005 |
| web followuplater | +0.0003 | +0.0000 | +0.0003 |
| branch notinterested | +0.0003 | +0.0000 | +0.0003 |
| web click | +0.0003 | +0.0000 | +0.0003 |
| branch notactioned | +0.0003 | +0.0000 | +0.0003 |
| mobile notinterested | +0.0002 | +0.0000 | +0.0002 |
| branch interested | +0.0002 | +0.0000 | +0.0002 |
| phone notinterested | +0.0002 | +0.0000 | +0.0002 |
| phone notactioned | +0.0002 | +0.0000 | +0.0002 |
| phone interested | +0.0002 | +0.0000 | +0.0002 |
| web noresponse | +0.0002 | +0.0000 | +0.0002 |
| web notinterested | +0.0002 | +0.0000 | +0.0002 |
| email open | +0.0001 | −0.0011 | +0.0012 |
| mobile noresponse | −0.0013 | −0.0032 | +0.0019 |

### D04-S025 — Close-up: channel × interaction table

- Repeats D04-S024 and makes its table legible; exact values are retained in D04-S024. The chart title reads `Shapley vs Doubly Robust attribution — top channel × interaction (by |DR|)`.

### D04-S026 — Project Scope & Data Overview (visible slide 18)

Slide number printed on the slide: **18**. Footer `Internal`. Header table:

| Total Customer Records | Converters | Analysis Period | Total channel | Num interactions |
|---|---|---|---|---|
| 2,604,922 | 35,453 (1.36%) | April – July 2025 | 9 (4 inbound – 5 outbound) | 1-5 |

Two charts: `Top 10 Channel Journeys by Conversion Rate` (left) and `Top 10 Channel Journeys by Number of Customers` (right). Both are transcribed from the legible close-ups in D04-S032 and D04-S029.

- These header values match D04-S002 exactly, but the journey charts on this slide are at **channel × event granularity** (e.g. `Email_OPEN | Email_CLICK`), whereas D04-S005 showed the same two chart titles at **channel-only granularity** (e.g. `Email+Mobile`). They are different cuts of the data, not duplicates.

### D04-S027 — Predictive Approach: Doubly Robust (visible slide 15)

Slide number **15**. Callout at top right: `Result: Stable uplift after doubly robust correction`. Body is a four-stage `End-to-End Architecture`.

**1 — TRAINING PHASE (Historical Data)**

- **A. RESPONSE MODEL (1 model)**
  - Features (X): `Prism score`; `Apr–May channel interactions (all channels, all event types)`.
  - Treatments (T): `t_email_clicked`, `t_display_view (0/1)`, `t_paid_search_clicked`, `t_leads_contacted`, `t_seo_clicked` — annotated `(June–July, outbound only)`.
  - Target (Y): `converted`.
  - Predicts: `P(conversion | who they are + customer journey)`.
- **B. PROPENSITY MODELS (1 per outbound channel)**
  - For channel C — Features: `Prism score + all Apr–May features EXCEPT channel C`.
  - Target: `t_channel_C (0/1) — was customer treated by C?`
  - Predicts: `P(receiving channel C | customer profile)`.
  - Purpose: `Corrects for selection bias — customers who end up in a channel may already be high-intent`.

**2 — SCORING PHASE (Per Customer)**, for each outbound channel C:

1. Response Model: predict with `T_C = 1` → `μ̂₁` (conversion if treat)
2. Response Model: predict with `T_C = 0` → `μ̂₀` (conversion if not)
3. Propensity Model C → `ê` (likelihood of treat)
4. Doubly Robust CATE: `Uplift(i, C) = (μ̂₁ − μ̂₀) + correction from propensity`, described on the slide as `incremental conversion lift CAUSED by channel C (not just correlated, but causal — corrected for selection)`.

**3 — MODEL OUTPUT** — illustrative table (five columns: Email, Display, Paid Search, Leads, SEO):

| Customer | Email | Display | Paid Search | Leads | SEO |
|---|---:|---:|---:|---:|---:|
| Cust 001 | +1.2pp | +2.8pp | +5.1pp | +1.9pp | +0.3pp |
| Cust 002 | +3.5pp | +0.4pp | +1.1pp | +4.2pp | +2.1pp |
| Cust 003 | +0.1pp | +3.9pp | +2.7pp | +0.8pp | +1.5pp |

Slide gloss: each value is `‘How many percentage points more likely is this customer to open a CC account IF we reach them via this channel vs. not’`, and `How much MORE likely is customer i to get a CC if we actively reach them via channel C, above and beyond what they would have done anyway?` The three customer rows are worked examples, not results.

**4 — ORCA OPTIMIZER**

- Input: `Uplift score matrix (N customers x 5 channels)`.
- Constraints: budget per channel (`e.g., max 500K emails/month`); channel capacity (`e.g., Leads has 25K max partnerships`); contact frequency (`e.g., max 3 channels per customer`); minimum uplift threshold (`don't treat if uplift < 0.5pp`); business rules (`don't send Display + Email same day`).
- Solves: `Maximize total expected incremental conversions subject to all constraints`.
- Output: `Final assignment — who gets what`: Cust 001 → Paid Search; Cust 002 → Leads + Email; Cust 003 → Display.

This is a **prospective channel recommendation** design paired with **causal/uplift estimation**. The stated constraint numbers are given as examples (`e.g.`) and are not evidence of configured production limits; no run lineage, tuning, feasibility check or optimizer output on real data is shown.

### D04-S028 — Close-up: conversion rate and baseline propensity by decile

Close-up of the right-hand chart on visible slide 17 (see D04-S033). Title: `Conversion rate and baseline propensity by decile`. Legend: green bars = `Conversion rate`; line with markers = `Avg baseline propensity`. Left axis `Conversion rate (%)` (0.0%–7.0%); right axis `Avg baseline propensity` (0.00–0.06). X axis: `Baseline any-card propensity decile (1 = highest, 10 = lowest)`.

Printed labels, decile 1 → 10: **5.97%** `[PARTIALLY READABLE: reads 5.97%, the marker overlaps the digit]`, **2.48%** `[PARTIALLY READABLE: marker overlaps the second digit]`, 1.58%, 1.11%, 0.83%, 0.62%, 0.4%, 0.3%, 0.2%, 0.11%.

- Ambiguity: the labels sit along the propensity line, but the bar for decile 1 also reaches ≈6.0%, so it is not established from the image whether the labels annotate the bars, the line, or both. Bar heights for deciles 2–10 are not separately labelled and are not inferred here.
- A left-edge fragment of an adjacent callout is visible (`...version` / `...elihood`), consistent with the `Conversion Likelihood` box on slide 17.

### D04-S029 — Close-up: Top 10 Channel Journeys by Number of Customers (slide 18)

Close-up of the right chart in D04-S026. Bars are read against `Conversion Rate (%)` (bottom axis, 0.0%–12.0%); the line/point labels are `Number of Customers` (top axis, 0–1,200,000).

| Journey | Number of Customers | Conversion Rate |
|---|---:|---:|
| Mobile_NoResponse | 1,181,582 | 0.52% |
| Email_OPEN | 715,975 | 0.92% |
| Email_OPEN \| Mobile_NoResponse | 136,033 | 1.88% |
| SEO_CLICK | 91,596 `[PARTIALLY READABLE: middle digits blurred; may be 91,539 as in D04-S005]` | 2.36% |
| Paid_Search_CLICK | 84,984 | 2.89% |
| Mobile_NoResponse \| Mobile_FollowUpLater | 70,938 | 1.21% |
| Email_OPEN \| Email_CLICK | 35,129 | 10.41% |
| Email_OPEN \| Mobile_NoResponse \| Mobile_FollowUpLater | 28,302 `[PARTIALLY READABLE: third digit blurred]` | 2.36% |
| Paid_Search_CLICK \| SEO_CLICK | 16,425 `[PARTIALLY READABLE: may be 16,225 as in D04-S005]` | 3.99% |
| Leads_contacted | 16,289 | 8.57% |

### D04-S030 — Our Position in Industry (visible slide 30)

Slide number printed as **30** `[PARTIALLY READABLE: rendered as stacked "3" and "0" at the right edge]`. Footer `Internal`. A vertical timeline of attribution methods, with a TD logo arrow pointing at the earliest entry and a green `Final Goal` arrow pointing at the latest.

| Method | Year shown | Reference text (hyperlinked on slide) |
|---|---|---|
| Rules Based | — | First-touch, last-touch, or time decay with logical business rules |
| Logistic Regression | 2011 | Multi-touch attribution (based on incremental propensity) |
| Bayesian | 2014 | Attributing conversions in multichannel online marketing; Mutually exciting point process model |
| Survival Theory | 2014 | Multi-touch attribution with survival theory |
| Markov Chain | 2018 | Marketing multi-channel attribution with Markov chains |
| Shapely Value (spelled thus) | — | Shapley values for attribution modeling |
| LSTM | — | NN with attention for multi-channel multi-touch attribution |
| Causal Models | 2020 / 2022 | CAMTA (2020); CausalMTA (2022) |
| Transformer Models | 2025 | LiDDA by LinkedIn; NNN by Google |

- The TD arrow points at `Rules Based`; `Final Goal` points at `Transformer Models`. The slide therefore positions TD's starting point as rules-based and a transformer approach as the aspiration. It does not state where the presented Lumen work sits on this timeline.

### D04-S031 — Predictive Results (visible slide 16)

Slide number **16**. Overview bullets:

- `Next Best Channel estimated for each outbound channel × customer pair using Doubly Robust estimation`
- `Uplift scores fed into ORCA optimizer, which assigns the best channel(s) per customer under real-world constraints (budget, channel caps, contact limits)`

Donut chart, titled `Average Next Best Channel Effect / Treatment Effect %`:

| Channel | Share |
|---|---:|
| Leads | 62% |
| Display | 21% |
| Paid Search | 8% |
| SEO | 7% |
| Email | 2% |

- The chart title mixes “Average Next Best Channel Effect” with “Treatment Effect %”, and the segments sum to 100%. It is not established from the slide whether these are shares of assigned customers, shares of total estimated effect, or normalised average effects. Flagged as ambiguous.

### D04-S032 — Close-up: Top 10 Channel Journeys by Conversion Rate (slide 18)

Close-up of the left chart in D04-S026. Bars read against `Conversion Rate (%)` (0%–80%); the line/point labels are `Number of Customers` (top axis, 50–400).

| Journey | Conversion Rate | Number of Customers |
|---|---:|---:|
| Leads_claim_sale | 78.79% | 396 |
| Mobile_NoResponse \| Leads_claim_sale | 75.0% | 92 |
| Email_OPEN \| Email_CLICK \| Mobile_NoResponse \| Display_VIEW | 35.62% | 73 `[PARTIALLY READABLE]` |
| Email_OPEN \| Email_CLICK \| Mobile_NoResponse \| Leads_contacted | 33.33% | 51 `[PARTIALLY READABLE]` |
| Email_OPEN \| Email_CLICK \| Display_VIEW | 33.1% | 284 |
| Email_OPEN \| Email_CLICK \| Paid_Search_CLICK \| Display_CLICK | 27.08% | 48 |
| Email_OPEN \| Email_CLICK \| Paid_Search_CLICK \| Display_VIEW | 26.03% | 73 |
| Email_OPEN \| Email_CLICK \| Leads_contacted | 24.83% `[PARTIALLY READABLE: marker overlaps the label; could be 24.43%]` | 145 |
| Email_OPEN \| Paid_Search_CLICK \| Display_CLICK \| Display_VIEW \| SEO_CLICK | 23.91% | 46 |
| Email_OPEN \| Email_CLICK \| Mobile_NoResponse \| SEO_CLICK | 23.49% | 138 |

- Sample sizes here are small (46–396 customers) relative to the 2.6M record base; the slide shows no uncertainty around these rates.
- `Leads_claim_sale` at 78.79% is an event label that on its face denotes a completed sale, so it may be outcome-adjacent rather than an upstream touchpoint. Flagged for verification, not asserted.

### D04-S033 — System Overview – Response model (visible slide 17)

Slide number **17**, viewed inside the Microsoft 365 editor (a browser banner is visible: `Your browser settings are preventing an optimal experience with Microsoft 365. Allow access to improve your experience.`). Footer `Internal`.

Diagram, left to right / top to bottom:

- `Customer Data (Prism)` — `10 Credit card propensity heads`, column headers shown as `4875001`, `4875004`, `4875005`, `…`, `4875012` (product codes; cell values blank/greyed in the mock).
- `CC_ind` — `Whether existing CC customer or not`.
- Both feed a lighthouse-icon block into `XGBoost` → `Conversion Likelihood`.
- `Customer Journeys` — `Aggregated Customer Journey (24 features)`, column headers `Display_view`, `Email_click`, `Email_view`, `…`, `SEO_Click`; two illustrative customer rows, one ending in a check mark and one in a cross.
- Right-hand panel: the decile chart transcribed in D04-S028.

Speaker notes are partially visible below the slide: `...his slide: how our product is going to be used and who is going to use it?` and `A high-level example (flow chart) from input to output` `[PARTIALLY READABLE: notes are cropped at both edges]`.

- This slide is **response prediction** (conversion likelihood from XGBoost), distinct from the DR uplift estimation on slide 15.

### D04-S034 — Close-up: Shapley vs Doubly Robust attribution chart

Close-up of the chart already recorded as D04-S024 / D04-S025; the underlying values are retained there and are not restated as new findings. Title: `Shapley vs Doubly Robust attribution — top channel x interaction (by |DR|)`. Legend: green = `Doubly robust (DR)`, orange/tan = `SHAP`. X axis `Attribution value`, range −0.04 to 0.10.

Newly legible detail in this view:

- Each row carries two printed labels, DR and SHAP, and the plotted values match D04-S024. The largest DR bar (`branch followuplater`) is labelled `+0.0851` `[PARTIALLY READABLE: label is clipped at the plot edge]` against a SHAP value of `+0.0000`.
- The only rows with visibly negative SHAP bars are `seo click` (−0.0289), `paid search click` (−0.0077), `leads contacted` (−0.0055), `mobile noresponse` (−0.0032), `email open` (−0.0011), `mobile interested` (−0.0010) and `display click` (−0.0001).
- `mobile noresponse` is the only row where both estimates are negative (DR −0.0013, SHAP −0.0032).
- A fragment of the adjacent slide table is visible along the left edge (partial digits `...145`, `...032`, `...028`, `...318`, `...104`, `...078`), consistent with the DR − SHAP column in D04-S024.

## D04 classification and checks

| Slides | Classification | Evidence boundary |
|---|---|---|
| D04-S002–S007 | Descriptive journey / retrospective data profile | Rates and journey patterns are observational; they are not causal effects. |
| D04-S008–S009 | Ambiguous mixed system/design | Shows temporal/system framing, not proof of a completed decisioning system. |
| D04-S010, S016–S025 | Retrospective attribution with causal/uplift intent not established | The deck explains DR and shows DR/SHAP outputs, but no estimation run lineage, identification diagnostics, uncertainty or external validation is visible. |
| D04-S011–S015 | Response prediction / recommendation support | ROC and decile comparisons are predictive-ranking evidence; the causal/off-policy comparison claim is under-specified. |
| D04-S026, S029, S032 | Descriptive journey / retrospective data profile | Event-level journey conversion rates on small samples; no uncertainty, no causal reading. |
| D04-S027, S031 | Causal/uplift estimation feeding prospective channel recommendation | Slide 15 specifies a DR CATE design and slide 16 reports an aggregate; neither shows estimation lineage, diagnostics, uncertainty or validation. Optimizer constraints are given as examples. |
| D04-S028, S033 | Response prediction | XGBoost conversion likelihood and a propensity-decile profile; predictive, not causal. |
| D04-S030 | Positioning / literature timeline | A method landscape and stated aspiration; not evidence about what was built. |
| D04-S034 | Retrospective attribution (close-up of D04-S024) | Adds legibility only; no new estimand, uncertainty or validation. |

## D04 important claims, tensions and questions

- **Important presentation claims (later batch):** slide 15 states the DR uplift is `incremental conversion lift CAUSED by channel C`; slide 15 also carries the callout `Result: Stable uplift after doubly robust correction`; slide 16 reports an average Next Best Channel effect split of Leads 62% / Display 21% / Paid Search 8% / SEO 7% / Email 2%; slide 30 positions TD at rules-based today with transformer models as the `Final Goal`.
- **Important presentation claims:** Lumen has higher AUC than PRISM (0.7510 vs 0.7017); selection bias is material and DR is offered as a mitigation; DR and SHAP can materially disagree, including Leads (+0.0183 DR vs −0.0061 SHAP) and SEO (+0.0026 DR vs −0.0280 SHAP).
- **Tension:** D04-S011 says Lumen gives better predictive performance, yet D04-S013 shows Lumen lower than PRISM in deciles 3–10. This can coexist with better top-decile concentration/AUC, but the deck does not explain the evaluation population or decile construction.
- **Tension (new, material):** the estimator scope is stated three different ways. D04-S010 says nine outcome models per channel; D04-S020/S022 show one response model plus **nine** propensity models covering Display, Paid Search, SEO, Email, Branch, Mobile, Web, Phone and Leads; D04-S027 (slide 15) says one response model plus **one propensity model per outbound channel**, with five treatments (`t_email_clicked`, `t_display_view`, `t_paid_search_clicked`, `t_leads_contacted`, `t_seo_clicked`) and a 5-channel output matrix. Five vs nine changes what is being estimated and what the optimizer can act on.
- **Tension:** D04-S023/S024 report DR values for Branch, Mobile, Web and Phone, which are not among the five outbound channels scored in D04-S027 and are not in the slide 16 donut. Whether those channels are treatments, features, or diagnostic-only is not resolved by the slides.
- **Tension:** the callout `Result: Stable uplift after doubly robust correction` (D04-S027) appears on a slide whose only numbers are illustrative worked examples; no stability evidence is shown anywhere in the supplied views.
- **Tension:** D04-S026 and D04-S005 share the same two chart titles but different granularity, and close-up readings differ slightly for SEO_CLICK (91,596 vs 91,539) and Paid_Search+SEO (16,425 vs 16,225). Both close-up digits are blurred, so this may be transcription rather than a real discrepancy.
- **Tension:** D04-S010 says DR has nine outcome models per channel, whereas D04-S020 diagram says one response model plus nine propensity models. This may be terminology or a slide-level simplification; verify the actual estimator architecture.
- **Questions to check against code/results (later batch):** Is the DR estimator built over five outbound channels or nine? Does `Leads_claim_sale` occur before or at/after the conversion event, and is it leaking outcome into the journey charts? What do the slide 16 donut percentages measure — assigned customers, share of total estimated effect, or normalised average uplift — and over which population? Are the ORCA constraint values (500K emails/month, 25K Leads partnerships, max 3 channels, 0.5pp threshold) real configured limits or illustrative? Was ORCA actually run on the uplift matrix, and is there a feasibility or sensitivity check? Do the decile-chart labels annotate the bars or the propensity line? What are the 24 aggregated journey features and the 10 propensity heads (codes 4875001–4875012)? What supports `stable uplift after doubly robust correction`?
- **Questions to check against code/results:** What is the exact outcome, treatment timing, target cohort and holdout split behind each AUC/decile chart? Are PRISM and Lumen scores evaluated on identical customers and windows? How is off-policy evaluation implemented for a single treatment group? What overlap/trimming, nuisance-model cross-fitting, propensity calibration, clustering and uncertainty method are used? What does each interaction label mean and how is it deduplicated/time-bounded? Are channel-level and interaction-level DR values ATEs, conditional effects, or another attribution scale? Why are these values reported to four decimals without confidence intervals? What live experiment or incrementality validation supports prospective use?

## D05 — `executive_review.pptx` — “PRISM LUMEN AI”

**Deck-level evidence.** A new deck, distinct from D04. Visible filename `executive_review.pptx`; cover title **PRISM LUMEN AI**; tagline “Make it clear. Make it human.”; date **April 1st, 2026**. Editor status bar reads **Slide 1 of 35**. Opened from `myteam.td.com/:p:/r/teams/TECEAIMLNewPracticeArea/_layouts/15/Doc.aspx?sourcedoc=%7B4061F2B4-E745-44DD-8C4C-59F518D9B00A%7D&file=executive_review.pptx&action=edit&mobileredirect=true`. Screenshots supplied 2026-09-09; the editor clock reads 3:02 AM, 9/9/2026.

- D04 (`DR_Shap_executive.pptx`) shares the same tagline and date but is titled **MTA LUMEN AI** and has **61** slides. D05 is titled **PRISM LUMEN AI** with **35** slides. They are treated as separate decks; whether one is derived from the other is not established.
- The slide panel shows a `Default Section` containing slides 1–4 and an `Appendix` section beginning at slide 5. The supplied screenshots cover slides 1–4 only.

### D05-S001 — Cover and editor context (visible slide 1)

- Slide body: `PRISM LUMEN AI` / `Make it clear. Make it human.` / `April 1st, 2026`, over a green illustrated banner.
- Editor: PowerPoint for the web, `Editing` mode, zoom 85%, `English (U.S.)`, status `Slide 1 of 35`. Account avatar initials `MA`. A Microsoft 365 banner reads `Allow access to Microsoft 365 account — Your browser settings are preventing an optimal experience with Microsoft 365.`
- Browser tabs visible: `TD Central - Search`, `New Tab`, `Team_BBQ_prep_list.xlsx`, `Knowledge Base - My He…`, `Mobile Enrollment - My H…`, `Agentic Forecasting.pptx`, `TECE AIML Practice - pre…`, `executive_review.pptx`.
- Bookmarks bar: `NBE`, `TD`, `Brain Folks`, `EDB-Superleads`, `CMT-cardtype`, `PIA_DAC_ADIDO`, `MTA`, `Prism`, `MMM`, `Intake forms`, `Reseach` (spelled thus), `All Bookmarks`.
- Slide panel thumbnails for slides 2–5 are too small to transcribe; only their layout is discernible.

### D05-S002 — Project Lumen – Marketing Personalization (visible slide 2)

Slide number **2**, footer `Internal`. Three panels:

- **What, Who, and Macro** — `Our goal is personalizing customer journeys to maximize campaign ROIs.` and `We know WHO to target and WHAT product they need`.
- **Customer's Journey** — an icon path only (Google, YouTube, phone, desktop, mobile, email, branch, card, hand). No text or values.
- **Blind Spot: The How** (amber header) — `PII barrier: We cannot share sensitive customer data with external vendors.` and `Current solution is rule-based, non-adaptive, and cannot provide personalized predictions.`

Speaker notes are cropped; the visible fragment reads `…tion, good for monitoring, by hassan's team` `[PARTIALLY READABLE]`.

This is a **framing/problem-statement** slide. The claim that the current solution is rule-based and non-adaptive is a stated characterisation of the incumbent, not measured evidence.

### D05-S003 — From Product to Next Best Channel (visible slide 3)

Slide number **3**, footer `Internal`. Two columns:

- **Marketing Application** — `Optimizes budget allocation per customer`; `Reports clear, per segment channel contribution`; `Provides personalized customer journeys`.
- **AI-Driven Attribution Engine** — `Predicts next best marketing channel`; `Maximizes customer conversion`; `Analyses long sequences using transformers`.

Lower diagram: `WHAT WE HAVE` — customer → `PRISM AI` → `Best Product` (card icons, `or`). A `+` connector. `WITH JOURNEY PERSONALIZATION` — `Customer History` → `LUMEN AI` → `Next Best Channel`.

Speaker notes are cropped; visible fragments: `…at are we offering?`, `…ropensity models and limitations`, `…e offer, what it does, and business impact` `[PARTIALLY READABLE]`.

- The slide positions PRISM as answering *which product* and LUMEN as answering *which channel next*. This is **prospective channel recommendation** framing.
- `Analyses long sequences using transformers` is stated as a capability of the engine. Zoom level 71%.

### D05-S004 — System Overview (visible slide 4)

Slide number **4**, footer `Internal`. A two-branch architecture diagram:

- **Predictive** (left): a per-customer score table (illustrative values `0.8 / 0.7 / 0.2 / 0.5`, `0.7 / 0.2 / 0.4 / 0.8`, `0.3 / 0.9 / 0.7 / 0.2` across four channel icons) → `ORCA` `Optimization Engine` → `Personalized Marketing`.
- **Diagnostic** (right): an analysis icon → a pie chart of channel segments (no labels or values shown).
- **Centre**: `Transformer Engine`, drawn with the Lumen lighthouse mark, fed from below and feeding both branches.
- **Bottom inputs**: `Customer Data`, `Customer Journeys` (three illustrative journeys ending in check / `?` / cross), `Campaign Data` (stacked cards).

Speaker notes are cropped; visible fragments: `…w our product is going to be used and who is going to use it?`, `…l example (flow chart) from input to output`, `…ention Orca as well as the decision-making engine.`, `…love items around, make the AI less generic, bigger, more impactful. Rearange the output to be smaller (style of next slide is pretty good)` `[PARTIALLY READABLE; spelling as shown]`.

- The last note is reviewer/author direction, evidence of a **draft under revision**, not of a built system.
- The score-table values are illustrative placeholders, not results.

## D05 classification and checks

| Slides | Classification | Evidence boundary |
|---|---|---|
| D05-S001 | Deck metadata / editor context | Establishes filename, title, date, deck length and workspace context only. |
| D05-S002 | Framing / problem statement | Characterises the incumbent and a PII constraint; no measurement shown. |
| D05-S003 | Prospective channel recommendation (positioning) | States intended capabilities; no estimand, data or results. |
| D05-S004 | Ambiguous mixed system/design | A conceptual architecture with placeholder values and open reviewer notes; not proof of implementation. |

## D05 claims, tensions and questions

- **Important presentation claims:** the current marketing solution is rule-based, non-adaptive and cannot personalise; a PII barrier prevents sharing customer data with external vendors; the Lumen engine `Analyses long sequences using transformers`; ORCA is the optimisation/decision-making engine sitting between scores and personalised marketing.
- **Tension (cross-deck):** D05-S003 and D05-S004 present a **Transformer Engine** as the core of the system, whereas the D04 method slides show an **XGBoost response model plus doubly robust uplift** (D04-S027, D04-S033) and place transformers only as a `Final Goal` on the industry timeline (D04-S030). Which of these describes the built system is not resolved by the slides.
- **Tension:** D05-S004 (`System Overview`, slide 4) closely resembles D04-S009 (`System Overview`, visible slide 5) — both show a Predictive branch through ORCA to Personalized Marketing alongside a Diagnostic branch. Whether these are the same asset at different revisions is not established.
- **Questions to check against code/results:** Is there a transformer model in the codebase, and if so, is it trained, evaluated, or aspirational? What is the relationship between `executive_review.pptx` (35 slides) and `DR_Shap_executive.pptx` (61 slides) — sibling drafts, a subset, or successive versions? What does `per segment channel contribution` mean operationally, and which of the D04 attribution outputs would populate it? What is the evidence base for the incumbent being non-adaptive? Does the PII constraint bear on which data sources or vendors can be used in the modelling pipeline? What is the `Appendix` section (slides 5–35)?

## D06 — `mta_biases.pptx` — “Multi-Touch Attribution Project – Introduction to Bias”

**Deck-level evidence.** Visible filename `mta_biases.pptx`; cover title **Multi-Touch Attribution Project – Introduction to Bias**; date **Dec 5, 2025**; branding `AI2 — Analytics, Insights & Artificial Intelligence`. Editor status bar reads **Slide 1 of 26**. Opened from `myteam.td.com/:p:/r/teams/TECEAIMLNewPracticeArea/_layouts/15/Doc.aspx?sourcedoc=%7B5E9F5737-21D2-4D1C-94F3-72985670227E%7D&file=mta_biases.pptx&action=edit&mobileredirect=true`. Screenshots supplied 2026-09-09; editor clock reads 3:03 AM, 9/9/2026.

- This is the **earliest-dated** deck in the file (Dec 2025), predating D04/D05 (April 2026) and D03 (July 2026). It is a methods/bias briefing rather than a results deck.
- Supplied screenshots cover visible slides **1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12**, uploaded out of slide order; IDs follow upload order. Slide numbers on two slides were not legible and are inferred from surrounding order — those are flagged.
- Account avatar initials read `AM` here; the D05 screenshot read `MA`. Both are small and low-contrast `[PARTIALLY READABLE]`; no conclusion is drawn about the account.

### D06-S001 — Cover and editor context (visible slide 1)

- Slide body: `Multi-Touch Attribution Project – Introduction to Bias`; `Dec 5, 2025`; `AI2 Analytics, Insights & Artificial Intelligence`.
- Editor: PowerPoint for the web, `Editing`, zoom 85%, `English (U.S.)`, `Slide 1 of 26`, status bar shows `Loading Add-ins`.
- Browser tabs and bookmarks match those recorded in D05-S001, with the final tab now `mta_biases.pptx`.
- Slide-panel thumbnails for slides 2–6 are visible but too small to transcribe.

### D06-S002 — Example – A simple campaign / Single Channel Experiment (visible slide 3)

Slide number **3**, footer `Internal`. Subtitle `Single Channel Experiment`. Premise: `Assume our population is divided into test and control based on a model's rank`.

| Segment | Email | Population | Conversion |
|---|---:|---:|---:|
| Rank > 50% | 1 | 1000 | 10% |
| Rank < 50% | 0 | 250 | 5% |

Four metrics, each marked with a red **✗**: `Absolute lift: +5%`; `Relative lift: +100%`; `Incremental conversions: +50`; `Incremental Percentage: 5%`.

Conclusion text: `The lower-ranked group is systematically different.` / `The 5% is biased for the top-50% segment.`

Chart labels: `Top 5 Deciles Model 1537 (EM)`; `Bottom 5 Deciles Model 1537(no touch)`; axis label `Population`.

- This is a **worked illustration of selection bias**, not a measurement. The same arithmetic as D06-S003 is deliberately marked invalid here because assignment was by model rank rather than randomisation.

### D06-S003 — Example – A simple campaign / Single Channel Test/Control (visible slide 2)

Slide number **2**, footer `Internal`. Subtitle `Single Channel Test/Control`. Premise: `Assume our population is divided into test and control based on random selection`.

| Segment | Email | Population | Conversion |
|---|---:|---:|---:|
| Test | 1 | 1000 | 10% |
| Control | 0 | 250 | 5% |

The same four metrics, each marked with a green **✓**: `Absolute lift: +5%`; `Relative lift: +100%`; `Incremental conversions: +50`; `Incremental Percentage: 5%`.

Conclusion text: `5% of test audience converted purely due to the email.` Chart labels: `Test (EM)`; `Control (no touch)`.

- Paired with D06-S002: identical numbers, opposite verdict, turning on random vs rank-based assignment. Both are constructed teaching examples with round numbers, not campaign results.

### D06-S004 — Campaign Wave 4 F25 Biases (visible slide 4)

Slide number **4**, footer `Internal`. Subtitle `Campaign Wave 4 F25 Selection Biases`. Text: `Even our test and control cells contain biases across segments` and `Example: Aeroplan Infinite Privilege – Cell ID: 6-1 & 16-1`.

A Sankey/flow diagram with visible node labels, left to right: `ORCA CC/ULOAN/ULOC` → `New/Current` → `QC/ROC` → `ITA/PA` → `ORCA CC TYPES` → `PA Lim` → `T/C`, with terminal labels `6-1`, `16-1`, `6C`, `16C` and a separate `Others` node at top right.

- Flow widths and counts are not labelled; the diagram is washed out by screen glare, so no volumes are transcribed `[PARTIALLY READABLE: node labels only]`.
- The named campaign cell (`Aeroplan Infinite Privilege`, cells 6-1 / 16-1) is presented as an example of a real campaign structure, but no data values appear on the slide.

### D06-S005 — Sources of Bias in Marketing Campaigns (visible slide 5)

Slide number **5**, footer `Internal`. Subtitle `Campaign Wave 4 F25 Selection Biases`. Lead-in: `Each campaign has several bias-inducing factors, such as:`

- `Propensity model scores (built in ORCA)`
- `Propensity model ranks (bottom/top 5 deciles)`
- `Pre-Approval (PA) limits`
- `User Zone (QC, Rest-of-Canada)`
- `Invitation Type (Pre-approved, Invitation-to-Apply)`
- `Manual Customer Profiling for Leads`
- `New vs Current Users`
- `Active + Beacon Scores`

This is the deck's enumeration of the **selection mechanism** behind campaign assignment. It is a stated list, not a quantified bias assessment.

### D06-S006 — Implicit Biases (visible slide 6, number not legible)

Slide number `[UNREADABLE: not visible in the screenshot; position inferred from slide order]`. Footer `Internal`.

**Example (Wave 4 F25 Campaign):**
- `[Email -> Reminder -> OBTM -> Lead]` — `Used for premium cards (higher response rate)`
- `[Email -> Reminder -> No other]` — `Used only for basic cards (lower response rate)`

**Example (LiDDA):** `Customer features used after attribution`. `However, there are still biases in the network:` — `Order of marketing touch points`; `Possibly Time-of-Year (in temporal embeddings)`.

Right-hand diagram: `Customer's Journey Embeddings` with columns labelled `DM TM LM RM`, combined (`+`) with `Campaign Metadata` and `Temporal Embeddings` → `Transformer Block` → `Attributions` (stacked tokens `DM`, `TM`, `LD`, `RD`); separately `Customer Embeddings` → `Aggregate` → `Target` → `Accept / Not`.

- Label inconsistency on the slide itself: the embedding columns read `LM` and `RM` while the attribution tokens read `LD` and `RD`. Transcribed as shown; not reconciled.
- The claim that touchpoint sequence is itself channel-dependent (premium vs basic cards) is a **stated design fact about the campaign**, offered as the source of implicit bias.

### D06-S007 — Bias Reduction using Adversarial Training (Selection Bias) (visible slide 8)

Slide number **8**, footer `Internal`. Heading: `Adversarial objective to obtain a bias-free latent space`.

Diagram — `Main Predictor Network`: `Data` → `Encoder Blocks` ×3 → `Latent Representation` → `Prediction Head` → `Target`. Branching down from the latent representation: `Selection Policy Prediction`, with a dashed red return arrow annotated `grad × −1` (gradient reversal).

Targets of the selection-policy head, listed at right: `User Zone`, `PA Limit`, `Model Rank/Score`, `New vs Current User`, `Top/Bottom 5 deciles`.

- This is a **proposed architecture**. `bias-free latent space` is the stated objective, not a demonstrated property; no training run, metric or diagnostic appears.

### D06-S008 — The Solution (visible slide 7)

Slide number **7**, footer `Internal`. Heading: `How do we reduce the bias?`

- `Lift calculation using Causal-inference methods` — `Inverse Propensity Weighting (IPW)`; `Doubly Robust Estimation Models`. Annotated with an arrow to `Useful for within segment analysis and cross-evaluations`.
- `Conventional ML models (tree-based methods)` — `Feature selection`; `Threshold adjustment`; `Data sampling policies`.
- `Deep-learning models` — `Adversarial training (inverse gradient layers)`; `Model architecture (inductive bias)`. Annotated with an arrow to **`Our Focus`**.

- Material for interpretation: as of Dec 2025, the deck places DR/IPW in a supporting role (`within segment analysis and cross-evaluations`) and names the **deep-learning/adversarial** track as the focus.

### D06-S009 — Bias Reduction using Adversarial Training (Order-of-Actions Bias) (visible slide 9, number not legible)

Slide number `[UNREADABLE: not visible in the screenshot; position inferred from slide order]`. Footer `Internal`. Heading: `Adversarial objective to reduce channel-order bias - CausalMTA`.

- `Reduce inherent bias in order of marketing actions`
- `The network should not be able to predict what the next marketing action is based on previous data`
- `Useful for causal or counterfactual inference`

Diagram — `Predictor Network`: `Customer Journey` tokens `DM TM LD RD` → `Transformer / RNN` → `Latent Representation Tokens` `DM TM LD RD`; a solid arrow to an adversarial branch (`DM TM LD RD`, last token shown dashed) → `Auto-Regressive Predictor` → `DM TM LD RD`, with a dashed red `grad × −1` arrow returning to the latent tokens.

- Cites **CausalMTA** by name, which also appears on the D04 industry timeline (D04-S030, dated 2022).

### D06-S010 — Architectural Inductive Bias for Causality (visible slide 10)

Slide number **10**, footer `Internal`.

- `Multi-Head Network Architecture` — `Shared encoders, separate heads (e.g., PRISM)`.
- `Causal Representation Learning` — `Disentangled latent space for confounders, treatments, and outcomes`; `For example, LiDDA provides customer features after attribution calculation`.
- `Meta Learners` — `Architectures such as T-learners, X-learners, or S-learners help to mitigate bias`.

Named options only; no selection, implementation or comparison is shown.

### D06-S011 — Brief Introduction to Causal-inference and ML Models (visible slide 12)

Slide number **12**, footer `Internal`.

**Causal inference models**
- `Inverse Propensity Weighting` — `IPW reweights samples based on treatment probabilities to simulate randomization and reduce bias in treatment effect estimation.`
- `Doubly Robust Estimation` — `Combines outcome and propensity modeling, improving estimation reliability if either model is correctly specified.`

**`ML Models (Tree-based, XGBoost) -> Current Decision: Within Segment Analysis`**
- `Feature Selection` — `Adding selection variables or removing proxy features prevents bias and ensures predictions reflect true causal relationships.`
- `Threshold Calibration` — `Adjusting decision thresholds optimizes incremental lift while maintaining fairness across user segments.`
- `Balanced Data Sampling` — `Sampling strategies like oversampling and stratification help reduce bias and maintain data representativeness.`

- The heading records an explicit **decision as of this deck**: tree-based/XGBoost work, scoped to within-segment analysis.

### D06-S012 — Progress Report (visible slide 11)

Slide number **11**, footer `Internal`.

- **`Campaign selection policy modeling`** — `Data simulation based on a campaign model`; `Time series generation`; `Acceptance, clicks, and marketing actions based on power law distributions or custom functions`.
- **`Customer segment clustering/segmentation based on selection policies:`**
  - `No-bias segments: Randomized test/controls segments`
  - `Single-bias segments: Containing one bias-inducing decision (e.g., PA limit, zone, new vs current)`
  - `Multi-bias segments: With multiple treatment options (excluding ORCA)`
- **`Basic Transformer model`**
  - `Optimization: Clipped-Muon Optimizer w/ learning rate warm-up and scheduling`
  - `Monitoring and Eval: MLFlow monitoring, saving checkpoints, and inference code`
  - `Pipeline: Eval/Test/Train splits, early stopping, and report generation`
  - `Inputs: Learnable campaign actions' embeddings, temporal embeddings`

- This is the only slide in D06 reporting **work done** rather than method options. As written, the transformer work sits on **simulated** campaign data (`Data simulation based on a campaign model`), and the segment taxonomy is constructed rather than observed. The slide does not report any metric, result or evaluation outcome.

## D06 classification and checks

| Slides | Classification | Evidence boundary |
|---|---|---|
| D06-S002, S003 | Teaching illustration of selection bias | Constructed round numbers; not campaign measurements. |
| D06-S004, S005, S006 | Selection-mechanism documentation | Names the assignment factors and sequence patterns that induce bias; no quantification of their effect. |
| D06-S007, S008, S009, S010, S011 | Method options / proposed architecture | Adversarial, meta-learner, DR/IPW and tree-based options are described as approaches; no run, metric or validation shown. |
| D06-S012 | Progress statement on simulated data | Reports build activity (simulation, segmentation, a basic transformer with MLFlow and splits) without any results. |

## D06 claims, tensions and questions

- **Important presentation claims:** lift computed across rank-split groups is biased, while the identical arithmetic on a randomised split is valid (S002/S003); even test/control cells carry segment biases (S004); campaign selection is driven by ORCA propensity scores and ranks, PA limits, zone, invitation type, manual Leads profiling, new-vs-current status and Active+Beacon scores (S005); touchpoint *sequence* differs systematically by card tier (S006); as of Dec 2025, adversarial training and architectural inductive bias are `Our Focus` (S008), while the `Current Decision` for the ML track is XGBoost within-segment analysis (S011).
- **Tension (within D06):** S008 names deep-learning/adversarial methods as `Our Focus` with DR/IPW placed in a supporting role, while S011's heading records the `Current Decision` as tree-based/XGBoost within-segment analysis. These may be different time horizons or different workstreams; the deck does not reconcile them.
- **Tension (cross-deck, material):** D06-S005 states that campaign assignment is driven by ORCA propensity scores and ranks, PA limits and zone. The D04 doubly robust design (D04-S027) models propensity from `Prism score + all Apr–May features EXCEPT channel C` — none of the ORCA/PA/zone/invitation-type selection variables named here appear in that feature list. If the D06 account of the selection mechanism is right, the D04 propensity models may omit the actual assignment drivers.
- **Tension (cross-deck):** D06-S012 reports the transformer work on **simulated** data as of Dec 2025, whereas D05-S003/S004 (April 2026) present a `Transformer Engine` as a system component and state the engine `Analyses long sequences using transformers`. Whether anything transformer-based ran on real campaign data is unresolved across all supplied decks.
- **Tension (cross-deck):** D06-S002 treats decile/rank-split lift as biased by construction, while D04-S011–S015 present decile comparisons between PRISM and Lumen as evidence. The evaluation population and split basis for those D04 charts remain unverified.
- **Questions to check against code/results:** Did the adversarial (gradient-reversal) models get built and trained, on simulated or real data, and with what result? Is `Clipped-Muon` the optimiser actually used, and are the MLFlow runs retrievable? Does the simulation code reproduce the no-bias / single-bias / multi-bias segment taxonomy, and was any estimator validated against those known-ground-truth segments? Do the production propensity models include the selection variables listed in S005 (ORCA score/rank, PA limit, zone, invitation type, new-vs-current, Active+Beacon)? What are `OBTM`, `DM/TM/LM/RM`, `LD/RD`, `ITA/PA`, `6-1 / 16-1 / 6C / 16C` in the campaign schema? Why does the S006 diagram label embeddings `LM/RM` but attributions `LD/RD`?

## D07 — `literature_review.pptx` — “Multi-Touch Attribution Project – Literature Review”

**Deck-level evidence.** Visible filename `literature_review.pptx`; cover title **Multi-Touch Attribution Project – Literature Review**; date **Dec 5, 2025**; branding `AI2 — Analytics, Insights & Artificial Intelligence`. Editor status bar reads **Slide 1 of 24**. Opened from `myteam.td.com/:p:/r/teams/TECEAIMLNewPracticeArea/_layouts/15/Doc.aspx?sourcedoc=%7BE0658B71-35E6-42DA-BD66-577F7C2C657A%7D&file=literature_review.pptx&action=edit&mobileredirect=true`. Screenshots supplied 2026-09-09; editor clock reads 3:11 AM, 9/9/2026.

- Same date as D06 (`mta_biases.pptx`, Dec 5 2025); the two appear to be companion decks from the same review, one on bias and one on literature. This is inferred from date and branding, not stated on either deck.
- This first batch covers visible slides **1, 2, 3, 4, 5, 6, 11, 13, 14, 15, 16, 17, 18** plus five slides whose printed numbers were not legible, and one close-up. IDs follow upload order.
- Several slide numbers are rendered as stacked digits at the right edge (e.g. `1` over `4` for 14) and are recorded accordingly.

### D07-S001 — Cover and editor context (visible slide 1)

- Slide body: `Multi-Touch Attribution Project – Literature Review`; `Dec 5, 2025`; `AI2 Analytics, Insights & Artificial Intelligence`.
- Editor: PowerPoint for the web, `Editing`, zoom 85%, `English (U.S.)`, `Slide 1 of 24`, status bar shows `Loading Add-ins`. Avatar initials `AM`.
- Browser tabs and bookmarks match D05-S001 / D06-S001, with the final tab now `literature_review.pptx`.
- Slide-panel thumbnails for slides 2–6 are visible but not transcribable.

### D07-S002 — Our Position in Industry (visible slide 4)

Slide number **4**, footer `Internal`. This is the **same slide** already transcribed as D04-S030 (where it carried slide number 30): identical timeline entries, TD arrow on `Rules Based`, `Final Goal` arrow on `Transformer Models`, same references and years (Logistic Regression 2011, Bayesian 2014, Survival Theory 2014, Markov Chain 2018, Shapely Value, LSTM, Causal Models 2020 CAMTA / 2022 CausalMTA, Transformer Models 2025 LiDDA / NNN). Values are not restated here.

- Evidence point: the same asset appears at slide 4 of a Dec 2025 literature deck and slide 30 of an April 2026 executive deck. The industry-positioning content therefore predates the D04 results material.

### D07-S003 — What if neither option is available? Simulated Campaigns

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`.

Heading: `2. CAMTA (2020): Compare models on simulated campaigns, using attributions to assign budgets`.

- `Metrics:` `Cost per Action (CPA): Total expenditure normalized by #Conversions (↓ is better)`; `Conversion Rate (CVR): #Conversions / #Samples (↑ is better)`.
- `Drawback: Assumes enough data are available to fill a hypothetical budget`
- `Future Direction: Models can be trained to increase CPA and CVR using RL`

Worked example, left to right:

| Estimated Contributions | Assume a Budget |
|---|---|
| DM 10% | $1 |
| TM 25% | $2.5 |
| LD 50% | $5 |
| RD 15% | $1.5 |

`Total Budget: $10`. Then `Sample from test data to fill the budget`:

| Cost & Contact | Response & ROI |
|---|---|
| 1 DM @ 0.8 each | 1 YES & $2 ROI |
| 1 TM @ 2.5 each | 0 YES & $0 ROI |
| 2 LD @ $2.5 each | 1 YES & $50 ROI |
| 10 RD @ $0.15 each | 2 YES $10 ROI |

`Performance (CPA-CVR)`: M1 `$9.4 – 10%` (green ✓); M2 `$10.4 – 8%` (red ✗).

- Internal inconsistency on the slide: CPA is defined as better when lower, but the future-direction line says models can be trained to **increase** CPA and CVR. Transcribed as written.
- CAMTA is dated **2020** here; the summary table in D07-S013 dates `Camta` to **2021**.

### D07-S004 — Multi-Touch Attribution Overview (visible slide 2)

Slide number **2**, footer `Internal`.

**Problem** — `How do we measure the contribution of each marketing channel?`; `What channels should the acquisition be attributed to?`

**Example: A Customer's Journey** — `Mobile Banner` (June 5th) → `Clicked on Email` (June 12th) → `Lead Appointment` (June 20th) → `CC Opened` (July 7th). Annotation under the first two steps: `To what degree did Mobile Banner and received Email influence this Customer?`

A framing example with illustrative dates; not a real customer record.

### D07-S005 — Why Evaluation is important (visible slide 5)

Slide number **5**, footer `Internal`.

**How are attributions used in practice?** — `Channel attributions used for ROI adjustments and Budget optimization. We cannot run a campaign for each model.`

Two pies with legend `DM`, `LD`, `TM`, `RD`:

- `Channel Contributions`: labels visible are 10%, 8%, 59% and one segment `[PARTIALLY READABLE: reads as 23% or 25%, obscured by the 3-D pie face]`.
- `Budget`: `$100`, `$150`, `$800`, and one segment `[PARTIALLY READABLE: appears to be $300]`.

Arrow to three goals: `Maximize ROI`; `Maximize Conversion`; `Minimize Cost per Contact`.

**What are common factors that cause attribution error?**
- `Error in the training/modeling phase. Such as:` `Biases caused by customer profiles, not captured due to campaign simplification`; `Model's output on out-of-distribution data is unreliable`
- `Assumptions during attribution measurement. For instance:` `Shapley assumes channel contributions are given`; `Sample size bias, Seasonality bias`

- The stated limitation that Shapley assumes channel contributions are given is relevant to the SHAP-vs-DR comparison presented in D04-S023/S024.

### D07-S006 — How are attributions evaluated in literature? (visible slide 6)

Slide number **6**, footer `Internal`.

**Problem Definition**
- `We need the actual, real contributions of each channel to properly evaluate any method`
- `But how can we measure the real contributions without any bias?` — `Qualitative insights from marketing team.`; `Marketing Mixed Models (MMM)`; `Controlled Experiments (exponential, 8 tests for 3 channels)`

Diagram: `Channels` — `Direct Mail (DM)`, `Telemarketing (TM)`, `Leads (LD)`, `Radar (RD)` → `ML Model / Statistical Methods` → `Estimated Contributions` 10%, 25%, 50%, 15% → compared (`?`) against `Real Contributions`, all four shown as `?`.

- The four-channel DM/TM/LD/RD taxonomy used throughout this deck is a **teaching abstraction**, and does not match the nine-channel schema in D04. `Radar` is defined here as `RD`.
- Core stated problem: ground-truth contributions are unavailable, so evaluation is the open question. This is the deck's central premise.

### D07-S007 — Executive Summary – What gets measured gets automated (visible slide 3)

Slide number **3**, footer `Internal`.

**Motivation**
- `How effective is Direct Mail at influencing customers?`
- `What are the most successful channels at driving conversions and revenue?`
- `Are the marketing investments justified?` — `Direct Mail is consuming 80% of the budget, however, contributes only 60% of the widgets/SVA.`
- `Where should we double down for the most impact?`

**Objective** — `Develop a data-driven approach.`; `Assess incremental channel contributions.`; `Be automated and scalable.`

**Marketing Applications** — `ROI adjustments`; `Budget optimization`; `Channel utilization monitoring`

- The 80%/60% figure is stated without source, period or definition of `widgets/SVA`. Recorded as a presented claim.

### D07-S008 — Close-up: cover slide

Close-up of the D07-S001 title slide; confirms `Multi-Touch Attribution Project – Literature Review`, `Dec 5, 2025` and the AI2 lockup. No new content.

### D07-S009 — Attention in Action

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`.

**Results**
- `Model scores is almost consistent with experiments`
- `Attention weights for attribution is better than the predicted conversions of the response model`

Chart: `ATTRIBUTION SCORES OVER 3 REPETITIONS`. Three series: `LiDDA (Attentions)` (light green), `Marginal Attribution (Controled experiments)` (mid green, spelled thus on the slide), `LiDDA (Predicted Conversions)` (dark green). Grouped by `TEST 1`, `TEST 2`, `TEST 3`. Red hand-drawn ellipses circle the first two bars in each group. Values are transcribed in the close-up, D07-S019.

- The stated conclusion compares the light-green attention series to the mid-green controlled-experiment series (the circled pairs). No sample size, uncertainty or significance test is shown, and `3 repetitions` is the entire basis.

### D07-S010 — Types of Embeddings Used in Literature (visible slide 14)

Slide number **14** `[rendered as stacked 1/4]`. Footer `Internal`. Banner line: `Embedding is all you need!`

**LiDDA by LinkedIn for MTA**
- `Customer Company (from internal data)`
- `Customer Profile (LLM Embedding)`
- `Time Encoding` — `Time of the Week`; `Time from last Action`; `Time from Response`
- `Channel Embedding` — `Channels and Actions (Learned by training)`; `Textual descriptions (LLM Embedding)`
- `Campaign Embedding` — `Textual Description (LLM Embedding)`

**NNN by Google for MMM**
- `Ad Media Video/Image/Text (Foundation models)`
- `Search Queries (Sentence Encoders)`
- `Clicked Search (User's Metadata using LLMs)`
- `User's Locations`
- `Time encoded as aggregates over weeks`

Describes published work; no TD implementation is claimed on this slide.

### D07-S011 — LiDDA: Integrating MMM and MTA Approaches (visible slide 13)

Slide number **13**, footer `Internal`.

**Training-Time Calibration** — `MTA model should match MMM's attribution`; `Adds a penalty term to loss function`.

Left branch, `Aggregated Macro Data`:

| Channels | DM | TM | LD | RD |
|---|---|---|---|---|
| Agg Spend | $23k | $15k | $10k | $5k |
| Impression / Reach | … | … | … | … |
| Clicks / Engagement | … | … | … | … |
| Seasonality, holidays | … | … | … | … |

→ `MMM` → `Attributions`: 11%, `30%` `[PARTIALLY READABLE]`, 59%, 18%.

Right branch, `Customer Journeys`: `Cust #1` DM TM LD RD; `Cust #2` RD EL DM LD; `Cust #N` LD RD EM DM → `Data Driven Attribution` → `Attributions`: 10%, 25%, 50%, 15%.

Formula line: `LiDDA Loss = Response Model Binary Classification Loss + MMM Attributions Consistency`.

- The MMM attribution row as transcribed sums to 118%, which is inconsistent with a share decomposition. The second value is partially obscured, so this may be a reading error rather than a slide error. Flagged, not resolved.
- Two new token labels appear in the journeys (`EL`, `EM`) that are not defined anywhere in the supplied views.

### D07-S012 — LiDDA: Overview (visible slide 11)

Slide number **11**, footer `Internal`.

`Input` block: `Customer's Journey Embeddings` (columns `DM`, `TM`, `LM`, `RM`) `+` `Campaign Metadata Embeddings` (`Textual Data` → `LLM` → vectors) `+` `Time Embeddings` (`Day of Week`, `Time from Last Contact`, `Time from Response`).

Separately: `Customer Embeddings` `+` `Company Embeddings` → `Aggregate`.

Flow: input → `Single Transformer Block` → `Extract Attention Scores & Normalize` → `Attributions` (`DM`, `TM`, `LD`, `RD`); and `Aggregate` → `FFN` → `Classification (Converts? Y/N)`.

- The same `LM/RM` vs `LD/RD` label inconsistency noted at D06-S006 recurs here; transcribed as shown.

### D07-S013 — Summary (paper table, visible slide 17)

Slide number **17** `[rendered as stacked 1/7]`. Footer `Internal`. Columns: `Paper | Year | Method | Assumptions | Data | Evaluation Metrics | Notes`.

**`Data-driven Multi-touch Attribution Models` (2011)** — Method: `1. Bagged Regression Model`; `2. Probabilistic model (Equ. 3)`. Assumptions: `All 2nd degree channel interactions are available`; `Does not require channel order`. Data: `39 channels`; `72.5m users`; `1:4 pos to neg ratio`; `50k Samples for each model`. Evaluation: `Bootstrapping Accuracy to obtain lowest variation`. Notes: `Uses 2nd order probability estimation`; `Simplification of Shapley method`.

**`CausalMTA` (2022)** — Method: `Trains a de-biased response model to obtain SHAP feature contribution`; `Recursive VAE for contact journey modeling`; `Performs Weights Estimation for Ad Journeys using the RVAE`; `Reverse Gradient layer for removing channel prediction bias from model`; `Relies on Shapley to obtain contributions from response model`. Assumptions: `Customer's dynamic/static features are independent from their interactions with marketing content`. Data: `Synthetic data`; `Proprietary data`; `Public data`. Evaluation: `1. Conversion Prediction`; `2. Data Reply (utilize the return on investment [21])`; `3. CPA and CRA below`. Notes: `Tries to debias the results from channel interactions & customer features`.

**`Camta` (2021)** — Method, Assumptions and Data cells appear **empty**. Evaluation: `1. Equ. 13 and 14`; `2. Allocates budget based on estimated contributions`; `3. Uses test data to fill in the budget`; `4. Obtain actual ROI`. Notes: `Basically, measures what would happen with different budget allocations using test set`; `Makes sense, cause our end goal is to maximize ROI`.

- `Camta` is dated 2021 here, 2020 on D07-S003 and 2020 on the industry timeline (D07-S002 / D04-S030).
- `CRA` in the CausalMTA evaluation cell is not defined on the visible slides; `CVR` is used elsewhere. Transcribed as printed.

### D07-S014 — Summary of Evaluation Methods (visible slide 16)

Slide number **16** `[rendered as stacked 1/6]`. Footer `Internal`. Heading: `Applicable methods (assuming no channel order)`.

- `Inverse Propensity Weighting (on leads channel)`
  - `Example in LiDDA – Shows significant bias without reweighting`
  - `Must also include cell-number in input to show how easily the leads were selected`
  - `Marketing campaign is dictating lots of our results. Either add it to the response model input, or use it to reweight channel conversions before Shapley/attribution calculation. Might be applicable to response model outputs/contributions too (if they are converted to prob first).`
- `Bootstrapping (multiple model retraining and observing the variance)` — `Either random sampling`; `Increasing Leads participation`
- `For correlation analysis, we should do so in each cell (according to TMD)` — `Adding campaign information as input such as cell (card type) or offer details`

- This is the deck's own working plan, not a literature summary. `Marketing campaign is dictating lots of our results` is a direct statement about the team's own outputs.
- `TMD` is not expanded on the visible slides.

### D07-S015 — Summary and Next Steps (visible slide 15)

Slide number **15** `[rendered as stacked 1/5]`. Footer `Internal`.

**Summary**
- `Studied common evaluation methods for data-driven attribution estimation` — `Comparative approaches (e.g., Bootstrapping, hypothetical budget allocations)`; `Exact estimations (e.g., controlled experiments)`
- `Investigated state-of-the-art models (e.g., embeddings and transformers) for MMM and MTA`

**Next Steps**
- `Design tests for future marketing campaigns to enable accurate MTA estimation`
- `Investigate MMM for validating channel-level attribution results`
- `Develop our response models by adding more campaigns and integrating campaign metadata`
- `Implement comparative evaluations to build a baseline/method leaderboard`
- `Collect related marketing data (e.g., PRISM customer embeddings, products, and campaign data)`

- As of Dec 2025 this deck describes itself as a study/investigation, with model development and evaluation infrastructure still ahead.

### D07-S016 — What if neither option is available? Observe Stability

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`.

- `Some methods can be used to compare models and select the best one:`
- `1. Measurement Stability Indicators (e.g., bootstrapping, k-fold, leave-a-profile-out cross-validation)`
  - `The variance between multiple tests indicates which model is more stable`
  - `Drawback: If prediction quality is low, the differences would not be statistically significant`

Diagram: `Channels` (DM, TM, LD, RD) → `ML Model / Statistical Methods` fed by `Test Data` → `Estimated Contributions` (10%, 25%, 50%, 15% plus unlabelled grey cells) → `Performance AUC ± STD`: **M1 74±2%** (✓) vs **M2 76±10%** (✗).

- The worked example makes the point that a higher point estimate with wide variance is rejected in favour of a lower, tighter one. These are illustrative numbers.
- Relevant to D04: the DR/SHAP attribution values in D04-S023/S024 are reported to four decimals with **no** variance, which is the diagnostic this slide argues is necessary.

### D07-S017 — Attention for Attribution Estimation

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`.

- `Using attention weights instead of response model probability results in better estimates`
- `Recent papers have adopted this strategy, e.g., LiDDA, NNN, and CausalMTA`
- `This can be as simple as average pooling the attention scores of each channel`

Diagram: `Customer Journey` (DM, TM, LD, RD) → `Transformer / RNN` → `Attention Scores` → `Normalize / FFN` → `Attributions` 10%, 25%, 50%, 15%.

- `CausalMTA uses attention layers to predict customers' journey, instead of response classification`
  - `Idea: A model should not have the ability to recall customer's journey during training`
  - `Method: Embeddings are passed to reverse-gradient layers to decorrelate them from customer's journey`
  - `Why: Useful for counterfactual inference`

### D07-S018 — Summary (LiDDA table row, visible slide 18)

Slide number **18** `[rendered as stacked 1/8]`. Footer `Internal`. Same table structure as D07-S013; this view shows the `LiDDA by LinkedIn` row, dated **2025**.

**Method** — `1. Transformers (for no modeling bias)`; `2. Time modeling -> discrete time embedding (time from response) + day-of-week embedding + tAPE for touch sequence IDs`; `3. Trains a response model, inputs are user journey`; `4. From the model, aggregated attention weights are normalized and presented as probability (sum=1), representing relative credits within the path`; `5. Uses MMM as macro-factor via post training calibration (also accounts for missing exposure data)`; `6. Final score is the sum of attentions… weird, no softtmax with temperature to tune` (spelled thus); `7. Channel Attribution from MMM is given as an auxiliary loss to the model (path level or batch level)`.

**Assumptions** — `Represents touchpoints as learned embeddings, concatenates with time embeddings and campaign metadata embedding, passes through MHA (extracts contributions here), then merges with customer (+company) embeddings, and passes through FF layers for response modeling`; `Summary: convert everything to an embedding and pass it to a transformer`.

**Data** — `Data levels:` `Member level – as member embedding + member company embedding + Sequence of touch-points`; `Aggregate level`; `Macro Factors (MMM)`. `The data is down sampled/sessionized to mimic fair frequency of touches. E.g. grouped touches.`

**Evaluation Metrics** — `Offline:` `10-fold accuracy for stability analysis`; `Anderson-Darling statistic (temporal consistency)`; `Bootstrap the data to obtain confidence intervals`. `Online:` `Attribution calculation using hold-out set`; `Inverse Propensity Weighting [11] (removing one channel and seeing the effect)`.

**Notes** — `According to their results:` `Data-driven Multi-touch Attribution Models has a bias that early touches have larger incremental changes before plateauing as paths grow in length`; `LSTM-based methods have a bias towards end-of-path touches`. `How does it address the attention sinks? (There's some zero padding, but no solution)`. `Another limitation is the encoder type modeling, where feature representations are carried over to the final layer.`

- The Notes column contains the author's own critical reading (`weird, no softtmax…`, `How does it address the attention sinks?`), which is evidence of review rather than adoption.

### D07-S019 — Close-up: attribution scores over 3 repetitions

Close-up of the chart in D07-S009. Series and grouping confirmed. Bar labels are printed vertically and partly blurred:

| Group | LiDDA (Attentions) | Marginal Attribution (Controlled experiments) | LiDDA (Predicted Conversions) |
|---|---:|---:|---:|
| TEST 1 | `7.6?` `[PARTIALLY READABLE]` | `8.68` `[PARTIALLY READABLE]` | 12.54 |
| TEST 2 | `14.06` `[PARTIALLY READABLE: could be 14.96]` | `14.?5` `[PARTIALLY READABLE]` | 19.61 |
| TEST 3 | `15.21` `[PARTIALLY READABLE: could be 16.21]` | 12.54 | 9.54 |

- The units of these scores are not labelled on either view.
- Reading the circled pairs as the slide instructs: TEST 1 and TEST 2 show attentions below the controlled-experiment value, TEST 3 above it. The direction of the gap is not consistent across the three repetitions.

### D07-S020 — LiDDA: Inverse Propensity Weighting (IPW) for Actual Attribution Calculation

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`.

**Objective** — `Obtain Actual Attribution of a particular channel`; `Used to evaluate a response model (like ours)`.

**Requirements** — `Controlled experiments for the channel being studied to isolate its impact (lift)`; `Requires "Treatment vs. Control (i.e., no treatment)"`; `All other variables and experimental settings should ideally remain the same`.

**Evaluation Steps**
1. `An Inverse Propensity (IP) model is trained to predict if the customers has received the treatment` — `Inputs: customer features, such as age, geo, history, etc.`
2. `Obtains the conversion rates: a) Treatment group, and b) Control group (no treatment)`
3. `Adjusts the control group's conversion rate using the IP model's outputs`

- The parenthetical `(like ours)` marks this as the intended evaluation route for TD's own response model, and it states a **controlled experiment as a requirement**.

### D07-S021 — Summary (NNN table row, visible slide 19)

Slide number **19** `[rendered as stacked 1/9]`. Footer `Internal`. Same table structure as D07-S013 / D07-S018; this view shows the `NNN by Google` row, dated **2025**.

- **Method** — `1. Only works for MMM`; `2. Trains a model on all available input data to predict sales (+ search)`; `3. Uses the model to calculate attribution of sales using the simple percentage formula (1 media excluded)`.
- **Assumptions** — cell is **empty**.
- **Data** — `Aggregate information`; `Embeddings: Search, Market, Ad, Customer`.
- **Evaluation Metrics** — `1. Accuracy`; `2. R-squared`.
- **Notes** — cell is **empty**.

### D07-S022 — LiDDA: MMM Integration – Output Calibration (visible slide 22)

Slide number **22** `[rendered as stacked 2/2]`. Footer `Internal`. Header: `LiDDA: Data Driven Attribution at LinkedIn`.

- `MMM (Marketing Mix Modeling):` `Works at macro level (channel-level attribution). Captures incrementality and external factors (e.g., economy, seasonality). Cannot trace individual member journeys.`
- `DDA (Data-Driven Attribution):` `Works at micro level (touchpoint-level attribution). Captures detailed paths but misses signals like TV, radio, or privacy-restricted data.`
- `Issue: These two systems can diverge. Marketers need a unified view that combines both.`
- `LiDDA's Solution: Training-Time Calibration` — `LiDDA teaches the DDA model during training to align with MMM's channel-level attribution by adding a penalty when DDA's channel-level totals differ from MMM's.`

Notation and objective as printed:

- `a_j(θ)`: DDA weight for touchpoint j.
- `A_c^DDA(θ) = Σ_{j:chan(j)=c} a_j(θ)`: Total DDA weight for channel c.
- `A_c^MMM`: Channel-level attribution from MMM.
- `L_DDA(θ)`: Original DDA loss.
- `β`: Tuning parameter.
- `𝓛_total(θ) = 𝓛_DDA(θ) + β Σ_c (A_c^DDA(θ) − A_c^MMM)²`

- The slide heading says `Output Calibration` while the body and D07-S011 both describe **training-time** calibration. Transcribed as printed; not reconciled.

### D07-S023 — LiDDA: Offline Validation (visible slide 23)

Slide number **23** `[rendered as stacked 2/3]`. Footer `Internal`.

- `Prediction Stability: 10% training data for holdout, 10 subsets, retrain the attribution model on each subset and test on holdout -> should have consistent ROC-AUC and PR-AUC`
- `Attribution Stability: bootstrapping each action's weights 100 times, computing the mean for each sample, analyzing the distribution of these means, and confirming convergence as a guardrail for consistency.`
- `Offline checks (train/validation splits, bootstraps) tell us the model is statistically consistent, but they don't prove that attention-based attributions match real channel contribution.`
- `Causality -> downsampling – experiments(counterfactual, propensity) -`

Box-plot figure, x-axis `Bootstrap Mean Bias from Actual Mean`, ticks approximately −0.0010 / −0.0005 / 0.0000 / 0.0005 / 0.0010. Row labels `[PARTIALLY READABLE: small and blurred]`, read as: `Email | Click`, `Email | Open`, `Email | Send`, `LinkedIn Platform | Click`, `LinkedIn Platform | Impression`, `Paid Search | Pageview`, `Paid Search | probabilistic impression w/ Pageview`, `Paid Search | probabilistic impression w/o Pageview`, `SEO | Pageview`. No box values are transcribed.

- This is a published-method description (LinkedIn's own validation), not a TD result. The stated limitation — statistical consistency does not prove attributions match real channel contribution — is the same distinction D07-S006 opens with.

### D07-S024 — LiDDA: Online Validation (visible slide 24)

Slide number **24** `[rendered as stacked 2/4]`. Footer `Internal`.

- `Lift Test: Hold out email in control; attribution should stay similar in control and treatment since emails are rare.` — `Result: Randomization is healthy → A/B test is reliable.`
- `Attribution metric: Experimental attribution = lift between original (S) vs counterfactual paths (S-T_EM); compare against DDA attention-based attribution.`
- `IPW adjustment: Estimate propensity from member embeddings; weight control samples with e_i/(1−e_i) to estimate counterfactual conversion for treatment.` — `Compare conversion probabilities with and without email touches.`; `Use Inverse Propensity Weighting (IPW) to adjust for bias.`

`Step 1: Estimate each member's treatment propensity, and responding IPW`

- `e_i = P(Z_i = 1|E_M_i)`, `w_i = 1 if Z_i = 1; e_i/(1−e_i) if Z_i = 0`

`Step 2: Compute the attribution`

- `â^exp(T^h) = [P̂₁(Y = 1|S = S₁) − P̂₁(Y = 1|S = S₁ − T^h)] / P̂₁(Y = 1|S = S₁)`
- `by plugging in P̂₁(Y = 1|S = S₁) = (Σ_{i:Z_i=1} Y_i)/(Σ_{i:Z_i=1} 1)`
- `P̂₁(Y = 1|S = S₁ − T^h) = Σ_{i:Z_i=0} w_i Y_i / Σ_{i:Z_i=0} w_i`

Subscripts and hats are small; the formulas are transcribed as read `[PARTIALLY READABLE: index notation]`.

- Note the structure: LinkedIn's online validation rests on an actual **held-out control**, with IPW used to adjust that control — not as a substitute for it.

### D07-S025 — Multi-Touch Attribution and Media Mix Model – Strategy Overview

**Numbering conflict — RESOLVED.** This slide belongs to `Channel_Attribution_plan.pptx`, where it is slide 2 (see D10-S014); it is a stray screenshot, not part of D07. The original observation is retained below. The printed slide number is **1**, but D07-S001 is the deck's title slide, also slide 1. The layout also differs from every other D07 slide: no `MTA` left header, full-width title. This screenshot may be from a different file or a different version open in the same session. Recorded here as supplied, with the conflict flagged rather than resolved. Footer `Internal`.

**Objectives**
- `Quantify true incremental impact across channels`
- `Enable data-driven budget allocation`
- `Build a scalable measurement framework`

**Marketing Applications** — `Budget optimization`; `Channel contribution clarity`; `Customer journey personalization`. Closing line: `From measurement transparency -> to AI-driven optimization`.

**Industry Positioning** (timeline) — `Rules Based`; `Logistic Regression 2011`; `Bayesian 2014`; `Survival Theory 2014`; `Shapely Value 2018`; `Causal Models 2020`; `Transformer Models 2025`.

**Roadmap**
| Phase | Method | Bullets | Date |
|---|---|---|---|
| Phase 1 | Shapley Value | `Fair and explainable credit allocation`; `Game-theory framework` | `Jan 2026` |
| Phase 2 | Doubly Robust | `True incremental impact measurement`; `Bias correction - confounding` | `Apr 2026` |
| Phase 3 | Transformer Model | `Sequence-aware AI decision engine`; `Cross-channel interaction learning` | `Sep 2026` |

- This is the **first dated plan** in the file that ties methods to delivery months, and it lines up with the other decks: the D04 doubly robust executive deck is dated April 1st 2026, matching Phase 2's `Apr 2026`. Phase 3 (Transformer Model) is dated **Sep 2026**, i.e. the current month at the time these screenshots were taken.
- The timeline here assigns **2018 to Shapely Value** and omits Markov Chain and LSTM, whereas the D07-S002 / D04-S030 version assigns 2018 to Markov Chain and gives Shapely Value no year. Same content, different attribution of the 2018 marker.

### D07-S026 — LiDDA: System Overview (visible slide 20)

Slide number **20** `[rendered as stacked 2/0]`. Footer `Internal`.

- `Goal: Predict Conversion Probability (Binary Classification): P(Y | E_M, E_C, S)` — `Y: Conversion outcome`; `E_M: Member Embedding (skills, titles, etc.)`; `E_C: Company Embedding (industry, roles, etc.)`; `S: Sequence of marketing touchpoints`.
- `Attention Heads:` `Traditional models miss sequential and contextual relationships between touchpoints.`; `Attention assigns weights to focus on the most impactful ones.`
- `Output:` `Normalized attention weights for each touchpoint in the sequence`
  - `Problem:` `Weights are relative credit per touchpoint within a path,` `not the absolute incremental impact across all channels.`
- `MMM Integration:` `Rescales MTA outputs for incrementality and missing exposure data`

- Material limitation stated on the slide itself: attention weights are **relative credit within a path**, not absolute incremental impact across channels. This qualifies the D07-S009 claim that attention weights are "better" for attribution, and is the stated reason MMM rescaling is needed.

### D07-S027 — LiDDA: Path Creation, Positional Representations, Attention Mechanism (visible slide 21)

Slide number **21** `[rendered as stacked 2/1]`. Footer `Internal`.

**Path Creation**
- `Sequence Representation:` `Touchpoints = (Channel, Action) pairs`; `Examples: (EMAIL, OPEN), (AD, CLICK)`
- `Touchpoint Embeddings:` `Learned embedding E_T for each touchpoint`
- `Campaign Embeddings:` `E_MCID semantic embedding on campaign's description generated by internal LLM`

**Positional Representations**
- `Challenge: Attention doesn't model order by default`
- `Solution:` `Sinusoidal positional encodings (adapted for smaller dimensions) -> Time Absolute Position Encoding (tAPE)`
- `Additional embeddings:` `Time interval (days until conversion) → E_D`; `Day-of-week (captures seasonality) → E_DOW`
- `Final touchpoint representation:` `Concat(E_MCID, E_T) + E_D + E_DOW + tAPE`

**Attention Mechanism**
- `Attention lets each element in a sequence consider all other elements when forming its representation, weighting marketing touchpoints based on their interactions to predict conversion.`
- `In LiDDA, self-attention is applied to marketing engagements, with multi-heads focusing on different attribution patterns (e.g., recency patterns, channel interactions, seasonality).`
- `Interpretability: attention weights significantly influence model predictions.`
  - `Challenge: Weights may not perfectly reflect causal impact.`
  - `Alternative methods (incremental propensity, Shapley) offer no clear advantage.`

- The `(Channel, Action)` touchpoint construction here is the same shape as the event-level labels in D04-S026 (`Email_OPEN`, `Paid_Search_CLICK`).

## D07 classification and checks

| Slides | Classification | Evidence boundary |
|---|---|---|
| D07-S001, S008 | Deck metadata | Filename, title, date, deck length only. |
| D07-S004, S007 | Framing / problem statement | Illustrative journey and motivating figures; the 80%/60% budget-vs-contribution claim is unsourced. |
| D07-S002 | Positioning / literature timeline | Same asset as D04-S030. |
| D07-S005, S006, S016, S020, S014 | Evaluation methodology | Describes how attribution could be validated (controlled experiments, MMM, IPW, stability). No TD evaluation is reported. |
| D07-S003, S010, S011, S012, S013, S017, S018 | Literature review | Descriptions of published methods with the author's own critical notes. Not TD implementations. |
| D07-S009, S019 | Reported experimental result | The only numbers in this batch presented as an outcome: three repetitions, no uncertainty, unlabelled units, unstated data source. |
| D07-S015 | Progress / plan statement | Positions the work as study plus a forward plan. |
| D07-S021–S024, S026, S027 | Literature review (LiDDA/NNN detail) | Method, calibration objective and LinkedIn's own validation design, transcribed from published work. No TD run. |
| D07-S025 | Dated roadmap / positioning | Commits methods to months (Jan/Apr/Sep 2026); a plan, not a record of delivery. Slide-number conflict flagged. |

## D07 claims, tensions and questions

- **Important presentation claims:** ground-truth channel contributions are unavailable, so evaluation is the core difficulty (S006); attributions drive real ROI and budget decisions and a campaign cannot be run per model (S005); Direct Mail takes 80% of budget for 60% of widgets/SVA (S007); attention weights give better attribution estimates than response-model predicted conversions (S009, S017); a model with a higher but wide-variance AUC should lose to a tighter one (S016); IPW for actual attribution **requires** a controlled experiment (S020).
- **Tension (cross-deck, important):** S020 states that obtaining actual attribution for a channel requires a controlled treatment-vs-control experiment, and S015's next steps are to *design* such tests. D04 (April 2026) reports channel-level DR attributions and a prospective Next Best Channel allocation without any experiment being shown. Whether the tests in S015 were ever run is unresolved.
- **Tension (cross-deck):** S016 argues that variance across repetitions is the basis for model selection; D04-S023/S024 report attribution values to four decimals with no variance or confidence intervals.
- **Tension (within deck):** CAMTA is dated 2020 on S003 and on the timeline (S002), but 2021 in the summary table (S013).
- **Tension (within deck):** S003's future-direction line says models can be trained to `increase CPA and CVR` while the same slide defines lower CPA as better.
- **Tension (within deck):** S009 concludes attention weights are better than predicted conversions, but the three circled comparisons in S019 do not go the same direction (attentions below the controlled-experiment value in tests 1–2, above it in test 3).
- **Note:** the DM/TM/LD/RD channel abstraction used throughout D07 (Direct Mail, Telemarketing, Leads, Radar) does not correspond to the nine-channel schema in D04, and `Radar` does not appear in any other supplied deck.
- **Important presentation claims (second batch):** LiDDA's attention weights are `relative credit per touchpoint within a path, not the absolute incremental impact across all channels` (S026), which is why MMM rescaling is applied; offline stability checks `don't prove that attention-based attributions match real channel contribution` (S023); LinkedIn's online validation uses a real held-out email control with IPW adjusting the control (S024); `Alternative methods (incremental propensity, Shapley) offer no clear advantage` over attention weights (S027).
- **Tension (within deck):** D07-S009 concludes attention weights are better for attribution, while S026 states plainly that those weights are path-relative credit rather than absolute incremental impact, and S023 states offline consistency does not establish that they match real contribution. The S009 claim is stronger than the method slides support.
- **Tension (within deck):** D07-S025's roadmap dates Shapely Value to 2018 and omits Markov Chain and LSTM; D07-S002 / D04-S030 give 2018 to Markov Chain and no year to Shapely Value.
- **Tension (within deck, minor):** D07-S022 is titled `Output Calibration` but describes training-time calibration, consistent with D07-S011's title.
- **Timeline evidence:** D07-S025 dates Phase 1 Shapley to Jan 2026, Phase 2 Doubly Robust to Apr 2026 and Phase 3 Transformer to Sep 2026. D04 (`DR_Shap_executive.pptx`, dated April 1st 2026) matches Phase 2; the D05/D06 transformer material is Phase 3, dated the current month. This is a plan, and none of the supplied decks show a Phase 3 delivery.
- **Questions to check against code/results:** What produced the `ATTRIBUTION SCORES OVER 3 REPETITIONS` chart — which dataset, which channel, what units, and is the code retained? Were the controlled experiments in S015/S020 ever designed or run, and if so where are the results? Was MMM ever used to validate channel-level attribution as planned? What is `Radar (RD)` in TD's channel schema, and what are `EL`/`EM` in the S011 journeys? What are `TMD`, `CRA`, and `widgets/SVA`? What is the source and period for the 80%/60% Direct Mail figure? Do the MMM attributions on S011 sum to 100%?

## D08 — `Channel_Attribution_Doubly_Robust_demo.pptx` — “MTA – Doubly Robust Estimate”

**Deck-level evidence.** Visible filename `Channel_Attribution_Doubly_Robust_demo.pptx`; cover title **MTA – Doubly Robust Estimate**; date **Dec 5, 2025**; branding `AI2 — Analytics, Insights & Artificial Intelligence`. Editor status bar reads **Slide 1 of 20**. Opened from `myteam.td.com/:p:/r/teams/TECEAIMLNewPracticeArea/_layouts/15/Doc.aspx?sourcedoc=%7BBD7D8273-299E-4EEB-B9A2-ED425AB96FC2%7D&file=Channel_Attribution_Doubly_Robust_demo.pptx&action=edit&mobileredirect=true` `[PARTIALLY READABLE: leading GUID characters]`. Screenshots supplied 2026-09-09; editor clock reads 3:13 AM, 9/9/2026.

- Third deck dated **Dec 5, 2025**, alongside D06 (`mta_biases.pptx`) and D07 (`literature_review.pptx`). This one carries the **actual DR run**: model diagnostics, per-channel overlap plots and attribution outputs.
- The channel set here is **five**: `channel_Email`, `channel_Leads`, `channel_Direct_Mail`, `channel_EasyLine_IVR`, `channel_Ebank_Telemarketing`. This matches neither D04's nine channels nor D07's DM/TM/LD/RD teaching set.
- First batch covers visible slides 1–12 plus eight slides whose printed numbers were not legible. IDs follow upload order.

### D08-S001 — Cover (visible slide 1, close view)

`MTA – Doubly Robust Estimate`; `Dec 5, 2025`; AI2 lockup. Status bar shows `Loading Add-ins`. No slide number printed on the title slide.

### D08-S002 — Doubly Robust Estimation Overview (visible slide 5)

Slide number **5**, footer `Internal`.

- `What is Doubly Robust?` — `Doubly robust combine two models to estimate true channel impact`; `Response (outcome) model: What would happen with vs. Without the channel`; `Propensity model: Who was likely to get the channel`.
- `The Key Benefit` — `Provides consistent estimates if either the propensity model or response model is correctly specified, offering protection against model misspecification.`

Diagram: `Propensity Model` (`Who gets which channel?`) `+` `Response Model` (`What happens with vs. Without channel?`) → `Doubly Robust Estimator` (`Response Model Estimate + Correction Term based on Propensity`).

### D08-S003 — Bias from Targeted Channel Assignment (visible slide 3)

Slide number **3**, footer `Internal`.

**Bias Problem**
- `The journey we see is not random. Marketing flags customers for certain channels based on their features.`
- `High propensity customers are intentionally targeted with stronger channels.`

Diagram: `Model Scores` (`April 30th`) → `Channel Assignment` (`May 30th`) → `A Customer's Journey:` `Mobile Banner` (June 5th) → `Clicked on Email` (June 12th) → `Lead Appointment` (June 20th) → `CC Opened` (July 7th).

- The dated sequence (scores April 30 → assignment May 30 → journey from June 5) is the same temporal design as D04-S008's `Time Window Selection`.

### D08-S004 — Multi-Touch Attribution Overview (visible slide 2)

Slide number **2**, footer `Internal`. Content is identical to D07-S004 (same `Problem` bullets, same four-step example journey with the same dates and the same `To what degree did Mobile Banner and received Email influence this Customer?` annotation). Values are not restated here.

- Evidence point: the same framing slide appears at slide 2 of both the Dec 2025 literature deck and the Dec 2025 DR deck.

### D08-S005 — Response Model Channel Contribution (visible slide 6)

Slide number **6**, footer `Internal`.

**Response Model**
- `Trained on customers and their responses to channels (5 binary features + customer features)`
- `Estimates conversion probability for each customer under different channel setting (email₀, email₁)`
- `Generates counterfactuals' response probability by toggling the channel (keep other features fixed)`

Diagram (`For all customers`), `Channels` + `Customer Features`: two blocks differing only in the Email flag — first block `Direct Mail 0, Telemarketing 1, Leads 1, Email 1, EasyLine 0`; second block `Direct Mail 0, Telemarketing 1, Leads 1, Email 0, EasyLine 0`. Feature-id column reads `1524`, `1536`, `1537`, `1538`, `1572` `[PARTIALLY READABLE]`. Both feed `Response Model`, producing `Response Probability if emailed` and `Response Probability if not emailed`; `Subtract` → `Email Baseline Incremental Lift`.

**The Limitation**
- `Customer Features included → model adjusts for confounding and baseline propensity`
- `However: Only protected if response model is perfectly specified`

- Note the channel list here uses `Telemarketing` where later slides use `Ebank_Telemarketing`, and `EasyLine` for `EasyLine_IVR`.

### D08-S006 — Propensity Weighting Example – Calculating LEADS Attribution (visible slide 8)

Slide number **8**, footer `Internal`. Two worked customers, both described as having converted.

**Left — `Expected Target Customer converted`**
- Customer features `0.8, 0.7, 0.9, 0.8, …` → `Leads Propensity Model` → **0.9**, `Likely to receive leads channel`
- Channel flags: `Direct Mail 0, Telemarketing 0, Leads 1, Email 0, EasyLine 0`; counterfactual block all `0`
- `Response Model` → **0.25** `Response score when contacted = PR₁`; **0.22** `Response score when not contacted = PR₀`
- Formula: `PR₁ − PR₀ + (Actual response − P(response) when treated) / propensity`
- `Lower DR Contribution = 0.86`

**Right — `Surprise Target Customer converted`**
- Customer features `0.2, 0.4, 0.4, 0.7, …` → `Leads Propensity Model` → **0.1**, `Unlikely to receive leads channel`
- `Response Model` → **0.08** `Response Probability when contacted = PR₁`; **0.02** `when not contacted = PR₀`
- Same formula; `Higher DR contribution 9.26`

Bottom: `Average(0.86, 9.26, … all customers)` → `Leads Attribution`.

- The two per-customer DR contributions (0.86 and 9.26) are far outside a probability scale, which is what an inverse-propensity correction with a small denominator produces. The slide presents this as the intended behaviour (`Fairness weight`, D08-S010) without discussing variance, trimming or clipping. Recorded as presented.

### D08-S007 — Close-up: ATE vs Shapley pies (from visible slide 10)

Close-up of the two pies on D08-S009. Left, `Absolute Average Treatment Effect (ATE) by Channel`; right, `Shapley Values by Channel`.

| Channel | Absolute ATE share | Shapley share |
|---|---:|---:|
| leads | 62.3% | 67.3% |
| ebank | 15.8% | 12.0% |
| directmail | 8.4% | 6.6% |
| email | 7.6% | 10.0% |
| easyline | 5.8% | 4.1% |

- The left chart is explicitly labelled **Absolute** ATE, i.e. shares of |ATE|. D08-S013 shows that two of these channels have **negative** ATE, so a positive share here does not mean a positive effect.

### D08-S008 — The Doubly Robust Pipeline (visible slide 9)

Slide number **9**, footer `Internal`.

- `Phase 1: Data ingestion` — `Customer Profile Score`; `5 Channel Flags`; `Conversion Target`.
- `Phase 2: Dual AI Models` — `Multi-label Propensity Model — Predicts P(Channel 1..5 | Profile)`; `Outcome Baseline Model — Predicts P(Conversion | Profile & Channels)`.
- `Phase 2: Statistical Safeguards` — `Probability Calibration`. `[The slide labels two different boxes "Phase 2"; there is no Phase 3. Transcribed as printed.]`
- `Phase 4: Causal Aggregation` — `Doubly Robust Aggregator` → `True Incremental Lift (Per Channel)`.

Arrow labels: `profiles`, `Observed features`, `Raw scores`, `Actual Treatment`, `Actual Conversion`.

- This slide says **one multi-label propensity model** predicting all five channels; D08-S010 and D08-S012 both say **one propensity model per channel** (five models). Flagged.

### D08-S009 — Doubly Robust Comparison with Shapley Values (visible slide 10)

Slide number **10**, footer `Internal`.

**Modeling Details**
- `Results visualized on a 10K-customer subset from the test set`
- `Model scores calibrated to correct for negative downsampling`

**Analysis**
- `Leads, eBank Telemarketing, and Direct Mail receive the highest attribution`
- `Consistent with response enhanced shapley value method`

Charts are transcribed in D08-S007.

- The `highest attribution` claim holds for the DR pie (62.3 / 15.8 / 8.4) but not for the Shapley pie, where **email (10.0%) exceeds directmail (6.6%)**. Flagged.
- `10K-customer subset from the test set` is the only stated evaluation population in this deck.

### D08-S010 — The Doubly Robust "Safety Net" (visible slide 7)

Slide number **7**, footer `Internal`.

**Propensity Models**
- `One model per channel predicts how likely a customer is to receive that channel given their profile.`
- `Isolates the "assignment logic" and captures how targeting decisions are made.`
- `Enables re-weighting the data to mimic a randomized trial.`
- `Used as a Fairness weight` — `Unlikely-but-treated → more credit`; `Likely-and-treated → less credit`

Diagram (`For each Channel`): `Customer Features` (`1524`, `1536`, `1537`, `1538`, `1572`) → `Propensity Model` → `Score this customer would be assigned the channel (the higher the more likely)`.

Speaker notes, cropped at the left edge: `…mer was unlikely to get the treatment and got it -> higher attribution`; `…mer was likely to get treatment and actually got it -> lower attribution` `[PARTIALLY READABLE]`.

### D08-S011 — Roadmap – F26 (visible slide 12)

Slide number **12**, footer `Internal`. Header block: `Development Timeline & Roadmap`.

| Date | Milestone |
|---|---|
| Nov 2025 | `Planning & Design` |
| Dec 2025 | `Phase 1 Release` |
| Dec 2025 | `Phase 1 Showcase` |
| Jan 2026 | `Phase 2 Planning & Design` |
| April 2026 | `Phase 2 Release` |
| May 2026 | `Showcase` |
| June 2026 | `Phase 3 - Further Development` |
| Sep 2026 | `Phase 3 Release` |

| Phase | Objectives | Notes |
|---|---|---|
| Phase 1 | `Shapley value and Doubly Robust approaches` | `Replicate previous works, obtain a baseline` |
| Phase 2 | `Transformer Model` | `Unifies Media Mix Model` |
| Phase 3 | `Further R&D` | (blank) |

- **Conflicts with D07-S025.** There, Phase 1 = Shapley (Jan 2026), Phase 2 = Doubly Robust (Apr 2026), Phase 3 = Transformer (Sep 2026). Here Phase 1 = Shapley **and** Doubly Robust (Dec 2025), Phase 2 = Transformer (Apr 2026), Phase 3 = Further R&D (Sep 2026). Same dates, different phase contents.
- `Replicate previous works, obtain a baseline` characterises the Phase 1 DR work — including everything in this deck — as a **baseline replication**, not a validated production estimate.

### D08-S012 — Summary & Next Steps (visible slide 11)

Slide number **11**, footer `Internal`.

**Summary**
- `Reported channel contributions using Doubly robust on raw data`
- `Developed a response model and 5 propensity models using MarLin-Sushi framework and extracted channel contributions`
- `Isolated true channel impact from underlying customer intent` — `Channels are credited for influence, not for finding good customers.`; `High-intent customers no longer inflate channel performance`

**Next Steps (Phase 1)**
- `Get full access to timestamped interaction data across all channels and leverage ordered customer touchpoints`
- `Transition to a time-series / transformer-based architecture that unifies multi-touch attribution with Media Mix Models`
- `Enforce always positive contributions` — `Using simulation data`; `Within model weight during training`

- `Enforce always positive contributions` is a stated intention to constrain the **sign** of estimated contributions. As of this deck two channels estimate negative (D08-S013). Recorded without interpretation of intent.
- `MarLin-Sushi framework` is named here and nowhere else in the supplied evidence.
- The next-steps bullet about timestamped interaction data implies the DR results in this deck were produced **without** ordered touchpoint timing.

### D08-S013 — Comparison with Shapley (bar charts)

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`.

Left chart, `Doubly Robust ATE Comparison by Channel`, y-axis `Average Treatment Effect (Probability Lift)`, printed bar labels:

| Channel | ATE |
|---|---:|
| channel_Email | **−0.0052** |
| channel_Leads | **+0.0429** |
| channel_Direct_Mail | **+0.0058** |
| channel_EasyLine_IVR | **−0.0040** |
| channel_Ebank_Telemarketing | **+0.0109** |

Right chart, `Shapley Values (Bar Plot)`, y-axis `Value`, x-axis categories `RD`, `RW`, `LD`, `EM`, `EL`, `RM`, `ET`, `DM`. No bar labels are printed; values are not transcribed. `LD` is much the tallest (≈0.040 against the axis), with `RM` next.

- **Two channels have negative estimated ATE** (Email, EasyLine_IVR). The pies on D08-S009 present these as positive shares because they use the **absolute** value.
- The Shapley bar plot has **eight** categories against the DR chart's **five**, and uses two-letter codes that are not defined on the visible slides. Whether `RD/RW/LD/EM/EL/RM/ET/DM` map onto the five channels is not established.

### D08-S014 — Editor context (visible slide 1)

Full editor view: filename `Channel_Attribution_Doubly_Robust_demo`, `Editing`, zoom 85%, `English (U.S.)`, **`Slide 1 of 20`**, avatar `AM`, clock 3:13 AM 9/9/2026. Browser tabs and bookmarks match D05–D07, with the final tab now `Channel_Attribution_Dou…`. Slide-panel thumbnails 1–6 visible but not transcribable.

### D08-S015 — Results – channel_Email

Slide number `[UNREADABLE]`. Footer `Internal`. Title: `Results – channel_Email`.

- Left: `ATE by Propensity Decile for channel_Email (Overlap Only)`, y-axis `Average Treatment Effect`, x-axis `Propensity Decile` 0–9. No bar values are printed. Read against the axis: decile 0 is strongly negative (≈ −0.018), deciles 1–4 slightly positive (decile 1 ≈ +0.0045), deciles 5–6 near zero, deciles 7, 8, 9 increasingly negative (≈ −0.006, −0.013, −0.016). Approximate readings only; no labels exist to transcribe.
- Right: `Propensity Score Overlap - channel_Email`, `Range: 0.095 to 0.977`, x-axis `Propensity Score (e_hat_calibrated)`, densities for `channel_Email` 0 and 1 overlapping across most of the range.
- Email has genuine overlap (0.095–0.977) and **ten** decile bins, but the per-decile effect changes sign across deciles, which the single pooled ATE (−0.0052) does not convey.

### D08-S016 — Model diagnostics: ROC-AUC tables

Slide number `[UNREADABLE]`.

- `Single Response model trained on channels and model scores.` — `Out-of-fold cross-prediction and then calibrated mu_0 and mu_1 to represent actual conversion rates.`; `This is because of negative downsampling for some of the channels.`
- `Propensity models for each channel trained on model scores.` — `Out-of-fold cross-prediction and then calibrated e_hat to represent actual treatment rates.`

Response-model table (`Channel | Model | Group Used | ROC-AUC`):

| Channel | mu_0 (Control 0) | mu_1 (Treated 1) |
|---|---:|---:|
| channel_Leads | 0.7823 | 0.6619 |
| channel_Email | 0.8247 | 0.7701 |
| channel_EasyLine_IVR | 0.7838 | 0.7868 |
| channel_Ebank_Telemarketing | 0.7875 | 0.7726 |
| channel_Direct_Mail | 0.8209 | 0.7749 |

Propensity-model table (`Channel | Model | ROC-AUC`):

| Channel | ehat |
|---|---:|
| channel_Email | 0.6824 |
| channel_Leads | 0.8744 |
| channel_Direct_Mail | 0.6985 |
| channel_EasyLine_IVR | 0.6827 |
| channel_Ebank_Telemarketing | 0.7728 |

- This is the most concrete estimation evidence in any supplied deck: out-of-fold cross-fitting, explicit calibration of both nuisance models, and per-model discrimination. It does not establish overlap, uncertainty or validation against an experiment.
- Propensity AUC for Leads is the highest (0.8744), i.e. Leads assignment is the most predictable from profile — consistent with its very narrow overlap in D08-S019.

### D08-S017 — Results – channel_Easyline

Slide number `[UNREADABLE]`. Title: `Results – channel_Easyline` (chart says `channel_EasyLine_IVR`).

- Left: `ATE by Propensity Decile for channel_EasyLine_IVR (Overlap Only)`, deciles **0–8** (nine bins). Unlabelled bars: decile 0 ≈ 0, deciles 1–6 negative (decile 6 ≈ −0.009), decile 7 slightly negative, decile 8 strongly positive (≈ +0.019). Approximate readings only.
- Right: `Propensity Score Overlap - channel_EasyLine_IVR`, `Range: 0.000 to 0.842`.
- The pooled ATE (−0.0040) averages over deciles that disagree in sign, with the single positive decile the largest in magnitude.

### D08-S018 — The Confounder: Features Drive Both Treatment and Outcome (visible slide 4)

Slide number **4**, footer `Internal`.

**The confounder**
- `Customer Features drive both channel assignment and final conversion.`
- `Confounding blurs where customer intent ends and where marketing impact begins, leading to biased attribution.`
- `This bias gives credit to channels when the customer was already likely to convert without it.`

Diagram (`The Bias Problem`): `Customer Features` → `Channel Treatment` (annotated `Propensity score based model`) and `Customer Features` → `Response` (annotated `output model`); `Channel Treatment` → `Response` (annotated `causal effect`).

### D08-S019 — Results – channel_Leads

Slide number `[UNREADABLE]`. Title: `Results – channel_Leads`.

- Left: `ATE by Propensity Decile for channel_Leads (Overlap Only)` — only **two** bins (0 and 1), at roughly 0.043 and 0.09 against the y-axis. Unlabelled; approximate.
- Right: `Propensity Score Overlap - channel_Leads`, **`Range: 0.000 to 0.194`**. Both densities are concentrated near zero and fall away by ≈0.15.
- **Material observation:** Leads carries 62.3% of the absolute-ATE share (D08-S007) and the largest ATE (+0.0429), yet its propensity support tops out at 0.194 and the overlap-only analysis collapses to two decile bins. D07-S008 (`Doubly Robust Estimation Models`) and D04-S020 both list **overlap** as a required assumption. The slide reports the number without commenting on this.

### D08-S020 — Results – channel_Ebank_Telemarketing

Slide number `[UNREADABLE]`. Title: `Results – channel_Ebank_Telemarketing`.

- Left: `ATE by Propensity Decile for channel_Ebank_Telemarketing (Overlap Only)` — again only **two** bins (0 and 1), roughly 0.0108 and 0.0086. Unlabelled; approximate.
- Right: `Propensity Score Overlap - channel_Ebank_Telemarketing`, **`Range: 0.000 to 0.181`**.
- Same narrow-support pattern as Leads: the second-largest positive ATE (+0.0109) rests on propensity support confined to roughly 0–0.18.

### D08-S021 — Results – channel_DirectMail

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`. Title: `Results – channel_DirectMail` (charts say `channel_Direct_Mail`).

- Left: `ATE by Propensity Decile for channel_Direct_Mail (Overlap Only)`, y-axis `Average Treatment Effect`, x-axis `Propensity Decile` **0–9** (ten bins). No bar values are printed. Read against the axis: decile 0 ≈ 0.030, decile 1 ≈ 0.0134, decile 2 ≈ 0.0103, decile 3 ≈ 0.0070, decile 4 ≈ 0.0086, decile 5 ≈ 0.0060, decile 6 ≈ 0.0062, decile 7 ≈ 0.0047, decile 8 ≈ 0.0040, decile 9 ≈ 0.0207. Approximate readings only; no labels exist to transcribe.
- Right: `Propensity Score Overlap - channel_Direct_Mail`, **`Range: 0.016 to 0.982`**, x-axis `Propensity Score (e_hat_calibrated)`. Both densities (0 and 1) span the full range with a shared mode near 0.75–0.85.
- This completes the five per-channel `Results` slides (Email S015, EasyLine S017, Leads S019, Ebank S020, Direct Mail S021).
- **Direct Mail is the only channel whose per-decile ATE is positive in every bin**, and along with Email it is one of only two with wide propensity support (0.016–0.982) and a full ten decile bins.
- **Observation:** every decile bar read here sits at or above the pooled `channel_Direct_Mail` ATE of **+0.0058** (D08-S013), most of them well above, with the two end deciles at roughly 0.030 and 0.021. Whether this reflects bin weighting, the overlap-only restriction, or a different population than the pooled figure is not shown on the slides. Recorded as an observation, not a claim of error.

## D08 classification and checks

| Slides | Classification | Evidence boundary |
|---|---|---|
| D08-S002, S003, S004, S018 | Framing / method explanation | States the confounding problem and the DR idea; no data. |
| D08-S005, S006, S008, S010 | Estimator design | Worked illustrations with invented numbers; internally inconsistent on one-model-per-channel vs one multi-label model. |
| D08-S016 | Model diagnostics (real run) | Out-of-fold, calibrated nuisance models with per-model ROC-AUC. Discrimination only — not overlap, uncertainty or validity. |
| D08-S007, S009, S013 | Causal/uplift estimation results | Per-channel ATE and Shapley comparison on a 10K test subset. No confidence intervals, no experimental validation. |
| D08-S015, S017, S019, S020, S021 | Overlap and heterogeneity diagnostics | The strongest self-diagnostic material in the file; also where the overlap problem for Leads and Ebank is visible. |
| D08-S011, S012 | Roadmap / progress statement | Describes the work as a Phase 1 baseline replication; conflicts with D07-S025 on phase contents. |

## D08 claims, tensions and questions

- **Important presentation claims:** channel contributions were reported using DR on raw data, with one response model and five propensity models built on the `MarLin-Sushi framework` (S012); `Channels are credited for influence, not for finding good customers` and `High-intent customers no longer inflate channel performance` (S012); Leads, eBank Telemarketing and Direct Mail receive the highest attribution and this is consistent with the Shapley method (S009); DR gives consistent estimates if **either** nuisance model is correct (S002).
- **Tension:** D08-S013 shows `channel_Email` at **−0.0052** and `channel_EasyLine_IVR` at **−0.0040**, while the D08-S009 pies present both as positive shares (7.6%, 5.8%) because the chart takes the **absolute** ATE. A reader seeing only the pies would not know two channels estimate negative.
- **Tension:** the S009 `Analysis` bullet names Leads, eBank Telemarketing and Direct Mail as highest, but in the Shapley pie on the same slide email (10.0%) outranks directmail (6.6%).
- **Overlap summary across all five channels (S015, S017, S019, S020, S021):** Direct Mail 0.016–0.982 (10 bins, all deciles positive); Email 0.095–0.977 (10 bins, sign changes); EasyLine_IVR 0.000–0.842 (9 bins, sign changes); Ebank_Telemarketing 0.000–0.181 (2 bins); Leads 0.000–0.194 (2 bins). The two channels carrying the largest positive ATEs are the two with the narrowest support.
- **Tension (material):** `channel_Leads` carries 62–67% of attribution but has propensity support of only **0.000 to 0.194** with two decile bins (S019); `channel_Ebank_Telemarketing` is 0.000 to 0.181, also two bins (S020). Overlap is listed as a required DR assumption in D04-S020 and D07-S008. The deck shows these ranges without discussing what they mean for the headline numbers.
- **Tension:** S008 describes a single `Multi-label Propensity Model — Predicts P(Channel 1..5 | Profile)`, while S010 and S012 describe **one propensity model per channel** (five models).
- **Tension:** S008's phase labels run `Phase 1`, `Phase 2`, `Phase 2`, `Phase 4` — no Phase 3.
- **Tension (cross-deck):** D08-S011 and D07-S025 give the same milestone dates but different phase contents (DR in Phase 1 here vs Phase 2 there; Transformer in Phase 2 here vs Phase 3 there).
- **Tension (cross-deck):** this deck's five-channel schema differs from D04's nine and from D07's DM/TM/LD/RD, and the S013 Shapley plot introduces an eighth, undefined set of two-letter codes.
- **Note on pooled estimates:** for Email (S015) and EasyLine (S017), the per-decile ATE changes sign across the propensity distribution. A single pooled ATE conceals this, and no heterogeneity caveat appears on S009 or S013.
- **Questions to check against code/results:** What is `MarLin-Sushi`, and is the pipeline retained? What overlap trimming or propensity clipping was applied, given per-customer DR contributions of 0.86 and 9.26 (S006)? Are the reported ATEs accompanied by standard errors anywhere in the code output? Why does Leads have propensity support only to 0.194, and is the estimate for it identified at all? What are the eight Shapley categories `RD/RW/LD/EM/EL/RM/ET/DM`? What was negative-downsampled, at what rate, and does the calibration recover the true base rate? Is the 10K test subset drawn from the same cohort as the 2.6M-record base in D04? How does `Enforce always positive contributions` (S012) interact with the two negative ATEs measured here?

## D09 — `Channel_Attribution_Shapley_value_demo.pptx` — “Multi-Touch Attribution Project Demo – Phase 1”

**Deck-level evidence.** Visible filename `Channel_Attribution_Shapley_value_demo.pptx`; cover title **Multi-Touch Attribution Project Demo – Phase 1**; date **Dec 5, 2025**; AI2 lockup. Editor status bar reads **Slide 1 of 25**. Opened from `myteam.td.com/:p:/r/teams/TECEAIMLNewPracticeArea/_layouts/15/Doc.aspx?sourcedoc=%7B5F3675A1-F380-4C42-BDF1-A6D13531F975%7D&file=Channel_Attribution_Shapley_value_demo.pptx&action=edit&mobileredirect=true`. Screenshots supplied 2026-09-09; editor clock reads 3:15 AM, 9/9/2026. Avatar initials `MA`.

- **Fourth deck dated Dec 5, 2025**, alongside D06, D07 and D08. This is the Shapley counterpart to D08's doubly robust demo; together they are the Phase 1 pair named on the roadmap.
- The channel set here is **eight**, and the deck defines the two-letter codes that were undefined in D08-S013: `RD` Radar Branch/Phone Prompts, `RW` Radar Web Intercepts, `LD` Leads, `EM` Email, `EL` EasyLine IVR, `RM` Radar Mobile Banners, `ET` Ebank Telemarketing, `DM` Direct Mail. **This resolves an open D08 question.**
- This deck also decodes the numeric customer-feature IDs used in D08 (`1524`, `1536`, `1537`, `1538`, `1572`) as legacy model scores (D09-S016).
- First batch covers visible slides 1–11, 13, 14, 16, 18, 19, 20 plus three slides whose printed numbers were not legible. IDs follow upload order.

### D09-S001 — Cover and editor context (visible slide 1)

`Multi-Touch Attribution Project Demo – Phase 1`; `Dec 5, 2025`; AI2 lockup. Editor: `Editing`, zoom 85%, `English (U.S.)`, **`Slide 1 of 25`**. Browser tabs and bookmarks match D05–D08, final tab `Channel_Attribution_Shap…`. Slide-panel thumbnails 1–6 visible, not transcribable.

### D09-S002 — Case Study – Consumer DCR Wave 4 F25 – June – CC Acquisition (visible slide 6)

Slide number **6**, footer `Internal`. Sub-header: `Top 3 channels (all data available)`. Prompt: `Example: How much has each channel contributed to positive responses (rates)?`

Full response table over the three channels RD, EM, DM:

| RD | EM | DM | rate | Count |
|---:|---:|---:|---:|---:|
| 0 | 0 | 0 | 0.0108 | 151,693 |
| 0 | 0 | 1 | 0.0188 | 27,823 |
| 0 | 1 | 0 | 0.0066 | 107,723 |
| 0 | 1 | 1 | 0.0158 | 69,677 |
| 1 | 0 | 0 | 0.0096 | 23,461 |
| 1 | 0 | 1 | 0.0106 | 58,331 |
| 1 | 1 | 0 | 0.0154 | 27,972 |
| 1 | 1 | 1 | 0.0177 | 50,408 |

`Shapley Values (Pie Chart)`: **DM 74.8%**, **EM 20.2%**, **RD 5.0%**. A companion `Shapley Values (Bar Plot)` shows RD, EM, DM with DM tallest; no bar values printed.

- This is the only fully observed coalition table in the supplied evidence: all 2³ = 8 combinations of three channels have real counts and rates, so Shapley here needs no model. Note `0,1,0` (EM alone, 0.0066) is **below** the all-zero baseline (0.0108).

### D09-S003 — Response Model Channel Contribution (visible slide 8)

Slide number **8**, footer `Internal`.

**Response Model**
- `Trained on customers and their responses to channels (8 binary features + customer features)`
- `Estimates the conversion for unavailable channel combinations`
- `Negative values: Customer profile impact on channel effectiveness estimation`

Donut, `Channel Importance` style, with legend `Direct Mail / EasyLine IVR / Ebank Telemarketing / Email / Leads / Radar Branch/Phone Prompts / Radar Mobile Banners / Radar Web Intercepts`:

| Code | Share |
|---|---:|
| LD | 60.6% |
| RM | 8.8% |
| RD | 8.3% |
| ET | 7.4% |
| RW | 5.0% |
| EL | 3.9% |
| DM | 3.7% |
| EM | 2.3% |

Right: a SHAP beeswarm (`SHAP value (impact on model output)`, x-axis −0.2 to 1.0) with rows `LD, RM, ET, RW, DM, EL, RD, EM` and a `Feature value` High/Low colour bar. `LD` shows a wide positive spread; the others cluster near zero. No point values are transcribable.

- Note the D08 response model was described as `5 binary features + customer features` (D08-S005); this one is **8 binary features**.

### D09-S004 — Shapley Value Overview (visible slide 5)

Slide number **5**, footer `Internal`.

- `What is Shapley?` — `Computes average incremental value of each channel across customers' journey.`
- `Why start here?` — `Previously attempted in 2021, but was not utilized in marketing`; `Rule-based approaches attribute impact to one channel, ignoring the additive influence of multiple touchpoints`; `The order of user interactions with touch points is not available to us yet`
- **Pros** — `Assesses all channels fairly`; `Intuitive and simple (can be converted to probability)`; `Linear with respect to gains`; `No gain equals no profit`; `If all gains are positive, all profits should be positive`
- **Cons** — `Relies on all combinations of touch points`; `Does not answer 'what if a channel was removed?' (not causal)`

- Two stated facts of record: a Shapley attempt was made in **2021** and not adopted, and touchpoint **order is not available**. The latter matches D08-S012's next step about timestamped data.

### D09-S005 — Case Study – Channel Importance and coalition coverage (visible slide 7)

Slide number **7**, footer `Internal`. Same case-study header (`Consumer DCR Wave 4 F25 – June – CC Acquisition`).

Donut, `Channel Importance`, footnote `*Channels with <2% are excluded`: **LD 86.5%**, **EL 6.1%**, **DM 4.6%**, **EM 2.7%**.

Coverage table:

| Channels | #Cust | #Resp | Rate |
|---|---:|---:|---:|
| LD | 11,046 | 1,887 | **17.08%** |
| RW, ET, DM | 8,862 | 363 | 4.1% |
| RW, ET, DM, RD | 8,862 | 363 | 4.1% |
| RW, ET | 9,027 | 366 | 4.05% |
| RW, ET, RD | 9,027 | 366 | 4.05% |
| DM | 1,502,094 | 29,333 | 1.95% |
| EM | 1,423,355 | 23,999 | 1.69% |
| RD | 1,388,091 | 27,209 | 1.96% |
| Control | 503,787 | 5,402 | 1.07% |
| ~129 combinations | … | … | … |
| **127 combinations** | **No exposure** | – | – |
| Total 256 Combinations | | | |

- **Material:** of 256 possible combinations across eight channels, **127 have no exposure at all**, and roughly 129 have some. The Shapley `Cons` on D09-S014 state that missing or sparse combinations make estimates unreliable; this slide quantifies exactly that gap, and D09-S015 states the response model exists **because of** those 127 unobserved combinations.
- Two pairs of rows have identical `#Cust` and `#Resp` (RW,ET,DM vs RW,ET,DM,RD at 8,862/363; RW,ET vs RW,ET,RD at 9,027/366), i.e. adding RD changes nothing in those cells. Recorded as printed.
- A **control group** of 503,787 customers at 1.07% appears here — the first control group named in the supplied evidence.

### D09-S006 — Summary & Next Steps (visible slide 10)

Slide number **10**, footer `Internal`.

**Summary**
- `Reported channel contributions using Shapley method on raw data`
- `Developed a response model using MarLin-Sushi framework and extracted channel contributions`
- `Simulated channel coalitions using the developed response model`
- `Model Calibration`

**Next Steps (Phase 1)**
- `Identify customer profiles: Meet with marketing team – from negative Shapley values`
- `Leverage PRISM scores` — `Optionally, use PRISM customer representations`
- `Enforce always positive contributions` — `Using simulation data`; `Within model weight during training`

- `Enforce always positive contributions` appears here in identical wording to D08-S012, and `from negative Shapley values` confirms negative estimates exist in this workstream too.

### D09-S007 — Our Position in Industry (visible slide 4)

Slide number **4**, footer `Internal`. Same timeline asset as D04-S030 / D07-S002, with **one addition**: a second green arrow labelled **`We are here`** pointing at `Shapely Value`, alongside the `Final Goal` arrow at `Transformer Models` and the TD arrow at `Rules Based`.

- This version spells the 2020 causal reference `Camta` (D07-S013 also uses `Camta`; D07-S003 and D04-S030 use `CAMTA`).
- The `We are here` marker dates TD's self-assessed position to the Shapley row as of Dec 2025.

### D09-S008 — Response Model Enhanced Channel Shapley Values (visible slide 9)

Slide number **9**, footer `Internal`.

**Simulation using Response Model**
- `Simulated over a subset of 10K customers from test set.`
- `For each customer, all possible channel combinations are considered.`
- `The calibrated model score is averaged for each set of coalition.`

**Analysis**
- `RD, RM, ET, and LD have high importance`
- `Consistent with Response model feature contributions.`

`Shapley Values (Pie Chart)`:

| Code | Share |
|---|---:|
| LD | 50.7% |
| RM | 14.0% |
| ET | 9.0% |
| EM | 7.5% |
| RD | 7.3% |
| DM | 5.0% |
| RW | 3.4% |
| EL | 3.1% |

A companion `Shapley Values (Bar Plot)` (x-axis `RD, RW, LD, EM, EL, RM, ET, DM`, y-axis to 0.040) shows LD much the tallest. **This is the same chart that appears in D08-S013**, confirming the eight-code Shapley plot in the DR deck came from this Shapley workstream.

- The `Analysis` bullet names RD, RM, ET and LD as high-importance, but by the pie the four largest are LD (50.7%), RM (14.0%), ET (9.0%) and **EM (7.5%)** — RD is fifth at 7.3%. Flagged.
- `10K customers from test set` matches the D08-S009 evaluation population.

### D09-S009 — Multi-Touch Attribution Overview (visible slide 2)

Slide number **2**, footer `Internal`. Identical content to D07-S004 and D08-S004 (same `Problem` bullets, same four-step journey with the same dates and annotation). Not restated.

### D09-S010 — Roadmap – F26 (visible slide 11)

Slide number **11**, footer `Internal`. Identical content to D08-S011 (same eight milestones Nov 2025 → Sep 2026; Phase 1 `Shapley value approaches and Doubly Robust` / `Replicate previous works, obtain a baseline`; Phase 2 `Transformer Model` / `Unifies Media Mix Model`; Phase 3 `Further R&D`). Values not restated.

- The same roadmap sits at slide 12 in D08 and slide 11 here, both dated Dec 5 2025, and both differ from D07-S025's phase assignment.

### D09-S011 — Cover in presentation mode

The same title slide shown full-screen via `usc-powerpoint.officeapps.live.com`, control bar reading **`01 of 25`**. Confirms the deck length; no new slide content.

### D09-S012 — Executive Summary – What gets measured gets automated (visible slide 3)

Slide number **3**, footer `Internal`. Identical content to D07-S007: same Motivation bullets (including `Direct Mail is consuming 80% of the budget, however, contributes only 60% of the widgets/SVA.`), same Objective and Marketing Applications. Not restated.

### D09-S013 — Executive Summary – What gets measured gets automated (visible slide 13)

Slide number **13**, footer `Internal`. **Same title as D09-S012 but different content.**

- **Motivation** — `Elevates the effectiveness of marketing campaigns.`; `Reveals the most successful channels at driving conversions and revenue.`; `Enables marketing spend justification.`; `Identifies where to double-down.`
- **Objective** — `Develop a data-driven approach.`; `Assess channel contributions to the outcomes of a multi-channel marketing campaigns.`; `Be as automated and scalable as possible.`
- **Marketing Benefits** — `Deeper insights into channel performance` (`Adjust ROI estimation at channel level more accurately.`); `Ability to optimize marketing investment and influence sales results` (`Optimize channels spend within a campaign to maximize conversions, revenue, ROI, etc.`; `Ultimately, optimize budget allocation across campaigns to maximize overall marketing strategic goals.`)

- Two differently-worded executive summaries under the same title, ten slides apart. The slide-13 version drops the 80%/60% Direct Mail figure. Recorded without inference about which is current.

### D09-S014 — Shapley Value (formal definition, visible slide 14)

Slide number **14**, footer `Internal`.

- `What it is?` — `A game-theoretic approach to fairly distribute conversion credit across marketing channels.`; `Based on each channel's marginal contribution across all possible combinations of channels (coalitions).`; `Computes average incremental value of each channel across permutations of the journey.`
- Formula as printed: `φ_i(v) = Σ_{S⊆N\{i}} [ |S|! · (n − |S| − 1)! / n! ] · ( v(S ∪ {i}) − v(S) )`
- **Pros** — `Fairness: Considers all possible positions and interactions.`; `Model-Free: Does not require strong assumptions or a predictive model.`; `Interpretable: Assigns transparent, intuitive value to each channel.`
- **Cons** — `Computationally Expensive for many channels (combinatorial explosion).`; `Requires Good coverage: Missing or Sparse channel combinations make estimates unreliable.`; `Assumes Additivity: Ignores time ordering and synergy effects unless modeled externally.`; `Not Causal: Descriptive only, doesn't answer 'what if we had removed a channel?'`

- **Tension within the deck:** the Pro `Model-Free: Does not require strong assumptions or a predictive model` sits against D09-S008, where the reported Shapley values are computed **from** a response model simulating unobserved coalitions. The Con `Requires Good coverage` is directly implicated by the 127 unobserved combinations in D09-S005.

### D09-S015 — Leveraged Data (visible slide 19)

Slide number **19**, footer `Internal`.

- `Model development process`: `Aggregate to Customer Level` → `Add Model Scores`; and → `Use Marlin Sushi to fit the response model`.
- Statement: **`The response model was developed due to 127 channel combinations that customers do not encounter.`**
- Right: an unlabelled `Interactions` pie captioned `Positive interactions per channel`, legend `Direct Mail, Email, Radar Branch/Phone, EasyLine IVR, Radar Mobile Banners, Radar Web Intercepts, EBank Telemarketing, Lead`. No values printed; none transcribed.

- This is the clearest statement in the file of **why** a response model sits inside the Shapley calculation: to supply values for coalitions never observed. It also means the headline Shapley numbers in D09-S008 are partly model extrapolation into unobserved regions.

### D09-S016 — Campaign Data (visible slide 16)

Slide number **16**, footer `Internal`.

Illustrative table:

| Customer ID | Channel 1 | Channel 2 | Channel 3 | Model Scores | CC Acquisition |
|---|---:|---:|---:|---:|---:|
| C#1 | 1 | 1 | 0 | 0.1 | 1 |
| C#2 | 0 | 1 | 1 | 0.5 | 0 |
| C#3 | 0 | 1 | 1 | 0.8 | 1 |

`Note: The sequence of channels to contact each customer was not tracked originally but is available now.`

**Channels Leveraged** (`Touch Points`): `1. Radar Branch/Phone`; `2. Radar Mobile Banners`; `3. Radar Web Intercept`; `4. E-Bank Telemarketing`; `5. EasyLine - IVR`; `6. Direct Mail`; `7. Email`; `8. Leads`. `Source: TMIA and campaign history`.

**Legacy Model Scores** (`Customer Features`):

| ID | Description |
|---|---|
| 1536 | Platinum Travel Acquisition - PTV |
| 1537 | Low-rate Acquisition - TDLR |
| 1538 | Aeroplan Infinite Acquisition - AERO |
| 1539 | First Class Travel Acquisition - FCT |
| 1540 | Cash Back Infinite Acquisition - CBI |
| 1541 | Rewards Acquisition - TDR |
| 1542 | Cash Back Entry Acquisition - CBE |
| 1572 | TDCT CC Pre-Approved Response model |
| 1524 | TDCT Personal CC Generic Propensity Model |

`Model scores gathered from 2025-03-31`.

- **This decodes the D08 feature IDs.** D08-S005/S010 showed customer-feature columns `1524, 1536, 1537, 1538, 1572`; they are legacy product-propensity and response model scores, snapshotted 2025-03-31.
- The note that channel sequence `was not tracked originally but is available now` is a data-availability claim relevant to D08-S012's transformer next step.

### D09-S017 — Campaign Database Details

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`. Heading: `Collected TMIA and Campaign Wave 4 Data`.

Schema as printed:

```
root
 |-- cust_id: long (nullable = true)              → Customer ID
 |-- cell_code: string (nullable = true)
 |-- campaign_id: string (nullable = true)
 |-- chanel_na: string (nullable = true)          → Channel Description
 |-- contrl_cell_in: string (nullable = true)
 |-- cntact_dt: date (nullable = true)
 |-- offer_efectv_dt: date (nullable = true)
 |-- offer_exprtn_dt: date (nullable = true)
 |-- target_prodct_tx: string (nullable = true)
 |-- resp_in: integer (nullable = true)           → Response -> Credit Card Acquisition
 |-- campaign_id: string (nullable = true)
 |-- measurement_start_date: date (nullable = true)
 |-- measurement_end_date: date (nullable = true)
 |-- indicator: string (nullable = false)
```

`Source data: TMIA and campaign history`. Callout: `One customer is eligible to multiple contacts through different channels.`

- `campaign_id` appears **twice** in the printed schema. Transcribed as shown.
- The schema contains `cntact_dt` (contact date), which is the field that would supply touchpoint ordering.

### D09-S018 — Statistics of the Train and Test Dataset (visible slide 18)

Slide number **18**, footer `Internal`.

**Population Information**

| Metric | Value | Share |
|---|---:|---:|
| Total customers | 2,592,528 | |
| Total Customers dropped (null model scores) | 145,864 | 5.32% |
| Total Positive Responses | 42,399 | 1.64% |
| Total Negative Responses | 2,550,129 | 98.36% |
| Control Group Size | 504,177 | 19.45% |

**Sankey flow**: `Dataset 2,592,528` → `Down Sampled 2,359,253` and `Model Development 233,275`; `Model Development` → `Testing 155,748` and `Training 77,527`; `Testing` → `Pos Testing 2,513` + `Neg Testing 153,235`; `Training` → `Pos Training 5,999` + `Neg Training 71,528`.

- Arithmetic checks: 2,513 + 153,235 = 155,748 ✓; 5,999 + 71,528 = 77,527 ✓; 155,748 + 77,527 = 233,275 ✓; 2,359,253 + 233,275 = 2,592,528 ✓. So `Down Sampled` labels the **discarded** 2.36M, and model development uses 233,275 records.
- **Observation:** the positive rate differs sharply between splits — training 5,999/77,527 ≈ **7.7%**, testing 2,513/155,748 ≈ **1.6%**. The test split is close to the population base rate (1.64%); the training split is not. This is consistent with downsampling applied asymmetrically, and it is the reason calibration is needed (D08-S016, D09-S019). Recorded as an arithmetic observation from the printed figures.
- The cohort here (2,592,528 total, 1.64% positive) is close to but **not identical** to D04-S002's 2,604,922 total / 1.36% converters. Different populations or different windows; not reconciled.

### D09-S019 — Response Model Parameters and Performance (visible slide 20)

Slide number **20**, footer `Internal`.

- Left: `Receiver Operating Characteristic (ROC) Curve Testing`, legend `Classifier (AUC = 0.79)` and `No Skill`.
- Printed settings: `Neg Down-Sample: 0.2`; `Pos Down-Sample: 0.2`; `Classifier Params:` `reg_alpha: 0.0`, `reg_lambda: 1.0`, `max-depth: 5`, `n-estimators: 20`, `Learning rate: 0.3`.
- Right: `Conversion rate against model score per multi-channel touch point combinuation` (spelled thus), x-axis `Response rate`, y-axis `Average Response Model Score`, legend `Test | corr = 0.65` and `Train | corr = 0.57`.

- These are the full hyperparameters of the response model that underpins the D09 Shapley simulation and (per D08-S016) the DR nuisance models. `n-estimators: 20` with `max-depth: 5` is a small model; recorded without comment on adequacy.
- Both down-sample rates read **0.2**, which does not by itself explain the asymmetric split base rates in D09-S018. Flagged as something to check against code.

### D09-S020 — Campaign Timeline

Slide number `[UNREADABLE: not visible in the screenshot]`. Footer `Internal`. Heading: `Legacy Modeling Time Window, using F2025 Wave 4:`

| Window | Months |
|---|---|
| `12-month observation window` | APR2024, MAY2024, … , MAR 2025 |
| `Leads preparation` / `Latency` | APR2025, MAY2025 |
| `Outcome window` / `Performance Window` | JUNE2025, JULY2025 |

- This is the **first explicit statement of the full modelling time window** in the supplied evidence: a 12-month feature window ending March 2025, a two-month latency/leads-preparation gap, then a two-month outcome window (June–July 2025).
- Consistent with D09-S016 (`Model scores gathered from 2025-03-31`) and with D08-S003's April 30 scores → May 30 assignment → June journey sequence, though the exact dates differ by a month.
- D04-S002 gives the analysis period as `April – July 2025`, which corresponds to the latency plus outcome windows here, not the 12-month observation window.

### D09-S021 — Repeat: Leveraged Data (visible slide 19)

Clearer repeat of D09-S015. Confirms slide number **19** and the statement `The response model was developed due to 127 channel combinations that customers do not encounter.` The `Interactions` pie legend is now fully legible: `Direct Mail`, `Email`, `Radar Branch/Phone`, `EasyLine IVR`, `Radar Mobile Banners`, `Radar Web Intercepts`, `EBank Telemarketing`, `Lead`. Still **no values printed** on the pie; by area the largest wedges are Direct Mail, Email and Radar Branch/Phone, but no shares are transcribed. Caption `Positive interactions per channel`.

### D09-S022 — Repeat: Campaign Data (visible slide 16)

Clearer repeat of D09-S016. All transcribed content confirmed unchanged: the three-row illustrative table, the `Note` about channel sequence, the eight `Channels Leveraged`, and the nine `Legacy Model Scores` (1536–1542, 1572, 1524) with `Model scores gathered from 2025-03-31`. No new content.

### D09-S023 — Repeat: Campaign Database Details

Clearer repeat of D09-S017. Slide number still `[UNREADABLE: not visible]`. Schema confirmed field-for-field, including the **duplicated `campaign_id`** entry and `indicator: string (nullable = false)`. Highlighting on `cust_id`, `chanel_na` and `resp_in` is now visible as yellow marker on the slide itself. Callout confirmed: `One customer is eligible to multiple contacts through different channels.`

### D09-S024 — Response Model Enhanced Channel Shapley Values (visible slide 22)

Slide number **22**, footer `Internal`. **Same title as D09-S008 (slide 9) and the same pie values**, with one addition: the bullet now states the combination count explicitly.

- `Simulated over a subset of 10K customers from test set.`
- `For each customer, all possible channel combinations are considered (256).`
- `The calibrated model score is averaged for each set of coalition.`

`Shapley Values (Pie Chart)`: LD **50.7%**, RM **14.0%**, ET **9.0%**, EM **7.5%**, RD **7.3%**, DM **5.0%**, RW **3.4%**, EL **3.1%**. Companion `Shapley Values (Bar Plot)` with x-axis `RD, RW, LD, EM, EL, RM, ET, DM`, y-axis to 0.040, LD much the tallest — the same chart reproduced in D08-S013.

- The `(256)` confirms the coalition space is all 2⁸ combinations for eight channels, of which **127 are never observed** (D09-S005, D09-S021).

### D09-S025 — Repeat: Response Model Parameters and Performance (visible slide 20)

Clearer repeat of D09-S019. Confirms `Classifier (AUC = 0.79)`, `Neg Down-Sample: 0.2`, `Pos Down-Sample: 0.2`, and classifier params `reg_alpha 0.0`, `reg_lambda 1.0`, `max-depth 5`, `n-estimators 20`, `Learning rate 0.3`. Scatter legend confirmed `Test | corr = 0.65` and `Train | corr = 0.57`; title misspelling `combinuation` confirmed. No new values.

### D09-S026 — Repeat: Campaign Timeline

Clearer repeat of D09-S020. Slide number still `[UNREADABLE: not visible]`. Confirms `Legacy Modeling Time Window, using F2025 Wave 4:` with `APR2024, MAY2024, ……, MAR 2025` as the `12-month observation window`; `APR2025, MAY2025` as `Leads preparation / Latency`; `JUNE2025, JULY2025` as `Outcome window / Performance Window`.

### D09-S027 — Repeat: Statistics of the Train and Test Dataset (visible slide 18)

Clearer repeat of D09-S018. All figures confirmed: totals 2,592,528 / 145,864 (5.32%) dropped / 42,399 (1.64%) positive / 2,550,129 (98.36%) negative / 504,177 (19.45%) control; Sankey `Down Sampled 2,359,253`, `Model Development 233,275`, `Testing 155,748` (Pos 2,513, Neg 153,235), `Training 77,527` (Pos 5,999, Neg 71,528). No new content.

### D09-S028 — Response Model Enhanced Channel Shapley Values (visible slide 21)

Slide number **21**, footer `Internal`. **Third slide with this title, and the values differ from S008/S024.**

**Remaining Challenges**
- `Customer profile impacts on the response model`
- `So, we fill the missing data using the response model and then run Shapley Method`

**Analysis**
- `RD, ET, and LD have high importance` — `This is similar to previous method`
- `Differences with response model feature contributions:` — `RM has lower importance`

**Negative values exists:**
- `Results do not match marketing assumptions.`
- `This is because of marketing profiles!`

Donut, legend `Radar Branch/Phone Prompts, Radar Web Intercepts, Leads, Email, EasyLine IVR, Radar Mobile Banners, Ebank Telemarketing, Direct Mail`:

| Code | Share |
|---|---:|
| LD | **54.6%** `[PARTIALLY READABLE: label sits behind the legend box; the printed labels for the other seven sum to 45.3%, leaving 54.7%]` |
| ET | 13.5% |
| RD | 11.7% |
| DM | 6.7% |
| EL | 6.6% |
| EM | 2.8% |
| RM | 2.7% |
| RW | 1.3% |

- **Two different eight-channel Shapley results under one title.** Slide 21: LD 54.6, ET 13.5, RD 11.7, DM 6.7, EL 6.6, EM 2.8, RM 2.7, RW 1.3. Slides 9/22: LD 50.7, RM 14.0, ET 9.0, EM 7.5, RD 7.3, DM 5.0, RW 3.4, EL 3.1. RM moves from second (14.0%) to seventh (2.7%); RD from fifth (7.3%) to third (11.7%). The slide's own `Analysis` — `RD, ET, and LD have high importance` and `RM has lower importance` — matches **this** slide's numbers, whereas D09-S008's `RD, RM, ET, and LD` matches the other. Which run is current, and what distinguishes them, is not stated.
- `Negative values exists` is stated plainly here, with the explanation attributed to `marketing profiles`. This connects to the `Enforce always positive contributions` next step in D09-S006 and D08-S012.

### D09-S029 — Close-up: Decile Analysis test

Close-up of the left chart on D09-S032. Title `Decile Analysis test`, x-axis `Average Value` 0.00–0.30, three series: `decile_avg_resp` (blue), `decile_avg_prob` (orange), `decile_avg_calibrated_prob` (green).

| Decile | calibrated_prob | raw prob | actual resp |
|---:|---:|---:|---:|
| 1 | 0.0751 | 0.2663 | 0.0730 |
| 2 | 0.0271 | 0.1255 | 0.0263 |
| 3 | 0.0171 | 0.0864 | 0.0173 |
| 4 | 0.0124 | 0.0644 | 0.0130 |
| 5 | 0.0098 | 0.0502 | 0.0088 |
| 6 | 0.0075 | 0.0397 | 0.0066 |
| 7 | 0.0060 | 0.0314 | 0.0061 |
| 8 | 0.0046 | 0.0240 | 0.0055 |
| 9 | 0.0031 | 0.0173 | 0.0028 |
| 10 | 0.0016 | 0.0098 | 0.0019 |

- The **raw** predicted probability runs roughly 3–5× the observed response rate at every decile, consistent with the downsampling; the **calibrated** value tracks the actual response closely across all ten deciles. This is the clearest direct evidence in the file that the calibration step does what it claims.

### D09-S030 — Phase 1 - Plan (visible slide 25)

Slide number **25**, footer `Internal`. `Two Solutions:`

1. `Shapley value method (Mehrazin)` — `Implement the script using existing public repositories`: `https://github.com/eeghor/mta`; `https://github.com/DP6/Marketing-Attribution-Models`
2. `Shapley value + response model (Jessie, Nazanin, Vandad)`
   - `Step1: Develop a response model` — `Incorporate marketing channels as input features using the marlin-sushi framework.`
   - `Step2: Simulate channel coalitions` — `Toggle each channel (on/off) within coalitions to estimate the average campaign outcome.`
   - `Step3: Calculate Shapley values` — `a) Use explicit coalition Shapley methods on model predictions (not raw data).` ; `b) Apply model explanation Shapley approaches for deeper attribution insights.`
   - `Step4: Normalize results` — `Standardize Shapley values to ensure comparability across channels.`

- Names two external public repositories as the implementation basis for the first solution, and names individual owners for each workstream. Recorded as printed.
- Step 3a states the method operates `on model predictions (not raw data)`, which is the deck's own explicit acknowledgement of the point flagged at D09-S014 (`Model-Free` listed as a Pro).
- Step 3a and 3b describe **two distinct Shapley routes** (explicit coalition vs model-explanation/SHAP). D09-S003 shows a SHAP beeswarm and D09-S008/S024/S028 show coalition results — plausibly the two routes, and plausibly the source of the differing numbers noted at D09-S028. Not established by the slides.

### D09-S031 — Baseline Response Model – Using PRISM features (visible slide 24)

Slide number **24**, footer `Internal`. Question: `How well can each PRISM head predict user response?`

`Summary of All Evaluation Results - Including Control`:

| Model | ROC AUC | PR AUC |
|---|---:|---:|
| sc_4875006 | 0.7279 | 0.0494 |
| sc_4875005 | **0.4546** | 0.0161 |
| sc_4875011 | 0.7515 | 0.0565 |
| sc_4875010 | 0.7020 | 0.0373 |
| sc_4875004 | 0.5590 | 0.0245 |
| sc_4875009 | 0.5817 | 0.0278 |
| sc_4875008 | 0.6216 | 0.0315 |
| sc_4875012 | 0.7541 | 0.0598 |
| sc_4875007 | 0.7451 | 0.0659 |
| sc_4875001 | 0.7554 | 0.0658 |
| sc_1572 | 0.7515 | 0.0455 |

Right: `Baseline ROC Curve: Model sc_4875001 - Excluding Control`, legend `ROC curve (AUC = 0.7554)` and `Random Guess (AUC = 0.50)`.

- **Cross-deck link:** the `sc_4875xxx` identifiers match the `10 Credit card propensity heads` shown in D04-S033 with column headers `4875001`, `4875004`, `4875005`, `…`, `4875012`. This slide gives their individual predictive performance.
- **`sc_4875005` has ROC AUC 0.4546, i.e. below random.** Three further heads (4875004 0.5590, 4875009 0.5817, 4875008 0.6216) are weak. Recorded as printed; the slide offers no comment.
- The table header says `Including Control` while the chart says `Excluding Control` — two different evaluation populations on one slide.

### D09-S032 — Decile Analysis After adding Calibration (visible slide 23)

Slide number **23**, footer `Internal`.

- `Isotonic regression is applied on all the data excluding the test set.`
- `Deciles are created based on model predicted score.`

Two charts side by side, `Decile Analysis test` (transcribed in D09-S029) and `Decile Analysis train` (transcribed in D09-S033).

- Names the calibration method explicitly: **isotonic regression**, fitted on everything except the test set. This is the calibration referred to in D08-S016 (`calibrated mu_0 and mu_1`, `calibrated e_hat`) and in D08-S009 (`Model scores calibrated to correct for negative downsampling`).

### D09-S033 — Close-up: Decile Analysis train

Close-up of the right chart on D09-S032. Same three series.

| Decile | calibrated_prob | raw prob | actual resp |
|---:|---:|---:|---:|
| 1 | 0.0746 | 0.2653 | 0.0746 |
| 2 | 0.0271 | 0.1253 | 0.0270 |
| 3 | 0.0170 | 0.0861 | 0.0170 |
| 4 | 0.0124 | 0.0643 | 0.0124 |
| 5 | 0.0098 | 0.0502 | 0.0098 |
| 6 | 0.0075 | 0.0397 | 0.0075 |
| 7 | 0.0060 | 0.0315 | 0.0059 |
| 8 | 0.0046 | 0.0241 | 0.0047 |
| 9 | 0.0031 | 0.0174 | 0.0031 |
| 10 | 0.0016 | 0.0099 | 0.0016 |

- On train, calibrated and actual agree to four decimals in eight of ten deciles — expected, since the isotonic fit includes this data. The **test** agreement (D09-S029) is the meaningful check, and it is close though not exact (e.g. decile 8: 0.0046 calibrated vs 0.0055 actual).

## D09 classification and checks

| Slides | Classification | Evidence boundary |
|---|---|---|
| D09-S004, S014 | Method explanation | Shapley definition, pros and cons as stated; the deck's own caveats (coverage, not causal) apply to its results. |
| D09-S002 | Retrospective attribution on fully observed data | All 8 combinations of 3 channels have real counts; Shapley here is descriptive, not causal. |
| D09-S005 | Coverage / exposure diagnostic | Quantifies 127 of 256 combinations with no exposure; names a 503,787 control group. |
| D09-S003, S008, S015 | Model-based attribution | Shapley computed over coalitions supplied by a response model where data does not exist. Descriptive by the deck's own `Not Causal` label. |
| D09-S016, S017, S018, S019, S020 | Data and model documentation | Schema, channel list, legacy score definitions, population/split counts, hyperparameters, time windows. The most complete data lineage in the file. |
| D09-S007, S010, S012, S013 | Positioning / framing / roadmap | Shared assets with D04, D07 and D08; `We are here` marks Shapley as the Dec 2025 position. |
| D09-S006 | Progress / next steps | Phase 1 statement; mirrors D08-S012. |
| D09-S021–S023, S025–S027 | Repeat views | Clearer re-shoots of slides 16, 18, 19, 20 and the two unnumbered slides; confirm earlier transcriptions, no new claims. |
| D09-S024, S028 | Model-based attribution (further runs) | Two more eight-channel Shapley results under the same title, with different shares. |
| D09-S029, S032, S033 | Calibration diagnostic | Isotonic regression named; decile-level calibrated vs actual comparison on both splits. The strongest calibration evidence in the file. |
| D09-S031 | Baseline model diagnostics | Per-PRISM-head ROC/PR AUC, including one head below random. |
| D09-S030 | Plan / ownership | Two named workstreams and two external repositories. |

## D09 claims, tensions and questions

- **Important presentation claims:** channel contributions were reported using Shapley on raw data, with a response model built on the `MarLin-Sushi` framework used to simulate coalitions (S006); `RD, RM, ET, and LD have high importance` and this is consistent with response-model feature contributions (S008); the response model exists specifically because 127 channel combinations are never encountered (S015); Shapley was previously attempted in 2021 and not adopted (S004); touchpoint order was not tracked originally but is available now (S016).
- **Resolution of an earlier open item:** the eight two-letter codes in D08-S013 are defined here (RD/RW/LD/EM/EL/RM/ET/DM), and the D08 Shapley bar plot is the same chart as D09-S008. The D08 five-channel DR work and this eight-channel Shapley work are therefore on different channel sets, presented side by side in D08-S009 and D08-S013.
- **Resolution of an earlier open item:** the numeric feature IDs `1524/1536/1537/1538/1572` in D08 are legacy product-propensity and response model scores, snapshot 2025-03-31 (S016).
- **Tension (material):** D09-S014 lists `Model-Free: Does not require strong assumptions or a predictive model` as a Pro of Shapley, while the deck's headline Shapley values (S008) are produced by averaging a **predictive model's** calibrated scores over coalitions, 127 of which are never observed (S005, S015). The same slide's Con — `Requires Good coverage: Missing or Sparse channel combinations make estimates unreliable` — applies directly to those values.
- **Tension:** the S008 `Analysis` bullet names RD among the four highest-importance channels, but RD is fifth (7.3%) in the same slide's pie, behind EM (7.5%).
- **Tension:** three different channel-share rankings appear across this deck and D08 for overlapping work — response-model importance (S003: LD 60.6%), response-model-enhanced Shapley (S008: LD 50.7%), and the three-channel case study (S002: DM 74.8%). Each is over a different channel set and population; none is presented with uncertainty.
- **Tension:** D09-S012 and D09-S013 are both titled `Executive Summary – What gets measured gets automated` with different content, ten slides apart.
- **Tension:** the response model is `8 binary features + customer features` here (S003) but `5 binary features + customer features` in D08-S005.
- **Observation:** train and test splits carry very different positive rates (≈7.7% vs ≈1.6%) despite both down-sample rates printing as 0.2 (S018, S019).
- **Observation:** the D09 cohort (2,592,528 customers, 1.64% positive) is close to but not the same as D04-S002's (2,604,922, 1.36%).
- **Tension (material, new):** three slides share the title `Response Model Enhanced Channel Shapley Values` (S008/slide 9, S028/slide 21, S024/slide 22) and carry **two different sets of shares**. RM is 14.0% in one and 2.7% in the other; RD moves from 7.3% to 11.7%. Each slide's `Analysis` bullet matches its own chart, so both were written deliberately, but nothing states which run supersedes which or what changed between them. D09-S030 describes two distinct Shapley routes (explicit-coalition vs model-explanation), which may be the explanation; the slides do not say.
- **Observation (new):** `sc_4875005` has ROC AUC **0.4546**, below random guessing, and three further PRISM heads sit between 0.56 and 0.62 (S031). These heads feed the response model as customer features.
- **Tension (new):** D09-S031's table header reads `Including Control` while its ROC chart reads `Excluding Control`.
- **Calibration evidence (new):** isotonic regression on all data except the test set (S032); on test, raw predicted probability runs 3–5× the observed rate at every decile while the calibrated value tracks actuals closely (S029). This substantiates the calibration claims made in D08-S009 and D08-S016.
- **Cross-deck link (new):** the `sc_4875xxx` model IDs in S031 are the `10 Credit card propensity heads` shown in D04-S033.
- **Questions to check against code/results:** Which of the two eight-channel Shapley runs (slide 21 vs slides 9/22) is current, and what differs between them — explicit-coalition vs SHAP, or a re-run? Why is PRISM head `sc_4875005` below random, and is it still used as a feature? Was the S031 evaluation on the control-inclusive or control-exclusive population? How are Shapley values computed for the 127 unobserved combinations, and how sensitive are the reported shares to that extrapolation? Do the S002 three-channel Shapley values (computed on fully observed data) agree with the model-based method run on the same three channels? Why do train and test positive rates differ if both down-sample rates are 0.2? Is the `control group` of 503,787 (S005/S018) usable as a real control for validation, and was it? What is `indicator` in the S017 schema, and why does `campaign_id` appear twice? Does `cntact_dt` in fact supply the ordering claimed as `available now` (S016)? Which executive summary — slide 3 or slide 13 — is current? How do the D09 eight-channel and D08 five-channel results relate, given they are shown together in D08-S013?

## D10 — `Channel_Attribution_plan.pptx` — “Multi-Touch Attribution Project Plan”

**Deck-level evidence.** Visible filename `Channel_Attribution_plan.pptx`; cover title **Multi-Touch Attribution Project Plan**; cover date **Feb 17, 2025**; AI2 lockup. Editor status bar reads **Slide 1 of 14**. Opened from `myteam.td.com/:p:/r/teams/TECEAIMLNewPracticeArea/_layouts/15/Doc.aspx?sourcedoc=%7B32C7DEF3-FA65-4C40-B354-5FC4818B1CEA%7D&file=Channel_Attribution_plan.pptx&action=edit&mobileredirect=true`. Screenshots supplied 2026-09-09; editor clock reads 3:18 AM, 9/9/2026. Avatar initials `MA`.

- **Date anomaly (material).** The cover reads **Feb 17, 2025**, but the deck's roadmap runs Nov 2025 → Sep 2026 and its Phase arrows are dated Jan/Apr/Sep **2026**. A Feb 2025 deck could not contain a Nov 2025 starting milestone. The cover date is most likely intended as Feb 17, **2026**, but this is not established — transcribed as printed and flagged.
- **This deck resolves the D07-S025 anomaly.** The `Multi-Touch Attribution – Strategy Overview` slide flagged there as having a conflicting number and a different layout from the rest of D07 appears here as **slide 2** of this deck, with identical content (see D10-S014). It belongs to `Channel_Attribution_plan.pptx`.
- The channel schema on D10-S008 is a **twelve**-channel set (Affiliate, Branch, Display, Email, Leads, Mobile, Onsite_Banner, Paid_Search, Phone, SEO, Social_CT, Web) — a fourth distinct schema across the file, matching neither D04's nine, D08's five, nor D09's eight.
- First batch covers visible slides 2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14 plus the cover in two views. IDs follow upload order.

### D10-S001 — Phase 1: Shapley Value – Response Model (printed slide number 4)

Printed slide number **4**, footer `Internal`. **See the numbering collision noted at D10-S009**, which also prints 4.

**Concept**
- `Trained on customers and their responses to channels`
- `Outputs predicted response probability for each customer under a given channel setting`
- `Generate counterfactuals' response probability by toggling the channel (keep other features fixed)`

Diagram, `Channels + Customer Features`: two blocks differing only in the Email flag — `Direct Mail 0, Telemarketing 1, Leads 1, Email 1, EasyLine 0` and `… Email 0 …`, each with a generic feature column `x1, x2, ·, ·, xn`. Both feed `Response Model` → `Predicted response probability if emailed` and `Predicted response probability if not emailed` → `Subtract` → `Email Incremental Lift`.

- This is the same construction as D08-S005, but with **generic** feature placeholders (`x1…xn`) rather than the numeric legacy score IDs, and without the `5 binary features` count or the `Only protected if response model is perfectly specified` limitation. Consistent with an earlier, planning-stage version.

### D10-S002 — Cover in presentation mode

The title slide full-screen via `usc-powerpoint.officeapps.live.com`, control bar reading **`01 of 14`**. Confirms `Multi-Touch Attribution Project Plan`, `Feb 17, 2025` and deck length. No new content.

### D10-S003 — Phase 2: Doubly Robust Overview (visible slide 6)

Slide number **6**, footer `Internal`.

- `What is Doubly Robust?` — `Doubly robust combine two models to estimate true channel impact`; `Response (outcome) model: What would happen with vs. Without the channel`; `Channel Propensity model: Who gets which channel`
- `The Key Benefit` — `Provides more reliable estimates of channel impact`

Diagram: `Channel Propensity Model` (`Who gets which channel?`) `+` `Response Model` (`What happens with vs. Without channel?`) → `Doubly Robust Estimator` — `Response Model Estimate + Correction Term based on Channel Propensity`.

- The stated benefit here is the weaker `more reliable estimates`. D08-S002 (Dec 2025) states the stronger and more specific `consistent estimates if either the propensity model or response model is correctly specified`. Consistent with this deck predating D08.

### D10-S004 — Phase 3: Transformer Model — LiDDA (visible slide 7)

Slide number **7**, footer `Internal`. Sub-header: `LiDDA: Data Driven Attribution at LinkedIn – 2025`.

Diagram identical in structure to D07-S012: `Input` = `Customer's Journey Embeddings` `+` `Campaign Metadata Embeddings` (`Textual Data` → vectors) `+` `Time Embeddings` (`Day of Week`, `Time from Last Contact`, `Time from Response`); separately `Customer Embeddings` → `Aggregate`; flow → `Single Transformer Block` → `Extract Attention Scores & Normalize` → `Attributions` (`DM`, `TM`, `LD`, `RD`); and `Aggregate` → `FFN` → `Classification (Converts? Y/N)`.

- Here the journey-embedding columns read **`DM TM LD RD`**, matching the attribution tokens. In D07-S012 and D06-S006 the same diagram read `DM TM LM RM` for the embeddings against `LD RD` for the attributions. This version is internally consistent; the D06/D07 versions are not.
- Phase 3 is presented as adopting a published external architecture (LiDDA), which is how the transformer work is framed in this plan.

### D10-S005 — Data Availability (visible slide 3)

Slide number **3**, footer `Internal`.

`Campaign History Data`:

| Customer ID | Channel 1 | Channel 2 | Channel 3 | Acquisition |
|---|---:|---:|---:|---:|
| c1 | 1 | 1 | 0 | 1 |
| c2 | 0 | 1 | 1 | 0 |
| c3 | 0 | 1 | 1 | 1 |

`Note: The sequence of channels to contact each customer was not tracked.`

`MTA Data – Customer's Journey`: `Mobile Banner` (June 5th) → `Clicked on Email` (June 12th) → `Lead Appointment` (June 20th) → `CC Opened` (July 7th).

- **Chronology evidence:** this note ends at `was not tracked.` D09-S016 (Dec 2025) carries the same note extended to `was not tracked originally but is available now.` The data-availability position changed between the two decks, which supports D10 preceding D09.

### D10-S006 — Cover and editor context (visible slide 1)

Full editor view: filename `Channel_Attribution_plan`, `Editing`, zoom 85%, `English (U.S.)`, **`Slide 1 of 14`**, avatar `MA`, clock 3:18 AM 9/9/2026. Browser tabs and bookmarks match D05–D09, final tab `Channel_Attribution_plan`. Slide-panel thumbnails 1–6 visible, not transcribable.

### D10-S007 — Results (visible slide 11)

Slide number **11**, footer `Internal`. Two `mean(|SHAP value|)` bar charts.

**Response Model** (x-axis 0.00–0.35):

| Channel | mean(\|SHAP\|) |
|---|---:|
| channel_Mobile | +0.32 |
| channel_Email | +0.15 |
| channel_SEO | +0.05 |
| channel_Leads | +0.04 |
| channel_Display | +0.03 |
| channel_Paid_Search | +0.03 |
| channel_Branch | +0.01 |
| channel_Web | +0 |
| channel_Phone | +0 |
| Sum of 3 other features | +0 |

**Doubly Robust Method** (x-axis 0.00–0.10):

| Channel | mean(\|SHAP\|) |
|---|---:|
| channel_Display | +0.1 |
| channel_SEO | +0.09 |
| channel_Paid_Search | +0.09 |
| channel_Leads | +0.06 |
| channel_Mobile | +0.06 |
| channel_Email | +0.06 |
| channel_Social_CT | +0.05 |
| channel_Branch | +0.05 |
| channel_Web | +0.04 |
| channel_Phone | +0.03 |

- **The two methods rank channels very differently.** `channel_Mobile` is by far the largest under the response model (+0.32) but mid-pack under DR (+0.06); `channel_Display` is largest under DR (+0.1) but fifth under the response model (+0.03). The slide carries **no commentary** — no title text, no analysis bullets, no note on the different axis scales (0.35 vs 0.10).
- Values are printed to one or two significant figures only, and both charts use **mean absolute** SHAP, so sign is not recoverable.

### D10-S008 — MTA – Conversion Summary (visible slide 10)

Slide number **10**, footer `Internal`. Columns: `is_treated | total_customers | total_conversion | conv_rate | channel_name | lift`. Rows highlighted yellow on the slide are marked below.

| Channel | untreated n / conv / rate | treated n / conv / rate | lift |
|---|---|---|---:|
| channel_Affiliate | 1,651,990 / 30,984 / 1.876% | **31** / 6 / 19.355% | 10.32 |
| channel_Branch | 1,599,456 / 29,967 / 1.874% | 52,565 / 1,023 / 1.946% | 1.04 |
| channel_Display | 1,638,091 / 29,616 / 1.808% | 13,930 / 1,374 / 9.864% | 5.46 |
| channel_Email *(highlighted)* | 678,528 / 13,540 / 1.995% | 973,493 / 17,450 / 1.793% | **0.90** |
| channel_Leads | 1,629,152 / 28,604 / 1.756% | 22,869 / 2,386 / 10.433% | 5.94 |
| channel_Mobile *(highlighted)* | 893,230 / 18,162 / 2.033% | 758,791 / 12,828 / 1.691% | **0.83** |
| channel_Onsite_Banner | 1,651,459 / 30,953 / 1.874% | **562** / 37 / 6.584% | 3.51 |
| channel_Paid_Search | 1,615,678 / 27,784 / 1.720% | 36,343 / 3,206 / 8.822% | 5.13 |
| channel_Phone *(highlighted)* | 1,647,651 / 30,932 / 1.877% | 4,370 / 58 / 1.327% | **0.71** |
| channel_SEO | 1,619,823 / 28,119 / 1.736% | 32,198 / 2,871 / 8.917% | 5.14 |
| channel_Social_CT | 1,651,110 / 30,910 / 1.872% | **911** / 80 / 8.782% | 4.69 |
| channel_Web *(highlighted)* | 1,602,164 / 30,179 / 1.884% | 49,857 / 811 / 1.627% | 0.86 |

- The four highlighted rows are exactly the channels with **lift below 1.0** (Email 0.90, Mobile 0.83, Phone 0.71, Web 0.86) — i.e. treated customers converted at a *lower* rate than untreated. Highlighting appears to mark them for attention; the slide gives no text.
- Several treated cells are very small: **Affiliate n=31** (6 conversions, lift 10.32), Onsite_Banner n=562, Social_CT n=911. A lift of 10.32 computed on 31 customers carries no stated uncertainty.
- This is a raw treated-vs-untreated comparison with no adjustment — precisely the confounded quantity that D10-S009 and the DR work are meant to correct.
- Total population implied is ≈1,652,021, which matches none of the other cohort figures in the file (D04: 2,604,922; D09: 2,592,528).

### D10-S009 — Confounding: Features Drive Both Treatment and Outcome (printed slide number 4)

Printed slide number **4**, footer `Internal`. **Numbering collision:** D10-S001 also prints 4. Both are transcribed as printed; the true positions are not established from these screenshots.

**Confounding Bias**
- `Customer Features drive both channel assignment and final conversion.`
- `Confounding blurs where customer intent ends and where marketing impact begins, leading to biased attribution.`
- `This bias gives credit to channels when the customer was already likely to convert without it.`

Diagram (`The Bias Problem`): `Customer Features` → `Channel Treatment` (`Propensity model`) and → `Response` (`output model`); `Channel Treatment` → `Response` (`causal effect`).

- Content is identical to D08-S018 apart from the title (`Confounding:` here vs `The Confounder:` there) and the box label (`Propensity model` vs `Propensity score based model`).

### D10-S010 — Roadmap – FY26 (visible slide 8)

Slide number **8**, footer `Internal`. Header block `Development Timeline & Roadmap`.

| Date as printed | Milestone |
|---|---|
| Nov 2025 | `Planning & Design` |
| `Jan2025` | `Phase 1 Release` + `Phase 2 Planning & Design` |
| `Feb 2025` | `Phase 1 Showcase` |
| April 2026 | `Phase 2 Release` + `Phase 3 Planning & Design` |
| May 2026 | `Phase 2 Showcase` |
| June 2026 | `Phase 3 - Development` |
| Sep 2026 | `Phase 3 Release` |

Callouts: `Phase 1: To have Shapley value approach ready and define evaluation metrics`; `Phase 2: To add causal inference model to overcome confounder bias`; `Phase 3: Transformer model`.

- **`Jan2025` and `Feb 2025` sit between Nov 2025 and April 2026 on the timeline**, so both are almost certainly typos for 2026. Transcribed as printed and flagged.
- Phase contents here (1 = Shapley, 2 = causal inference/DR, 3 = Transformer) match **D07-S025 / D10-S014**, and differ from D08-S011 / D09-S010 (where Phase 1 = Shapley *and* DR, Phase 2 = Transformer). The Dec 2025 decks reassigned the phases relative to this plan.

### D10-S011 — Propensity Weighting Example – Calculating LEADS Attribution (visible slide 12)

Slide number **12**, footer `Internal`. Same worked example as D08-S006, with the feature vector here labelled **`Model Scores`** rather than `Customer Features`.

- Left, `Expected Target Customer converted`: model scores `0.8, 0.7, 0.9, 0.8, …` → `Leads Propensity Model` → **0.9** `Likely to receive leads channel`; channel flags `Direct Mail 0, Telemarketing 0, Leads 1, Email 0, EasyLine 0` with an all-zero counterfactual block; `Response Model` → **0.25** `Probability of response when contacted = PR₁`, **0.22** `when not contacted = PR₀`; `Lower DR Contribution = 0.86`.
- Right, `Surprise Target Customer converted`: model scores `0.2, 0.4, 0.4, 0.7, …` → **0.1** `Unlikely to receive leads channel`; `Response Model` → **0.08** `= PR₁`, **0.02** `= PR₀`; `Higher DR contribution 9.26`.
- Formula both sides: `PR₁ − PR₀ + (Actual response − P(response) when treated) / propensity`. Bottom: `Average(0.86, 9.26, … all customers)` → `Leads Attribution`.

- Identical numbers to D08-S006, confirming that worked example originated in this plan deck.

### D10-S012 — Executive Summary (visible slide 14)

Slide number **14**, footer `Internal`.

- `Motivation:` `Marketing channel attribution is crucial. It helps to evaluate the effectiveness of marketing campaigns and reveals which channels are most successful at driving conversions and revenue. It allows to justify marketing spend and identify where to double-down.`
- `Objective` — `Develop a data-driven approach.`; `Assess incremental channel contributions.`; `Be automated and scalable.`
- `Marketing Applications` — `ROI adjustments`; `Budget optimization`; `Channel utilization monitoring`

- The Objective and Marketing Applications columns are word-for-word those in D07-S007 / D09-S012. The Motivation is written as a paragraph here rather than the bulleted questions used there, and **omits the 80%/60% Direct Mail figure**. This is a third variant of the executive summary across the file (see also D09-S013).

### D10-S013 — Our Position in Industry (visible slide 13)

Slide number **13** `[rendered as stacked 1/3]`, footer `Internal`. The familiar timeline asset, here annotated with **three dated phase arrows**:

- `Phase 1 (Jan 2026)` → pointing at `Shapely Value`
- `Phase 2 (Apr 2026)` → pointing at `Causal Models`
- `Phase 3 (Sep 2026)` → pointing at `Transformer Models`

Timeline entries as before (Rules Based; Logistic Regression 2011; Bayesian 2014; Survival Theory 2014; Markov Chain 2018; Shapely Value; LSTM; Causal Models 2020 `Camta` / 2022 `CausalMTA`; Transformer Models 2025 LiDDA / NNN). The TD arrow points at `Rules Based`.

- This version assigns **2018 to Markov Chain** and gives `Shapely Value` no year — matching D04-S030 / D07-S002, and differing from D10-S014 where 2018 sits against `Shapely Value`. The two variants appear in the **same deck**.
- The three phase arrows here map onto the same method rows as the D10-S014 roadmap, and confirm Phase 2 = Causal Models, not Transformer.

### D10-S014 — Multi-Touch Attribution – Strategy Overview (visible slide 2)

Slide number **2**, footer `Internal`. Viewed in presentation mode (`usc-powerpoint.officeapps.live.com` banner overlaps the title).

**This is the slide recorded as D07-S025**, whose printed number and layout conflicted with the rest of D07. It belongs here. Content confirmed identical:

- **Objectives** — `Quantify true incremental impact across channels`; `Enable data-driven budget allocation`; `Build a scalable measurement framework`. **Marketing Applications** — `Budget optimization`; `Channel contribution clarity`; `Customer journey personalization`. Closing: `From measurement transparency -> to AI-driven optimization`.
- **Industry Positioning** — Rules Based; Logistic Regression 2011; Bayesian 2014; Survival Theory 2014; **Shapely Value 2018**; Causal Models 2020; Transformer Models 2025.
- **Roadmap** — Phase 1 `Shapley Value` (`Fair and explainable credit allocation`; `Game-theory framework`) **Jan 2026**; Phase 2 `Doubly Robust` (`True incremental impact measurement`; `Bias correction - confounding`) **Apr 2026**; Phase 3 `Transformer Model` (`Sequence-aware AI decision engine`; `Cross-channel interaction learning`) **Sep 2026**.

- The D07-S025 entry should be read as a stray screenshot of this deck. The earlier flag there is now resolved.

## D10 classification and checks (first batch)

| Slides | Classification | Evidence boundary |
|---|---|---|
| D10-S002, S006 | Deck metadata | Filename, title, cover date, deck length. Cover date conflicts with internal roadmap dates. |
| D10-S005, S009, S012, S014 | Framing / problem statement / positioning | Data-availability position, confounding explanation, executive summary, strategy overview. |
| D10-S001, S003, S004, S011 | Method / plan design | Phase-by-phase method descriptions with illustrative numbers; no results. |
| D10-S008 | Descriptive treated-vs-untreated comparison | Raw conversion rates and naive lift by channel. Unadjusted and confounded by the deck's own argument; some cells have tiny treated samples. |
| D10-S007 | Model-based attribution comparison | Response-model vs DR mean-absolute SHAP, no commentary, different axis scales, sign not recoverable. |
| D10-S010, S013 | Roadmap | Phase contents and dates; two printed years are almost certainly typos. |

## D10 claims, tensions and questions (first batch)

- **Important presentation claims:** the phased plan is Shapley (Jan 2026) → causal inference / Doubly Robust to overcome confounder bias (Apr 2026) → Transformer model (Sep 2026); DR `provides more reliable estimates of channel impact`; channel sequence `was not tracked`; four channels (Email, Mobile, Phone, Web) show raw lift **below 1.0**.
- **Resolution:** the `Multi-Touch Attribution – Strategy Overview` slide recorded at D07-S025 belongs to this deck (D10-S014, slide 2). The earlier numbering/layout flag is closed.
- **Tension (material):** the cover date **Feb 17, 2025** cannot be reconciled with a roadmap beginning Nov 2025 and phase arrows dated 2026. Most likely a typo for 2026; not established.
- **Tension:** two slides in this deck both print slide number **4** (D10-S001 Phase 1 Shapley response model, D10-S009 Confounding).
- **Tension:** the roadmap prints `Jan2025` and `Feb 2025` between `Nov 2025` and `April 2026`.
- **Tension (cross-deck, resolved direction):** this deck's phase assignment (1 = Shapley, 2 = DR/causal, 3 = Transformer) matches D07-S025 but **not** D08-S011 / D09-S010, where Phase 1 covers Shapley *and* DR and Phase 2 is the Transformer. Combined with the data-availability wording (S005) and the weaker DR benefit statement (S003), the evidence points to D10 being the earlier plan and the Dec 2025 decks reflecting a later reassignment.
- **Tension (within deck):** D10-S013 dates 2018 to `Markov Chain` while D10-S014 dates 2018 to `Shapely Value` — the same timeline asset, two variants, one deck.
- **Tension:** D10-S007's two methods rank channels very differently (Mobile first under the response model at +0.32 but mid-pack under DR; Display first under DR), and the slide offers no commentary or reconciliation.
- **Observation:** D10-S008's naive lift of **10.32 for channel_Affiliate rests on 31 treated customers and 6 conversions**; Onsite_Banner (562) and Social_CT (911) are also very small. No uncertainty is shown.
- **Observation:** a fourth distinct channel schema appears here (twelve channels including Affiliate, Onsite_Banner, Social_CT), and the implied population ≈1,652,021 matches no other cohort figure in the file.
- **Questions to check against code/results:** Is the cover date a typo, and what is the deck's true date? Which slide is really slide 4? What population and window produced the 1,652,021-customer conversion summary, and how does it relate to the 2,592,528 cohort in D09-S018? Why are Email, Mobile, Phone and Web below 1.0 raw lift, and does the DR work recover positive effects for them? Are the D10-S007 SHAP comparisons on the same population and features, and why are the axis scales different? What are the `3 other features` summed in the response-model chart? Which twelve-channel source feeds S008, given later decks use eight (D09) and five (D08)?

## Processing log (continued)

- 2026-09-09: Processed 25 screenshots from inferred deck `DR_Shap_executive.pptx` as `D04-S001`–`D04-S025`. The final five include one repeated full view and close-ups of the DR diagram and Slide 14 table. Close-up numeric values were transcribed only where legible; uncertain labels are explicitly marked.
- 2026-09-09: Processed the final 9 screenshots of deck D04 as `D04-S026`–`D04-S034`, in displayed upload order. Covers visible slides 18, 15, 30, 16 and 17 plus four close-ups (decile chart, both slide-18 journey charts, and the Shapley-vs-DR chart already recorded at D04-S024). Unreadable or ambiguous items flagged: slide-30 page number rendering, decile labels 5.97%/2.48%, the 24.83%/24.43% journey label, three blurred customer counts on the slide-18 customer chart, the clipped `+0.0851` DR label, and the cropped speaker notes on slide 17.
- 2026-09-09: Opened deck `D05` (`executive_review.pptx`, “PRISM LUMEN AI”, Slide 1 of 35) and processed 4 screenshots as `D05-S001`–`D05-S004`, covering visible slides 1–4 (cover/editor context, marketing personalization framing, product-to-next-best-channel positioning, system overview). Speaker notes on slides 2–4 are cropped at the left edge and are transcribed only as fragments. The `Appendix` section (slides 5–35) has not been supplied.
- 2026-09-09: Opened deck `D06` (`mta_biases.pptx`, “Multi-Touch Attribution Project – Introduction to Bias”, Dec 5 2025, Slide 1 of 26) and processed 12 screenshots as `D06-S001`–`D06-S012`, covering visible slides 1–12 in upload order. Slide numbers on the `Implicit Biases` and `Order-of-Actions Bias` slides were not legible and are marked inferred. The Sankey on slide 4 is legible for node labels only; no flow volumes transcribed.
- 2026-09-09: Opened deck `D07` (`literature_review.pptx`, “Multi-Touch Attribution Project – Literature Review”, Dec 5 2025, Slide 1 of 24) and processed the first batch of 20 screenshots as `D07-S001`–`D07-S020`. Five slide numbers were not visible and are flagged; the attribution-score bar labels are printed vertically and several digits are uncertain. D07-S002 is the same asset as D04-S030 and is cross-referenced rather than re-transcribed.
- 2026-09-09: Processed the second D07 batch of 7 screenshots as `D07-S021`–`D07-S027`: the NNN summary row (slide 19) and LiDDA slides 20–24, plus a `Strategy Overview` slide whose printed number (1) conflicts with the deck cover and whose layout differs from the rest of D07 — flagged as possibly a different file rather than reassigned. Box-plot row labels on slide 23 and subscript notation on slide 24 are partially readable.
- 2026-09-09: Opened deck `D08` (`Channel_Attribution_Doubly_Robust_demo.pptx`, “MTA – Doubly Robust Estimate”, Dec 5 2025, Slide 1 of 20) and processed the first batch of 20 screenshots as `D08-S001`–`D08-S020`. Eight slide numbers were not visible and are flagged. The four per-channel `Results` charts carry no printed bar labels, so only axis-relative approximations are recorded, explicitly marked as such; the two propensity-overlap ranges and the ROC-AUC tables are transcribed exactly.
- 2026-09-09: Processed the final D08 screenshot as `D08-S021` (`Results – channel_DirectMail`), completing the five per-channel overlap/heterogeneity slides. Slide number not visible; bar values unlabelled and recorded as axis-relative approximations. Overlap ranges for all five channels are now consolidated in the D08 tensions section.
- 2026-09-09: Opened deck `D09` (`Channel_Attribution_Shapley_value_demo.pptx`, “Multi-Touch Attribution Project Demo – Phase 1”, Dec 5 2025, Slide 1 of 25) and processed the first batch of 20 screenshots as `D09-S001`–`D09-S020`. Three slide numbers were not visible and are flagged. This deck resolves two open D08 questions: the eight two-letter channel codes and the numeric legacy-model-score feature IDs. Unlabelled pies and the SHAP beeswarm were described rather than assigned values.
- 2026-09-09: Processed the second D09 batch of 13 screenshots as `D09-S021`–`D09-S033`. Six are clearer repeats of slides 16, 18, 19, 20 and the two unnumbered slides, recorded as their own IDs and cross-linked without duplicating claims. New material: slides 21, 22, 23, 24, 25 and close-ups of both decile-analysis charts. Full decile tables (test and train) and the PRISM-head AUC table are transcribed exactly; the LD share on slide 21 is partly hidden behind the legend and is flagged.
- 2026-09-09: Opened deck `D10` (`Channel_Attribution_plan.pptx`, “Multi-Touch Attribution Project Plan”, cover dated Feb 17 2025, Slide 1 of 14) and processed the first batch of 14 screenshots as `D10-S001`–`D10-S014`. Two slides both print the number 4 and the roadmap prints two 2025 dates that must be 2026 — both flagged, not corrected. This deck resolves the D07-S025 stray-slide flag: that Strategy Overview slide is D10 slide 2, and the D07 entry has been annotated accordingly.
- 2026-09-09: Processed 2 monitor photographs of the SharePoint `presentations` library (TECE AIML Practice site) as `L01-S001`–`L01-S002`, in upload order. These are file listings, not slides, so no deck ID was opened; a new `L` prefix was added to the ID conventions. Fifteen entries transcribed (14 files + a `Results` folder). Nine of ten processed decks are matched to source files by filename; `D02` is matched only probably, to `MTA_MMM_two_stream_timeline.pptx`. Year digits are truncated on five `Created` values and are marked `[TRUNCATED]`; `Modified By` surnames are clipped and marked partially readable; the `Camaigns`/`Camaiqns` rendering of one filename is flagged as image blur. New tensions 8 and 9 record that printed cover dates conflict with file metadata and that deck chronology cannot be ordered reliably from dates alone. Five library files and one folder remain unprocessed.
