"""Arithmetic on printed aggregate numbers, not a TD model reproduction.

Python standard library only. No source data access, network, model training,
notebook execution, or side effects. Prints JSON to stdout.
"""
import json
from math import factorial


def main():
    ate = {
        "Email": -0.0052,
        "Leads": 0.0429,
        "Direct Mail": 0.0058,
        "EasyLine": -0.0040,
        "eBank": 0.0109,
    }
    denom = sum(abs(v) for v in ate.values())
    # D09-S002: exact-coalition rates as printed; no claim of causal identification.
    coalition_rates = {
        (0, 0, 0): 0.0108, (0, 0, 1): 0.0188,
        (0, 1, 0): 0.0066, (0, 1, 1): 0.0158,
        (1, 0, 0): 0.0096, (1, 0, 1): 0.0106,
        (1, 1, 0): 0.0154, (1, 1, 1): 0.0177,
    }
    shapley = {}
    for j, channel in enumerate(["RD", "EM", "DM"]):
        total = 0.0
        for coalition, value in coalition_rates.items():
            if coalition[j]:
                continue
            k = sum(coalition)
            augmented = list(coalition)
            augmented[j] = 1
            weight = factorial(k) * factorial(2-k) / factorial(3)
            total += weight * (coalition_rates[tuple(augmented)] - value)
        shapley[channel] = total
    results = {
        "scope": "Arithmetic using the consolidated transcription; original figures and code not verified.",
        "D03_S012": {
            "printed_rate_percent": {"bau": 1.31, "constrained": 1.45},
            "absolute_gain_pp": 1.45 - 1.31,
            "relative_gain_percent": (1.45 / 1.31 - 1) * 100,
            "relative_gain_bounds_assuming_nearest_0_01_percent_rounding": [
                (1.445 / 1.315 - 1) * 100,
                (1.455 / 1.305 - 1) * 100,
            ],
        },
        "D04_S011": {
            "printed_auc": [0.7017, 0.7510],
            "absolute_auc_gain": 0.7510 - 0.7017,
            "relative_gain_percent": (0.7510 / 0.7017 - 1) * 100,
        },
        "D08_S007_S013": {
            "signed_ate_as_transcribed": ate,
            "absolute_sum": denom,
            "absolute_magnitude_shares_percent": {k: abs(v)/denom*100 for k, v in ate.items()},
            "note": "Rounded source estimates; these are global magnitude shares, not per-conversion credits.",
        },
        "D04_S023_S024_Branch": {
            "event_values_as_transcribed": [0.0851, 0.0003, 0.0003, 0.0002],
            "simple_mean": (0.0851 + 0.0003 + 0.0003 + 0.0002) / 4,
            "channel_value_as_transcribed": -0.0037,
            "note": "Incompatible with a simple mean of the listed values; distinct estimators/cohorts/runs could explain this.",
        },
        "D09_S002": {
            "rate_game_shapley": shapley,
            "signed_normalized_shares_percent": {k: v/sum(shapley.values())*100 for k, v in shapley.items()},
            "note": "Assumes v(S) equals the displayed exact-coalition rate. Rounded rates and an unverified value function limit comparison with the slide pie.",
        },
    }
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
