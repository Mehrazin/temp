# Review of the consolidated presentation evidence

Reviewed September 9, 2026. Source: `PRESENTATION_EVIDENCE (5).md`, preserved unchanged in this package. This review examines the supplied transcription and commentary, not the original screenshots or the VDI code. Arithmetic checks use the numbers as transcribed. They do not reproduce the TD models.

## Update following the project owner's history clarification

The owner subsequently explained the project sequence (OWNER-20260909; see `08_PROJECT_HISTORY_UPDATE.txt`). The broad differences between decks are now substantially explained: early TMIA campaign research, a small April–July 2025 credit-card measurement-data study, expansion into diagnostic/predictive Lumen work, then data-replication effort and a renewed focus on delivering MTA in the measurement team's zone by September 2026. Dates are approximate. The owner took over leadership around May 2026.

The current priority is **MTA first for September, predictive work afterward**. This supersedes earlier prediction-first scheduling language, including that part of D02. Early roadmaps remain history. The later showcased baseline results were based on the small study snapshot according to the owner; adapting and validating that work on the full measurement data is distinct from having already delivered it there.

TMIA entries can mark batch assignment or Leads-list generation rather than actual contact. The measurement pipeline also has a reported legacy-system-to-Salesforce transition and supplementary feeds, making source coverage/parity a concrete integration question. Those are now explicit Copilot checks. Presentation questions can be answered directly by the owner; moving decks into VDI is unnecessary.

This clarification resolves much of the **historical interpretation**, but does not settle arithmetic discrepancies, exact score timing, estimator implementation, fractional-allocation rules or full-data acceptance. The original review below remains useful for those specific checks. Do not treat its request to reconstruct chronology as an invitation to ignore the owner's explanation.

**The file is sufficient to start a focused code review. The main missing piece is the link from each important presentation result to its actual model, population and generating output—not another full transcription pass.**

## What this evidence adds

| Work represented | What the document records | How to use it |
|---|---|---|
| Measurement-team pipeline audit | Detailed join/rank logic; observability, history-window and excluded-event analyses; notebook/report inventory | Verify decisive predicates and saved outputs; reuse the EDA rather than commissioning it again. |
| Campaign/TMIA modeling | Eight channel flags, legacy scores, explicit population/split tables and coalition-Shapley results; five-channel DR diagnostics | Preserve as a distinct historical branch. It helps establish what work was done, even if the production measurement pipeline doesn't use it. |
| Measurement-journey modeling | Nine channels, 24 event features, PRISM heads, existing-card indicator, response and DR figures | Reconstruct its actual training and scoring windows; do not inherit the TMIA variant's validation. |
| Prospective decisioning | Controllable-action framing; optimizer notebooks; BAU/constrained/unconstrained simulation and opt-out diagnostics | Separate recommendation output and estimated policy value from retrospective conversion credit. |
| Literature and roadmap | LiDDA, causal methods, simulated/transformer work, MMM and incrementality plans | Record research and stated plans, with implementation status determined separately. |

The material also resolves some earlier unknowns: D09 defines the eight legacy channel codes and model-score IDs, documents a TMIA/campaign schema, and supplies calibration and sample-count tables. Those should not remain generic questions for you.

## Six checks that affect the presentation

### 1. Which fractional output actually exists?

D08-S007 explicitly plots **absolute average treatment-effect shares**. Using the signed values from D08-S013:

\[
s_c=\frac{|\widehat{ATE}_c|}{\sum_j|\widehat{ATE}_j|}.
\]

This calculation reproduces the displayed shares after rounding: Leads 62.4%, eBank 15.8%, Direct Mail 8.4%, Email 7.6%, EasyLine 5.8%. The displayed Leads label is 62.3%; underlying unrounded estimates can account for that tenth-point difference. Email and EasyLine have **negative** signed estimates.

This is an aggregate magnitude chart. It does not establish a rule that allocates each conversion among its observed touchpoints. Copilot must find the actual customer/conversion allocation code, its denominator, event masking, negative handling and aggregation order. If it finds only global importance charts, that is a concrete remaining implementation question—not evidence that no useful modeling was done.

### 2. Is the customer score a DR pseudo-outcome or a fitted CATE?

D04-S020 presents a per-row correction involving the observed outcome; S027 calls a corrected output customer-level CATE. The difference matters for future scoring:

\[
\psi_i=\hat\mu_1(X_i)-\hat\mu_0(X_i)
+\frac{T_i(Y_i-\hat\mu_1(X_i))}{\hat e(X_i)}
-\frac{(1-T_i)(Y_i-\hat\mu_0(X_i))}{1-\hat e(X_i)}.
\]

An AIPW estimate can average these scores; a DR learner fits a final effect model to corrected targets. The code review should establish which output feeds attribution and ORCA. The illustrative score 9.26 in D08 is not automatically an arithmetic error: inverse-weighted pseudo-outcomes need not be bounded like probability differences. It should not be read as that customer's conversion-probability uplift. [EconML's DR methodology](https://www.pywhy.org/EconML/spec/estimation/dr.html) describes the distinction between corrected targets and the final conditional-effect model.

### 3. Reconcile the headline simulation and prediction gains

| Anchor | Arithmetic using the transcription | What remains to verify |
|---|---|---|
| D03-S012: 1.31% BAU → 1.45% constrained | +0.14 percentage points; **about +10.7% relative**, not +13% | Exact caption/footnote, population, weighting and generating output. Even ordinary two-decimal rounding implies roughly 9.9–11.5%, not 13%. |
| D04-S011: AUC 0.7017 → 0.7510 | **+0.0493 absolute AUC**; about +7.03% relative | Meaning of the printed “+4.93%” annotation and comparable evaluation cohort. |

Do not silently replace the old figures: reconcile the source. The D03 notes explicitly call impact model-estimated historical simulation; that qualification belongs with the result.

### 4. Channel and event results need their own lineage

D04-S023 shows Branch mean DR −0.0037. The four Branch event values transcribed in S024 are positive; their simple mean is +0.021475. These tables therefore cannot be a simple average of the same displayed event estimates as currently transcribed. They may be separate fits, different populations, iterations or a transcription issue. This does **not** establish a model bug; it identifies exactly what to trace.

Likewise, D03's alternative ATE tiles and D09's alternative Shapley shares should retain their run identities. “Latest screenshot” is not a version-selection rule.

### 5. Coverage figures use different denominators

The report distinguishes 10,536,464 supplementary audit entities from 10,123,225 production IDs, and another primary audit uses 10,538,441. In particular, 82.37% technical linkage and 34.18% production attribution must not be presented as successive percentages over one common population without reconciliation.

Another important change from the earlier verbal description: R01 describes an **OR-based candidate join**, special timing rules and retained unattributed conversions. Copilot should check those precise predicates. A candidate join, a displayed path and a winner are different outputs.

### 6. An actionable treatment is different from a recorded reaction

D09 records TMIA/contact-history fields and control flags; D04/D03 also use opened, clicked, interested and other reaction events. D04's optimizer illustration includes Display/Paid Search/SEO, while D03 explicitly recommends controllable Email/Direct Mail/Leads actions. Preserve these as potentially different variants. The review should identify what the implemented treatment actually means and what the optimizer can assign.

## Interpretations in the consolidated file that need correction

These are corrections to the **commentary**, not claims of errors in your implementation:

- A propensity range ending near 0.19 or two occupied bins alone does not establish failed overlap. Both treatment groups' support, counts, tails, weights and binning rules matter. Conversely, a range spanning almost 0–1 doesn't certify good overlap.
- The Direct Mail commentary says all subgroup values exceed the pooled ATE, but its own approximate list contains lower values. That particular premise is unsupported.
- A February 2025 plan can contain future 2026 milestones. Future dates do not disprove its cover date. Some ordered timeline entries look inconsistent, but chronology and supersession remain unresolved.
- Different model rankings, channel sets or bottom-decile rates are not automatically contradictions. Cohort, task, units and method must match first.
- D09's isotonic-calibration results cannot verify D08's implementation merely because both discuss calibration. Similarly, low AUC of one product head does not alone prove it is an unusable feature for another model.
- A named “control” cell does not establish randomized assignment for the whole analysis population. The recorded assignment process is the evidence needed.
- A diagram, a research claim, implementation code, saved output, an accepted release and deployed use are separate states. The file sometimes moves too quickly from a presented claim to a statement that a real run or chronology is established.

I have preserved the original document and put these qualifications into the review instructions so neither earlier model's commentary becomes assumed ground truth.

## Only a few additional views are worth collecting now

| Priority | What to provide | Why |
|---|---|---|
| First | The preferred current **Diagnostic Signal Results** slide from `LumenAI_VP_Deck`, including the complete `*` footnote, title and any scope note (D03-S008/S009/S018). If none is designated current, say so. | Resolve units/asterisk and which result is intended for the showcase. One full slide plus one close-up if necessary. |
| First | **What Changes Under Lumen AI**, including the full expected-impact card and notes (D03-S012/S013). | Resolve the approximately +13% caption versus the displayed rates. One or two views. |
| Optional | The filename/title of the single item inside SharePoint **Results**, and its overview only if it contains a result or validation not already covered. | It is the most promising uninspected results artifact; we do not yet know its contents. |
| Owner answer, no new photos needed | Which deck/result set and which roadmap are currently intended for the AVP? | Source inspection can recover code lineage, but cannot infer stakeholder approval. If undecided, the coordinator will propose a selection and label it as such. |

No need now for all 31 missing D05 appendix slides, all remaining D04 slides, another full HTML-report transcription, or all 2021 material. Original HTML text, notebook results and formulas are better resolved inside VDI. The figures above are useful additions, not blockers to running the review.

## How this changes the Copilot workflow

Use **three focused reviews in parallel**, then one coordinator: data/production logic; modeling/fractional allocation; results/decisioning evidence. All use the same immutable text snapshot, write separate findings, and cite specific cells/outputs. The coordinator resolves disagreements from evidence rather than voting among models, then produces ten compact review cards.

The added prompts include actual filenames and slide anchors, so Copilot can trace existing work directly. They do not ask you to repeat the EDA, force a switch from XGBoost, assume a transformer was delivered, or equate normalized effect magnitudes with per-conversion attribution. Models and high effort can help inspect difficult code, but the important improvement here is the bounded assignment and shared evidence record.
