"""Prepare local text extracts and install the review prompts. No notebook execution."""
from pathlib import Path
import shutil
import sys

KIT = Path(__file__).resolve().parent


def main():
    if sys.version_info < (3, 9):
        raise SystemExit('Use an existing Python 3.9+ interpreter.')
    addon = KIT / 'review_addon' / 'MTA_Evidence_Review'
    if not (addon / '01_COORDINATOR_START.txt').is_file():
        raise SystemExit('Incomplete package: review_addon/MTA_Evidence_Review is missing.')
    # This trusted extractor treats originals as data; no original code is executed.
    sys.path.insert(0, str(KIT))
    import prepare_text
    workspace, records = prepare_text.prepare(KIT.parent)
    destination = workspace / 'MTA_Evidence_Review'
    if destination.is_symlink():
        raise SystemExit('Review destination must not be a symbolic link.')
    # Package has no live run pointers/checkpoints: merge preserves existing runs.
    for source in addon.rglob('*'):
        target = destination / source.relative_to(addon)
        if target.is_symlink():
            raise SystemExit('Review package destination contains a symbolic link.')
    shutil.copytree(addon, destination, dirs_exist_ok=True)
    print('\nREVIEW READY')
    print('Open ONLY this folder in a new VS Code window: ' + str(workspace))
    print('Start a fresh chat with: ' + str(destination / '01_COORDINATOR_START.txt'))
    print('Do not use the older 02_REVIEW_PROMPT.txt in the workspace root for this run.')
    print('No Databricks connection or notebook execution occurred.')


if __name__ == '__main__':
    main()
