# Tonight: existing files to one review report

This is the complete entry package. It includes the existing text extractor, the project history, presentation evidence and the updated parallel-review prompts. You do not need the earlier ZIPs. No new Databricks analysis, model training or API configuration is required.

## 1. Put the folder in VDI

Extract the ZIP. Place its folder **MTA_VDI_Text_Kit** directly inside your investigation folder, beside **Measurement team** and **Our team**. Your source notebooks, saved notebook results and reports stay where they are. If that kit folder already exists, merge/replace the package files; do not delete your source folders or generated review workspace.

Expected location: `Documents/Investigate_mta/MTA_VDI_Text_Kit/setup_review.py`. Use the actual investigation-folder spelling on your machine. Avoid a second nested MTA_VDI_Text_Kit folder.

## 2. Preparation chat: Sol Low

Open the investigation folder in VS Code. Close original notebook/image tabs. Open `MTA_VDI_Text_Kit/00_START_PROMPT.txt`, copy its complete contents and send them in a fresh Copilot **Agent** chat. Do not attach notebooks or select whole-workspace context.

Copilot runs the local preparation script. It converts notebooks/reports to text, preserves saved textual outputs, records image omissions and installs the review prompts. Originals stay unchanged. A new text snapshot is created; previous review outputs remain available. This reads downloaded files, not Databricks tables.

## 3. Coordinator chat: Sol Medium

When preparation finishes, use **File > New Window > Open Folder** and open only the reported **mta_text_workspace** folder. Keep the original source folder out of this window.

Open `MTA_Evidence_Review/01_COORDINATOR_START.txt`. Paste its complete contents into a new Copilot Agent chat. It creates the shared index and a numbered review run, then stops. Label the chat Coordinator if convenient.

## 4. Three reviewers: start together after coordinator setup

Open three new Copilot Agent chats in that same text-workspace window. Each gets one complete prompt from MTA_Evidence_Review:

| Chat | File to paste | Setting | Responsibility |
|---|---|---|---|
| Data | `02_DATA_REVIEW.txt` | Sol Medium | Measurement code, existing EDA, coverage, join/rank logic and Salesforce supplements |
| Model | `03_MODEL_REVIEW.txt` | Sol High | Our team's actual training/inference, PRISM features, DR and fractional-attribution calculation |
| Results | `04_RESULTS_REVIEW.txt` | Sol Medium | Existing numeric results, plot-generation lineage and what can be presented |

They read the same pinned snapshot and write separate directories. They do not edit one another's outputs. No copying responses between chats is required. Use Agent mode with the normal local-file permissions; respond to actual VS Code execution approvals if shown.

## 5. Consolidate: return to Coordinator, Sol High

When all three reviewers report completion, return to Coordinator. Select High if available and paste `MTA_Evidence_Review/05_COORDINATOR_SYNTHESIS.txt`.

It writes **REVIEW_CARDS.html**, **AVP_BRIEF.md**, **TECHNICAL_APPENDIX.md**, **CLAIM_LEDGER.csv** and short deferred checks under the numbered directory in `90_review/presentation_evidence/`. It reports the exact location. It resolves disagreements from source evidence and labels unresolved claims; no additional audit or training is launched.

## 6. What to bring back

Open **REVIEW_CARDS.html** in your normal browser, not in an image tool inside Copilot. Bring the **12 labeled cards**: C01–C10 plus T01 and T02. The last two preserve the actual model/feature/timing and fractional-allocation details needed for technical discussion. Aim for one photo per card, but use two if needed for legibility. Include the card title, metric units and scope notes. The full appendix stays available in VDI.

If time runs short, prioritize C02–C06, C08, T01 and T02; the other cards can follow. Upload them to the existing presentation-planning chat. You do not need to transcribe them yourself or collect all original plots again.

## Settings and practical boundaries

Use Low for executing the provided preparation, Medium for extraction/review and High for the two tasks with the most reasoning. Max is not the starting choice tonight. These are practical recommendations using the Sol option you reported, not a measured runtime guarantee for your Copilot installation. General reasoning guidance favors lower effort for speed and higher effort for difficult reasoning: [official OpenAI guidance](https://developers.openai.com/api/docs/guides/reasoning#reasoning-effort).

No second model is required for tonight. Opus can later review one genuinely unresolved issue; that doesn't need to delay the report.

The working goal is fractional attribution for the measurement team. Precise rollout/acceptance details can be aligned later and do not block tonight's evidence extraction. Missing outputs are marked unavailable; the model must not fabricate values or treat a generated EDA summary as proof of execution.

If a chat becomes too long, use `06_CHECKPOINT.txt`, then a new chat with `07_RESUME.txt`. If one reviewer stops without completing, resume that role; don't start all reviews again.

Do not use the older generic review prompts sitting at the workspace root. For this run, the coordinator and specialist prompts are all inside **MTA_Evidence_Review**. Current-run instructions in `09_TONIGHT_MODE.txt` supersede the older broader-audit wording.
