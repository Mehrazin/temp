import contextlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from prepare_text import prepare, extract_notebook, html_text


def notebook(output='0.81', code='print("test")'):
    return {'nbformat':4, 'nbformat_minor':5, 'metadata':{}, 'cells':[
        {'cell_type':'markdown','source':['# Analysis\n','![chart](attachment:chart.png)'], 'attachments':{'chart.png':{'image/png':'SECRET_IMAGE_PAYLOAD'}},'metadata':{}},
        {'cell_type':'code','id':'cell_a','execution_count':3,'source':[code], 'metadata':{},'outputs':[
            {'output_type':'stream','name':'stdout','text':[output]},
            {'output_type':'display_data','data':{'image/png':'SECRET_IMAGE_PAYLOAD','image/svg+xml':'<svg>SECRET_SVG</svg>','text/plain':'<Figure size 600x400>'},'metadata':{}},
            {'output_type':'display_data','data':{'text/html':'<table><tr><th>Metric</th><th>Value</th></tr><tr><td>AUC</td><td>0.81</td></tr></table><script>SECRET_SCRIPT</script>', 'application/json':{'n':120,'rate':0.81},'application/vnd.plotly.v1+json':{'x':'SECRET_PLOTLY'}},'metadata':{}},
        ]}
    ]}


class ExtractionTests(unittest.TestCase):
    def run_prep(self, root, **kwargs):
        with contextlib.redirect_stdout(io.StringIO()):
            return prepare(root, **kwargs)

    def test_mime_attachments_removed_and_numeric_text_preserved(self):
        notices=[]
        text, codehash=extract_notebook(json.dumps(notebook()).encode(), notices)
        for secret in ['SECRET_IMAGE_PAYLOAD','SECRET_SVG','SECRET_SCRIPT','SECRET_PLOTLY','![chart]']:
            self.assertNotIn(secret,text)
        self.assertIn('AUC',text)
        self.assertIn('0.81',text)
        self.assertIn('"n": 120',text)
        self.assertIn('CELL 2 OUTPUT 2',text)
        self.assertIn('image/png',text)
        self.assertEqual(len(codehash),64)

    def test_html_visible_table_not_scripts_or_embeds(self):
        notices=[]
        text=html_text('<div>Hello</div><img src="data:image/png;base64,AAAA"><svg><text>SECRET</text></svg><script>SECRET2</script><table><tr><td>Count</td><td>500</td></tr></table>',notices)
        self.assertIn('Hello',text)
        self.assertIn('500',text)
        self.assertNotIn('SECRET',text)
        self.assertNotIn('data:image',text)

    def test_original_not_executed_or_changed(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            sentinel=root/'should_not_exist.txt'
            nb=root/'experiment.ipynb'
            original=json.dumps(notebook(code=f'open({str(sentinel)!r}, "w").write("BAD")')).encode()
            nb.write_bytes(original)
            out,records=self.run_prep(root)
            self.assertFalse(sentinel.exists())
            self.assertEqual(nb.read_bytes(),original)
            self.assertEqual(len(records),1)
            self.assertTrue((out/'02_REVIEW_PROMPT.txt').exists())
            self.assertTrue(all(p.suffix in {'.txt','.md','.json','.csv'} for p in out.rglob('*') if p.is_file()))

    def test_duplicate_code_different_saved_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for name,value in [('a','0.81'),('b','0.90'),('c','0.81')]:
                (root/(name+'.ipynb')).write_text(json.dumps(notebook(value)))
            _,rs=self.run_prep(root)
            self.assertEqual(rs[0]['ordered_code_sha256'],rs[1]['ordered_code_sha256'])
            self.assertNotEqual(rs[0]['sha256'],rs[1]['sha256'])
            self.assertEqual(rs[0]['sha256'],rs[2]['sha256'])

    def test_malformed_and_binary_are_explicit_not_fatal(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'broken.ipynb').write_text('not JSON')
            (root/'figure.png').write_bytes(b'not decoded')
            (root/'good.py').write_text('x=5')
            _,rs=self.run_prep(root)
            statuses={r['original_relative_path']:r['status'] for r in rs}
            self.assertEqual(statuses['broken.ipynb'],'extraction_error')
            self.assertEqual(statuses['figure.png'],'not_extracted_unsupported')
            self.assertEqual(statuses['good.py'],'extracted_text')

    def test_repeat_run_preserves_review_and_does_not_ingest_output(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'a.py').write_text('x=5')
            out,rs=self.run_prep(root)
            (out/'90_review').mkdir()
            (out/'90_review'/'CHECKPOINT.md').write_text('saved')
            old=list((out/'snapshots').iterdir())[0]
            old_manifest=(old/'SOURCE_MANIFEST.json').read_bytes()
            _,rs2=self.run_prep(root)
            self.assertEqual(len(rs2),1)
            self.assertEqual(len(list((out/'snapshots').iterdir())),2)
            self.assertEqual((old/'SOURCE_MANIFEST.json').read_bytes(),old_manifest)
            self.assertEqual((out/'90_review'/'CHECKPOINT.md').read_text(),'saved')

    def test_size_limit_and_chunking(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'oversize.md').write_text('word ' * 300000)
            (root/'long.txt').write_text('numerical finding 123\n' * 7000)
            out,rs=self.run_prep(root,max_file_mb=1)
            by_name={r['original_relative_path']:r for r in rs}
            self.assertEqual(by_name['oversize.md']['status'],'not_extracted_size_limit')
            self.assertGreater(len(by_name['long.txt']['text_files']),1)
            combined=''.join((out/f).read_text() for f in by_name['long.txt']['text_files'])
            self.assertEqual(combined.count('numerical finding 123'),7000)

    def test_pptx_text_only(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            with zipfile.ZipFile(root/'deck.pptx','w') as z:
                z.writestr('ppt/slides/slide1.xml','<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:p><a:r><a:t>Result 42</a:t></a:r></a:p></p:sld>')
                z.writestr('ppt/media/image1.png',b'SECRET_IMAGE_PAYLOAD')
            out,rs=self.run_prep(root)
            text=(out/rs[0]['text_files'][0]).read_text()
            self.assertIn('Result 42',text)
            self.assertNotIn('SECRET_IMAGE_PAYLOAD',text)


if __name__=='__main__':
    unittest.main(verbosity=2)
