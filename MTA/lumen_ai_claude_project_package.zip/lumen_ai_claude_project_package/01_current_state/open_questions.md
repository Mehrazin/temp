# Open Questions

Refreshed 2026-06-15. Grouped by theme. Detail and provenance in `02_change_log/2026-06-15_update.md`.

## Data Foundation

1. **MTA vs TMIA vs hybrid** — which source should the predictive model use, or should it combine "what the bank can do" (TMIA) with "what customers reacted to" (MTA)? Unresolved.
2. **Direct-mail sourcing** — the other team's MTA direct-mail code does not work, so DM is pulled from TMIA only (historical `channel_Direct_Mail_Contacted` is effectively empty). When/how is this fixed?
3. **Reconcile scale** — **Reframed (2026-06-16 data-scale correction).** Four distinct layers, counts approximate: (1) prototype experiment subset ≈2–3M customers; (2) prototype test/eval set ≈500K (the ~521K rows; Sample1 ≈100K is a sub-sample of it); (3) full source ≈10–15M customers since ≈2022; (4) cleaned transformer-ready dataset — does not exist yet. *Remaining confirmations:* exact customer counts per layer, and the prototype window **end date (July vs January, depends on experiment version)**. See `02_change_log/2026-06-16_data_scale_correction.md`.
4. **Channel taxonomy / controllability** — confirmed direct control: Email, Direct Mail, Leads, OBTM; semi-control (inbound): branch/phone/Radar_* prompts; MTA-only digital: no control (uncertain). Exact mapping of TMIA names (Radar_*, Ebank_Telemarketing, EasyLine__IVR) to controllable actions is not finalized.

## Modeling & Causal Validity

5. **Underdetermined covariance / `zstat=-inf`** — root cause and whether it is production-blocking for the causal claims (vs. the point-prediction scores actually deployed). Persists after the Tree-VIF removal of `Social_CT` (e.g., Paid_Search). **Root cause identified (2026-06-15 review):** EconML emits this when rank(final-stage feature matrix) < #parameters; the matrix is featurizer(X) + intercept interacted with treatment, so it fires on collinear X columns or too-few-obs-per-arm. Driven here by C2 (treatment-in-X collinearity), rare channels, and overlap violations. Blocks all DR inference (CIs/p-values); point scores less affected. See `method_critiques.md` C1 and `04_outputs/2026-06-15_method_review.md` §3.1/§5.
6. **One-vs-rest DR design** — is placing `t_channel_*` columns in `X` while also using them as `T`/`W` causally sound, or does it leak/collinear? (To verify against EconML; the "s-learner / undetermined matrices" note flags this.) **Review note:** likely the highest-leverage fix for OQ5 — confirm EconML's expected X/T/W contract and remove treatment columns from the conditioning set if they should not be there.
7. **`W_test = zeros` at scoring** — intended counterfactual ("all other channels off") or a simplification to revisit? It shapes the conversion scores feeding the optimizer.
8. **Calibration** — needed or not? It was trialed then disabled (≈no effect; possibly learning identity). Revisit given the optimizer consumes predicted probabilities.

## Validation

9. **Train/test split** — adopt a **time-based / windowed holdout** (e.g., a ±4-month window) instead of the current random 60/20/20? Discussed, not implemented. Also: does the random split explain the unrealistic test-set channel mix?
10. **OPE-vs-PRISM validity** — the "lucky match" comparison gave +11.18% AUC on ~7,070 matched rows; it is an internal self-check, **not significance-tested**, and AUC measures ranking, not incremental uplift. What does it actually license us to claim, and is the sample adequate? (Need to recheck the query/metrics.)
11. **Path to a defensible uplift claim** — what live experiment (e.g., champion/challenger) or defensible off-policy design is realistic before claiming true incremental business impact?

## Optimization & Deployment

12. **Optimization objective** — conversion vs. incremental lift vs. cost-adjusted acquisition vs. NPV/CLTV?
13. **One vs. N recommended channels** — **Resolved in principle (2026-06-16):** the business wants flexibility — top-1, top-K, multiple channels per customer, capacity constraints, allowed-channel filters, no-contact logic, and different objectives (D011). The model stays decoupled: a reusable scorer + a separate config-driven layer makes the choice each cycle (D010). *Remaining:* which use-case subset is in scope for v1 (OQ41).
14. **Output table design** — define the table the monthly/weekly scoring job populates (e.g., per-customer per-channel scores vs. a single recommendation).
15. **Leads / channel caps** — confirm operational capacity limits (business-decided; ~20K–30K) for the constrained optimizer.

## Strategy, Scope & Governance

16. **Transformer option** — **Resolved/decided (2026-06-16):** manager/team confirmed the transformer as the primary direction (D004); XGBoost/DR is now the baseline (D001). Open *execution* questions moved to the "Manager/Team Transformer Confirmation" section below. (Note: the "compliance path cannot transfer between architectures" caveat still stands.)
17. **Business scope / horizon** — credit-card-first now, expanding later; a 2-year vision broken into ~3-month deliveries was discussed (no firm dates).
18. **Productionization & governance** — persist models, clean up/version the notebooks, and plan for the approval/model-validation/compliance cycle (the real bottleneck).
19. **Roadmap revision** — the deck's roadmap (Shapley → DR → Atlantis package → Transformer) is outdated under model-first and needs to be rewritten.

## Raised by the 2026-06-15 Method Review

20. **Optimizer objective: conversion vs. uplift** — the optimizer currently maximizes predicted conversion, which can target "sure things." Should it maximize incremental lift (`conversion_{ch}_1` − `conversion_{ch}_0`), which the DR machinery already produces? (Mostly a wiring change; relates to OQ12.) See `method_critiques.md` C8.
21. **Propensity calibration / AUC-tuning mismatch** — XGBoost propensity tuned to AUC ranks well but may be miscalibrated; DR weighting and the optimizer both depend on calibrated probabilities. Re-evaluate propensity and outcome calibration with Brier/reliability (not "did the number move"). Relates to OQ8. See C4/C5.
22. **Defensible off-policy evaluation to replace "lucky match"** — adopt an IPS / doubly-robust off-policy estimator of the Lumen *policy*'s value vs. the logged/BAU policy, with confidence intervals, before any live test. This is the principled replacement for the selection-on-agreement OPE-vs-PRISM comparison (OQ10). See C7/C11.
23. **Evaluate with uplift-native metrics (Qini / AUUC)** — for a next-best-action system, report Qini curves / AUUC (incremental targeting efficiency) rather than response-model AUC. See review §6.
24. **Causal-forest / meta-learner benchmark** — once the data foundation is fixed, run `CausalForestDML` (honest splitting, valid CIs, native multi-arm) and X-/DR-learners head-to-head against `LinearDRLearner`; the causal forest also sidesteps the rank-deficient linear final stage (OQ5). See review §6.

## Transformer / Sequence-Modeling Feasibility (raised by the 2026-06-15 deep review)

Detail and full citations in `03_research_memory/transformer_sequence_modeling_review.md`. These are the data facts needed before any transformer effort can be estimated; a "Lumen transformer" needs three layers (sequence encoder + causal/uplift head + decision layer) — off-the-shelf recommenders and LiDDA only cover encoding/attribution, not the causal head.

25. **Journey length** — distribution of touches per customer. The single biggest determinant of whether sequence models add value; short/sparse journeys favor keeping XGBoost.
26. **Event richness** — how many distinct `channel×interaction` types actually populate journeys (DM sparsity, OQ2, directly degrades a sequence model).
27. **Volume vs. DL threshold** — **Corrected premise (2026-06-16):** the ≈500K figure was the prototype *test* set, not the population. Re-assess transformer fit against the **full source (≈10–15M customers since ≈2022, long histories — approx)**, which may clear the large-scale + long-sequence bar the prototype slice did not. Confirm against the actual profiled full-data numbers (depends on building Layer 4, OQ44).
28. **Timestamp quality/granularity** — event-time resolution needed for time-gap embeddings (BST) or temporal point processes (THP). Confirm what `efectv_dt` / event timestamps provide.
29. **Timing / multi-step in scope?** — does the product want only "which channel" (current) or also "when" and "what sequence of channels"? Decides whether TPP (THP/EasyTPP) and RL/bandit (DRQN-attention) paths are in scope.
30. **Label horizon** — next-touch conversion vs. a long-term engagement objective (PinnerFormer-style); shapes the head and the training loss.
31. **Causal head choice** — if pursuing the transformer uplift path, decide between a CRN-style (LSTM) vs Causal-Transformer-style head and a multi-treatment design (M³TN); note research-grade code and unproven healthcare→marketing transfer. See review §3 and §9.

## Model Ladder — Sparse Low-Frequency Journey Data (raised by the 2026-06-15b round)

Data context confirmed by tech lead: bank journeys from 2022, low/uneven event frequency (digital frequent; Email/DM/Leads sparse), and the current model collapses an April–July snapshot into a flat XGBoost vector. This regime favors simpler models; transformer is the top of a ladder, not the next step. See `03_research_memory/transformer_sequence_modeling_review.md` §6b/§10 and method-critique C14.

32. **Stop collapsing the journey (F0)** — should v-next replace the single April–July snapshot vector with multi-window / RFM / recency / inter-touch-gap features computed over the **full 2022+ history**, keeping XGBoost + DR? Lowest-effort, highest value-per-effort; also unblocks the time-based holdout (OQ9, C6).
33. **Reframe outcome as time-to-event / survival?** — convert-or-not over a multi-year journey is right-censored time-to-event, not a static binary. Should Lumen adopt a survival framing, and specifically a **Causal Survival Forest** (grf `causal_survival_forest`) for per-channel uplift on censored data — reusing the causal-forest direction in OQ24? Strong fit for sparse data.
34. **Sequence-model ladder order** — confirm the try-order before any transformer spend: F0 temporal-feature XGBoost → F2 causal survival forest → F1 Markov/HMM + F3 GRU baselines → F4 classical Hawkes (if timing) → transformer paths only if OQ25/27 (length/volume) later justify.

## Transformer Implementation Spike (manager-directed; raised 2026-06-15c)

Manager is persisting on the transformer path; 2–4 week plan + experiments. Design = treatment-conditional core model + process (D010). Detail in `03_research_memory/transformer_implementation_plan.md`.

35. **Causal head: S-learner vs rigorous?** — is `uplift(A)=pred(A)−pred(∅)` from an S-learner "good enough" for v1, or do we need a Causal-Transformer/G-Transformer confounding-adjusted head? Decide via the Week-4 pilot (do counterfactuals differ materially from the S-learner?).
36. **Combo generalization validation** — does the set-pooled treatment encoding (Deep Sets / Set Transformer) actually generalize to **held-out channel combos**? Must be tested before relying on on-demand combo scoring.
37. **Process-layer / optimizer contract** — define how the monthly process supplies candidate sets (allowed universe, per-customer eligible sets, caps, one-vs-combo policy) and whether to use a plain ILP vs a differentiable-ILP allocation (arXiv 2408.11623). Reuses the existing constrained optimizer.
38. **TFT feature typing** — if using Temporal Fusion Transformer, which features are static vs time-varying-observed vs known-future (the planned action)? Needed to configure `TimeSeriesDataSet`; start by treating PRISM scores as static.
39. **Data-fit gating for the chosen architecture** — run the §3 data-fit checklist (sequence length, per-channel/combo frequency, overlap/positivity, time-varying confounding, censoring, volume, leakage) before committing to A3/A4 vs falling back to A1/A2.

## Manager/Team Transformer Confirmation (raised 2026-06-16)

Transformer is the confirmed primary direction (D004); flexible config-driven outputs are a confirmed requirement (D011). Detail in `02_change_log/2026-06-16_manager_transformer_decision.md`.

40. **2–4 week feasibility** — is the timeline realistic given the unresolved data-foundation blockers (OQ1–3, OQ9) that sit underneath it? What is the minimum data prep required before the spike can produce a meaningful result, and what is the fallback if data work overruns?
41. **v1 use-case scope** — which of the confirmed use cases (top-1, top-K, multiple-per-customer, caps, allowed-channel filters, no-contact, alternative objectives) must v1 support, and which are deferred? Defines the config-layer contract.
42. **"Finalize the design" deliverable** — what exactly is the end-of-spike artifact (a chosen architecture + experimental comparison vs. the XGBoost/DR baseline + a design doc)? What evidence bar counts as "good enough" to finalize?
43. **Baseline comparison protocol** — how is the transformer judged against the XGBoost/DR baseline within the spike (which metric — uplift/Qini/AUUC vs AUC, which split, which data source), so the comparison is fair and not circular?

## Data Scale & Full-Source Readiness (raised 2026-06-16 data-scale correction)

The prototype slice is not the full data. Full source ≈10–15M customers since ≈2022 (approx); cleaned transformer-ready dataset does not exist yet. Detail in `02_change_log/2026-06-16_data_scale_correction.md`.

44. **Build the cleaned, transformer-ready dataset (Layer 4)** — profile the full ~2022+ source and construct it: per-customer event sequences, timestamp validation/granularity, channel-coverage checks, label-window design, dedup/cleaning. This is a prerequisite for using the full data and a real risk against the 2–4 week timeline (relates to OQ40). What is the minimum viable version for the spike?
45. **Confirm layer counts** — exact (or tighter) customer counts for the prototype experiment subset (≈2–3M), the test set (≈500K), and the full source (≈10–15M). Currently approximate.
46. **Confirm prototype window end date** — the experiment ran ~April → July *or* January depending on version; pin the exact end date(s) per experiment version.
47. **Re-evaluate transformer feasibility on full-data numbers** — once Layer 4 exists, re-run the §3 data-fit / volume-vs-DL-threshold checks (OQ25–28) on the real full-data profile; the prior "transformer will only match XGBoost" expectation is re-opened, not settled.
