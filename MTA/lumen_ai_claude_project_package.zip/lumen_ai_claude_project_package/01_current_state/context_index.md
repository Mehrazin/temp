# Context Index

## How To Use This Index

Use `01_current_state/current_snapshot.md` first — it is the concise current source of truth (refreshed 2026-06-16). Use this index to decide which historical, research, or evidence files to open. Prefer current-state files, then the latest dated change log, then research memory and method-review outputs, then the archived baseline (background only).

## Current-State Files

### `01_current_state/current_snapshot.md`

Purpose: concise current project state. Refreshed 2026-06-16: transformer confirmed as the primary direction; XGBoost/DR repositioned as baseline; flexible config-driven scorer requirement. Relevant for: all tasks.

### `01_current_state/decision_register.md`

Purpose: versioned decisions D001–D011 with statuses and dated updates. Relevant for: roadmap, manager communication, post-meeting updates.

### `01_current_state/open_questions.md`

Purpose: active unresolved questions (OQ1–43), grouped by theme, including the method-review and transformer-spike questions. Relevant for: research, critique, planning.

## Change Log Files

### `02_change_log/2026-06-15_initial_baseline_ingestion.md`

Purpose: records ingestion of the archived summary as the initial baseline.

### `02_change_log/2026-06-15_update.md`

Purpose: detailed merge of the voice update, the 2026-06-05 deck, the MTA/TMIA notebooks, and reference material — the full evidence detail behind the snapshot.

### `02_change_log/2026-06-16_manager_transformer_decision.md`

Purpose: the manager/team decision confirming the transformer as the primary direction (2–4 week spike), repositioning XGBoost/DR as baseline, deferring package-first, and confirming the flexible config-driven output requirement.

### `02_change_log/2026-06-16_data_scale_correction.md`

Purpose: corrects a data-scale misinterpretation. Establishes the four data layers (prototype experiment subset ≈2–3M; prototype test set ≈500K; full source ≈10–15M since ≈2022; cleaned transformer-ready dataset — not built yet). Read before any scale-dependent claim or model-design step; counts approximate, prototype window end-date needs confirmation.

## Research Memory Files

### `03_research_memory/research_index.md`

Purpose: high-level map of research outputs and the index of research-memory entries.

### `03_research_memory/literature_notes.md`

Purpose: summaries of literature/method findings, organized by round (2026-06-15 method review; 06-15b lighter-weight models; 06-15c transformer implementation). Holds LiDDA and DR-reference notes.

### `03_research_memory/reference_bank.md`

Purpose: durable, categorized source list (EconML/DR tooling, overlap/positivity, attribution, uplift/CATE evaluation, off-policy/bandits, sequence/transformer, lighter-weight sparse-journey models, transformer-implementation references).

### `03_research_memory/method_critiques.md`

Purpose: accumulated critiques of the current method (C1–C14+): underdetermined-covariance root cause, treatment-in-X collinearity, calibration, optimizer objective, OPE validity, split design, sparse-data ladder.

### `03_research_memory/transformer_sequence_modeling_review.md`

Purpose: deep literature/feasibility review for a sequence model — families A–F (recommender encoders, causal/uplift heads, TPP, RL/NBA, marketing journey models, lighter-weight pre-transformer models), the data-fit gating evidence, a candidate composite "Lumen transformer," and per-path effort/risk. Read before estimating transformer effort.

### `03_research_memory/transformer_implementation_plan.md`

Purpose: build-oriented plan and shortlist — the treatment-conditional core + thin assignment process (D010), 5 ranked core options (A1–A5), cross-domain data-fit checklist, and a concrete 2–4 week experimentation plan. Read for the D004 spike.

## Output Files

### `04_outputs/2026-06-15_method_review.md`

Purpose: research & method review — executive summary, current-method assessment, key methodological risks (incl. §3.1/§5 on the underdetermined covariance), production-readiness gaps, recommended validation steps, alternative methods, and §7 claim guidance (what can/cannot be said). Primary input for D005 discipline.

### `04_outputs/transformer_design_input_snapshot.md`

Purpose: consolidated design input for the transformer delivery planning. **Caution:** carries a 2026-06-16 correction banner — its original scale statements (§5, §9) treated the prototype ~500K test slice as the full population; corrected per `02_change_log/2026-06-16_data_scale_correction.md`. Scale-dependent conclusions (§5 data-regime, §12 path feasibility, §16 item 5 "match not beat") are under re-evaluation against the full data. Otherwise still useful for the output-contract and architecture-neutral framing.

### `04_outputs/latest_manager_roadmap.md`

Purpose: latest manager-facing roadmap. The deck's roadmap (Shapley → DR → Atlantis package → Transformer) is outdated and pending revision under the transformer-first direction.

### `04_outputs/latest_timeline.md`

Purpose: latest timeline and milestones (pending revision; a 2–4 week transformer spike is now the near-term focus).

### `04_outputs/latest_talking_points.md`

Purpose: latest verbal summaries and meeting talking points.

## External Evidence (not files in this repo)

- **VP/AVP deck "PRISM LUMEN AI"** (2026-06-05) — two-lens framing, diagnostic ATEs, optimizer scenarios, +~10% model-estimated lift.
- **Databricks notebooks** (Azure, cluster `AnalyticsCA0EDAMLDS…`): `model_exploration` (MTA) and `model_exploration_tmia_final_predictive_only` (TMIA). Partial/messy/poorly-versioned.
- Cleaned delta tables under `vandad.*` (`tmp_mta_new_acct_predictive`, `tmp_tmia_new_acct_predictive`, `…_econml`, `…_single_treatment_predictive`, `…_grouped_treatment_predictive`).

## Archive Files

### `99_archive/old_project_summary_2026-05.md`

Purpose: historical baseline summary (~May 2026). Background only — superseded by `current_snapshot.md` and the dated change logs. Its package-first roadmap and "prototype" framing are outdated.
