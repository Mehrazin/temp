# Current Snapshot — Lumen AI

## Snapshot Status

Refreshed 2026-06-16 via the Context Updater workflow. Supersedes the archived May-2026 seeding. History in `02_change_log/2026-06-15_update.md`, `02_change_log/2026-06-16_manager_transformer_decision.md`, and `02_change_log/2026-06-16_data_scale_correction.md`. Items not clearly confirmed are marked **(uncertain)**; counts are **approximate** unless confirmed.

## Project Identity

Lumen AI is a multi-touch attribution and next-best-channel optimization initiative for TD Bank credit-card marketing. Framing: **PRISM decides what product to offer; Lumen AI decides how (which channel) to reach the customer.** It spans a diagnostic/attribution lens and a predictive/optimization lens; the predictive lens is the priority.

## Confirmed Direction (2026-06-16)

- **Transformer-based model is the confirmed primary modeling direction** (manager-directed, team-aligned). This is a **direction, not a proven or built model** — outcome unknown.
- **Timeline:** ~**2–4 weeks** to produce a model, run experimentation, and finalize the design ("good enough," not perfect).
- **XGBoost + Doubly Robust (the implemented MTA/TMIA work) is now the baseline / comparison**, not the main direction — retained as a benchmark and fallback.
- **Package-first is deferred / secondary** (retained, not dropped); the deployable model is the priority (D009).
- **Flexible-output requirement (confirmed):** the model/design must support many business use cases — top-1, top-K, multiple channels per customer, capacity constraints, allowed-channel filters, no-contact logic, and different objectives. Agreed design intent: a **reusable scorer** (single core model with the proposed action-set as an *input*) plus a **separate config-driven scoring/optimization layer** that produces business-specific outputs each cycle without retraining (D010/D011).

## Leadership

- Tech lead changed; the current tech lead leads the work.
- Manager-directed: model-first; predictive/next-best-channel over diagnostic. Package likely named "Lumen" (undecided), hosted in the "Atlantis" environment (Atlantis = host, not the package); another team would ultimately build/own it.

## Implemented Today (now the baseline/comparison)

Two Databricks notebooks (Azure; cluster `AnalyticsCA0EDAMLDS…`): MTA `model_exploration` (diagnostic + predictive) and TMIA `model_exploration_tmia_final_predictive_only` (predictive-only). Partial/messy, poorly versioned; models not persisted.

- **Data:** MTA `mta_perm.mta_dm_predictive` (`efectv_dt=2025-04-30`); TMIA `mta_perm.tmia_final`. Features: ~10 PRISM scores + credit-card indicator; historical `channel_*` flags; prospective `t_channel_*` actions.
- **Method:** econml **`LinearDRLearner`** (XGB propensity + XGB outcome, 5-fold cross-fitting, one-vs-rest treatments); predicted potential outcomes (`conversion_{ch}_0/_1`) feed the optimizer. **Grouped channel-level is the canonical granularity** (D006); single-interaction retained; combinatorial shelved (D008).
- **Data hygiene:** manual bad-channel list + zero-variance drop + Tree-VIF deterministic-feature scan.
- **Optimizer:** linear/integer one-channel-per-customer under caps; constrained (usable) vs unconstrained (illustrative); Sample1 (≈100K, a sub-sample of the prototype ~500K **test/eval** set — see Data Scale below) canonical; leads cap business-decided.
- **Calibration:** trialed then disabled (≈no effect).

## Data Scale — Four Distinct Layers (corrected 2026-06-16)

The prototype's evaluation slice must **not** be read as the full population. Counts are approximate. Detail in `02_change_log/2026-06-16_data_scale_correction.md`.

1. **Prototype experiment subset** — the *filtered* slice the XGBoost/DR baseline trained on (experimental only). **≈2–3M customers.** Window ~April → (July *or* January depending on experiment version); exact end date **(needs confirmation)**. Corresponds to the ~2.8M-row cleaned table.
2. **Prototype test / evaluation set** — the held-out subset of the prototype, **≈500K customers** (≈521K rows; Sample1 ≈100K is a sub-sample of this). **500K is a test subset, not the modeling population.**
3. **Full available rich source data** — timestamped touchpoint history back to **≈2022**, likely **≈10–15M customers** with many touchpoints. **Not yet used for modeling.**
4. **Cleaned, transformer-ready training dataset** — **does not exist yet.** Requires profiling, cleaning, sequence construction, timestamp validation, channel-coverage checks, and label-window design before use.

Implication: Lumen is **not** limited to 500K customers and should **not** be called "moderate volume" on the basis of the prototype test set. The full source may be substantially **more** suitable for sequence/transformer modeling than the prototype slice suggested — but is **not automatically transformer-ready** (Layer 4 must be built first), and that data-engineering work sits underneath the 2–4 week spike timeline.

## Results To Date — Model-Estimated / Exploratory, Not Experiment-Validated

- Deck constrained optimizer: BAU 1.31% → 1.44–1.45% (**+~10% lift / +137 conversions**), model-estimated.
- Diagnostic ATEs (vary by run): Display/SEO/Paid/Leads/Direct positive; Email and Mobile negative at channel level (Email CLICK positive).
- DR vs naive Shapley: sign flips → rationale for DR (D007).
- **OPE vs PRISM ("lucky matches"):** Lumen AUC 0.831 vs PRISM 0.719 (+11.18%) on ~7,070 matched rows — internal self-check, **not significance-tested**, ranking not uplift. Per D005, do not present as "beating PRISM."

## Known Limitations / Production-Readiness Gaps

- **DR inference numerically unreliable:** underdetermined covariance / `zstat=-inf` (persists after Tree-VIF). Root cause identified in the method review (rank-deficient final stage from one-vs-rest treatment-in-X collinearity + rare channels + overlap); blocks DR CIs/p-values; point scores less affected. See `method_critiques.md` C1.
- **No experimental or defensible-OPE validation** → cannot claim true incremental uplift.
- **Data foundation unsettled:** MTA vs TMIA vs hybrid; direct-mail sourcing broken (DM via TMIA only); **the cleaned transformer-ready dataset (Layer 4) does not exist yet** and must be built from the full ~2022+ source; **random (non-temporal) split**. These sit underneath the 2–4 week transformer timeline.
- **Transformer is unbuilt/unproven**; a new architecture needs its own compliance/model-validation path (cannot inherit the XGBoost approval path).
- Reproducibility/governance: models not persisted; notebooks unversioned.

## Current Working Assumption

The implemented XGBoost/DR + optimizer is a **baseline**; the **confirmed forward direction is a transformer-based scorer with a config-driven assignment layer**, to be designed and experimentally explored in a 2–4 week spike. No model (baseline or transformer) is production-validated; reported gains are model-estimated/exploratory.

## Immediate Priorities

1. **Transformer spike (2–4 weeks):** produce a model, run experiments, finalize the design — using the shortlist/plan in `03_research_memory/transformer_implementation_plan.md`; keep XGBoost/DR as the benchmark.
2. **Reusable scorer + config-driven layer (D010/D011):** action-set as input; validate set-pooled combo generalization (OQ36).
3. **Data foundation:** profile the full ~2022+ source (Layer 3) and build the cleaned transformer-ready dataset (Layer 4) — sequence construction, timestamp validation, channel coverage, label-window; decide MTA vs TMIA vs hybrid; fix direct-mail sourcing; address the non-temporal split.
4. **Validity:** resolve the underdetermined-covariance issue for the baseline; plan a defensible uplift/OPE evaluation (Qini/AUUC, IPS/DR-OPE) before any claim.
5. **Deployment contract:** define the scoring output table and the process-layer/optimizer interface for one-vs-N channel use cases.
