NBE final fixed package

Files:
- nbe_report_functions_final_fixed.py : single reusable functions/helper file
- notebooks/: analysis notebooks

Key fixes:
- Notebook 01 uses rich original reporting flow with detailed plot config + extensive Excel sections.
- Outputs now save into notebook-specific directories:
  BASE_OUTPUT_ROOT/<scenario_name>/<notebook_name>/
- Notebooks 2-8 export summary-only Excel files (no customer-level rows).
- Notebook 08 adds customer-specific product filtering and then re-runs the core comparison on masked tables.
