
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Union

import pandas as pd
import matplotlib.pyplot as plt

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T


# ============================================================
# Directory helpers
# ============================================================

def ensure_dir(path: Union[str, Path]) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def notebook_output_dir(
    base_output_root: Union[str, Path],
    scenario_name: str,
    notebook_name: str,
) -> Path:
    return ensure_dir(Path(base_output_root) / scenario_name / notebook_name)


# ============================================================
# Scenario helpers
# ============================================================

def make_scenario(
    scenario_name: str,
    customer_subset=None,
    product_cols: Optional[List[str]] = None,
    top_k_values: Optional[List[int]] = None,
) -> Dict:
    return {
        "scenario_name": scenario_name,
        "customer_subset": customer_subset,
        "product_cols": product_cols,
        "top_k_values": top_k_values,
    }


def build_standard_scenarios(
    all_products: List[str],
    changed_products: List[str],
    active_products: List[str],
    active_changed_products: List[str],
    one_million_customer_df=None,
    top_k_values: Optional[List[int]] = None,
) -> List[Dict]:
    return [
        make_scenario("S1_full_8m_all37", None, all_products, top_k_values),
        make_scenario("S2_full_8m_changed8", None, changed_products, top_k_values),
        make_scenario("S3_full_8m_active12", None, active_products, top_k_values),
        make_scenario("S4_full_8m_active_changed", None, active_changed_products, top_k_values),
        make_scenario("S5_1m_all37", one_million_customer_df, all_products, top_k_values),
        make_scenario("S6_1m_changed8", one_million_customer_df, changed_products, top_k_values),
        make_scenario("S7_1m_active12", one_million_customer_df, active_products, top_k_values),
        make_scenario("S8_1m_active_changed", one_million_customer_df, active_changed_products, top_k_values),
    ]


# ============================================================
# Generic dataframe helpers
# ============================================================

def _safe_product_cols(
    df: DataFrame,
    product_cols: Optional[List[str]],
    customer_id_col: str,
    control_col: Optional[str],
    extra_exclude_cols: Optional[Sequence[str]] = None,
) -> List[str]:
    exclude = {customer_id_col}
    if control_col is not None:
        exclude.add(control_col)
    for c in (extra_exclude_cols or []):
        exclude.add(c)
    return [c for c in df.columns if c not in exclude] if product_cols is None else product_cols


def filter_to_nbe_group(df: DataFrame, control_col: str = "control") -> DataFrame:
    return df.filter(F.col(control_col) == 0)


def subset_by_customer_ids(
    df: DataFrame,
    customer_ids=None,
    customer_id_col: str = "customer_id",
) -> DataFrame:
    if customer_ids is None:
        return df
    if isinstance(customer_ids, DataFrame):
        ids_df = customer_ids.select(customer_id_col).distinct()
        return df.join(ids_df, on=customer_id_col, how="inner")
    if isinstance(customer_ids, (list, tuple, set)):
        return df.filter(F.col(customer_id_col).isin(list(customer_ids)))
    raise ValueError("customer_ids must be None, a Spark DataFrame, or a Python sequence.")


def subset_by_product_cols(
    df: DataFrame,
    product_cols=None,
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
) -> DataFrame:
    if product_cols is None:
        return df
    keep = [customer_id_col]
    if control_col is not None and control_col in df.columns:
        keep.append(control_col)
    keep += product_cols
    keep = [c for c in keep if c in df.columns]
    return df.select(*keep)


def apply_subsetting(
    df: DataFrame,
    customer_ids=None,
    product_cols=None,
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    filter_control_zero: bool = True,
) -> DataFrame:
    out = df
    if filter_control_zero and control_col is not None and control_col in out.columns:
        out = filter_to_nbe_group(out, control_col=control_col)
    out = subset_by_customer_ids(out, customer_ids=customer_ids, customer_id_col=customer_id_col)
    out = subset_by_product_cols(out, product_cols=product_cols, customer_id_col=customer_id_col, control_col=control_col)
    return out


def _filled_numeric_col(col_name: str, null_fill_value: float = 0.0):
    return F.coalesce(F.col(col_name).cast("double"), F.lit(float(null_fill_value)))


# ============================================================
# Core ranking / EV helpers
# ============================================================

def compute_rank_array(
    df: DataFrame,
    product_cols=None,
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    structs = [
        F.struct(
            (-_filled_numeric_col(c, null_fill_value)).alias("sort_score"),
            F.lit(c).alias("product"),
        )
        for c in product_cols
    ]
    return df.select(
        customer_id_col,
        F.transform(F.array_sort(F.array(*structs)), lambda x: x["product"]).alias("ranked_products"),
    )


def add_topk_product_array(
    df: DataFrame,
    k: int,
    product_cols=None,
    output_col: str = "topk_products",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    ranked = compute_rank_array(df, product_cols, customer_id_col, control_col, null_fill_value)
    return ranked.select(customer_id_col, F.slice(F.col("ranked_products"), 1, k).alias(output_col))


def compute_total_expected_value(
    df: DataFrame,
    product_cols=None,
    output_col: str = "EV_total",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    expr = None
    for c in product_cols:
        term = _filled_numeric_col(c, null_fill_value)
        expr = term if expr is None else expr + term
    return df.select(customer_id_col, expr.alias(output_col))


def compute_topk_expected_value(
    df: DataFrame,
    k: int,
    product_cols=None,
    output_col: str = "EV_topK",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    structs = [
        F.struct(
            (-_filled_numeric_col(c, null_fill_value)).alias("sort_score"),
            _filled_numeric_col(c, null_fill_value).alias("ev"),
            F.lit(c).alias("product"),
        )
        for c in product_cols
    ]
    sorted_array = F.array_sort(F.array(*structs))
    topk_array = F.slice(sorted_array, 1, k)
    return df.select(
        customer_id_col,
        F.aggregate(topk_array, F.lit(0.0), lambda acc, x: acc + x["ev"]).alias(output_col),
    )


def metric_difference_table(
    legacy_metric_df: DataFrame,
    new_metric_df: DataFrame,
    metric_col: str,
    customer_id_col: str = "customer_id",
    diff_col: str = "metric_diff",
) -> DataFrame:
    return (
        legacy_metric_df.select(customer_id_col, F.col(metric_col).alias(f"{metric_col}_legacy"))
        .join(new_metric_df.select(customer_id_col, F.col(metric_col).alias(f"{metric_col}_new")), on=customer_id_col, how="inner")
        .withColumn(diff_col, F.col(f"{metric_col}_new") - F.col(f"{metric_col}_legacy"))
    )


def summarize_metric(df: DataFrame, metric_col: str) -> DataFrame:
    return df.select(metric_col).summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")


# ============================================================
# Rank correlation helpers
# ============================================================

@F.udf(T.DoubleType())
def _spearman_from_full_orders(old_order, new_order):
    if old_order is None or new_order is None or len(old_order) == 0:
        return None
    if len(old_order) == 1:
        return 1.0
    old_rank = {p: i + 1 for i, p in enumerate(old_order)}
    new_rank = {p: i + 1 for i, p in enumerate(new_order)}
    common = [p for p in old_order if p in new_rank]
    m = len(common)
    if m < 2:
        return None
    d2 = sum((old_rank[p] - new_rank[p]) ** 2 for p in common)
    return float(1.0 - (6.0 * d2) / (m * (m**2 - 1)))


@F.udf(T.DoubleType())
def _spearman_from_topn_orders(old_topn, new_topn):
    if old_topn is None or new_topn is None:
        return None
    n = max(len(old_topn), len(new_topn))
    all_products = list(dict.fromkeys((old_topn or []) + (new_topn or [])))
    m = len(all_products)
    if m == 0:
        return None
    old_rank = {p: i + 1 for i, p in enumerate(old_topn)}
    new_rank = {p: i + 1 for i, p in enumerate(new_topn)}
    if m == 1:
        p = all_products[0]
        return 1.0 if old_rank.get(p, n + 1) == new_rank.get(p, n + 1) else 0.0
    d2 = sum((old_rank.get(p, n + 1) - new_rank.get(p, n + 1)) ** 2 for p in all_products)
    return float(1.0 - (6.0 * d2) / (m * (m**2 - 1)))


@F.udf(T.DoubleType())
def _shared_only_topn_rank_correlation(old_topn, new_topn):
    if old_topn is None or new_topn is None:
        return None
    old_rank = {p: i + 1 for i, p in enumerate(old_topn)}
    new_rank = {p: i + 1 for i, p in enumerate(new_topn)}
    shared = [p for p in old_topn if p in new_rank]
    m = len(shared)
    if m == 0:
        return None
    if m == 1:
        p = shared[0]
        return 1.0 if old_rank[p] == new_rank[p] else 0.0
    d2 = sum((old_rank[p] - new_rank[p]) ** 2 for p in shared)
    return float(1.0 - (6.0 * d2) / (m * (m**2 - 1)))


def compute_full_rank_correlation(
    legacy_df: DataFrame,
    new_df: DataFrame,
    product_cols=None,
    output_col: str = "rank_correlation",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    old_r = compute_rank_array(legacy_df, product_cols, customer_id_col, control_col, null_fill_value).withColumnRenamed("ranked_products", "legacy_ranked_products")
    new_r = compute_rank_array(new_df, product_cols, customer_id_col, control_col, null_fill_value).withColumnRenamed("ranked_products", "new_ranked_products")
    return old_r.join(new_r, on=customer_id_col, how="inner").select(
        customer_id_col,
        _spearman_from_full_orders(F.col("legacy_ranked_products"), F.col("new_ranked_products")).alias(output_col),
    )


def compute_topn_rank_correlation(
    legacy_df: DataFrame,
    new_df: DataFrame,
    n: int,
    product_cols=None,
    output_col: str = "topN_rank_correlation",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    old_topn = add_topk_product_array(legacy_df, n, product_cols, "legacy_topn_products", customer_id_col, control_col, null_fill_value)
    new_topn = add_topk_product_array(new_df, n, product_cols, "new_topn_products", customer_id_col, control_col, null_fill_value)
    return old_topn.join(new_topn, on=customer_id_col, how="inner").select(
        customer_id_col,
        _spearman_from_topn_orders(F.col("legacy_topn_products"), F.col("new_topn_products")).alias(output_col),
    )


def compute_topn_shared_rank_correlation(
    legacy_df: DataFrame,
    new_df: DataFrame,
    n: int,
    product_cols=None,
    output_col: str = "topN_shared_rank_correlation",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    old_topn = add_topk_product_array(legacy_df, n, product_cols, "legacy_topn_products", customer_id_col, control_col, null_fill_value)
    new_topn = add_topk_product_array(new_df, n, product_cols, "new_topn_products", customer_id_col, control_col, null_fill_value)
    return old_topn.join(new_topn, on=customer_id_col, how="inner").select(
        customer_id_col,
        _shared_only_topn_rank_correlation(F.col("legacy_topn_products"), F.col("new_topn_products")).alias(output_col),
    )


def compute_topk_overlap(
    legacy_df: DataFrame,
    new_df: DataFrame,
    k: int,
    product_cols=None,
    output_col: str = "topK_overlap",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    old_topk = add_topk_product_array(legacy_df, k, product_cols, "legacy_topk_products", customer_id_col, control_col, null_fill_value)
    new_topk = add_topk_product_array(new_df, k, product_cols, "new_topk_products", customer_id_col, control_col, null_fill_value)
    return old_topk.join(new_topk, on=customer_id_col, how="inner").select(
        customer_id_col,
        (F.size(F.array_intersect(F.col("legacy_topk_products"), F.col("new_topk_products"))) / F.lit(float(k))).alias(output_col),
    )


def add_overlap_count_from_ratio(overlap_df: DataFrame, k: int, overlap_col: str = "topK_overlap", output_col: str = "overlap_count") -> DataFrame:
    return overlap_df.withColumn(output_col, F.round(F.col(overlap_col) * F.lit(float(k)), 0).cast("int"))


def compute_topk_swap_rate(
    legacy_df: DataFrame,
    new_df: DataFrame,
    k: int,
    product_cols=None,
    output_col: str = "topK_changed",
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    old_topk = add_topk_product_array(legacy_df, k, product_cols, "legacy_topk_products", customer_id_col, control_col, null_fill_value)
    new_topk = add_topk_product_array(new_df, k, product_cols, "new_topk_products", customer_id_col, control_col, null_fill_value)
    return old_topk.join(new_topk, on=customer_id_col, how="inner").select(
        customer_id_col,
        F.when(F.col("legacy_topk_products") == F.col("new_topk_products"), F.lit(0)).otherwise(F.lit(1)).alias(output_col),
    )


def compute_product_distribution_shift(
    legacy_df: DataFrame,
    new_df: DataFrame,
    k: int,
    product_cols=None,
    customer_id_col: str = "customer_id",
    control_col: Optional[str] = "control",
    null_fill_value: float = 0.0,
) -> DataFrame:
    old_topk = add_topk_product_array(legacy_df, k, product_cols, "legacy_topk_products", customer_id_col, control_col, null_fill_value)
    new_topk = add_topk_product_array(new_df, k, product_cols, "new_topk_products", customer_id_col, control_col, null_fill_value)
    old_n = old_topk.count()
    new_n = new_topk.count()

    old_freq = (
        old_topk.select(F.explode("legacy_topk_products").alias("product"))
        .groupBy("product")
        .count()
        .withColumnRenamed("count", "legacy_topK_frequency")
        .withColumn("legacy_topK_pct", F.col("legacy_topK_frequency") / F.lit(float(old_n)))
    )
    new_freq = (
        new_topk.select(F.explode("new_topk_products").alias("product"))
        .groupBy("product")
        .count()
        .withColumnRenamed("count", "new_topK_frequency")
        .withColumn("new_topK_pct", F.col("new_topK_frequency") / F.lit(float(new_n)))
    )
    return (
        old_freq.join(new_freq, on="product", how="full")
        .na.fill(0)
        .withColumn("pct_diff", F.col("new_topK_pct") - F.col("legacy_topK_pct"))
        .withColumn("freq_diff", F.col("new_topK_frequency") - F.col("legacy_topK_frequency"))
        .orderBy(F.desc(F.abs(F.col("pct_diff"))))
    )


# ============================================================
# Input value comparison
# ============================================================

def compare_same_product_values(
    legacy_df: DataFrame,
    new_df: DataFrame,
    product_cols: List[str],
    customer_id_col: str = "customer_id",
) -> DataFrame:
    joined = legacy_df.alias("l").join(new_df.alias("n"), on=customer_id_col, how="inner")
    diff_exprs = [
        F.abs(F.coalesce(F.col(f"n.{c}").cast("double"), F.lit(0.0)) - F.coalesce(F.col(f"l.{c}").cast("double"), F.lit(0.0))).alias(f"{c}_abs_diff")
        for c in product_cols
    ]
    out = joined.select(F.col(customer_id_col), *diff_exprs)
    sum_expr = None
    for c in product_cols:
        term = F.col(f"{c}_abs_diff")
        sum_expr = term if sum_expr is None else sum_expr + term
    return out.withColumn("sum_abs_diff", sum_expr)


def summarize_customer_value_diffs(
    legacy_df: DataFrame,
    new_df: DataFrame,
    product_cols: List[str],
    customer_id_col: str = "customer_id",
) -> DataFrame:
    return compare_same_product_values(legacy_df, new_df, product_cols, customer_id_col).select("sum_abs_diff").summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")


# ============================================================
# Coverage and null diagnostics
# ============================================================

def compute_product_score_coverage_report(
    prism_df: DataFrame,
    legacy_df: DataFrame,
    product_cols: List[str],
    customer_id_col: str = "customer_id",
) -> DataFrame:
    joined = prism_df.alias("p").join(legacy_df.alias("l"), on=customer_id_col, how="inner")
    pieces = []
    for c in product_cols:
        pieces.append(
            joined.select(
                F.lit(c).alias("product"),
                F.when(F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNull(), 1).otherwise(0).alias("prism_only_available"),
                F.when(F.col(f"p.{c}").isNull() & F.col(f"l.{c}").isNotNull(), 1).otherwise(0).alias("legacy_only_available"),
                F.when(F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNotNull(), 1).otherwise(0).alias("both_available"),
                F.when(F.col(f"p.{c}").isNull() & F.col(f"l.{c}").isNull(), 1).otherwise(0).alias("both_null"),
            )
        )
    out = pieces[0]
    for p in pieces[1:]:
        out = out.unionByName(p)
    total_rows = prism_df.select(customer_id_col).distinct().count()
    return (
        out.groupBy("product")
        .agg(
            F.sum("prism_only_available").alias("prism_only_available"),
            F.sum("legacy_only_available").alias("legacy_only_available"),
            F.sum("both_available").alias("both_available"),
            F.sum("both_null").alias("both_null"),
        )
        .withColumn("pct_prism_only_available", F.col("prism_only_available") / F.lit(float(total_rows)))
        .withColumn("pct_legacy_only_available", F.col("legacy_only_available") / F.lit(float(total_rows)))
        .withColumn("pct_both_available", F.col("both_available") / F.lit(float(total_rows)))
        .withColumn("pct_both_null", F.col("both_null") / F.lit(float(total_rows)))
        .orderBy("product")
    )


def compute_customer_availability_diagnostics(
    prism_df: DataFrame,
    legacy_df: DataFrame,
    product_cols: List[str],
    customer_id_col: str = "customer_id",
) -> DataFrame:
    joined = prism_df.alias("p").join(legacy_df.alias("l"), on=customer_id_col, how="inner")
    p_expr = l_expr = c_expr = m_expr = None
    for c in product_cols:
        p_avail = F.when(F.col(f"p.{c}").isNotNull(), 1).otherwise(0)
        l_avail = F.when(F.col(f"l.{c}").isNotNull(), 1).otherwise(0)
        c_avail = F.when(F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNotNull(), 1).otherwise(0)
        mismatch = F.when(
            ((F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNull()) | (F.col(f"p.{c}").isNull() & F.col(f"l.{c}").isNotNull())),
            1,
        ).otherwise(0)
        p_expr = p_avail if p_expr is None else p_expr + p_avail
        l_expr = l_avail if l_expr is None else l_expr + l_avail
        c_expr = c_avail if c_expr is None else c_expr + c_avail
        m_expr = mismatch if m_expr is None else m_expr + mismatch
    return (
        joined.select(
            F.col(customer_id_col),
            p_expr.alias("prism_available_count"),
            l_expr.alias("legacy_available_count"),
            c_expr.alias("common_available_count"),
            m_expr.alias("mismatch_count"),
        ).withColumn("exact_match_flag", F.when(F.col("mismatch_count") == 0, 1).otherwise(0))
    )


def summarize_customer_availability_diagnostics(diag_df: DataFrame) -> Dict[str, DataFrame]:
    total = diag_df.count()
    return {
        "exact_match_summary": diag_df.agg(
            F.count("*").alias("n_customers"),
            F.avg(F.col("exact_match_flag").cast("double")).alias("exact_match_rate"),
            F.avg(F.col("prism_available_count").cast("double")).alias("avg_prism_available_count"),
            F.avg(F.col("legacy_available_count").cast("double")).alias("avg_legacy_available_count"),
            F.avg(F.col("common_available_count").cast("double")).alias("avg_common_available_count"),
        ),
        "common_count_distribution": diag_df.groupBy("common_available_count").agg(F.count("*").alias("n_customers")).withColumn("pct_customers", F.col("n_customers") / F.lit(float(total))).orderBy("common_available_count"),
    }


def _rank_available_products_array(df: DataFrame, product_cols: List[str], prefix: str, customer_id_col: str = "customer_id") -> DataFrame:
    structs = [
        F.struct(
            (-F.col(f"{prefix}.{c}").cast("double")).alias("sort_score"),
            F.lit(c).alias("product"),
            F.col(f"{prefix}.{c}").isNotNull().alias("is_present"),
        )
        for c in product_cols
    ]
    return df.select(
        F.col(customer_id_col),
        F.transform(F.array_sort(F.filter(F.array(*structs), lambda x: x["is_present"])), lambda x: x["product"]).alias(f"{prefix}_available_ranked_products"),
    )


def compute_full_rank_correlation_exact_match_nonnull(
    prism_df: DataFrame,
    legacy_df: DataFrame,
    product_cols: List[str],
    customer_id_col: str = "customer_id",
    min_common_products: int = 2,
) -> Dict[str, DataFrame]:
    availability_diag = compute_customer_availability_diagnostics(prism_df, legacy_df, product_cols, customer_id_col=customer_id_col)
    eligible = availability_diag.filter((F.col("exact_match_flag") == 1) & (F.col("common_available_count") >= min_common_products)).select(customer_id_col, "common_available_count")
    joined = prism_df.alias("p").join(legacy_df.alias("l"), on=customer_id_col, how="inner").join(eligible, on=customer_id_col, how="inner")
    p_rank = _rank_available_products_array(joined, product_cols, "p", customer_id_col)
    l_rank = _rank_available_products_array(joined, product_cols, "l", customer_id_col)
    corr_df = (
        p_rank.join(l_rank, on=customer_id_col, how="inner")
        .join(eligible, on=customer_id_col, how="inner")
        .select(
            customer_id_col,
            "common_available_count",
            _spearman_from_full_orders(F.col("p_available_ranked_products"), F.col("l_available_ranked_products")).alias("rank_correlation"),
        )
    )
    return {
        "customer_level": corr_df,
        "summary": corr_df.select("rank_correlation").summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max"),
        "summary_by_common_count": corr_df.groupBy("common_available_count").agg(
            F.count("*").alias("n_customers"),
            F.avg("rank_correlation").alias("avg_rank_correlation"),
            F.expr("percentile_approx(rank_correlation, 0.5)").alias("median_rank_correlation"),
            F.min("rank_correlation").alias("min_rank_correlation"),
            F.max("rank_correlation").alias("max_rank_correlation"),
        ).orderBy("common_available_count"),
    }


def compute_customer_availability_common_corr_breakdown(
    prism_df: DataFrame,
    legacy_df: DataFrame,
    product_cols: List[str],
    customer_id_col: str = "customer_id",
) -> Dict[str, DataFrame]:
    return compute_full_rank_correlation_exact_match_nonnull(prism_df, legacy_df, product_cols, customer_id_col, min_common_products=2)


# ============================================================
# Customer-specific dynamic product filtering
# ============================================================

def build_customer_product_set(
    filter_long_df: DataFrame,
    customer_id_col: str = "customer_id",
    product_col: str = "product",
) -> DataFrame:
    return filter_long_df.groupBy(customer_id_col).agg(F.collect_set(product_col).alias("product_set"))


def mask_wide_table_by_customer_product_set(
    wide_df: DataFrame,
    customer_product_set_df: DataFrame,
    product_cols: List[str],
    customer_id_col: str = "customer_id",
) -> DataFrame:
    joined = wide_df.join(customer_product_set_df, on=customer_id_col, how="inner")
    select_exprs = [F.col(customer_id_col)]
    if "control" in joined.columns:
        select_exprs.append(F.col("control"))
    for c in product_cols:
        select_exprs.append(F.when(F.array_contains(F.col("product_set"), F.lit(c)), F.col(c)).otherwise(F.lit(None)).alias(c))
    return joined.select(*select_exprs)


def compute_customer_specific_product_count_distribution(
    customer_product_set_df: DataFrame,
    customer_id_col: str = "customer_id",
) -> Dict[str, DataFrame]:
    counts = customer_product_set_df.select(customer_id_col, F.size("product_set").alias("n_products"))
    total = counts.count()
    dist = counts.groupBy("n_products").agg(F.count("*").alias("n_customers")).withColumn("pct_customers", F.col("n_customers") / F.lit(float(total))).orderBy("n_products")
    return {"customer_product_counts": counts, "distribution": dist}


def compute_topk_eligibility_summary(
    customer_product_count_df: DataFrame,
    top_k_values: List[int],
) -> DataFrame:
    total = customer_product_count_df.count()
    rows = []
    for k in top_k_values:
        eligible_n = customer_product_count_df.filter(F.col("n_products") >= k).count()
        rows.append((int(k), int(eligible_n), float(eligible_n / total if total else 0.0)))
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()
    return spark.createDataFrame(rows, schema="k int, eligible_customers long, pct_eligible double")


# ============================================================
# Priority alignment / response hierarchy / deciles / history
# ============================================================

def compute_priority_alignment_report(
    priority_df: DataFrame,
    proposed_df: DataFrame,
    active_product_cols: List[str],
    customer_id_col: str = "customer_id",
    proposed_product_col: str = "proposed_product",
) -> Dict[str, DataFrame]:
    priority_rank_df = compute_rank_array(priority_df, product_cols=active_product_cols, customer_id_col=customer_id_col, control_col=None)
    priority_alignment_df = proposed_df.join(priority_rank_df, on=customer_id_col, how="inner").select(
        customer_id_col,
        proposed_product_col,
        F.array_position(F.col("ranked_products"), F.col(proposed_product_col)).alias("priority_rank"),
    )
    return {
        "priority_rank_df": priority_rank_df,
        "priority_alignment_df": priority_alignment_df,
        "priority_alignment_summary": priority_alignment_df.agg(
            F.count("*").alias("n_offers"),
            F.avg((F.col("priority_rank") == 1).cast("double")).alias("pct_top1"),
            F.avg((F.col("priority_rank") <= 3).cast("double")).alias("pct_top3"),
            F.avg((F.col("priority_rank") <= 5).cast("double")).alias("pct_top5"),
            F.avg((F.col("priority_rank") <= 10).cast("double")).alias("pct_top10"),
        ),
        "priority_alignment_distribution": priority_alignment_df.groupBy("priority_rank").count().orderBy("priority_rank"),
    }


def add_response_flags_if_needed(df: DataFrame, response_state_col: str = "response_state") -> DataFrame:
    cols = set(df.columns)
    out = df
    if {"activated", "actioned", "interested"}.issubset(cols):
        return out
    s = F.upper(F.col(response_state_col))
    if "activated" not in cols:
        out = out.withColumn("activated", F.when(s.isin("ACTIVATED", "ACTIONED", "INTERESTED", "NOT INTERESTED"), 1).otherwise(0))
    if "actioned" not in cols:
        out = out.withColumn("actioned", F.when(s.isin("ACTIONED", "INTERESTED", "NOT INTERESTED"), 1).otherwise(0))
    if "interested" not in cols:
        out = out.withColumn("interested", F.when(s == "INTERESTED", 1).otherwise(0))
    return out


def compute_response_hierarchy_report(
    measurement_df: DataFrame,
    customer_group_df: Optional[DataFrame] = None,
    customer_id_col: str = "customer_id",
    group_col_name: str = "top1_same",
    response_state_col: str = "response_state",
) -> Dict[str, DataFrame]:
    df = add_response_flags_if_needed(measurement_df, response_state_col=response_state_col)
    if customer_group_df is not None:
        df = df.join(customer_group_df, on=customer_id_col, how="left")
    out = {
        "measurement_enriched": df,
        "response_state_summary": df.groupBy(response_state_col).agg(
            F.count("*").alias("n"),
            F.avg(F.col("activated").cast("double")).alias("activation_rate"),
            F.avg(F.col("actioned").cast("double")).alias("action_rate"),
            F.avg(F.col("interested").cast("double")).alias("interest_rate"),
        ).orderBy(F.desc("n")),
        "funnel_summary": df.agg(
            F.count("*").alias("n_proposed"),
            F.avg(F.col("activated").cast("double")).alias("activation_rate"),
            F.avg(F.col("actioned").cast("double")).alias("action_rate"),
            F.avg(F.col("interested").cast("double")).alias("interest_rate"),
        ),
    }
    if customer_group_df is not None:
        out["outcome_by_group"] = df.groupBy(group_col_name).agg(
            F.count("*").alias("n"),
            F.avg(F.col("activated").cast("double")).alias("activation_rate"),
            F.avg(F.col("actioned").cast("double")).alias("action_rate"),
            F.avg(F.col("interested").cast("double")).alias("interest_rate"),
        ).orderBy(group_col_name)
    return out


def assign_score_deciles(df: DataFrame, score_col: str, output_col: str, partition_cols=None) -> DataFrame:
    partition_cols = partition_cols or []
    w = Window.partitionBy(*partition_cols).orderBy(F.desc(F.col(score_col))) if partition_cols else Window.orderBy(F.desc(F.col(score_col)))
    return df.withColumn(output_col, F.ntile(10).over(w))


def compute_decile_diagnostics_report(
    df: DataFrame,
    prism_score_col: str,
    legacy_score_col: str,
    product_col: Optional[str] = None,
) -> Dict[str, DataFrame]:
    out = df
    parts = [product_col] if product_col else []
    if "prism_decile" not in out.columns:
        out = assign_score_deciles(out, prism_score_col, "prism_decile", parts)
    if "legacy_decile" not in out.columns:
        out = assign_score_deciles(out, legacy_score_col, "legacy_decile", parts)
    return {
        "decile_ready_df": out,
        "prism_decile_distribution": out.groupBy("prism_decile").count().orderBy("prism_decile"),
        "legacy_decile_distribution": out.groupBy("legacy_decile").count().orderBy("legacy_decile"),
        "decile_transition_matrix": out.groupBy("prism_decile", "legacy_decile").count().orderBy("prism_decile", "legacy_decile"),
    }


def compute_historical_month_report(
    monthly_df: DataFrame,
    month_col: str = "month",
    product_col: str = "product",
    customer_id_col: str = "customer_id",
    month_a_value: Optional[str] = None,
    month_b_value: Optional[str] = None,
) -> Dict[str, DataFrame]:
    df = add_response_flags_if_needed(monthly_df, response_state_col="response_state") if "response_state" in monthly_df.columns else monthly_df
    out = {
        "month_product_rates": df.groupBy(month_col, product_col).agg(
            F.count("*").alias("n_offers"),
            F.avg(F.col("activated").cast("double")).alias("activation_rate"),
            F.avg(F.col("actioned").cast("double")).alias("action_rate"),
            F.avg(F.col("interested").cast("double")).alias("interest_rate"),
        ).orderBy(month_col, product_col)
    }
    if month_a_value and month_b_value:
        a = df.filter(F.col(month_col) == month_a_value)
        b = df.filter(F.col(month_col) == month_b_value)
        common = a.select(customer_id_col).distinct().intersect(b.select(customer_id_col).distinct())
        common_df = df.join(common, on=customer_id_col, how="inner")
        out["common_month_product_rates"] = common_df.groupBy(month_col, product_col).agg(
            F.count("*").alias("n_offers"),
            F.avg(F.col("activated").cast("double")).alias("activation_rate"),
            F.avg(F.col("actioned").cast("double")).alias("action_rate"),
            F.avg(F.col("interested").cast("double")).alias("interest_rate"),
        ).orderBy(month_col, product_col)
    return out


# ============================================================
# Product-level raw-score rank correlation
# ============================================================

def prepare_product_score_comparison(
    prism_scores_df: DataFrame,
    legacy_scores_df: DataFrame,
    model_mapping_df: DataFrame,
    customer_subset_df: Optional[DataFrame] = None,
    customer_id_col: str = "customer_id",
    model_id_col: str = "model_id",
    score_col: str = "model_score",
    product_col: str = "product",
    legacy_model_id_col: str = "legacy_model_id",
    prism_model_id_col: str = "prism_model_id",
) -> DataFrame:
    prism_map = model_mapping_df.select(F.col(product_col), F.col(prism_model_id_col).alias(model_id_col))
    legacy_map = model_mapping_df.select(F.col(product_col), F.col(legacy_model_id_col).alias(model_id_col))

    prism_prepped = prism_scores_df.join(prism_map, on=model_id_col, how="inner").select(customer_id_col, product_col, F.col(score_col).cast("double").alias("prism_score"))
    legacy_prepped = legacy_scores_df.join(legacy_map, on=model_id_col, how="inner").select(customer_id_col, product_col, F.col(score_col).cast("double").alias("legacy_score"))

    if customer_subset_df is not None:
        ids = customer_subset_df.select(customer_id_col).distinct()
        prism_prepped = prism_prepped.join(ids, on=customer_id_col, how="inner")
        legacy_prepped = legacy_prepped.join(ids, on=customer_id_col, how="inner")

    return prism_prepped.join(legacy_prepped, on=[customer_id_col, product_col], how="full")


def compute_product_score_availability_summary(
    score_compare_df: DataFrame,
    customer_subset_df: DataFrame,
    customer_id_col: str = "customer_id",
    product_col: str = "product",
) -> DataFrame:
    total = customer_subset_df.select(customer_id_col).distinct().count()
    return (
        score_compare_df.groupBy(product_col)
        .agg(
            F.sum(F.when(F.col("prism_score").isNotNull() & F.col("legacy_score").isNull(), 1).otherwise(0)).alias("prism_only_n"),
            F.sum(F.when(F.col("prism_score").isNull() & F.col("legacy_score").isNotNull(), 1).otherwise(0)).alias("legacy_only_n"),
            F.sum(F.when(F.col("prism_score").isNotNull() & F.col("legacy_score").isNotNull(), 1).otherwise(0)).alias("both_n"),
        )
        .withColumn("none_n", F.lit(int(total)) - F.col("prism_only_n") - F.col("legacy_only_n") - F.col("both_n"))
        .withColumn("prism_only_pct", F.col("prism_only_n") / F.lit(float(total)))
        .withColumn("legacy_only_pct", F.col("legacy_only_n") / F.lit(float(total)))
        .withColumn("both_pct", F.col("both_n") / F.lit(float(total)))
        .withColumn("none_pct", F.col("none_n") / F.lit(float(total)))
        .orderBy(product_col)
    )


def compute_product_level_rank_correlation(
    score_compare_df: DataFrame,
    customer_id_col: str = "customer_id",
    product_col: str = "product",
) -> Dict[str, DataFrame]:
    both = score_compare_df.filter(F.col("prism_score").isNotNull() & F.col("legacy_score").isNotNull())
    w_prism = Window.partitionBy(product_col).orderBy(F.desc("prism_score"))
    w_legacy = Window.partitionBy(product_col).orderBy(F.desc("legacy_score"))

    ranked = (
        both.withColumn("prism_customer_rank", F.row_number().over(w_prism))
        .withColumn("legacy_customer_rank", F.row_number().over(w_legacy))
        .withColumn("rank_gap", F.abs(F.col("prism_customer_rank") - F.col("legacy_customer_rank")))
    )

    return {
        "ranked_customer_scores": ranked,
        "product_rank_summary": ranked.groupBy(product_col).agg(
            F.count("*").alias("n_both"),
            F.corr("prism_customer_rank", "legacy_customer_rank").alias("pearson_rank_corr"),
            F.avg("rank_gap").alias("avg_rank_gap"),
            F.expr("percentile_approx(rank_gap, 0.5)").alias("median_rank_gap"),
        ).orderBy(product_col),
    }


# ============================================================
# Response vs raw-decile calibration
# ============================================================

def compute_response_raw_decile_calibration(
    responders_df: DataFrame,
    score_compare_df: DataFrame,
    customer_id_col: str = "customer_id",
    product_col: str = "product",
) -> Dict[str, DataFrame]:
    joined = (
        responders_df.select(customer_id_col, product_col).distinct()
        .join(score_compare_df.select(customer_id_col, product_col, "prism_score", "legacy_score"), on=[customer_id_col, product_col], how="inner")
    )

    prism_deciled = assign_score_deciles(joined, "prism_score", "prism_decile", [product_col])
    both_deciled = assign_score_deciles(prism_deciled, "legacy_score", "legacy_decile", [product_col])

    prism_dist = both_deciled.groupBy("prism_decile").count().withColumnRenamed("count", "n_responders").orderBy("prism_decile")
    legacy_dist = both_deciled.groupBy("legacy_decile").count().withColumnRenamed("count", "n_responders").orderBy("legacy_decile")

    prism_total = prism_dist.agg(F.sum("n_responders").alias("n")).collect()[0]["n"] or 1
    legacy_total = legacy_dist.agg(F.sum("n_responders").alias("n")).collect()[0]["n"] or 1

    prism_dist = prism_dist.withColumn("pct_responders", F.col("n_responders") / F.lit(float(prism_total)))
    legacy_dist = legacy_dist.withColumn("pct_responders", F.col("n_responders") / F.lit(float(legacy_total)))

    capture = both_deciled.agg(
        F.avg((F.col("prism_decile") <= 1).cast("double")).alias("prism_top10_capture"),
        F.avg((F.col("legacy_decile") <= 1).cast("double")).alias("legacy_top10_capture"),
        F.avg((F.col("prism_decile") <= 2).cast("double")).alias("prism_top20_capture"),
        F.avg((F.col("legacy_decile") <= 2).cast("double")).alias("legacy_top20_capture"),
        F.avg((F.col("prism_decile") <= 3).cast("double")).alias("prism_top30_capture"),
        F.avg((F.col("legacy_decile") <= 3).cast("double")).alias("legacy_top30_capture"),
    )

    return {
        "responders_scored": both_deciled,
        "prism_responder_decile_dist": prism_dist,
        "legacy_responder_decile_dist": legacy_dist,
        "responder_capture_summary": capture,
    }


# ============================================================
# Plot config
# ============================================================

DEFAULT_PLOT_CONFIG = {
    "theme": {
        "figsize": (10, 6),
        "dpi": 150,
        "palette": {
            "legacy": "#1f77b4",
            "prism": "#ff7f0e",
            "accent": "#9467bd",
            "changed": "#d62728",
            "unchanged": "#2ca02c",
        },
    },
    "ev_total_diff_hist": {"enabled": True, "bins": 50, "filename": "01_ev_total_diff_hist.png"},
    "topk_overlap_distribution": {"enabled": True, "filename_template": "02_top{k}_overlap_distribution.png"},
    "topk_product_shift": {"enabled": True, "filename_template": "03_top{k}_product_shift.png", "top_n": 15},
}


# ============================================================
# Export helpers
# ============================================================

def _export_named_tables_to_single_sheet_excel(
    named_tables: List[Tuple[str, Union[DataFrame, pd.DataFrame]]],
    excel_path: Union[str, Path],
    max_rows_per_table: int = 10000,
) -> str:
    excel_path = Path(excel_path)
    ensure_dir(excel_path.parent)
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        startrow = 0
        for name, df in named_tables:
            pd.DataFrame({"Artifact": [name]}).to_excel(writer, sheet_name="report", startrow=startrow, index=False)
            startrow += 1
            pdf = df.limit(max_rows_per_table).toPandas() if hasattr(df, "toPandas") else df.copy()
            pdf.to_excel(writer, sheet_name="report", startrow=startrow, index=False)
            startrow += len(pdf) + 2
    return str(excel_path)


def export_priority_alignment_outputs(alignment_report: Dict[str, DataFrame], output_dir: Union[str, Path], excel_filename: str = "priority_alignment_report.xlsx") -> Dict:
    excel = _export_named_tables_to_single_sheet_excel(
        [
            ("priority_alignment_summary", alignment_report["priority_alignment_summary"]),
            ("priority_alignment_distribution", alignment_report["priority_alignment_distribution"]),
        ],
        Path(output_dir) / excel_filename,
    )
    return {"excel_file": excel}


def export_response_hierarchy_outputs(hierarchy_report: Dict[str, DataFrame], output_dir: Union[str, Path], excel_filename: str = "response_hierarchy_report.xlsx") -> Dict:
    tables = [
        ("response_state_summary", hierarchy_report["response_state_summary"]),
        ("funnel_summary", hierarchy_report["funnel_summary"]),
    ]
    if hierarchy_report.get("outcome_by_group") is not None:
        tables.append(("outcome_by_group", hierarchy_report["outcome_by_group"]))
    excel = _export_named_tables_to_single_sheet_excel(tables, Path(output_dir) / excel_filename)
    return {"excel_file": excel}


def export_decile_outputs(decile_report: Dict[str, DataFrame], output_dir: Union[str, Path], excel_filename: str = "decile_diagnostics_report.xlsx") -> Dict:
    output_dir = ensure_dir(output_dir)
    excel = _export_named_tables_to_single_sheet_excel(
        [
            ("prism_decile_distribution", decile_report["prism_decile_distribution"]),
            ("legacy_decile_distribution", decile_report["legacy_decile_distribution"]),
            ("decile_transition_matrix", decile_report["decile_transition_matrix"]),
        ],
        Path(output_dir) / excel_filename,
    )

    prism_pdf = decile_report["prism_decile_distribution"].toPandas()
    legacy_pdf = decile_report["legacy_decile_distribution"].toPandas()

    plot_path = Path(output_dir) / "decile_distribution_comparison.png"
    plt.figure(figsize=(10, 6), dpi=150)
    plt.plot(prism_pdf["prism_decile"], prism_pdf["count"], marker="o", label="PRISM")
    plt.plot(legacy_pdf["legacy_decile"], legacy_pdf["count"], marker="o", label="Legacy")
    plt.title("Decile Distribution Comparison")
    plt.xlabel("Decile")
    plt.ylabel("Count")
    plt.grid(alpha=0.2)
    plt.legend()
    plt.tight_layout()
    plt.savefig(plot_path, bbox_inches="tight")
    plt.close()

    return {"excel_file": excel, "plot_file": str(plot_path)}


def export_historical_outputs(historical_report: Dict[str, DataFrame], output_dir: Union[str, Path], excel_filename: str = "historical_month_report.xlsx") -> Dict:
    tables = [("month_product_rates", historical_report["month_product_rates"])]
    if "common_month_product_rates" in historical_report:
        tables.append(("common_month_product_rates", historical_report["common_month_product_rates"]))
    excel = _export_named_tables_to_single_sheet_excel(tables, Path(output_dir) / excel_filename)
    return {"excel_file": excel}


def export_rank_null_diagnostics_outputs(
    product_coverage_df: DataFrame,
    availability_summaries: Dict[str, DataFrame],
    raw_full_corr_summary_df: DataFrame,
    exact_common_corr_report: Dict[str, DataFrame],
    output_dir: Union[str, Path],
    excel_filename: str = "rank_null_diagnostics_report.xlsx",
) -> Dict:
    output_dir = ensure_dir(output_dir)
    excel = _export_named_tables_to_single_sheet_excel(
        [
            ("product_coverage", product_coverage_df),
            ("exact_match_summary", availability_summaries["exact_match_summary"]),
            ("common_count_distribution", availability_summaries["common_count_distribution"]),
            ("raw_full_rank_corr_summary", raw_full_corr_summary_df),
            ("matched_common_corr_summary", exact_common_corr_report["summary"]),
            ("matched_common_corr_by_common_count", exact_common_corr_report["summary_by_common_count"]),
        ],
        Path(output_dir) / excel_filename,
    )
    pdf = exact_common_corr_report["summary_by_common_count"].toPandas()
    plot_path = Path(output_dir) / "matched_corr_by_common_count.png"
    plt.figure(figsize=(10, 6), dpi=150)
    plt.plot(pdf["common_available_count"], pdf["avg_rank_correlation"], marker="o")
    plt.title("Average Rank Correlation by Common Product Count")
    plt.xlabel("Common Product Count")
    plt.ylabel("Average Rank Correlation")
    plt.grid(alpha=0.2)
    plt.tight_layout()
    plt.savefig(plot_path, bbox_inches="tight")
    plt.close()
    return {"excel_file": excel, "plot_file": str(plot_path)}


def export_product_level_rank_outputs(
    availability_summary_df: DataFrame,
    product_rank_summary_df: DataFrame,
    output_dir: Union[str, Path],
    excel_filename: str = "product_level_rank_report.xlsx",
) -> Dict:
    output_dir = ensure_dir(output_dir)
    excel = _export_named_tables_to_single_sheet_excel(
        [
            ("product_score_availability_summary", availability_summary_df),
            ("product_rank_summary", product_rank_summary_df),
        ],
        Path(output_dir) / excel_filename,
    )
    pdf = product_rank_summary_df.toPandas()
    plot_path = Path(output_dir) / "product_rank_correlation.png"
    plt.figure(figsize=(12, 6), dpi=150)
    plt.bar(pdf["product"], pdf["pearson_rank_corr"], edgecolor="white")
    plt.title("Product-Level Customer Rank Correlation (PRISM vs Legacy)")
    plt.xlabel("Product")
    plt.ylabel("Rank Correlation")
    plt.xticks(rotation=90)
    plt.grid(axis="y", alpha=0.2)
    plt.tight_layout()
    plt.savefig(plot_path, bbox_inches="tight")
    plt.close()
    return {"excel_file": excel, "plot_file": str(plot_path)}


def export_response_raw_decile_outputs(
    response_calibration: Dict[str, DataFrame],
    output_dir: Union[str, Path],
    excel_filename: str = "response_raw_decile_report.xlsx",
) -> Dict:
    output_dir = ensure_dir(output_dir)
    excel = _export_named_tables_to_single_sheet_excel(
        [
            ("prism_responder_decile_dist", response_calibration["prism_responder_decile_dist"]),
            ("legacy_responder_decile_dist", response_calibration["legacy_responder_decile_dist"]),
            ("responder_capture_summary", response_calibration["responder_capture_summary"]),
        ],
        Path(output_dir) / excel_filename,
    )
    prism_pdf = response_calibration["prism_responder_decile_dist"].toPandas()
    legacy_pdf = response_calibration["legacy_responder_decile_dist"].toPandas()
    plot_path = Path(output_dir) / "response_decile_curve.png"
    plt.figure(figsize=(10, 6), dpi=150)
    plt.plot(prism_pdf["prism_decile"], prism_pdf["pct_responders"], marker="o", label="PRISM")
    plt.plot(legacy_pdf["legacy_decile"], legacy_pdf["pct_responders"], marker="o", label="Legacy")
    plt.title("Positive Responder Distribution by Raw-Score Decile")
    plt.xlabel("Decile (1 = highest)")
    plt.ylabel("Percent of Responders")
    plt.grid(alpha=0.2)
    plt.legend()
    plt.tight_layout()
    plt.savefig(plot_path, bbox_inches="tight")
    plt.close()
    return {"excel_file": excel, "plot_file": str(plot_path)}


def export_customer_specific_filter_outputs(
    distribution_df: DataFrame,
    eligibility_df: DataFrame,
    output_dir: Union[str, Path],
    excel_filename: str = "customer_specific_filter_report.xlsx",
) -> Dict:
    output_dir = ensure_dir(output_dir)
    excel = _export_named_tables_to_single_sheet_excel(
        [
            ("customer_specific_product_count_distribution", distribution_df),
            ("topk_eligibility_summary", eligibility_df),
        ],
        Path(output_dir) / excel_filename,
    )
    pdf = distribution_df.toPandas()
    plot_path = Path(output_dir) / "customer_specific_product_count_distribution.png"
    plt.figure(figsize=(10, 6), dpi=150)
    plt.bar(pdf["n_products"], pdf["n_customers"], edgecolor="white")
    plt.title("Customer-Specific Product Count Distribution")
    plt.xlabel("Number of Allowed Products")
    plt.ylabel("Customers")
    plt.grid(axis="y", alpha=0.2)
    plt.tight_layout()
    plt.savefig(plot_path, bbox_inches="tight")
    plt.close()
    return {"excel_file": excel, "plot_file": str(plot_path)}


# ============================================================
# Notebook 01 rich scenario runner
# ============================================================

def _plot_ev_total_diff_hist(ev_total_diff_df: DataFrame, output_dir: Path, plot_config: Dict):
    if not plot_config["ev_total_diff_hist"]["enabled"]:
        return None
    pdf = ev_total_diff_df.select("EV_total_diff").limit(200000).toPandas()
    out = output_dir / plot_config["ev_total_diff_hist"]["filename"]
    plt.figure(figsize=plot_config["theme"]["figsize"], dpi=plot_config["theme"]["dpi"])
    plt.hist(pdf["EV_total_diff"].dropna(), bins=plot_config["ev_total_diff_hist"]["bins"], color=plot_config["theme"]["palette"]["accent"], edgecolor="white")
    plt.title("EV Total Difference (PRISM - Legacy)")
    plt.xlabel("EV Total Difference")
    plt.ylabel("Customer Count")
    plt.grid(axis="y", alpha=0.2)
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()
    return str(out)


def _plot_topk_overlap_distribution(overlap_summary_df: DataFrame, k: int, output_dir: Path, plot_config: Dict):
    if not plot_config["topk_overlap_distribution"]["enabled"]:
        return None
    pdf = overlap_summary_df.toPandas()
    out = output_dir / plot_config["topk_overlap_distribution"]["filename_template"].format(k=k)
    plt.figure(figsize=plot_config["theme"]["figsize"], dpi=plot_config["theme"]["dpi"])
    plt.bar(pdf["overlap_count"].astype(str), pdf["pct_customers"], color=plot_config["theme"]["palette"]["legacy"], edgecolor="white")
    plt.title(f"Top-{k} Overlap Distribution")
    plt.xlabel("Common Products in Top-K")
    plt.ylabel("Percent of Customers")
    plt.grid(axis="y", alpha=0.2)
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()
    return str(out)


def _plot_topk_product_shift(shift_df: DataFrame, k: int, output_dir: Path, plot_config: Dict):
    if not plot_config["topk_product_shift"]["enabled"]:
        return None
    pdf = shift_df.limit(plot_config["topk_product_shift"]["top_n"]).toPandas()
    out = output_dir / plot_config["topk_product_shift"]["filename_template"].format(k=k)
    x = list(range(len(pdf)))
    width = 0.4
    plt.figure(figsize=(12, 6), dpi=plot_config["theme"]["dpi"])
    plt.bar([i - width/2 for i in x], pdf["legacy_topK_pct"], width=width, label="Legacy", color=plot_config["theme"]["palette"]["legacy"], edgecolor="white")
    plt.bar([i + width/2 for i in x], pdf["new_topK_pct"], width=width, label="PRISM", color=plot_config["theme"]["palette"]["prism"], edgecolor="white")
    plt.xticks(x, pdf["product"], rotation=90)
    plt.ylabel("Top-K Appearance %")
    plt.title(f"Top-{k} Product Appearance Shift")
    plt.grid(axis="y", alpha=0.2)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()
    return str(out)


def run_nbe_scenario_outputs(
    spark,
    legacy_df: DataFrame,
    new_df: DataFrame,
    scenario_name: str,
    base_output_path: Union[str, Path],
    customer_subset=None,
    product_cols: Optional[List[str]] = None,
    top_k_values: Optional[List[int]] = None,
    customer_id_col: str = "customer_id",
    control_col: str = "control",
    plot_config: Optional[Dict] = None,
    export_excel: bool = True,
) -> Dict:
    plot_config = plot_config or DEFAULT_PLOT_CONFIG
    top_k_values = top_k_values or [1, 3, 5]

    output_dir = ensure_dir(Path(base_output_path) / scenario_name)

    legacy_s = apply_subsetting(legacy_df, customer_subset, product_cols, customer_id_col, control_col, True)
    prism_s = apply_subsetting(new_df, customer_subset, product_cols, customer_id_col, control_col, True)
    analysis_product_cols = _safe_product_cols(legacy_s, product_cols, customer_id_col, control_col)

    value_diff_summary = summarize_customer_value_diffs(legacy_s, prism_s, analysis_product_cols, customer_id_col)
    legacy_ev_total = compute_total_expected_value(legacy_s, analysis_product_cols, "EV_total", customer_id_col, control_col)
    prism_ev_total = compute_total_expected_value(prism_s, analysis_product_cols, "EV_total", customer_id_col, control_col)
    ev_total_diff = metric_difference_table(legacy_ev_total, prism_ev_total, "EV_total", customer_id_col, "EV_total_diff")

    full_rank_corr = compute_full_rank_correlation(legacy_s, prism_s, analysis_product_cols, "rank_correlation", customer_id_col, control_col)
    full_rank_corr_summary = summarize_metric(full_rank_corr, "rank_correlation")

    export_tables = [
        ("scenario_meta", pd.DataFrame([{
            "scenario_name": scenario_name,
            "n_customers": legacy_s.count(),
            "n_products": len(analysis_product_cols),
            "top_k_values": ",".join(str(x) for x in top_k_values),
        }])),
        ("value_diff_summary", value_diff_summary),
        ("ev_total_diff_summary", ev_total_diff.select("EV_total_diff").summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")),
        ("full_rank_corr_summary", full_rank_corr_summary),
    ]

    plot_files = {}
    plot_path = _plot_ev_total_diff_hist(ev_total_diff, output_dir, plot_config)
    if plot_path:
        plot_files["ev_total_diff_hist"] = plot_path

    for k in top_k_values:
        topk_overlap = compute_topk_overlap(legacy_s, prism_s, k, analysis_product_cols, "topK_overlap", customer_id_col, control_col)
        topk_overlap = add_overlap_count_from_ratio(topk_overlap, k)
        total_rows = topk_overlap.count()
        overlap_summary = topk_overlap.groupBy("overlap_count").agg(F.count("*").alias("n_customers")).withColumn("pct_customers", F.col("n_customers") / F.lit(float(total_rows))).orderBy("overlap_count")

        shift_df = compute_product_distribution_shift(legacy_s, prism_s, k, analysis_product_cols, customer_id_col, control_col)

        legacy_topk_ev = compute_topk_expected_value(legacy_s, k, analysis_product_cols, "EV_topK", customer_id_col, control_col)
        prism_topk_ev = compute_topk_expected_value(prism_s, k, analysis_product_cols, "EV_topK", customer_id_col, control_col)
        topk_ev_diff = metric_difference_table(legacy_topk_ev, prism_topk_ev, "EV_topK", customer_id_col, f"EV_top{k}_diff")

        topk_corr = compute_topn_rank_correlation(legacy_s, prism_s, k, analysis_product_cols, "topN_rank_correlation", customer_id_col, control_col)
        topk_shared_corr = compute_topn_shared_rank_correlation(legacy_s, prism_s, k, analysis_product_cols, "topN_shared_rank_correlation", customer_id_col, control_col)
        topk_swap = compute_topk_swap_rate(legacy_s, prism_s, k, analysis_product_cols, "topK_changed", customer_id_col, control_col)

        export_tables.extend([
            (f"top{k}_ev_diff_summary", topk_ev_diff.select(f"EV_top{k}_diff").summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")),
            (f"top{k}_corr_summary", topk_corr.select("topN_rank_correlation").summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")),
            (f"top{k}_shared_corr_summary", topk_shared_corr.select("topN_shared_rank_correlation").summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")),
            (f"top{k}_overlap_distribution", overlap_summary),
            (f"top{k}_swap_summary", topk_swap.groupBy("topK_changed").agg(F.count("*").alias("n_customers")).orderBy("topK_changed")),
            (f"top{k}_product_shift", shift_df),
        ])

        p1 = _plot_topk_overlap_distribution(overlap_summary, k, output_dir, plot_config)
        if p1:
            plot_files[f"top{k}_overlap_distribution"] = p1
        p2 = _plot_topk_product_shift(shift_df, k, output_dir, plot_config)
        if p2:
            plot_files[f"top{k}_product_shift"] = p2

    excel_file = None
    if export_excel:
        excel_file = _export_named_tables_to_single_sheet_excel(export_tables, output_dir / f"{scenario_name}_report.xlsx")

    return {
        "scenario_name": scenario_name,
        "scenario_dir": str(output_dir),
        "excel_file": excel_file,
        "plot_files": plot_files,
    }
