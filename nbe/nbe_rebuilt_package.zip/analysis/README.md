NBE rebuilt package

Files:
- analysis/nbe_report_functions_final_onefile.py  -> single helper/functions file
- notebooks/*.ipynb                              -> runnable notebooks

Design:
- Notebook 01 is the rich scenario runner with polished Excel + plots.
- Notebooks 01.1 to 08 export summary-only Excel files.
- No customer-level data is written to Excel.
- Directory pattern:
  BASE_OUTPUT_ROOT/<scenario_name>/<notebook_name>/
