# Generator script omitted in file package; see chat history for the exact script outline.
