NBE Final Full Package Refreshed

analysis/
  nbe_report_functions_final_v3.py
  README.md

notebooks/
  notebook_01_core_scenarios_and_reporting.ipynb
  notebook_01_1_rank_correlation_null_diagnostics.ipynb
  notebook_02_priority_alignment.ipynb
  notebook_03_response_hierarchy_and_business_impact.ipynb
  notebook_04_decile_diagnostics.ipynb
  notebook_05_historical_month_comparison.ipynb
  notebook_06_product_level_raw_rank_correlation.ipynb
  notebook_07_response_raw_decile_calibration.ipynb
