
from typing import Dict, List, Optional
from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

def _safe_product_cols(df: DataFrame, product_cols: Optional[List[str]], customer_id_col: str, control_col: Optional[str]):
    exclude = {customer_id_col}
    if control_col is not None:
        exclude.add(control_col)
    return [c for c in df.columns if c not in exclude] if product_cols is None else product_cols

def filter_to_nbe_group(df: DataFrame, control_col: str = "control") -> DataFrame:
    return df.filter(F.col(control_col) == 0)

def subset_by_customer_ids(df: DataFrame, customer_ids=None, customer_id_col: str = "customer_id") -> DataFrame:
    if customer_ids is None:
        return df
    if isinstance(customer_ids, DataFrame):
        return df.join(customer_ids.select(customer_id_col).distinct(), on=customer_id_col, how="inner")
    if isinstance(customer_ids, (list, tuple, set)):
        return df.filter(F.col(customer_id_col).isin(list(customer_ids)))
    raise ValueError("customer_ids must be None, a Spark DataFrame, or a Python sequence.")

def subset_by_product_cols(df: DataFrame, product_cols=None, customer_id_col: str = "customer_id", control_col: Optional[str] = "control") -> DataFrame:
    if product_cols is None:
        return df
    keep = [customer_id_col]
    if control_col is not None and control_col in df.columns:
        keep.append(control_col)
    keep += product_cols
    keep = [c for c in keep if c in df.columns]
    return df.select(*keep)

def apply_subsetting(df: DataFrame, customer_ids=None, product_cols=None, customer_id_col: str = "customer_id", control_col: Optional[str] = "control", filter_control_zero: bool = True) -> DataFrame:
    out = df
    if filter_control_zero and control_col is not None and control_col in out.columns:
        out = filter_to_nbe_group(out, control_col=control_col)
    out = subset_by_customer_ids(out, customer_ids=customer_ids, customer_id_col=customer_id_col)
    out = subset_by_product_cols(out, product_cols=product_cols, customer_id_col=customer_id_col, control_col=control_col)
    return out

def compute_rank_array(df: DataFrame, product_cols=None, customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    structs = [F.struct((-F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value)))).alias("sort_score"), F.lit(c).alias("product")) for c in product_cols]
    return df.select(customer_id_col, F.transform(F.array_sort(F.array(*structs)), lambda x: x["product"]).alias("ranked_products"))

def compute_total_expected_value(df: DataFrame, product_cols=None, output_col: str = "EV_total", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    expr = None
    for c in product_cols:
        term = F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value)))
        expr = term if expr is None else expr + term
    return df.select(customer_id_col, expr.alias(output_col))

def compute_topk_expected_value(df: DataFrame, k: int, product_cols=None, output_col: str = "EV_topK", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    structs = [F.struct((-F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value)))).alias("sort_score"), F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value))).alias("ev"), F.lit(c).alias("product")) for c in product_cols]
    arr = F.array_sort(F.array(*structs))
    topk = F.slice(arr, 1, k)
    return df.select(customer_id_col, F.aggregate(topk, F.lit(0.0), lambda acc, x: acc + x["ev"]).alias(output_col))

def metric_difference_table(legacy_metric_df: DataFrame, new_metric_df: DataFrame, metric_col: str, customer_id_col: str = "customer_id", diff_col: str = "metric_diff") -> DataFrame:
    return legacy_metric_df.select(customer_id_col, F.col(metric_col).alias(f"{metric_col}_legacy")).join(new_metric_df.select(customer_id_col, F.col(metric_col).alias(f"{metric_col}_new")), on=customer_id_col, how="inner").withColumn(diff_col, F.col(f"{metric_col}_new") - F.col(f"{metric_col}_legacy"))

@F.udf(T.DoubleType())
def _spearman_from_full_orders(old_order, new_order):
    if old_order is None or new_order is None or len(old_order) == 0:
        return None
    if len(old_order) == 1:
        return 1.0
    old_rank = {p: i + 1 for i, p in enumerate(old_order)}
    new_rank = {p: i + 1 for i, p in enumerate(new_order)}
    common = [p for p in old_order if p in new_rank]
    m = len(common)
    if m < 2:
        return None
    d2 = sum((old_rank[p] - new_rank[p]) ** 2 for p in common)
    return float(1.0 - (6.0 * d2) / (m * (m**2 - 1)))

def compute_full_rank_correlation(legacy_df: DataFrame, new_df: DataFrame, product_cols=None, output_col: str = "rank_correlation", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    old_r = compute_rank_array(legacy_df, product_cols, customer_id_col, control_col, null_fill_value).withColumnRenamed("ranked_products", "legacy_ranked_products")
    new_r = compute_rank_array(new_df, product_cols, customer_id_col, control_col, null_fill_value).withColumnRenamed("ranked_products", "new_ranked_products")
    return old_r.join(new_r, on=customer_id_col, how="inner").select(customer_id_col, _spearman_from_full_orders(F.col("legacy_ranked_products"), F.col("new_ranked_products")).alias(output_col))

def compute_top1_agreement(prism_rank_df: DataFrame, legacy_rank_df: DataFrame, customer_id_col: str = "customer_id") -> DataFrame:
    return prism_rank_df.alias("p").join(legacy_rank_df.alias("l"), on=customer_id_col, how="inner").select(customer_id_col, F.col("p.ranked_products")[0].alias("prism_top1"), F.col("l.ranked_products")[0].alias("legacy_top1"), (F.col("p.ranked_products")[0] == F.col("l.ranked_products")[0]).alias("top1_same"))

def compute_priority_alignment_report(priority_df: DataFrame, proposed_df: DataFrame, active_product_cols: List[str], customer_id_col: str = "customer_id", proposed_product_col: str = "proposed_product"):
    priority_rank_df = compute_rank_array(priority_df, product_cols=active_product_cols, customer_id_col=customer_id_col, control_col=None)
    priority_alignment_df = proposed_df.join(priority_rank_df, on=customer_id_col, how="inner").select(customer_id_col, proposed_product_col, F.array_position(F.col("ranked_products"), F.col(proposed_product_col)).alias("priority_rank"))
    return {
        "priority_rank_df": priority_rank_df,
        "priority_alignment_df": priority_alignment_df,
        "priority_alignment_summary": priority_alignment_df.agg(F.count("*").alias("n_offers"), F.avg((F.col("priority_rank") == 1).cast("double")).alias("pct_top1"), F.avg((F.col("priority_rank") <= 3).cast("double")).alias("pct_top3")),
        "priority_alignment_distribution": priority_alignment_df.groupBy("priority_rank").count().orderBy("priority_rank"),
    }

def add_response_flags_if_needed(df: DataFrame, response_state_col: str = "response_state") -> DataFrame:
    out = df
    cols = set(df.columns)
    if {"activated", "actioned", "interested"}.issubset(cols):
        return out
    s = F.upper(F.col(response_state_col))
    if "activated" not in cols:
        out = out.withColumn("activated", F.when(s.isin("ACTIVATED", "ACTIONED", "INTERESTED", "NOT INTERESTED"), 1).otherwise(0))
    if "actioned" not in cols:
        out = out.withColumn("actioned", F.when(s.isin("ACTIONED", "INTERESTED", "NOT INTERESTED"), 1).otherwise(0))
    if "interested" not in cols:
        out = out.withColumn("interested", F.when(s == "INTERESTED", 1).otherwise(0))
    return out

def compute_response_hierarchy_report(measurement_df: DataFrame, customer_group_df: Optional[DataFrame] = None, customer_id_col: str = "customer_id", group_col_name: str = "top1_same", response_state_col: str = "response_state"):
    df = add_response_flags_if_needed(measurement_df, response_state_col=response_state_col)
    if customer_group_df is not None:
        df = df.join(customer_group_df, on=customer_id_col, how="left")
    out = {
        "measurement_enriched": df,
        "response_state_summary": df.groupBy(response_state_col).agg(F.count("*").alias("n"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(F.desc("n")),
        "funnel_summary": df.agg(F.count("*").alias("n_proposed"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate"))
    }
    if customer_group_df is not None:
        out["outcome_by_group"] = df.groupBy(group_col_name).agg(F.count("*").alias("n"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(group_col_name)
    return out

def assign_score_deciles(df: DataFrame, score_col: str, output_col: str, partition_cols=None) -> DataFrame:
    partition_cols = partition_cols or []
    w = Window.partitionBy(*partition_cols).orderBy(F.desc(F.col(score_col))) if partition_cols else Window.orderBy(F.desc(F.col(score_col)))
    return df.withColumn(output_col, F.ntile(10).over(w))

def compute_decile_diagnostics_report(df: DataFrame, prism_score_col: str, legacy_score_col: str, product_col: Optional[str] = None):
    out = df
    parts = [product_col] if product_col else []
    if "prism_decile" not in out.columns:
        out = assign_score_deciles(out, prism_score_col, "prism_decile", parts)
    if "legacy_decile" not in out.columns:
        out = assign_score_deciles(out, legacy_score_col, "legacy_decile", parts)
    return {
        "decile_ready_df": out,
        "prism_decile_distribution": out.groupBy("prism_decile").count().orderBy("prism_decile"),
        "legacy_decile_distribution": out.groupBy("legacy_decile").count().orderBy("legacy_decile"),
        "decile_transition_matrix": out.groupBy("prism_decile", "legacy_decile").count().orderBy("prism_decile", "legacy_decile"),
    }

def compute_historical_month_report(monthly_df: DataFrame, month_col: str = "month", product_col: str = "product", customer_id_col: str = "customer_id", month_a_value: Optional[str] = None, month_b_value: Optional[str] = None):
    df = add_response_flags_if_needed(monthly_df, response_state_col="response_state") if "response_state" in monthly_df.columns else monthly_df
    out = {"month_product_rates": df.groupBy(month_col, product_col).agg(F.count("*").alias("n_offers"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(month_col, product_col)}
    if month_a_value and month_b_value:
        a = df.filter(F.col(month_col) == month_a_value)
        b = df.filter(F.col(month_col) == month_b_value)
        common = a.select(customer_id_col).distinct().intersect(b.select(customer_id_col).distinct())
        common_df = df.join(common, on=customer_id_col, how="inner")
        out["common_month_product_rates"] = common_df.groupBy(month_col, product_col).agg(F.count("*").alias("n_offers"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(month_col, product_col)
    return out

def prepare_product_score_comparison(prism_scores_df: DataFrame, legacy_scores_df: DataFrame, model_mapping_df: DataFrame, customer_subset_df: Optional[DataFrame] = None, customer_id_col: str = "customer_id", model_id_col: str = "model_id", score_col: str = "model_score", product_col: str = "product", legacy_model_id_col: str = "legacy_model_id", prism_model_id_col: str = "prism_model_id") -> DataFrame:
    prism_map = model_mapping_df.select(F.col(product_col), F.col(prism_model_id_col).alias(model_id_col))
    legacy_map = model_mapping_df.select(F.col(product_col), F.col(legacy_model_id_col).alias(model_id_col))
    prism_prepped = prism_scores_df.join(prism_map, on=model_id_col, how="inner").select(customer_id_col, product_col, F.col(score_col).cast("double").alias("prism_score"))
    legacy_prepped = legacy_scores_df.join(legacy_map, on=model_id_col, how="inner").select(customer_id_col, product_col, F.col(score_col).cast("double").alias("legacy_score"))
    if customer_subset_df is not None:
        ids = customer_subset_df.select(customer_id_col).distinct()
        prism_prepped = prism_prepped.join(ids, on=customer_id_col, how="inner")
        legacy_prepped = legacy_prepped.join(ids, on=customer_id_col, how="inner")
    return prism_prepped.join(legacy_prepped, on=[customer_id_col, product_col], how="full")

def compute_product_score_availability_summary(score_compare_df: DataFrame, customer_subset_df: DataFrame, customer_id_col: str = "customer_id", product_col: str = "product") -> DataFrame:
    total = customer_subset_df.select(customer_id_col).distinct().count()
    return score_compare_df.groupBy(product_col).agg(F.sum(F.when(F.col("prism_score").isNotNull() & F.col("legacy_score").isNull(), 1).otherwise(0)).alias("prism_only_n"), F.sum(F.when(F.col("prism_score").isNull() & F.col("legacy_score").isNotNull(), 1).otherwise(0)).alias("legacy_only_n"), F.sum(F.when(F.col("prism_score").isNotNull() & F.col("legacy_score").isNotNull(), 1).otherwise(0)).alias("both_n")).withColumn("none_n", F.lit(int(total)) - F.col("prism_only_n") - F.col("legacy_only_n") - F.col("both_n")).withColumn("prism_only_pct", F.col("prism_only_n") / F.lit(float(total))).withColumn("legacy_only_pct", F.col("legacy_only_n") / F.lit(float(total))).withColumn("both_pct", F.col("both_n") / F.lit(float(total))).withColumn("none_pct", F.col("none_n") / F.lit(float(total))).orderBy(product_col)

def compute_product_level_rank_correlation(score_compare_df: DataFrame, customer_id_col: str = "customer_id", product_col: str = "product"):
    both = score_compare_df.filter(F.col("prism_score").isNotNull() & F.col("legacy_score").isNotNull())
    w_p = Window.partitionBy(product_col).orderBy(F.desc("prism_score"))
    w_l = Window.partitionBy(product_col).orderBy(F.desc("legacy_score"))
    ranked = both.withColumn("prism_customer_rank", F.row_number().over(w_p)).withColumn("legacy_customer_rank", F.row_number().over(w_l)).withColumn("rank_gap", F.abs(F.col("prism_customer_rank") - F.col("legacy_customer_rank")))
    return {
        "ranked_customer_scores": ranked,
        "product_rank_summary": ranked.groupBy(product_col).agg(F.count("*").alias("n_both"), F.corr("prism_customer_rank", "legacy_customer_rank").alias("pearson_rank_corr"), F.avg("rank_gap").alias("avg_rank_gap"), F.expr("percentile_approx(rank_gap, 0.5)").alias("median_rank_gap")).orderBy(product_col)
    }

def compute_response_raw_decile_calibration(responders_df: DataFrame, score_compare_df: DataFrame, customer_id_col: str = "customer_id", product_col: str = "product"):
    joined = responders_df.select(customer_id_col, product_col).distinct().join(score_compare_df.select(customer_id_col, product_col, "prism_score", "legacy_score"), on=[customer_id_col, product_col], how="inner")
    prism_deciled = assign_score_deciles(joined, "prism_score", "prism_decile", [product_col])
    both_deciled = assign_score_deciles(prism_deciled, "legacy_score", "legacy_decile", [product_col])
    prism_dist = both_deciled.groupBy("prism_decile").count().withColumnRenamed("count", "n_responders").orderBy("prism_decile")
    legacy_dist = both_deciled.groupBy("legacy_decile").count().withColumnRenamed("count", "n_responders").orderBy("legacy_decile")
    p_total = prism_dist.agg(F.sum("n_responders").alias("n")).collect()[0]["n"] or 1
    l_total = legacy_dist.agg(F.sum("n_responders").alias("n")).collect()[0]["n"] or 1
    prism_dist = prism_dist.withColumn("pct_responders", F.col("n_responders") / F.lit(float(p_total)))
    legacy_dist = legacy_dist.withColumn("pct_responders", F.col("n_responders") / F.lit(float(l_total)))
    capture = both_deciled.agg(F.avg((F.col("prism_decile") <= 1).cast("double")).alias("prism_top10_capture"), F.avg((F.col("legacy_decile") <= 1).cast("double")).alias("legacy_top10_capture"), F.avg((F.col("prism_decile") <= 2).cast("double")).alias("prism_top20_capture"), F.avg((F.col("legacy_decile") <= 2).cast("double")).alias("legacy_top20_capture"), F.avg((F.col("prism_decile") <= 3).cast("double")).alias("prism_top30_capture"), F.avg((F.col("legacy_decile") <= 3).cast("double")).alias("legacy_top30_capture"))
    return {"responders_scored": both_deciled, "prism_responder_decile_dist": prism_dist, "legacy_responder_decile_dist": legacy_dist, "responder_capture_summary": capture}

def make_scenario(scenario_name: str, customer_subset=None, product_cols: Optional[List[str]] = None, top_k_values: Optional[List[int]] = None):
    return {"scenario_name": scenario_name, "customer_subset": customer_subset, "product_cols": product_cols, "top_k_values": top_k_values}
