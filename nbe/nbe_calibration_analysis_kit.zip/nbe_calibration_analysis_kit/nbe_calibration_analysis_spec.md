# NBE Calibration Removal Analysis — Implementation Specification

## 1. Objective

Compare two current-customer ranking systems using only:

- raw model propensity,
- current calibration factor / adjusted propensity,
- model-score decile and percentile,
- CLTV,
- historical rolling-window decile summaries: count, average predicted propensity, average actual response.

No control-group, campaign-assignment, presentation, or causal analysis is required here.

The key ranking object is **every feasible product pair for a customer**, because downstream execution may compare an arbitrary subset of products.

---

## 2. Required input tables

### 2.1 Current customer-product score table

One row per `customer_id × product_id`.

Required columns:

| Column | Meaning |
|---|---|
| `customer_id` | Customer key |
| `product_id` | Product/model key |
| `raw_propensity` | Current raw model score in `[0,1]` |
| `cltv` | Customer-product CLTV/value |
| `decile` | Within-product score decile; **1 = strongest** |
| `percentile` | Within-product score percentile; **higher = stronger** |

Optional columns:

| Column | Meaning |
|---|---|
| `calibration_factor` | Current aggregate odds factor |
| `adjusted_propensity` | Existing production adjusted score |

If factor/adjusted score are absent, Notebook 01 derives them from the historical table.

### 2.2 Historical rolling-window calibration table

One row per `product_id × window_id × decile`.

Required columns:

| Column | Meaning |
|---|---|
| `product_id` | Product/model key |
| `window_id` | Window identifier |
| `window_start` | Start date |
| `window_end` | End date |
| `decile` | Score decile; 1 = strongest |
| `n_customers` | Number of observations represented by the row |
| `avg_predicted` | Mean model propensity in that window/decile |
| `avg_actual` | Mean historical response in that window/decile |

Rolling windows may overlap, e.g. Jan–Mar, Feb–Apr, Mar–May.

---

## 3. Core notation

For customer `c`, product `p`, decile `d`, historical window `w`:

\[
p_{cp}=\text{raw propensity},\qquad V_{cp}=CLTV
\]

Historical summary:

\[
\bar p_{pdw}=\text{average predicted},\qquad
\bar y_{pdw}=\text{average actual},\qquad
n_{pdw}=\text{count}.
\]

Define

\[
\operatorname{logit}(x)=\log\frac{x}{1-x},\qquad
\sigma(z)=\frac{1}{1+e^{-z}}.
\]

Historical log-odds correction:

\[
\delta_{pdw}=\operatorname{logit}(\bar y_{pdw})-\operatorname{logit}(\bar p_{pdw}).
\]

Calibration factor, using the existing convention:

\[
f_{pdw}=e^{-\delta_{pdw}}
=\frac{\operatorname{odds}(\bar p_{pdw})}{\operatorname{odds}(\bar y_{pdw})}.
\]

Adjusted current propensity:

\[
p^{adj}_{cp}=\sigma(\operatorname{logit}(p_{cp})+\delta_{pd}).
\]

Equivalent factor form:

\[
p^{adj}_{cp}=\frac{p_{cp}}{p_{cp}+(1-p_{cp})f_{pd}}.
\]

Current ranking scores:

\[
EV^{raw}_{cp}=p_{cp}V_{cp},\qquad
EV^{cal}_{cp}=p^{adj}_{cp}V_{cp}.
\]

---

# Tier 1 — Must do

## 4. Pairwise reversal rate

For every customer and unordered product pair `(A,B)`:

\[
R_{cAB}=I[w^{raw}_{cAB}\neq w^{cal}_{cAB}].
\]

Aggregate:

\[
PRR=\frac{\sum R_{cAB}}{\#\text{pairs}}.
\]

**Output:** overall PRR, PRR by product pair, PRR by number of products per customer if useful.

## 5. Top-1 change and rank displacement

\[
Top1Change=P[\arg\max_p EV^{raw}_{cp}\neq\arg\max_p EV^{cal}_{cp}].
\]

\[
RankMove=\operatorname{mean}|rank^{raw}_{cp}-rank^{cal}_{cp}|.
\]

## 6. Decile / percentile analysis

Assume decile 1 is strongest and higher percentile is stronger.

For ranking method `M`:

\[
DC(M)=P[d_{winner(M)}<d_{loser(M)}].
\]

\[
PC(M)=P[q_{winner(M)}>q_{loser(M)}].
\]

For reversed pairs also compute:

\[
|\Delta d|=|d_A-d_B|,\qquad
|\Delta q|=|q_A-q_B|.
\]

Recommended buckets:

- same decile,
- 1 decile apart,
- 2–3 apart,
- >3 apart,
- percentile gap `<5`, `5–10`, `10–20`, `>20`.

Interpretation: **relative model strength only**. Do not claim cross-product deciles/percentiles are calibrated probabilities.

## 7. CLTV analysis

Pairwise CLTV concordance:

\[
VC(M)=P[V_{winner(M)}>V_{loser(M)}].
\]

For reversed pairs, orient the pair so `B = raw winner`, `A = calibrated winner`:

\[
\Delta V=V_B-V_A.
\]

Report fraction `ΔV>0`, median/mean `ΔV`, and absolute gap.

Equal-acceptance CLTV regret:

\[
Regret_M=\max(V_A,V_B)-V_{winner(M)}.
\]

This is an explicit sensitivity assumption, not a full ranking-quality metric.

## 8. Reversal severity / attribution

For every reversed pair store:

\[
|\Delta d|,\ |\Delta q|,\ |\Delta CLTV|,\ |\Delta\log f|,
\]

plus normalized score margins:

\[
Margin^{raw}=\frac{|EV_A^{raw}-EV_B^{raw}|}{\max(|EV_A^{raw}|,|EV_B^{raw}|,\epsilon)}
\]

and the analogous calibrated margin.

Summarize which product pairs and which calibration-factor differences generate most reversals.

## 9. Linear probability interpolation break-even

For a reversed pair, `A = calibrated winner`, `B = raw winner`:

\[
p_p(\alpha)=\alpha p_p^{raw}+(1-\alpha)p_p^{adj},\qquad \alpha\in[0,1].
\]

Define

\[
\Delta_{BA}(\alpha)=V_Bp_B(\alpha)-V_Ap_A(\alpha).
\]

Break-even:

\[
\alpha^*: \Delta_{BA}(\alpha^*)=0.
\]

Closed form:

\[
\alpha^*=\frac{-D_{cal}}{D_{raw}-D_{cal}},
\]

where

\[
D_{cal}=EV_B^{cal}-EV_A^{cal}<0,\qquad
D_{raw}=EV_B^{raw}-EV_A^{raw}>0.
\]

Report distribution / CDF of `α*` rather than only one aggregate number.

Also compute an aggregate net-value break-even over reversed pairs:

\[
G(\alpha)=\sum_i [V_{B_i}p_{B_i}(\alpha)-V_{A_i}p_{A_i}(\alpha)].
\]

Report both the pair-sum break-even and a customer-normalized version where each customer receives total weight 1 across their reversed pairs. Keep the pairwise `α*` distribution primary because aggregate sums can be dominated by high-CLTV pairs.

## 10. Calibration-strength break-even

Prefer this as the calibration-mechanism sensitivity test:

\[
p_p(\gamma)=\sigma(\operatorname{logit}(p_p^{raw})+\gamma\delta_{pd}),
\qquad \gamma\in[0,1].
\]

- `γ=0`: raw
- `γ=1`: full calibration

For each reversed pair solve numerically:

\[
\gamma^*:V_Ap_A(\gamma^*)=V_Bp_B(\gamma^*).
\]

Interpret `γ*` as the fraction of the existing correction needed to flip the raw decision. It is a **fragility parameter**, not an estimated probability of calibration being correct.

---

# Tier 2 — Strongest additions from rolling historical windows

## 11. Window-level correction stability

For every product-decile collect

\[
\delta_{pd1},\ldots,\delta_{pdW}.
\]

Compute:

- window count,
- mean / median `δ`,
- standard deviation,
- IQR,
- min / max,
- sign consistency relative to aggregate correction,
- latest correction,
- recent-K correction.

Sign consistency:

\[
SC_{pd}=\frac{\#\{w:\operatorname{sign}(\delta_{pdw})=\operatorname{sign}(\delta_{pd}^{agg})\}}{W}.
\]

## 12. Recent-vs-aggregate drift

\[
Drift_{pd}=|\delta^{recent}_{pd}-\delta^{agg}_{pd}|.
\]

Re-rank current customers using recent correction and compare with current aggregate calibration.

## 13. Historical-factor scenario stress test

For each historical window `w`, apply that window's product-decile correction to today's customer rows:

\[
p^{(w)}_{cp}=\sigma(\operatorname{logit}(p_{cp})+\delta_{pdw})
\]

\[
EV^{(w)}_{cp}=V_{cp}p^{(w)}_{cp}.
\]

For each scenario compute:

- coverage of products/rows,
- top-1 disagreement vs raw,
- top-1 disagreement vs aggregate calibration,
- pairwise disagreement vs raw,
- pairwise disagreement vs aggregate calibration.

For current raw-vs-calibrated reversed pairs, where both product-decile corrections exist in the same historical window, compute historical-scenario support for each winner.

### Historical-response × CLTV scenario

A separate scenario uses the historical decile response itself:

\[
U^{(w)}_{cp}=V_{cp}\bar y_{p,d(c,p),w}.
\]

For each current reversed pair, count the fraction of common historical windows where the raw winner has higher `U^(w)` than the calibrated winner. This is a useful historical-response scenario but **not independent validation**, because these historical responses also contribute to the calibration factors.

## 14. Out-of-time walk-forward validation

This is the strongest probability-scale validation available from the supplied summaries.

For each product-decile, sort windows by time. Prefer a **non-overlapping subset** for formal validation.

At test window `j`, estimate the correction only from earlier selected windows.

Train aggregate:

\[
\bar p^{train}=\frac{\sum_{w<j}n_w\bar p_w}{\sum_{w<j}n_w},\qquad
\bar y^{train}=\frac{\sum_{w<j}n_w\bar y_w}{\sum_{w<j}n_w}.
\]

\[
\delta^{train}=\operatorname{logit}(\bar y^{train})-\operatorname{logit}(\bar p^{train}).
\]

Test predictions:

\[
q^{raw}=\bar p_j,
\]

\[
q^{cal}=\sigma(\operatorname{logit}(\bar p_j)+\delta^{train}).
\]

Observed rate is `y_j = avg_actual_j`.

Grouped Bernoulli log loss:

\[
LL(q,y)=-[y\log q+(1-y)\log(1-q)].
\]

Grouped Brier loss:

\[
BS(q,y)=y(1-q)^2+(1-y)q^2.
\]

Improvement:

\[
\Delta Loss=Loss_{raw}-Loss_{cal}.
\]

Positive = historical calibration generalizes better; negative = raw generalizes better.

Aggregate losses using `n_customers` weights. Report overall, by product, and by decile.

## 15. Aggregation-method sensitivity

Construct several reasonable correction summaries:

1. current pooled-rate method,
2. equal-window mean of `δ_w`,
3. median of `δ_w`,
4. recent-K mean of `δ_w`,
5. pooled non-overlapping windows.

Apply each summary to current scores and compare resulting rankings.

This tests whether the production decision is sensitive to the arbitrary historical summarization rule.

## 16. Overlapping-window handling

Rolling windows such as Jan–Mar, Feb–Apr, Mar–May are correlated.

Use:

- **all windows** for descriptive trend/stability plots,
- **non-overlapping windows** for formal OOT tests and approximate uncertainty calculations.

Do not treat `sum(n_customers)` across overlapping windows as a count of independent observations.

---

# Tier 3 — Uncertainty-aware analysis

## 17. Approximate interval for actual response → delta → factor

Using non-overlapping windows, aggregate approximate successes:

\[
k=\sum n_w\bar y_w,
\qquad N=\sum n_w.
\]

A Jeffreys-style Beta posterior for the response rate is:

\[
\theta\mid data\approx Beta(k+1/2,N-k+1/2).
\]

Use its 2.5% / 97.5% quantiles for an approximate interval for `θ`.

Transform:

\[
\delta^L=\operatorname{logit}(\theta^L)-\operatorname{logit}(\bar p),
\qquad
\delta^U=\operatorname{logit}(\theta^U)-\operatorname{logit}(\bar p).
\]

Factor interval:

\[
f\in[e^{-\delta^U},e^{-\delta^L}].
\]

Diagnostic:

\[
0\in CI(\delta)\iff1\in CI(f).
\]

Treat this as approximate because repeated customers across disjoint time windows may still exist and `avg_predicted` is treated as fixed.

## 18. Random-effects / temporal heterogeneity summary

Use non-overlapping window corrections as repeated estimates:

\[
\delta_w\approx\mu+u_w,
\qquad u_w\sim N(0,\tau^2).
\]

The notebooks implement a lightweight DerSimonian–Laird random-effects meta-analysis on `δ_w` using approximate within-window logit variance.

Outputs:

- `μ`: persistent correction,
- `τ`: between-window instability,
- confidence interval for `μ`,
- predictive interval for a future latent correction.

This is an approximation, but it is substantially more informative than treating the aggregate factor as known exactly.

## 19. Robust EV intervals

For a current row, transform correction interval to probability interval:

\[
p^L=\sigma(\operatorname{logit}(p^{raw})+\delta^L),\qquad
p^U=\sigma(\operatorname{logit}(p^{raw})+\delta^U).
\]

\[
EV\in[V p^L,V p^U].
\]

For pair A/B:

\[
EV_A^L>EV_B^U\Rightarrow A\text{ robustly dominates B}.
\]

Otherwise the pair is uncertainty-sensitive/ambiguous under the interval model.

## 20. Monte Carlo pairwise win probability

Using the random-effects predictive correction distribution, sample plausible future corrections:

\[
\delta_{pd}^{(s)}\sim N(\hat\mu_{pd},\hat\sigma^2_{pred,pd}).
\]

For each current reversed pair:

\[
\pi_{raw}=P(EV_{raw-winner}>EV_{cal-winner}\mid historical\ windows).
\]

Recommended outputs:

- median `π_raw`,
- fraction with `π_raw > .9`,
- fraction with `π_raw < .1`,
- fraction in `[.4,.6]` = highly ambiguous.

This is a decision-uncertainty summary, conditional on the chosen random-effects approximation.

## 21. Decile smoothness / monotonicity diagnostics

For aggregate correction by product:

\[
R_p=\sum_{d=1}^{9}(\delta_{p,d+1}-\delta_{p,d})^2.
\]

Also count adjacent violations of expected historical response ordering:

\[
\bar y_{p,1}\ge\bar y_{p,2}\ge\cdots\ge\bar y_{p,10}.
\]

High roughness / many violations suggests decile-level factors may contain noise or unstable local corrections.

---

# 22. Recommended output artifacts

The analysis notebook writes an output folder containing CSV files and, when an Excel engine is available, `nbe_calibration_analysis.xlsx`.

Recommended sheets/files:

1. `summary_metrics`
2. `product_pair_summary`
3. `reversed_pairs_sample` / full CSV separately
4. `calibration_stability`
5. `aggregation_sensitivity`
6. `scenario_summary`
7. `reversal_scenario_support`
8. `oot_detail`
9. `oot_summary`
10. `uncertainty_summary`
11. `random_effects_summary`
12. `mc_reversal_probabilities`
13. `product_smoothness`

---

# 23. Scaling guidance

The notebooks are written as a pandas prototype for 5–10 products and a manageable current-customer sample.

Pair materialization scales as approximately:

\[
N_{customers}\binom{P}{2}.
\]

For millions of customers, port the same transformations to Spark and retain the exact metric definitions in this document. The notebook includes configurable customer caps for pairwise and Monte Carlo sections so the logic can be validated before distributed implementation.

---

# 24. Recommended decision sequence

1. **How much changes?** — PRR, top-1, rank movement.
2. **What direction do changes move?** — decile/percentile + CLTV analysis.
3. **How fragile are reversals?** — `α*`, `γ*`, score margins.
4. **Is the historical correction stable?** — `δ_w`, drift, scenario stress.
5. **Does the correction generalize forward?** — walk-forward Brier/log loss.
6. **Does the answer depend on aggregation choices?** — sensitivity analysis.
7. **How uncertain is the correction?** — intervals/random effects.
8. **How robust are current pairwise decisions under that uncertainty?** — EV intervals / Monte Carlo win probabilities.

---

# 25. Claims to avoid

- Do not call cross-product decile/percentile differences true probability differences.
- Do not interpret `α*` or `γ*` as a probability that calibration is correct.
- Do not treat overlapping rolling windows as independent observations.
- Do not treat historical-response calibration as causal uplift.
- Do not use raw EV or calibrated EV as independent ground truth for choosing between the two ranking systems.
