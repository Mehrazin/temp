# NBE Calibration Analysis Kit

## Files

- `nbe_calibration_visual_guide.html` — compact visual/math map of the analysis.
- `nbe_calibration_analysis_spec.md` — detailed implementation context for a coding agent.
- `01_prepare_and_validate.ipynb` — input schema, validation, factor reconstruction, prepared tables.
- `02_run_analysis.ipynb` — pairwise, decile/CLTV, break-even, stability, OOT, uncertainty, scenario, and export analysis.
- `data/example_current_scores.csv` — synthetic 5-product example.
- `data/example_historical_windows.csv` — synthetic rolling 3-month calibration history.
- `requirements.txt` — suggested Python packages.

## Run

1. Open the HTML guide.
2. Replace the two input paths / column mappings in Notebook 01.
3. Run Notebook 01.
4. Run Notebook 02.
5. Results are written to `outputs/analysis/` as CSVs and, when an Excel engine is available, `nbe_calibration_analysis.xlsx`.

Both notebooks were executed end-to-end against the bundled synthetic example before packaging.

For millions of customers, validate the logic on a sample first, then port the pairwise transformations to Spark using the formulas in the Markdown specification.
