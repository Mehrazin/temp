Final package update for granular Notebook 08.

Files changed:
1. analysis/nbe_report_functions_final_fixed_v2.py
2. notebooks/notebook_08_customer_specific_product_filtering.ipynb

Notebook 01 is unchanged.

Notebook 08 now adds:
- filter-only allowed product count distribution
- granular score coverage breakdown by:
  K = allowed product count
  L = Legacy scored count
  P = PRISM scored count
  O = overlap count
  exact_match_flag
- rank analysis for all groups with O >= 2
- separate summaries for exact-match vs partial-overlap groups
- per-section artifact folders with Excel + plots

Artifacts for Notebook 08 are saved under:
BASE_OUTPUT_ROOT/<scenario_name>/notebook_08_customer_specific_product_filtering/
  01_filter_distribution/
  02_coverage/
  03_rank_analysis/
  04_top1_distribution/
