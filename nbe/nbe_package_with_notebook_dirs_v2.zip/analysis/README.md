Updated package with shared scenario config and per-notebook output directories.
Every notebook now contains executable setup + example execution cells, not comment-only final cells.
