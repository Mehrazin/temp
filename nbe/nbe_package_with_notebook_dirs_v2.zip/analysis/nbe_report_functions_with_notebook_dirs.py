
from typing import Dict, List, Optional, Union
from pathlib import Path
from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

# ============================================================
# Shared directory / scenario helpers
# ============================================================

def ensure_dir(path: Union[str, Path]) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path

def make_scenario(
    scenario_name: str,
    customer_subset=None,
    product_cols: Optional[List[str]] = None,
    top_k_values: Optional[List[int]] = None,
):
    return {
        "scenario_name": scenario_name,
        "customer_subset": customer_subset,
        "product_cols": product_cols,
        "top_k_values": top_k_values,
    }

def build_standard_scenarios(
    all_products: List[str],
    changed_products: List[str],
    active_products: List[str],
    active_changed_products: List[str],
    one_million_customer_df=None,
    top_k_values: Optional[List[int]] = None,
) -> List[Dict]:
    return [
        make_scenario("S1_full_8m_all37", None, all_products, top_k_values),
        make_scenario("S2_full_8m_changed8", None, changed_products, top_k_values),
        make_scenario("S3_full_8m_active12", None, active_products, top_k_values),
        make_scenario("S4_full_8m_active_changed", None, active_changed_products, top_k_values),
        make_scenario("S5_1m_all37", one_million_customer_df, all_products, top_k_values),
        make_scenario("S6_1m_changed8", one_million_customer_df, changed_products, top_k_values),
        make_scenario("S7_1m_active12", one_million_customer_df, active_products, top_k_values),
        make_scenario("S8_1m_active_changed", one_million_customer_df, active_changed_products, top_k_values),
    ]

def make_notebook_output_dir(
    base_output_root: Union[str, Path],
    scenario_name: str,
    notebook_name: str,
) -> str:
    out = ensure_dir(Path(base_output_root) / scenario_name / notebook_name)
    return str(out)

def save_df_artifact(df: DataFrame, output_dir: Union[str, Path], artifact_name: str, mode: str = "overwrite") -> str:
    path = str(Path(output_dir) / artifact_name)
    df.write.mode(mode).parquet(path)
    return path

# ============================================================
# Generic dataframe helpers
# ============================================================

def _safe_product_cols(df: DataFrame, product_cols, customer_id_col: str, control_col: Optional[str]):
    exclude = {customer_id_col}
    if control_col is not None:
        exclude.add(control_col)
    return [c for c in df.columns if c not in exclude] if product_cols is None else product_cols

def filter_to_nbe_group(df: DataFrame, control_col: str = "control") -> DataFrame:
    return df.filter(F.col(control_col) == 0)

def subset_by_customer_ids(df: DataFrame, customer_ids=None, customer_id_col: str = "customer_id") -> DataFrame:
    if customer_ids is None:
        return df
    if isinstance(customer_ids, DataFrame):
        return df.join(customer_ids.select(customer_id_col).distinct(), on=customer_id_col, how="inner")
    if isinstance(customer_ids, (list, tuple, set)):
        return df.filter(F.col(customer_id_col).isin(list(customer_ids)))
    raise ValueError("customer_ids must be None, a Spark DataFrame, or a Python sequence.")

def subset_by_product_cols(df: DataFrame, product_cols=None, customer_id_col: str = "customer_id", control_col: Optional[str] = "control") -> DataFrame:
    if product_cols is None:
        return df
    keep = [customer_id_col]
    if control_col is not None and control_col in df.columns:
        keep.append(control_col)
    keep += product_cols
    keep = [c for c in keep if c in df.columns]
    return df.select(*keep)

def apply_subsetting(df: DataFrame, customer_ids=None, product_cols=None, customer_id_col: str = "customer_id", control_col: Optional[str] = "control", filter_control_zero: bool = True) -> DataFrame:
    out = df
    if filter_control_zero and control_col is not None and control_col in out.columns:
        out = filter_to_nbe_group(out, control_col=control_col)
    out = subset_by_customer_ids(out, customer_ids=customer_ids, customer_id_col=customer_id_col)
    out = subset_by_product_cols(out, product_cols=product_cols, customer_id_col=customer_id_col, control_col=control_col)
    return out

# ============================================================
# Core ranking / EV helpers
# ============================================================

def compute_rank_array(df: DataFrame, product_cols=None, customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    structs = [F.struct((-F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value)))).alias("sort_score"), F.lit(c).alias("product")) for c in product_cols]
    return df.select(customer_id_col, F.transform(F.array_sort(F.array(*structs)), lambda x: x["product"]).alias("ranked_products"))

def add_topk_product_array(df: DataFrame, k: int, product_cols=None, output_col: str = "topk_products", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    ranked = compute_rank_array(df, product_cols, customer_id_col, control_col, null_fill_value)
    return ranked.select(customer_id_col, F.slice(F.col("ranked_products"), 1, k).alias(output_col))

def compute_total_expected_value(df: DataFrame, product_cols=None, output_col: str = "EV_total", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    expr = None
    for c in product_cols:
        term = F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value)))
        expr = term if expr is None else expr + term
    return df.select(customer_id_col, expr.alias(output_col))

def compute_topk_expected_value(df: DataFrame, k: int, product_cols=None, output_col: str = "EV_topK", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    product_cols = _safe_product_cols(df, product_cols, customer_id_col, control_col)
    structs = [F.struct((-F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value)))).alias("sort_score"), F.coalesce(F.col(c).cast("double"), F.lit(float(null_fill_value))).alias("ev"), F.lit(c).alias("product")) for c in product_cols]
    arr = F.array_sort(F.array(*structs))
    topk = F.slice(arr, 1, k)
    return df.select(customer_id_col, F.aggregate(topk, F.lit(0.0), lambda acc, x: acc + x["ev"]).alias(output_col))

def metric_difference_table(legacy_metric_df: DataFrame, new_metric_df: DataFrame, metric_col: str, customer_id_col: str = "customer_id", diff_col: str = "metric_diff") -> DataFrame:
    return legacy_metric_df.select(customer_id_col, F.col(metric_col).alias(f"{metric_col}_legacy")).join(new_metric_df.select(customer_id_col, F.col(metric_col).alias(f"{metric_col}_new")), on=customer_id_col, how="inner").withColumn(diff_col, F.col(f"{metric_col}_new") - F.col(f"{metric_col}_legacy"))

def summarize_metric(df: DataFrame, metric_col: str) -> DataFrame:
    return df.select(metric_col).summary("count", "mean", "stddev", "min", "25%", "50%", "75%", "max")

# ============================================================
# Rank correlation / overlap
# ============================================================

@F.udf(T.DoubleType())
def _spearman_from_full_orders(old_order, new_order):
    if old_order is None or new_order is None or len(old_order) == 0:
        return None
    if len(old_order) == 1:
        return 1.0
    old_rank = {p: i + 1 for i, p in enumerate(old_order)}
    new_rank = {p: i + 1 for i, p in enumerate(new_order)}
    common = [p for p in old_order if p in new_rank]
    m = len(common)
    if m < 2:
        return None
    d2 = sum((old_rank[p] - new_rank[p]) ** 2 for p in common)
    return float(1.0 - (6.0 * d2) / (m * (m**2 - 1)))

@F.udf(T.DoubleType())
def _spearman_from_topn_orders(old_topn, new_topn):
    if old_topn is None or new_topn is None:
        return None
    n = max(len(old_topn), len(new_topn))
    all_products = list(dict.fromkeys((old_topn or []) + (new_topn or [])))
    m = len(all_products)
    if m == 0:
        return None
    old_rank = {p:i+1 for i,p in enumerate(old_topn)}
    new_rank = {p:i+1 for i,p in enumerate(new_topn)}
    if m == 1:
        p = all_products[0]
        return 1.0 if old_rank.get(p, n+1) == new_rank.get(p, n+1) else 0.0
    d2 = sum((old_rank.get(p, n+1) - new_rank.get(p, n+1))**2 for p in all_products)
    return float(1.0 - (6.0 * d2) / (m * (m**2 - 1)))

def compute_full_rank_correlation(legacy_df: DataFrame, new_df: DataFrame, product_cols=None, output_col: str = "rank_correlation", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    old_r = compute_rank_array(legacy_df, product_cols, customer_id_col, control_col, null_fill_value).withColumnRenamed("ranked_products", "legacy_ranked_products")
    new_r = compute_rank_array(new_df, product_cols, customer_id_col, control_col, null_fill_value).withColumnRenamed("ranked_products", "new_ranked_products")
    return old_r.join(new_r, on=customer_id_col, how="inner").select(customer_id_col, _spearman_from_full_orders(F.col("legacy_ranked_products"), F.col("new_ranked_products")).alias(output_col))

def compute_topn_rank_correlation(legacy_df: DataFrame, new_df: DataFrame, n: int, product_cols=None, output_col: str = "topN_rank_correlation", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    old_topn = add_topk_product_array(legacy_df, n, product_cols, "legacy_topn_products", customer_id_col, control_col, null_fill_value)
    new_topn = add_topk_product_array(new_df, n, product_cols, "new_topn_products", customer_id_col, control_col, null_fill_value)
    return old_topn.join(new_topn, on=customer_id_col, how="inner").select(customer_id_col, _spearman_from_topn_orders(F.col("legacy_topn_products"), F.col("new_topn_products")).alias(output_col))

def compute_topk_overlap(legacy_df: DataFrame, new_df: DataFrame, k: int, product_cols=None, output_col: str = "topK_overlap", customer_id_col: str = "customer_id", control_col: Optional[str] = "control", null_fill_value: float = 0.0) -> DataFrame:
    old_topk = add_topk_product_array(legacy_df, k, product_cols, "legacy_topk_products", customer_id_col, control_col, null_fill_value)
    new_topk = add_topk_product_array(new_df, k, product_cols, "new_topk_products", customer_id_col, control_col, null_fill_value)
    return old_topk.join(new_topk, on=customer_id_col, how="inner").select(customer_id_col, (F.size(F.array_intersect(F.col("legacy_topk_products"), F.col("new_topk_products"))) / F.lit(float(k))).alias(output_col))

# ============================================================
# Diagnostics / downstream analyses
# ============================================================

def compute_product_score_coverage_report(prism_df: DataFrame, legacy_df: DataFrame, product_cols: List[str], customer_id_col: str = "customer_id") -> DataFrame:
    joined = prism_df.alias("p").join(legacy_df.alias("l"), on=customer_id_col, how="inner")
    pieces = []
    for c in product_cols:
        pieces.append(joined.select(
            F.lit(c).alias("product"),
            F.when(F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNull(), 1).otherwise(0).alias("prism_only_available"),
            F.when(F.col(f"p.{c}").isNull() & F.col(f"l.{c}").isNotNull(), 1).otherwise(0).alias("legacy_only_available"),
            F.when(F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNotNull(), 1).otherwise(0).alias("both_available"),
            F.when(F.col(f"p.{c}").isNull() & F.col(f"l.{c}").isNull(), 1).otherwise(0).alias("both_null"),
        ))
    out = pieces[0]
    for p in pieces[1:]:
        out = out.unionByName(p)
    total_rows = prism_df.select(customer_id_col).distinct().count()
    return out.groupBy("product").agg(
        F.sum("prism_only_available").alias("prism_only_available"),
        F.sum("legacy_only_available").alias("legacy_only_available"),
        F.sum("both_available").alias("both_available"),
        F.sum("both_null").alias("both_null"),
    ).withColumn("pct_prism_only_available", F.col("prism_only_available") / F.lit(float(total_rows))).withColumn("pct_legacy_only_available", F.col("legacy_only_available") / F.lit(float(total_rows))).withColumn("pct_both_available", F.col("both_available") / F.lit(float(total_rows))).withColumn("pct_both_null", F.col("both_null") / F.lit(float(total_rows))).orderBy("product")

def compute_customer_availability_diagnostics(prism_df: DataFrame, legacy_df: DataFrame, product_cols: List[str], customer_id_col: str = "customer_id") -> DataFrame:
    joined = prism_df.alias("p").join(legacy_df.alias("l"), on=customer_id_col, how="inner")
    p_expr = l_expr = c_expr = m_expr = None
    for c in product_cols:
        p_avail = F.when(F.col(f"p.{c}").isNotNull(), 1).otherwise(0)
        l_avail = F.when(F.col(f"l.{c}").isNotNull(), 1).otherwise(0)
        c_avail = F.when(F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNotNull(), 1).otherwise(0)
        mismatch = F.when(((F.col(f"p.{c}").isNotNull() & F.col(f"l.{c}").isNull()) | (F.col(f"p.{c}").isNull() & F.col(f"l.{c}").isNotNull())), 1).otherwise(0)
        p_expr = p_avail if p_expr is None else p_expr + p_avail
        l_expr = l_avail if l_expr is None else l_expr + l_avail
        c_expr = c_avail if c_expr is None else c_expr + c_avail
        m_expr = mismatch if m_expr is None else m_expr + mismatch
    return joined.select(F.col(customer_id_col), p_expr.alias("prism_available_count"), l_expr.alias("legacy_available_count"), c_expr.alias("common_available_count"), m_expr.alias("mismatch_count")).withColumn("exact_match_flag", F.when(F.col("mismatch_count") == 0, 1).otherwise(0))

def summarize_customer_availability_diagnostics(diag_df: DataFrame):
    total = diag_df.count()
    return {
        "exact_match_summary": diag_df.agg(F.count("*").alias("n_customers"), F.avg(F.col("exact_match_flag").cast("double")).alias("exact_match_rate"), F.avg(F.col("prism_available_count").cast("double")).alias("avg_prism_available_count"), F.avg(F.col("legacy_available_count").cast("double")).alias("avg_legacy_available_count"), F.avg(F.col("common_available_count").cast("double")).alias("avg_common_available_count")),
        "common_count_distribution": diag_df.groupBy("common_available_count").agg(F.count("*").alias("n_customers")).withColumn("pct_customers", F.col("n_customers") / F.lit(float(total))).orderBy("common_available_count"),
    }

def compute_priority_alignment_report(priority_df: DataFrame, proposed_df: DataFrame, active_product_cols: List[str], customer_id_col: str = "customer_id", proposed_product_col: str = "proposed_product"):
    priority_rank_df = compute_rank_array(priority_df, product_cols=active_product_cols, customer_id_col=customer_id_col, control_col=None)
    priority_alignment_df = proposed_df.join(priority_rank_df, on=customer_id_col, how="inner").select(customer_id_col, proposed_product_col, F.array_position(F.col("ranked_products"), F.col(proposed_product_col)).alias("priority_rank"))
    return {
        "priority_rank_df": priority_rank_df,
        "priority_alignment_df": priority_alignment_df,
        "priority_alignment_summary": priority_alignment_df.agg(F.count("*").alias("n_offers"), F.avg((F.col("priority_rank") == 1).cast("double")).alias("pct_top1"), F.avg((F.col("priority_rank") <= 3).cast("double")).alias("pct_top3"), F.avg((F.col("priority_rank") <= 5).cast("double")).alias("pct_top5")),
    }

def add_response_flags_if_needed(df: DataFrame, response_state_col: str = "response_state") -> DataFrame:
    cols = set(df.columns)
    out = df
    if {"activated", "actioned", "interested"}.issubset(cols):
        return out
    s = F.upper(F.col(response_state_col))
    if "activated" not in cols:
        out = out.withColumn("activated", F.when(s.isin("ACTIVATED", "ACTIONED", "INTERESTED", "NOT INTERESTED"), 1).otherwise(0))
    if "actioned" not in cols:
        out = out.withColumn("actioned", F.when(s.isin("ACTIONED", "INTERESTED", "NOT INTERESTED"), 1).otherwise(0))
    if "interested" not in cols:
        out = out.withColumn("interested", F.when(s == "INTERESTED", 1).otherwise(0))
    return out

def compute_response_hierarchy_report(measurement_df: DataFrame, customer_group_df: Optional[DataFrame] = None, customer_id_col: str = "customer_id", group_col_name: str = "top1_same", response_state_col: str = "response_state"):
    df = add_response_flags_if_needed(measurement_df, response_state_col=response_state_col)
    if customer_group_df is not None:
        df = df.join(customer_group_df, on=customer_id_col, how="left")
    out = {"measurement_enriched": df, "response_state_summary": df.groupBy(response_state_col).agg(F.count("*").alias("n"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(F.desc("n")), "funnel_summary": df.agg(F.count("*").alias("n_proposed"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate"))}
    if customer_group_df is not None:
        out["outcome_by_group"] = df.groupBy(group_col_name).agg(F.count("*").alias("n"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(group_col_name)
    return out

def assign_score_deciles(df: DataFrame, score_col: str, output_col: str, partition_cols=None) -> DataFrame:
    partition_cols = partition_cols or []
    w = Window.partitionBy(*partition_cols).orderBy(F.desc(F.col(score_col))) if partition_cols else Window.orderBy(F.desc(F.col(score_col)))
    return df.withColumn(output_col, F.ntile(10).over(w))

def compute_decile_diagnostics_report(df: DataFrame, prism_score_col: str, legacy_score_col: str, product_col: Optional[str] = None):
    out = df
    parts = [product_col] if product_col else []
    if "prism_decile" not in out.columns:
        out = assign_score_deciles(out, prism_score_col, "prism_decile", parts)
    if "legacy_decile" not in out.columns:
        out = assign_score_deciles(out, legacy_score_col, "legacy_decile", parts)
    return {"decile_ready_df": out, "prism_decile_distribution": out.groupBy("prism_decile").count().orderBy("prism_decile"), "legacy_decile_distribution": out.groupBy("legacy_decile").count().orderBy("legacy_decile")}

def compute_historical_month_report(monthly_df: DataFrame, month_col: str = "month", product_col: str = "product", customer_id_col: str = "customer_id", month_a_value: Optional[str] = None, month_b_value: Optional[str] = None):
    df = add_response_flags_if_needed(monthly_df, response_state_col="response_state") if "response_state" in monthly_df.columns else monthly_df
    out = {"month_product_rates": df.groupBy(month_col, product_col).agg(F.count("*").alias("n_offers"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(month_col, product_col)}
    if month_a_value and month_b_value:
        a = df.filter(F.col(month_col) == month_a_value)
        b = df.filter(F.col(month_col) == month_b_value)
        common = a.select(customer_id_col).distinct().intersect(b.select(customer_id_col).distinct())
        common_df = df.join(common, on=customer_id_col, how="inner")
        out["common_month_product_rates"] = common_df.groupBy(month_col, product_col).agg(F.count("*").alias("n_offers"), F.avg(F.col("activated").cast("double")).alias("activation_rate"), F.avg(F.col("actioned").cast("double")).alias("action_rate"), F.avg(F.col("interested").cast("double")).alias("interest_rate")).orderBy(month_col, product_col)
    return out

def prepare_product_score_comparison(prism_scores_df: DataFrame, legacy_scores_df: DataFrame, model_mapping_df: DataFrame, customer_subset_df: Optional[DataFrame] = None, customer_id_col: str = "customer_id", model_id_col: str = "model_id", score_col: str = "model_score", product_col: str = "product", legacy_model_id_col: str = "legacy_model_id", prism_model_id_col: str = "prism_model_id") -> DataFrame:
    prism_map = model_mapping_df.select(F.col(product_col), F.col(prism_model_id_col).alias(model_id_col))
    legacy_map = model_mapping_df.select(F.col(product_col), F.col(legacy_model_id_col).alias(model_id_col))
    prism_prepped = prism_scores_df.join(prism_map, on=model_id_col, how="inner").select(customer_id_col, product_col, F.col(score_col).cast("double").alias("prism_score"))
    legacy_prepped = legacy_scores_df.join(legacy_map, on=model_id_col, how="inner").select(customer_id_col, product_col, F.col(score_col).cast("double").alias("legacy_score"))
    if customer_subset_df is not None:
        ids = customer_subset_df.select(customer_id_col).distinct()
        prism_prepped = prism_prepped.join(ids, on=customer_id_col, how="inner")
        legacy_prepped = legacy_prepped.join(ids, on=customer_id_col, how="inner")
    return prism_prepped.join(legacy_prepped, on=[customer_id_col, product_col], how="full")

def compute_product_score_availability_summary(score_compare_df: DataFrame, customer_subset_df: DataFrame, customer_id_col: str = "customer_id", product_col: str = "product") -> DataFrame:
    total = customer_subset_df.select(customer_id_col).distinct().count()
    return score_compare_df.groupBy(product_col).agg(F.sum(F.when(F.col("prism_score").isNotNull() & F.col("legacy_score").isNull(), 1).otherwise(0)).alias("prism_only_n"), F.sum(F.when(F.col("prism_score").isNull() & F.col("legacy_score").isNotNull(), 1).otherwise(0)).alias("legacy_only_n"), F.sum(F.when(F.col("prism_score").isNotNull() & F.col("legacy_score").isNotNull(), 1).otherwise(0)).alias("both_n")).withColumn("none_n", F.lit(int(total)) - F.col("prism_only_n") - F.col("legacy_only_n") - F.col("both_n")).withColumn("prism_only_pct", F.col("prism_only_n") / F.lit(float(total))).withColumn("legacy_only_pct", F.col("legacy_only_n") / F.lit(float(total))).withColumn("both_pct", F.col("both_n") / F.lit(float(total))).withColumn("none_pct", F.col("none_n") / F.lit(float(total))).orderBy(product_col)

def compute_product_level_rank_correlation(score_compare_df: DataFrame, customer_id_col: str = "customer_id", product_col: str = "product"):
    both = score_compare_df.filter(F.col("prism_score").isNotNull() & F.col("legacy_score").isNotNull())
    w_p = Window.partitionBy(product_col).orderBy(F.desc("prism_score"))
    w_l = Window.partitionBy(product_col).orderBy(F.desc("legacy_score"))
    ranked = both.withColumn("prism_customer_rank", F.row_number().over(w_p)).withColumn("legacy_customer_rank", F.row_number().over(w_l)).withColumn("rank_gap", F.abs(F.col("prism_customer_rank") - F.col("legacy_customer_rank")))
    return {"ranked_customer_scores": ranked, "product_rank_summary": ranked.groupBy(product_col).agg(F.count("*").alias("n_both"), F.corr("prism_customer_rank", "legacy_customer_rank").alias("pearson_rank_corr"), F.avg("rank_gap").alias("avg_rank_gap"), F.expr("percentile_approx(rank_gap, 0.5)").alias("median_rank_gap")).orderBy(product_col)}

def compute_response_raw_decile_calibration(responders_df: DataFrame, score_compare_df: DataFrame, customer_id_col: str = "customer_id", product_col: str = "product"):
    joined = responders_df.select(customer_id_col, product_col).distinct().join(score_compare_df.select(customer_id_col, product_col, "prism_score", "legacy_score"), on=[customer_id_col, product_col], how="inner")
    prism_deciled = assign_score_deciles(joined, "prism_score", "prism_decile", [product_col])
    both_deciled = assign_score_deciles(prism_deciled, "legacy_score", "legacy_decile", [product_col])
    return {"responders_scored": both_deciled, "prism_responder_decile_dist": both_deciled.groupBy("prism_decile").count().orderBy("prism_decile"), "legacy_responder_decile_dist": both_deciled.groupBy("legacy_decile").count().orderBy("legacy_decile")}
