#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/starter_repo"
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
pytest -q
