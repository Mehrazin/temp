# Demo Metrics Template

Use this during the live demo or a dry run.

| Metric | Chat mode | Agent mode | Notes |
|---|---:|---:|---|
| Number of prompts |  |  | Count every submitted prompt. |
| Manual copy/paste actions |  |  | Include files, generated code, and error tracebacks. |
| Manual file edits |  |  | Include replacing file contents and fixing formatting/imports. |
| Test runs |  |  | Count `pytest -q` runs. |
| Tracebacks manually copied |  |  | Usually higher in Chat mode. |
| Time to green tests |  |  | Use stopwatch. |
| Final diff review | Yes | Yes | This should remain the same. |

## Notes

Do not present estimated times as measured results. If the demo is not timed in advance, present the measured handoff count instead.
