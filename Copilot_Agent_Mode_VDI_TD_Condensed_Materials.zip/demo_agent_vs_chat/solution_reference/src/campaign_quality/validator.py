from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd


REQUIRED_COLUMNS = ["customer_id", "product", "propensity", "rank"]


@dataclass
class ValidationReport:
    """Simple validation report used by model-validation checks."""

    passed: bool
    errors: list[str] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)

    def raise_if_failed(self) -> None:
        if not self.passed:
            raise ValueError("; ".join(self.errors))


def _is_positive_integer_series(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    return numeric.notna() & (numeric % 1 == 0) & (numeric >= 1)


def validate_scoring_output(df: pd.DataFrame, top_k: int = 3) -> ValidationReport:
    """Validate a campaign scoring output dataframe.

    Expected columns:
    - customer_id: customer identifier
    - product: product / campaign name
    - propensity: calibrated propensity score in [0, 1]
    - rank: 1-based product rank per customer
    """
    errors: list[str] = []

    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a pandas DataFrame")

    if not isinstance(top_k, int) or top_k < 1:
        raise ValueError("top_k must be a positive integer")

    missing = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing:
        return ValidationReport(
            passed=False,
            errors=[f"Missing required columns: {missing}"],
            summary={"rows": len(df), "top_k": top_k},
        )

    if df["customer_id"].isna().any():
        errors.append("Null customer_id values are not allowed")

    if df["product"].isna().any():
        errors.append("Null product values are not allowed")

    if df["propensity"].isna().any():
        errors.append("Null propensity values are not allowed")

    propensity_numeric = pd.to_numeric(df["propensity"], errors="coerce")
    if propensity_numeric.isna().any() or (~propensity_numeric.between(0, 1)).any():
        errors.append("Propensity values must be numeric and outside [0, 1] values are not allowed")

    valid_rank = _is_positive_integer_series(df["rank"])
    if not valid_rank.all():
        errors.append("rank must be a positive integer")

    if valid_rank.all() and (pd.to_numeric(df["rank"]) > top_k).any():
        errors.append("rank cannot be greater than top_k")

    duplicate_customer_product = df.duplicated(subset=["customer_id", "product"], keep=False)
    if duplicate_customer_product.any():
        errors.append("Duplicate customer/product rows are not allowed")

    duplicate_rank = df.duplicated(subset=["customer_id", "rank"], keep=False)
    if duplicate_rank.any():
        errors.append("Duplicate rank values within a customer are not allowed")

    return ValidationReport(
        passed=not errors,
        errors=errors,
        summary={
            "rows": len(df),
            "customers": int(df["customer_id"].nunique(dropna=True)),
            "products": int(df["product"].nunique(dropna=True)),
            "top_k": top_k,
        },
    )
