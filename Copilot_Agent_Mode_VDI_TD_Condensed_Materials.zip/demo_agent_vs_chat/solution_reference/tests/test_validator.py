import pandas as pd
import pytest

from campaign_quality.validator import validate_scoring_output


def valid_df():
    return pd.DataFrame(
        {
            "customer_id": [101, 101, 101, 202, 202, 202],
            "product": ["Visa", "Loan", "Savings", "Visa", "Loan", "Savings"],
            "propensity": [0.81, 0.42, 0.12, 0.71, 0.38, 0.20],
            "rank": [1, 2, 3, 1, 2, 3],
        }
    )


def test_valid_output_passes():
    report = validate_scoring_output(valid_df(), top_k=3)
    assert report.passed
    assert report.errors == []
    assert report.summary["rows"] == 6
    assert report.summary["customers"] == 2
    assert report.summary["products"] == 3


def test_missing_required_column_fails():
    df = valid_df().drop(columns=["propensity"])
    report = validate_scoring_output(df)
    assert not report.passed
    assert any("Missing required columns" in error for error in report.errors)


def test_null_propensity_fails():
    df = valid_df()
    df.loc[0, "propensity"] = None
    report = validate_scoring_output(df)
    assert not report.passed
    assert any("Null propensity" in error for error in report.errors)


def test_propensity_out_of_range_fails():
    df = valid_df()
    df.loc[0, "propensity"] = 1.2
    report = validate_scoring_output(df)
    assert not report.passed
    assert any("outside [0, 1]" in error for error in report.errors)


@pytest.mark.parametrize("bad_rank", [0, -1, 1.5, None])
def test_rank_must_be_positive_integer(bad_rank):
    df = valid_df()
    df.loc[0, "rank"] = bad_rank
    report = validate_scoring_output(df)
    assert not report.passed
    assert any("rank" in error.lower() for error in report.errors)


def test_duplicate_customer_product_rows_fail():
    df = pd.concat([valid_df(), valid_df().iloc[[0]]], ignore_index=True)
    report = validate_scoring_output(df)
    assert not report.passed
    assert any("Duplicate customer/product" in error for error in report.errors)


def test_duplicate_rank_within_customer_fails():
    df = valid_df()
    df.loc[1, "rank"] = 1
    report = validate_scoring_output(df)
    assert not report.passed
    assert any("Duplicate rank" in error for error in report.errors)


def test_rank_greater_than_top_k_fails():
    df = valid_df()
    df.loc[2, "rank"] = 4
    report = validate_scoring_output(df, top_k=3)
    assert not report.passed
    assert any("top_k" in error for error in report.errors)


def test_raise_if_failed_raises_value_error():
    df = valid_df().drop(columns=["product"])
    report = validate_scoring_output(df)
    with pytest.raises(ValueError):
        report.raise_if_failed()
