# Reference Solution

This folder contains one possible solution for the demo. Keep this hidden during the live demo and use it only if you need a fallback.

Run:

```bash
pip install -r requirements.txt
pip install -e .
pytest -q
```
