# Demo Runbook — Copilot Chat vs Agent Mode

Use `starter_repo`. It is sanitized and contains no bank data or credentials.

## Goal

Show that Agent mode reduces the manual loop for building validation logic and unit tests.

## Setup

```bash
cd starter_repo
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
pip install -e .
pytest -q
```

The first test run should fail.

## Agent mode prompt

```text
You are working in a sanitized Python analytics package. Implement robust validation for campaign scoring output.

Requirements:
1. Read the existing tests and source files.
2. Update src/campaign_quality/validator.py so all tests pass.
3. Validate required columns, duplicate customer/product rows, null propensities, propensity range [0,1], positive integer rank, and top-k uniqueness per customer.
4. Preserve the public API: validate_scoring_output(df, top_k=3) -> ValidationReport.
5. Run pytest -q, inspect failures, and iterate until tests pass.
6. Keep the implementation simple, readable, and suitable for model validation review.
```

## Chat mode prompt

```text
I have a Python function validate_scoring_output(df, top_k=3) that needs to pass unit tests. I will paste the current source file and tests. Please return the full corrected validator.py only.
```

Then paste both files manually:

- `src/campaign_quality/validator.py`
- `tests/test_validator.py`

Run `pytest -q`, copy any traceback back into Chat, and repeat.

## Metrics to capture

| Metric | Chat mode | Agent mode |
|---|---:|---:|
| Number of prompts |  |  |
| Manual copy/paste actions |  |  |
| Test runs |  |  |
| Tracebacks copied manually |  |  |
| Time to green tests |  |  |
| Final diff review required | Yes | Yes |
