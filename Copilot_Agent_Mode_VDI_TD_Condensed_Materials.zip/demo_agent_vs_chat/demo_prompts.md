# Demo Prompts: Chat Mode vs Agent Mode

## Demo setup

Use `starter_repo`. It is sanitized and contains no bank data or credentials.

Recommended command before each run:

```bash
cd starter_repo
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
pip install -e .
pytest -q
```

The first run should fail because `validate_scoring_output` is intentionally incomplete.

---

## Agent mode prompt

Paste this into VS Code Copilot Agent mode:

```text
You are working in a sanitized Python analytics package. Implement robust validation for campaign scoring output.

Requirements:
1. Read the existing tests and source files.
2. Update src/campaign_quality/validator.py so all tests pass.
3. Validate required columns, duplicate customer IDs, null propensities, propensity range [0,1], positive integer rank, and top-k rank uniqueness per customer.
4. Preserve the public API: validate_scoring_output(df, top_k=3) -> ValidationReport.
5. Run pytest -q, inspect failures, and iterate until tests pass.
6. Keep the implementation simple, readable, and suitable for model validation review.
```

### What to highlight while Agent mode runs

- It reads the project context without manual file copying.
- It edits the relevant file directly.
- It can run `pytest -q` after you approve terminal use.
- It can inspect failures and continue iterating.
- The developer still reviews the diff before accepting/committing.

---

## Chat mode prompt sequence

### Prompt 1

```text
I have a Python function validate_scoring_output(df, top_k=3) that needs to pass unit tests. I will paste the current source file and tests. Please return the full corrected validator.py only.
```

Then manually paste:

1. `src/campaign_quality/validator.py`
2. `tests/test_validator.py`

### Manual work after Prompt 1

1. Copy Chat output.
2. Paste it into `src/campaign_quality/validator.py`.
3. Save the file.
4. Run `pytest -q`.
5. If tests fail, copy the traceback.
6. Paste the traceback back into Chat.

### Prompt 2, if tests fail

```text
The updated code still fails. Here is the pytest traceback. Please diagnose the issue and return the full corrected validator.py only.

[PASTE TRACEBACK HERE]
```

Repeat until tests pass.

---

## Measurement template

| Metric | Chat mode | Agent mode |
|---|---:|---:|
| Number of prompts |  |  |
| Manual file copy/paste actions |  |  |
| Manual edits applied by developer |  |  |
| Test runs |  |  |
| Tracebacks manually copied |  |  |
| Time to green tests |  |  |
| Final developer review required? | Yes | Yes |

## Recommended conclusion

Agent mode does not remove developer accountability. It removes the repetitive mechanics around context collection, file edits, test execution, and failure feedback.
