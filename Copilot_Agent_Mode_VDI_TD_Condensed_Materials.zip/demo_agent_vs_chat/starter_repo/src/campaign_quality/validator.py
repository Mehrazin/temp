from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd


REQUIRED_COLUMNS = ["customer_id", "product", "propensity", "rank"]


@dataclass
class ValidationReport:
    """Simple validation report used by model-validation checks."""

    passed: bool
    errors: list[str] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)

    def raise_if_failed(self) -> None:
        if not self.passed:
            raise ValueError("; ".join(self.errors))


def validate_scoring_output(df: pd.DataFrame, top_k: int = 3) -> ValidationReport:
    """Validate a campaign scoring output dataframe.

    Expected columns:
    - customer_id: customer identifier
    - product: product / campaign name
    - propensity: calibrated propensity score in [0, 1]
    - rank: 1-based product rank per customer

    TODO: implement robust validation.
    """
    errors: list[str] = []

    # This intentionally incomplete implementation is used for the demo.
    missing = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing:
        errors.append(f"Missing required columns: {missing}")

    return ValidationReport(
        passed=not errors,
        errors=errors,
        summary={"rows": len(df), "top_k": top_k},
    )
