# Copilot Chat vs Agent Mode Demo: Campaign Scoring Validation

This is a sanitized demo repo designed to show the difference between GitHub Copilot Chat mode and Agent mode inside VS Code.

## Demo story

Model validation requires repeatable unit tests for campaign/model scoring utilities. The starter code is intentionally incomplete. The demo task is to implement production-style validation and make the tests pass.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
pip install -e .
pytest -q
```

The first test run should fail. That is expected.

## Agent mode demo prompt

Open the starter repo in VS Code Agent mode and paste:

```text
You are working in a sanitized Python analytics package. Implement robust validation for campaign scoring output.

Requirements:
1. Read the existing tests and source files.
2. Update src/campaign_quality/validator.py so all tests pass.
3. Validate required columns, duplicate customer IDs, null propensities, propensity range [0,1], positive integer rank, and top-k rank uniqueness per customer.
4. Preserve the public API: validate_scoring_output(df, top_k=3) -> ValidationReport.
5. Run pytest -q, inspect failures, and iterate until tests pass.
6. Keep the implementation simple, readable, and suitable for model validation review.
```

## Chat mode demo prompt

Use Chat mode only. Manually attach/copy the files below, ask for changes, paste the generated code back into the repo, run tests, then copy errors back into chat.

```text
I have a Python function validate_scoring_output(df, top_k=3) that needs to pass unit tests. I will paste the current source file and tests. Please return the full corrected validator.py only.
```

Then paste:
- `src/campaign_quality/validator.py`
- `tests/test_validator.py`

Run:

```bash
pytest -q
```

If there are failures, copy the traceback back into Chat mode and repeat.
