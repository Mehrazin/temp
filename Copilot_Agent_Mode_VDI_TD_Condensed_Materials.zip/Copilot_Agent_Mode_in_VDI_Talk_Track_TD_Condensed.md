# Copilot Agent Mode in VDI — Condensed Talk Track

## Slide 1 — Make Copilot Useful Where We Actually Build

**Core message:** This is a workflow enablement request, not a data-access request.

**Suggested talk track:**
“Today, inside VDI, VS Code only gives us Copilot Chat. That means we can ask for help, but we still manually move context between files, Chat, test output, and Databricks/ADB. Agent mode does not change where data lives or who has access to it. It helps automate the local development loop inside the existing workspace. The expected benefit is faster unit-test and package iteration, fewer copy/paste mistakes, and fewer context handoffs.”

**Transition:**
“The next slide shows the specific loop that changes.”

---

## Slide 2 — Chat vs Agent: Same Boundary, Different Loop

**Core message:** Chat mode makes the developer manually act as the agent. Agent mode performs the mechanical loop inside the same boundary.

**Suggested talk track:**
“With Chat only, we ask questions and get suggested code, but we manually attach files, paste code into source files, run tests, copy errors back, and repeat. This creates delay and introduces manual copy/paste mistakes. With Agent mode, Copilot can read the open workspace, edit files, run approved commands such as `pytest`, inspect failures, and iterate. The developer still reviews the diff. The VDI boundary, Databricks access, Git branch process, and PR review remain the same.”

**Risk wording to use:**
“The incremental change is workflow automation. It is not new Databricks access, not new production write access, and not a bypass of PR review.”

**Transition:**
“We will demonstrate this using a unit-test task that is common in model development and validation.”

---

## Slide 3 — Demo: Unit-Test Creation for Model Validation

**Core message:** The demo is small enough to run live, but realistic enough to matter.

**Suggested talk track:**
“We chose unit tests because this is a practical pain point. For model development, we often need validation utilities and tests for review or model validation. The demo repo is sanitized and has no bank data. The starter implementation is intentionally incomplete. The task is to make the validation function and unit tests pass. In Chat mode, we need to paste the source and test files into Chat, copy the output back, run `pytest` ourselves, and paste errors back. In Agent mode, Copilot can inspect the repo, edit the source, run `pytest` after approval, and iterate.”

**What to measure during the demo:**
- Number of prompts
- Manual copy/paste actions
- Number of test runs
- Tracebacks copied back manually
- Time to green tests
- Final diff review quality

**Transition:**
“After the demo, the decision is whether we can pilot this safely in VDI.”

---

## Slide 4 — Pilot Ask and Guardrails

**Core message:** Ask for a controlled pilot with measurable outcomes and explicit guardrails.

**Suggested talk track:**
“The ask is not broad enablement for everyone. We are proposing a 30-day pilot for selected users and approved workspaces. The controls should be straightforward: visible diffs, approved terminal commands, no production writes without review, no credential or policy bypass, and normal Git branch/PR process. The pilot should measure time to green tests, manual handoffs, test iterations, and whether any data-boundary exceptions occur. At the end, we can decide to expand, adjust, or stop.”

**Close:**
“Agent mode lets us spend more time reviewing and validating code, and less time manually copying context between tools.”

---

# Live Demo Runbook

## Demo goal

Show that Agent mode reduces the mechanical loop required to build and test a small validation utility. The task is intentionally safe: sanitized repo, no data, no credentials, no Databricks connection.

## Setup

Use the folder:

```bash
demo_agent_vs_chat/starter_repo
```

Recommended setup:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
pip install -e .
pytest -q
```

The first test run should fail because `validate_scoring_output` is intentionally incomplete.

## Agent mode demo prompt

Paste into VS Code Copilot Agent mode:

```text
You are working in a sanitized Python analytics package. Implement robust validation for campaign scoring output.

Requirements:
1. Read the existing tests and source files.
2. Update src/campaign_quality/validator.py so all tests pass.
3. Validate required columns, duplicate customer/product rows, null propensities, propensity range [0,1], positive integer rank, and top-k uniqueness per customer.
4. Preserve the public API: validate_scoring_output(df, top_k=3) -> ValidationReport.
5. Run pytest -q, inspect failures, and iterate until tests pass.
6. Keep the implementation simple, readable, and suitable for model validation review.
```

What to say while it runs:
“Notice that I did not paste files into the prompt. Agent mode can inspect the repo, edit the right file, request approval to run tests, read the failure output, and continue. I still review the diff before accepting anything.”

## Chat mode demo prompt

Use Chat mode only. Manually paste the source and test files.

```text
I have a Python function validate_scoring_output(df, top_k=3) that needs to pass unit tests. I will paste the current source file and tests. Please return the full corrected validator.py only.
```

Then paste:

1. `src/campaign_quality/validator.py`
2. `tests/test_validator.py`

After Chat responds:

1. Copy the generated code.
2. Paste it into `validator.py`.
3. Run `pytest -q`.
4. If tests fail, copy the traceback.
5. Paste the traceback back into Chat.
6. Repeat until tests pass.

## Recommended demo conclusion

“The final review standard is the same in both modes. The difference is that Chat mode requires us to manually transfer context, code, and errors. Agent mode keeps the loop inside the workspace.”

---

# Appendix Talk Track

## Appendix A1 — Detailed Demo Script

Use only if the AVP asks for the mechanics before the demo. The point is to show the same task, same repo, same tests, and same final review standard.

## Appendix A2 — Demo Prompts

Use as a copy/paste backup during the live demo.

## Appendix A3 — Risk / Control Mapping and References

Key wording:
“Agent mode can perform more local actions than Chat mode, so it should be governed. But those actions remain inside existing workspace, VDI, Git, and Databricks controls. The pilot should measure the operational benefit while confirming no change to the data-access boundary.”
